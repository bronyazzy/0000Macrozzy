'use strict';
// Electron main process: window, app:// protocol (UI + book + dictionary resources), IPC.
const { app, BrowserWindow, protocol, ipcMain, dialog, shell, clipboard, nativeImage, Menu, screen, safeStorage, net } = require('electron');
const path = require('path');
const fs = require('fs');
const { Service, API_METHODS } = require('./backend/service');

protocol.registerSchemesAsPrivileged([
  { scheme: 'app', privileges: { standard: true, secure: true, supportFetchAPI: true, corsEnabled: true, stream: true } },
]);

const BOOK_RE = /\.(epub|pdf|html?|xhtml?|xht|shtml)$/i;
let win = null;
let imageWin = null; // the picture window (看图), opened by the page with window.open
let service = null;
let pendingFile = null;
let closeReady = false;
let closeTimer = null;
let boundsTimer = null;

function fileArg(argv) {
  for (const a of (argv || []).slice(1)) {
    if (!a || a.startsWith('-')) continue;
    try {
      if (BOOK_RE.test(a) && fs.existsSync(a)) return path.resolve(a);
    } catch { /* ignore */ }
  }
  return null;
}

if (!app.requestSingleInstanceLock()) {
  app.quit();
} else {
  app.on('second-instance', (_e, argv) => {
    const f = fileArg(argv);
    if (!win) return;
    if (win.isMinimized()) win.restore();
    win.focus();
    if (f) win.webContents.send('open-file', f);
  });
  app.whenReady().then(init);
}

function init() {
  if (process.platform === 'win32') app.setAppUserModelId('BilingualReader');
  Menu.setApplicationMenu(null);
  const userData = path.join(app.getPath('userData'), 'data');
  service = new Service({ userDataDir: userData, appDir: __dirname });
  service.userDataDir = userData;
  service.emit = (channel, payload) => { if (win && !win.isDestroyed()) win.webContents.send(channel, payload); };
  // AI services: API keys are encrypted with Windows DPAPI (safeStorage); requests use Chromium's network stack
  // (net.fetch), so the system proxy settings apply.
  service.ai.setSecrets({
    kind: 'dpapi',
    encrypt: (s) => (safeStorage && safeStorage.isEncryptionAvailable()
      ? 'dpapi:' + safeStorage.encryptString(String(s)).toString('base64')
      : 'plain:' + Buffer.from(String(s), 'utf8').toString('base64')),
    decrypt: (v) => {
      const str = String(v || '');
      if (str.startsWith('dpapi:')) return safeStorage.decryptString(Buffer.from(str.slice(6), 'base64'));
      if (str.startsWith('plain:')) return Buffer.from(str.slice(6), 'base64').toString('utf8');
      return '';
    },
  });
  if (net && typeof net.fetch === 'function') service.ai.setFetch((url, init) => net.fetch(url, init));
  try { if (service.ai.importKeyFile()) console.log('已导入 AI 服务的 API Key'); } catch (e) { console.error(e); }

  protocol.handle('app', async (request) => {
    try {
      const url = new URL(request.url);
      if (url.host !== 'ui') return new Response('not found', { status: 404 });
      const r = service.handle(url.pathname, url.search);
      return new Response(r.body, { status: r.status, headers: r.headers });
    } catch (e) {
      return new Response(String(e && e.message || e), { status: 500 });
    }
  });

  const electronApi = {
    getPending: () => { const f = pendingFile; pendingFile = null; return f; },
    pickBook: async () => {
      const r = await dialog.showOpenDialog(win, {
        title: '打开书籍',
        properties: ['openFile'],
        filters: [{ name: '书籍（EPUB、PDF、HTML）', extensions: ['epub', 'pdf', 'html', 'htm', 'xhtml', 'xht'] }, { name: '所有文件', extensions: ['*'] }],
      });
      return r.canceled ? [] : r.filePaths;
    },
    pickDicts: async (kind) => {
      const filters = kind === 'csv'
        ? [{ name: 'CSV / TSV 词库', extensions: ['csv', 'tsv', 'txt'] }]
        : [{ name: 'MDict 词典', extensions: ['mdx'] }];
      const r = await dialog.showOpenDialog(win, { title: kind === 'csv' ? '导入 CSV 词库' : '导入 MDX 词典', properties: ['openFile', 'multiSelections'], filters });
      return r.canceled ? [] : r.filePaths;
    },
    pickSave: async (name, filters, opts) => {
      const owner = opts && opts.imageWindow && imageWin && !imageWin.isDestroyed() ? imageWin : win;
      const r = await dialog.showSaveDialog(owner, { defaultPath: path.join(app.getPath('documents'), name || '导出.txt'), filters: filters || [] });
      return r.canceled ? null : r.filePath;
    },
    // the picture window: show it again (without taking the keyboard from the book), keep it in front of
    // the reading window (置顶), or bring the reading window forward (AI answers appear there)
    imageWindow: (action, arg) => {
      const st = service.store.get('image-window', {});
      if (action === 'state') return { open: !!(imageWin && !imageWin.isDestroyed()), pinned: imagePinned(st) };
      if (action === 'focusMain') {
        if (win) { if (win.isMinimized()) win.restore(); win.focus(); }
        return true;
      }
      if (action === 'pin') {
        const on = !!arg;
        service.store.set('image-window', { ...st, pinned: on });
        if (imageWin && !imageWin.isDestroyed()) pinImageWindow(imageWin, on);
        return on;
      }
      if (!imageWin || imageWin.isDestroyed()) return false;
      if (action === 'show') {
        if (imageWin.isMinimized()) imageWin.restore();
        imageWin.showInactive();
        imageWin.moveTop();
        return true;
      }
      return false;
    },
    clipboardWrite: (o) => {
      const text = String((o && o.text) || '');
      if (o && o.html) clipboard.write({ text, html: String(o.html) }); else clipboard.writeText(text);
      return true;
    },
    // image viewer: copy an image (PNG data URL) / write it to a file chosen in the save dialog
    clipboardImage: (dataUrl) => {
      const img = nativeImage.createFromDataURL(String(dataUrl || ''));
      if (img.isEmpty()) throw new Error('图片数据无效');
      clipboard.writeImage(img);
      return true;
    },
    saveImage: (file, dataUrl) => {
      const m = /^data:image\/[\w.+-]+;base64,([A-Za-z0-9+/=\s]+)$/.exec(String(dataUrl || ''));
      if (!m || !file || !/\.(png|jpe?g|gif|webp|svg|bmp)$/i.test(String(file))) throw new Error('无法保存这张图片');
      fs.writeFileSync(String(file), Buffer.from(m[1], 'base64'));
      return true;
    },
    openExternal: (url) => { if (/^(https?|mailto):/i.test(String(url))) shell.openExternal(String(url)); return true; },
    showInFolder: (p) => { if (p && fs.existsSync(p)) shell.showItemInFolder(p); return true; },
    win: (action) => {
      if (!win) return null;
      if (action === 'minimize') win.minimize();
      else if (action === 'maximize') { if (win.isMaximized()) win.unmaximize(); else win.maximize(); }
      else if (action === 'close') win.close();
      else if (action === 'fullscreen') win.setFullScreen(!win.isFullScreen());
      else if (action === 'devtools') win.webContents.toggleDevTools();
      return windowState();
    },
    closeReady: () => {
      closeReady = true;
      clearTimeout(closeTimer);
      if (win) setImmediate(() => win && win.close());
      return true;
    },
  };

  ipcMain.handle('api', async (event, method, args) => {
    if (!win || event.sender !== win.webContents) throw new Error('forbidden');
    const a = Array.isArray(args) ? args : [];
    if (method === 'getState') return { ...service.getState(), userDataDir: userData };
    if (API_METHODS.includes(method)) return service[method](...a);
    if (Object.prototype.hasOwnProperty.call(electronApi, method)) return electronApi[method](...a);
    throw new Error('未知的调用：' + method);
  });

  pendingFile = fileArg(process.argv);
  createWindow();
}

function windowState() {
  return win ? { maximized: win.isMaximized(), fullscreen: win.isFullScreen() } : null;
}

function sendState() {
  if (win) win.webContents.send('window-state', windowState());
}

function visibleBounds(b) {
  if (!b || !b.width || !b.height) return null;
  const area = screen.getDisplayMatching(b).workArea;
  const ix = Math.max(0, Math.min(b.x + b.width, area.x + area.width) - Math.max(b.x, area.x));
  const iy = Math.max(0, Math.min(b.y + b.height, area.y + area.height) - Math.max(b.y, area.y));
  if (ix < 120 || iy < 80) return null;
  return { x: b.x, y: b.y, width: Math.min(b.width, area.width), height: Math.min(b.height, area.height) };
}

// 置顶 (default): the picture window belongs to the reading window, so it stays in front of it (not in
// front of other programs) and hides with it; off: an ordinary window of its own
function imagePinned(st) { return !st || st.pinned !== false; }
function pinImageWindow(w, on) {
  try {
    w.setParentWindow(on && win && !win.isDestroyed() ? win : null);
    // an owned window has no taskbar button to come back from
    w.setMinimizable(!on);
  } catch { /* ignore */ }
}

// first picture window: on a second screen if there is one (filling it), else in the lower right corner of
// this screen, like a picture-in-picture
function defaultImageBounds() {
  const main = win ? win.getBounds() : { x: 0, y: 0, width: 1280, height: 800 };
  const here = screen.getDisplayMatching(main);
  const other = (screen.getAllDisplays ? screen.getAllDisplays() : []).find((d) => d.id !== here.id);
  if (other) {
    const a = other.workArea;
    return { x: a.x + Math.round(a.width * 0.05), y: a.y + Math.round(a.height * 0.05), width: Math.round(a.width * 0.9), height: Math.round(a.height * 0.9) };
  }
  const a = here.workArea;
  const width = Math.round(Math.min(1000, Math.max(600, a.width * 0.4)));
  const height = Math.round(Math.min(900, Math.max(380, a.height * 0.6)));
  return { x: a.x + a.width - width - 16, y: a.y + a.height - height - 16, width, height };
}

function saveBounds() {
  if (!win || win.isDestroyed()) return;
  const b = win.getNormalBounds();
  service.store.set('window', { ...b, maximized: win.isMaximized() });
}

function createWindow() {
  const saved = service.store.get('window', {});
  const b = visibleBounds(saved);
  win = new BrowserWindow({
    width: b ? b.width : 1380,
    height: b ? b.height : 880,
    x: b ? b.x : undefined,
    y: b ? b.y : undefined,
    minWidth: 760,
    minHeight: 480,
    frame: false,
    show: false,
    backgroundColor: '#f3f4f6',
    title: '双语阅读器',
    icon: path.join(__dirname, 'assets', process.platform === 'win32' ? 'icon.ico' : 'icon.png'),
    webPreferences: {
      preload: path.join(__dirname, 'preload.js'),
      contextIsolation: true,
      nodeIntegration: false,
      sandbox: false,
      spellcheck: false,
      webviewTag: false,
    },
  });
  if (saved && saved.maximized) win.maximize();
  win.loadURL('app://ui/index.html');
  win.once('ready-to-show', () => win.show());
  win.webContents.on('did-finish-load', sendState);
  for (const ev of ['maximize', 'unmaximize', 'enter-full-screen', 'leave-full-screen']) win.on(ev, sendState);
  for (const ev of ['resize', 'move']) win.on(ev, () => { clearTimeout(boundsTimer); boundsTimer = setTimeout(saveBounds, 600); });

  win.on('close', (e) => {
    saveBounds();
    if (closeReady) return;
    e.preventDefault();
    win.webContents.send('before-close');
    clearTimeout(closeTimer);
    closeTimer = setTimeout(() => { closeReady = true; if (win) win.close(); }, 1500);
  });
  win.on('closed', () => {
    win = null;
    if (service) service.ai.cancelAll();
    if (imageWin && !imageWin.isDestroyed()) imageWin.destroy();
  });

  // window.open: only the picture window (an empty page the reader fills in); web links go to the browser
  win.webContents.setWindowOpenHandler(({ url, frameName }) => {
    if (frameName === 'br-image-viewer' && (!url || url === 'about:blank')) {
      const st = service.store.get('image-window', {});
      const b = visibleBounds(st) || defaultImageBounds();
      return {
        action: 'allow',
        overrideBrowserWindowOptions: {
          x: b.x, y: b.y, width: b.width, height: b.height,
          minWidth: 600,
          minHeight: 360,
          title: '看图',
          icon: path.join(__dirname, 'assets', process.platform === 'win32' ? 'icon.ico' : 'icon.png'),
          backgroundColor: '#0e0f12',
          autoHideMenuBar: true,
          // the viewer's toolbar is the title bar; the system buttons are drawn over its right end
          titleBarStyle: 'hidden',
          titleBarOverlay: { color: '#1a1b1f', symbolColor: '#e6e6e6', height: 42 },
        },
      };
    }
    if (/^https?:/i.test(url)) shell.openExternal(url);
    return { action: 'deny' };
  });
  win.webContents.on('did-create-window', (child, details) => {
    if (!details || details.frameName !== 'br-image-viewer') return;
    imageWin = child;
    child.setMenu(null);
    const st = service.store.get('image-window', {});
    pinImageWindow(child, imagePinned(st));
    if (st.maximized) child.maximize();
    child.webContents.setWindowOpenHandler(() => ({ action: 'deny' }));
    child.webContents.on('will-navigate', (e) => e.preventDefault());
    let t = null;
    const save = () => {
      if (child.isDestroyed()) return;
      service.store.set('image-window', { ...service.store.get('image-window', {}), ...child.getNormalBounds(), maximized: child.isMaximized() });
    };
    for (const ev of ['resize', 'move', 'maximize', 'unmaximize']) child.on(ev, () => { clearTimeout(t); t = setTimeout(save, 500); });
    child.on('close', save);
    child.on('closed', () => { clearTimeout(t); if (imageWin === child) imageWin = null; });
  });
  win.webContents.on('will-navigate', (e, url) => {
    if (!String(url).startsWith('app://ui/')) e.preventDefault();
  });
  win.webContents.on('will-frame-navigate', (e) => {
    const url = String(e.url || '');
    if (!url.startsWith('app://ui/') && url !== 'about:blank' && !url.startsWith('about:srcdoc')) e.preventDefault();
  });
  win.webContents.on('before-input-event', (e, input) => {
    if (input.type !== 'keyDown') return;
    const k = input.key;
    if (['F6', 'F7', 'F8', 'F9', 'F11', 'F12'].includes(k) && !input.control && !input.alt && !input.meta) {
      e.preventDefault();
      if (k === 'F11') { win.setFullScreen(!win.isFullScreen()); return; }
      if (k === 'F12') { win.webContents.toggleDevTools(); return; }
      win.webContents.send('shortcut', k);
      return;
    }
    if (input.alt && !input.control && (k === 'ArrowUp' || k === 'ArrowLeft')) {
      e.preventDefault();
      win.webContents.send('shortcut', 'back');
    }
  });
  win.on('app-command', (_e, cmd) => {
    if (cmd === 'browser-backward') win.webContents.send('shortcut', 'back');
  });
}

app.on('before-quit', () => { if (service) service.flush(); });
app.on('window-all-closed', () => {
  if (service) service.shutdown();
  app.quit();
});
