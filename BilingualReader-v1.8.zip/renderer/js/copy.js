// Copy-by-language: selection restriction while dragging, and serialization of a selection
// (or of whole groups) to plain text + HTML, keeping only English, only Chinese, or both.

function elOf(node) {
  return node && (node.nodeType === 1 ? node : node.parentElement);
}

// Language of the content under a node: 'en' | 'zh' | null (neutral / shared).
export function langAt(node) {
  const e = elOf(node);
  if (!e || !e.closest) return null;
  const cell = e.closest('.br-cell');
  if (cell) return cell.classList.contains('br-en') ? 'en' : 'zh';
  const l = e.closest('[data-lang]');
  if (l && (l.dataset.lang === 'en' || l.dataset.lang === 'zh')) return l.dataset.lang;
  return null;
}

function normalizeText(t) {
  return String(t)
    .replace(/ /g, ' ')
    .replace(/[­​‌‍﻿]/g, '')
    .replace(/[ \t]+\n/g, '\n')
    .replace(/\n[ \t]+(?=\S)/g, '\n')
    .replace(/\n{3,}/g, '\n\n')
    .trim();
}

const KEEP_ATTR = new Set(['colspan', 'rowspan', 'lang', 'dir']);

function cleanHtml(box) {
  const c = box.cloneNode(true);
  for (const e of c.querySelectorAll('img,svg,video,audio,canvas,picture,iframe,object')) e.remove();
  const all = c.getElementsByTagName('*');
  for (let i = 0; i < all.length; i++) {
    for (const a of [...all[i].attributes]) if (!KEEP_ATTR.has(a.name)) all[i].removeAttribute(a.name);
  }
  // unwrap our layout wrappers
  return c.innerHTML.replace(/<div>\s*<\/div>/g, '');
}

function makeBox(doc) {
  const box = doc.createElement('div');
  box.className = 'br-copybox';
  const w = doc.querySelector('.br-cell') ? Math.max(320, doc.querySelector('.br-cell').getBoundingClientRect().width) : Math.min(900, doc.documentElement.clientWidth);
  box.style.width = w + 'px';
  return box;
}

function finish(doc, box, lang, textOnly = false) {
  for (const e of box.querySelectorAll('.br-ui, script, style, link, .br-copy-skip')) e.remove();
  if (lang === 'en' || lang === 'zh') {
    const other = lang === 'en' ? 'zh' : 'en';
    for (const e of box.querySelectorAll(`.br-cell.br-${other}, [data-lang="${other}"]`)) e.remove();
  }
  for (const q of box.querySelectorAll('q')) {
    const zh = langAt(q) === 'zh' || /[一-鿿]/.test(q.textContent || '');
    q.prepend(zh ? '“' : '“');
    q.append(zh ? '”' : '”');
  }
  doc.body.append(box);
  const text = textOnly ? box.innerText : normalizeText(box.innerText);
  const html = textOnly ? '' : cleanHtml(box);
  box.remove();
  return { text, html };
}

// Plain text of many element lists at once (e.g. every group of a chapter): one offscreen layout for
// all of them instead of one per list, which matters for long chapters. Returns one text per list.
const MARK = '\u2063\u2060\u2063';
export function serializeTexts(lists, lang) {
  const first = lists.find((els) => els && els.length);
  if (!first) return lists.map(() => '');
  const doc = first[0].ownerDocument;
  const box = makeBox(doc);
  lists.forEach((els, i) => {
    const m = doc.createElement('div');
    m.textContent = MARK + i + MARK;
    box.append(m);
    for (const e of els || []) {
      const c = e.cloneNode(true);
      if (c.removeAttribute) c.removeAttribute('id');
      box.append(c);
    }
  });
  const { text } = finish(doc, box, lang, true);
  const out = lists.map(() => '');
  const re = new RegExp(MARK + '(\\d+)' + MARK, 'g');
  let at = -1;
  let from = 0;
  let m;
  while ((m = re.exec(text))) {
    if (at >= 0) out[at] = normalizeText(text.slice(from, m.index));
    at = +m[1];
    from = m.index + m[0].length;
  }
  if (at >= 0) out[at] = normalizeText(text.slice(from));
  return out;
}

// Serialize a selection range keeping one language ('en' | 'zh') or 'all'.
export function serializeRange(range, lang) {
  const doc = range.startContainer.ownerDocument;
  const box = makeBox(doc);
  box.append(range.cloneContents());
  return finish(doc, box, lang);
}

// Serialize whole elements (e.g. the cells of several groups).
export function serializeEls(els, lang) {
  if (!els.length) return { text: '', html: '' };
  const doc = els[0].ownerDocument;
  const box = makeBox(doc);
  for (const e of els) {
    const c = e.cloneNode(true);
    c.removeAttribute && c.removeAttribute('id');
    box.append(c);
  }
  return finish(doc, box, lang);
}

// Install selection restriction + Ctrl+C handling on a book document.
// getMode(): current layout mode ('original'|'two'|'stack'|'en'|'zh')
export function attachCopy(doc, { getMode, onCopied }) {
  doc.addEventListener('mousedown', (e) => {
    if (e.button !== 0) return;
    const lang = langAt(e.target);
    const html = doc.documentElement;
    if (lang) html.dataset.brSel = lang; else delete html.dataset.brSel;
  }, true);
  doc.addEventListener('copy', (e) => {
    const sel = doc.getSelection();
    if (!sel || sel.isCollapsed || !sel.rangeCount) return;
    const mode = getMode();
    let lang = doc.documentElement.dataset.brSel || null;
    if (mode === 'en' || mode === 'zh') lang = mode;
    if (!lang) lang = langAt(sel.anchorNode) || 'all';
    const range = sel.getRangeAt(0);
    const out = serializeRange(range, lang);
    if (!out.text) return;
    e.clipboardData.setData('text/plain', out.text);
    if (out.html) e.clipboardData.setData('text/html', out.html);
    e.preventDefault();
    if (onCopied) onCopied(lang, out.text);
  });
}
