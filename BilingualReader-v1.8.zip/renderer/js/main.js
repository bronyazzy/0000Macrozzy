// Application controller: wires views, panels, dictionary, settings and shortcuts together.
import * as api from './api.js';
import { $, $$, el, debounce, throttle, toast, clamp, isEditable, escapeHtml } from './util.js';
import { FlowView } from './flowview.js';
import { PdfView } from './pdfview.js';
import { loadEpub, loadHtmlBook } from './epub.js';
import { Lightbox, ImageWindow } from './lightbox.js';
import { openMenu, closeMenu, isMenuOpen } from './menu.js';
import { TocPanel, BookmarksPanel, SearchPanel, Library } from './panels.js';
import { DictPanel, VocabPanel, formsRegex } from './dictpanel.js';
import { AiPanel } from './aichat.js';
import { StudyHub } from './study.js';
import { STATE_LABEL } from './vocabstate.js';
import { NotesPanel } from './notes.js';
import { GlossaryPanel } from './glossary.js';
import { ReadAloud } from './readaloud.js';
import { PracticeSession } from './practice.js';
import { DEFAULTS, THEMES, typographyControls, themeControls, openPopover, closePopover, openSettings, closeModal, importDicts } from './settings.js';
import { installIcons, icon } from './icons.js';
import { textNodes } from './bilingual.js';
import { sentences, stats as textStats } from './textlang.js';

const MODE_LABEL = { original: '原书排版', two: '左右双栏', stack: '上下对照', en: '仅英文', zh: '仅中文' };
const BOOK_RE = /\.(epub|pdf|html?|xhtml?|xht|shtml)$/i;
const DICT_RE = /\.(mdx|mdd|csv|tsv)$/i;

class App {
  constructor() {
    this.state = {};
    this.settings = { ...DEFAULTS };
    this.info = null;
    this.book = null;
    this.bookData = null;
    this.view = null;
    this.lastPos = null;
    this.history = [];
    this.popoverOpen = false;
    this.modalOpen = false;
    this.lookupToken = 0;
    this.saveSettingsSoon = debounce(() => api.call('saveSettings', this.settings).catch(() => {}), 500);
    this.glossarySoon = debounce(() => this.glossary.refresh(), 700);
    this.tocHighlightSoon = throttle(() => this.toc.highlight(), 400);
  }

  async init() {
    installIcons();
    this.flow = new FlowView(this);
    this.pdf = new PdfView(this);
    this.lightbox = new Lightbox(this);
    this.imageWin = new ImageWindow(this);
    this.toc = new TocPanel(this);
    this.bookmarks = new BookmarksPanel(this);
    this.search = new SearchPanel(this);
    this.library = new Library(this);
    this.dict = new DictPanel(this);
    this.vocab = new VocabPanel(this);
    this.ai = new AiPanel(this);
    this.study = new StudyHub(this);
    this.notes = new NotesPanel(this);
    this.glossary = new GlossaryPanel(this);
    this.tts = new ReadAloud(this);
    this.practice = new PracticeSession(this);
    this.vocabForms = [];
    this._speedT = setInterval(() => this.sampleReadingSpeed(), 30000);
    await this.reloadState();
    this.settings = { ...DEFAULTS, ...(this.state.settings || {}) };
    this._wire();
    this.applySettings(false);
    this.applyPanels();
    this.library.render();
    this.vocab.refresh().catch(() => {});
    this.ai.init().catch((e) => console.error(e));
    this.study.init().catch((e) => console.error(e));
    this.refreshVocabForms().catch(() => {});
    document.body.classList.toggle('electron', api.isElectron);

    api.on('open-file', (p) => this.openPath(p));
    api.on('shortcut', (k) => this.handleShortcut(k));
    api.on('before-close', () => this.beforeClose());
    api.on('window-state', (s) => this.onWindowState(s));

    let pending = null;
    if (api.isElectron) { try { pending = await api.call('getPending'); } catch { pending = null; } }
    if (pending) await this.openPath(pending);
    else if (this.settings.reopenLast) {
      const last = (this.state.library || []).find((b) => !b.missing);
      if (last) await this.openPath(last.path, { quiet: true });
    }
    document.body.classList.add('ready');
    let restored = null;
    try { restored = JSON.parse(sessionStorage.getItem('br-restored') || 'null'); sessionStorage.removeItem('br-restored'); } catch { restored = null; }
    if (restored) toast(`已恢复学习数据：生词 ${restored.vocab} 个、笔记 ${restored.notes} 条、书签 ${restored.bookmarks} 个。恢复前的数据已另存到 backups 文件夹。`, { ms: 7000 });
  }

  async reloadState() {
    this.state = { ...this.state, ...(await api.call('getState')) };
    return this.state;
  }

  // replaces the learning data with a backup (JSON text) and reloads the window
  async restoreBackup(text) {
    closeModal(this);
    try { await this.study.flush(); } catch { /* ignore */ }
    if (this.book) await this.closeBook();
    try { await api.call('saveSettings', this.settings); } catch { /* ignore */ }
    // nothing of this window may be saved over the restored data
    this.saveSettingsSoon = () => {};
    clearInterval(this.study._t1);
    clearInterval(this.study._t2);
    let r;
    try {
      r = await api.call('backupRestore', text);
    } catch (e) {
      toast('恢复失败：' + e.message, { type: 'error', ms: 6000 });
      setTimeout(() => location.reload(), 2500);
      return;
    }
    try { sessionStorage.setItem('br-restored', JSON.stringify(r)); } catch { /* ignore */ }
    location.reload();
  }

  // ------------------------------------------------------------------ UI wiring
  _wire() {
    const on = (id, ev, fn) => { const e = document.getElementById(id); if (e) e.addEventListener(ev, fn); };
    on('btn-left', 'click', () => this.togglePanel('left'));
    on('btn-home', 'click', () => this.closeBook());
    on('btn-open', 'click', () => this.pickAndOpen());
    on('start-open', 'click', () => this.pickAndOpen());
    on('btn-bookmark', 'click', () => this.addBookmark());
    on('btn-search', 'click', () => this.showPanel('search'));
    on('btn-dict', 'click', () => this.togglePanel('right'));
    on('btn-blur', 'click', () => this.toggleBlur());
    on('btn-tts', 'click', () => this.tts.toggle());
    on('btn-ai', 'click', () => (this.settings.rightOpen && this.settings.rightTab === 'ai' ? this.togglePanel('right', false) : this.openAi()));
    on('btn-clean', 'click', () => this.toggleClean());
    on('btn-settings', 'click', () => openSettings(this));
    on('btn-typo', 'click', (e) => { e.stopPropagation(); this.togglePopover(e.currentTarget, '排版', () => typographyControls(this)); });
    on('btn-theme', 'click', (e) => { e.stopPropagation(); this.togglePopover(e.currentTarget, '背景与护眼', () => themeControls(this)); });
    on('back-pill', 'click', () => this.goBack());
    on('win-min', 'click', () => api.call('win', 'minimize'));
    on('win-max', 'click', () => api.call('win', 'maximize'));
    on('win-close', 'click', () => api.call('win', 'close'));
    for (const b of $$('#mode-switch button')) b.addEventListener('click', () => this.setMode(b.dataset.mode));
    for (const b of $$('#left-panel .panel-tabs button')) b.addEventListener('click', () => this.setLeftTab(b.dataset.tab));
    for (const b of $$('#right-panel .panel-tabs button')) b.addEventListener('click', () => this.setRightTab(b.dataset.tab));
    document.addEventListener('keydown', (e) => this.onKeyDown(e, 'main'));
    document.addEventListener('mousedown', (e) => {
      const pop = document.getElementById('popover');
      if (this.popoverOpen && !pop.contains(e.target)) closePopover(this);
    });
    document.addEventListener('dragover', (e) => { e.preventDefault(); this.onDragOver(e); });
    document.addEventListener('dragleave', (e) => { if (!e.relatedTarget) this.hideDrop(); });
    document.addEventListener('drop', (e) => this.onDrop(e));
    document.addEventListener('mouseup', (e) => { if (e.button === 3) { e.preventDefault(); this.goBack(); } });
    this._splitter('split-left', 'left');
    this._splitter('split-right', 'right');
    const ph = document.getElementById('pair-handle');
    ph.innerHTML = '⋮';
    ph.addEventListener('mouseenter', () => clearTimeout(this._phTimer));
    ph.addEventListener('mouseleave', () => this.hidePairHandle(true));
    ph.addEventListener('click', (e) => {
      if (!this._phItem) return;
      const r = ph.getBoundingClientRect();
      this.openAlignMenu(r.left, r.bottom + 2, this._phView, this._phItem, null);
      e.stopPropagation();
    });
    const ch = document.getElementById('col-handle');
    ch.addEventListener('mousedown', (e) => this._dragColumns(e));
    ch.addEventListener('mouseleave', () => this.hidePairHandle(true));
    ch.addEventListener('mouseenter', () => clearTimeout(this._phTimer));
    window.addEventListener('resize', debounce(() => this.hidePairHandle(), 50));
  }

  _splitter(id, side) {
    const sp = document.getElementById(id);
    sp.addEventListener('mousedown', (e) => {
      e.preventDefault();
      const cover = el('div', { class: 'drag-cover' });
      document.body.append(cover);
      const startX = e.clientX;
      const start = side === 'left' ? this.settings.leftWidth : this.settings.rightWidth;
      const move = (ev) => {
        const d = ev.clientX - startX;
        const w = clamp(side === 'left' ? start + d : start - d, 180, 640);
        if (side === 'left') this.settings.leftWidth = w; else this.settings.rightWidth = w;
        this.applyPanels();
      };
      const up = () => {
        cover.remove();
        window.removeEventListener('mousemove', move);
        window.removeEventListener('mouseup', up);
        this.saveSettingsSoon();
      };
      window.addEventListener('mousemove', move);
      window.addEventListener('mouseup', up);
    });
  }

  togglePopover(anchor, title, build) {
    if (this.popoverOpen && this._popAnchor === anchor) { closePopover(this); return; }
    this._popAnchor = anchor;
    openPopover(this, anchor, title, build());
  }

  closeMenus() {
    closeMenu();
    if (this.popoverOpen) closePopover(this);
  }

  // ------------------------------------------------------------------ panels
  applyPanels() {
    const s = this.settings;
    const root = document.documentElement;
    root.style.setProperty('--left-w', s.leftWidth + 'px');
    root.style.setProperty('--right-w', s.rightWidth + 'px');
    document.body.classList.toggle('left-open', !!s.leftOpen);
    document.body.classList.toggle('right-open', !!s.rightOpen);
    for (const b of $$('#left-panel .panel-tabs button')) b.classList.toggle('on', b.dataset.tab === s.leftTab);
    for (const t of $$('#left-panel .tab')) t.hidden = t.id !== 'tab-' + s.leftTab;
    for (const b of $$('#right-panel .panel-tabs button')) b.classList.toggle('on', b.dataset.tab === s.rightTab);
    for (const t of $$('#right-panel .tab')) t.hidden = t.id !== 'tab-' + s.rightTab;
    this.state.leftTab = s.leftTab;
    this.hidePairHandle();
  }

  // narrow windows show the left panel as a drawer over the page; a click on the page closes it
  dismissOverlay() {
    if (this.settings.leftOpen && window.matchMedia('(max-width: 1100px)').matches) this.togglePanel('left', false);
  }

  togglePanel(side, open) {
    const k = side === 'left' ? 'leftOpen' : 'rightOpen';
    this.settings[k] = open == null ? !this.settings[k] : open;
    this.applyPanels();
    this.saveSettingsSoon();
  }

  setLeftTab(tab) {
    this.settings.leftTab = tab;
    this.settings.leftOpen = true;
    this.applyPanels();
    this.saveSettingsSoon();
    if (tab === 'toc') this.toc.highlight();
    if (tab === 'glossary') this.glossary.refresh();
    if (tab === 'notes') this.notes.render();
  }

  setRightTab(tab) {
    this.settings.rightTab = tab;
    this.settings.rightOpen = true;
    this.applyPanels();
    this.saveSettingsSoon();
    if (tab === 'vocab') this.vocab.refresh();
    if (tab === 'ai') this.ai.onShow();
  }

  // Opens the AI tab (leaving the clean F9 mode, which only shows text + dictionary).
  // ------------------------------------------------------------------ pictures
  // the image viewer: in the picture window (default, 设置 → 阅读), or over the reading window
  showImages(items, index = 0) {
    if (!items || !items.length) return;
    if (this.settings.imageWindow !== false && this.imageWin.open(items, index)) return;
    this.lightbox.openItems(items, index);
  }

  showImage(src, opts = {}) { this.showImages([{ src, ...opts }], 0); }

  focusReadingWindow() {
    if (api.isElectron) api.call('imageWindow', 'focusMain').catch(() => {});
    else { try { window.focus(); } catch { /* ignore */ } }
  }

  openAi(focus = true) {
    if (document.body.classList.contains('clean')) this.toggleClean(false);
    if (!this.settings.rightOpen || this.settings.rightTab !== 'ai') this.setRightTab('ai');
    if (focus) this.ai.focus();
  }

  // Text for "AI 解释所选": the live selection in the book, or the last one made there.
  aiSelection() {
    if (this.view === this.flow && this.flow.doc) {
      const sel = this.flow.doc.getSelection();
      const t = sel && !sel.isCollapsed ? sel.toString() : '';
      if (t.trim()) return { text: t, kind: 'selection' };
    }
    if (this.view === this.pdf) {
      const sel = document.getSelection();
      const t = sel && !sel.isCollapsed && this.pdf.container.contains(sel.anchorNode) ? sel.toString() : '';
      if (t.trim()) return { text: t, kind: 'selection' };
    }
    const l = this.lastSelection;
    if (l && l.view === this.view && l.text.trim() && Date.now() - l.at < 15 * 60e3) return { text: l.text, kind: 'selection' };
    return null;
  }

  noteSelection(view, text) {
    if (text && text.trim()) this.lastSelection = { view, text, at: Date.now() };
  }

  async aiChapterText() {
    if (this.view === this.flow && this.flow.doc) {
      const t = this.flow.book && this.flow.book.chapterTitles ? this.flow.book.chapterTitles[this.flow.index] : '';
      return { text: this.flow.chapterText(), label: t ? `本章（${t}）` : '本章' };
    }
    if (this.view === this.pdf && this.pdf.pdf) {
      const n = this.pdf.viewer.currentPageNumber;
      return { text: await this.pdf.pageText(n), label: `第 ${n} 页` };
    }
    return null;
  }

  _aiSource(view, target, selText, lang) {
    if (selText && selText.trim()) return { text: selText, kind: 'selection' };
    const bilingual = view.plan && view.plan.bilingual;
    const r = view.copyText(bilingual ? lang : 'both', target);
    return { text: (r && r.text) || '', kind: 'paragraph' };
  }

  showPanel(tab) {
    if (['toc', 'bookmarks', 'search', 'glossary', 'notes'].includes(tab)) {
      this.setLeftTab(tab);
      if (tab === 'search') {
        const sel = this.view && this.view === this.flow ? this.flow.currentSelectionText().trim() : '';
        this.search.focus(sel && sel.length < 60 ? sel : '');
      }
    } else this.setRightTab(tab);
  }

  // ------------------------------------------------------------------ settings / theme
  themeColors() {
    const s = this.settings;
    let name = s.theme;
    let t = THEMES[name];
    if (name === 'custom') t = { bg: s.customBg, fg: s.customFg, link: '#1a5fb4', ui: 'light' };
    if (!t) { name = 'light'; t = THEMES.light; }
    if (s.eyeCare && name !== 'dark') { name = 'green'; t = THEMES.green; }
    return { name, bg: t.bg, fg: t.fg, link: t.link, ui: t.ui || 'light' };
  }

  applySettings(save = true) {
    const s = this.settings;
    const theme = this.themeColors();
    const root = document.documentElement;
    root.style.setProperty('--reader-bg', theme.bg);
    root.style.setProperty('--reader-fg', theme.fg);
    document.body.classList.toggle('ui-dark', theme.ui === 'dark');
    const eye = document.getElementById('eyecare');
    eye.style.opacity = s.eyeCare ? String(clamp(s.eyeCareStrength, 0, 60) / 100) : '0';
    document.body.classList.toggle('eyecare', !!s.eyeCare);
    document.body.classList.toggle('dict-compact', !!s.dictCompact);
    if (this.view === this.flow) this.flow.applySettings(s);
    this.applyPdfTheme();
    if (this.dict && this.dict.result) this.dict.render();
    this.updateModeUi();
    this.updateStatus();
    if (save) this.saveSettingsSoon();
  }

  applyPdfTheme() {
    const host = document.getElementById('pdf-host');
    const theme = this.themeColors();
    host.classList.toggle('pdf-dark', theme.name === 'dark');
    host.classList.toggle('pdf-tint', theme.name !== 'dark' && theme.name !== 'light');
    host.style.setProperty('--pdf-tint', theme.bg);
  }

  // ------------------------------------------------------------------ open / close books
  async pickAndOpen() {
    if (!api.isElectron) {
      const p = await this.prompt('要打开的文件路径', '');
      if (p) await this.openPath(p);
      return;
    }
    const paths = await api.call('pickBook');
    if (paths && paths[0]) await this.openPath(paths[0]);
  }

  showLoading(text) {
    const l = document.getElementById('loading');
    if (text) { l.textContent = text; l.hidden = false; } else l.hidden = true;
  }

  async openPath(path, { quiet = false } = {}) {
    if (!path) return;
    this.showLoading('正在打开…');
    try {
      if (this.view) await this.savePosition();
      const info = await api.call('openBook', path);
      await this.openInfo(info);
    } catch (e) {
      console.error(e);
      if (!quiet) toast('打开失败：' + e.message, { type: 'error', ms: 5000 });
      else toast('上次的书无法打开：' + e.message, { type: 'error', ms: 4000 });
      if (!this.book) this.closeBook();
    } finally {
      this.showLoading(null);
    }
  }

  async openInfo(info) {
    this._teardown();
    this.info = info;
    this.bookData = info.data || { position: null, bookmarks: [], align: {} };
    this.bookData.bookmarks = this.bookData.bookmarks || [];
    this.bookData.align = this.bookData.align || {};
    this.history = [];
    this.hideBackPill();
    document.body.classList.remove('no-book');
    document.body.classList.toggle('is-pdf', info.type === 'pdf');
    const pos = this.bookData.position;
    if (info.type === 'pdf') {
      this.view = this.pdf;
      this.book = await this.pdf.open(info, pos && pos.kind === 'pdf' ? pos : null);
    } else {
      this.view = this.flow;
      this.book = info.type === 'epub' ? await loadEpub(info) : await loadHtmlBook(info);
      this.flow.mode = this.bookData.mode || this.settings.defaultMode;
      this.search.reset();
      await this.flow.open(this.book, pos && pos.kind === 'flow' ? pos : { index: 0 });
    }
    this.search.reset();
    document.getElementById('book-title').textContent = this.book.title;
    document.title = this.book.title + ' - 双语阅读器';
    this.toc.render();
    this.bookmarks.render();
    this.updateModeUi();
    this.updateStatus();
    this.ai.setBook(info.bookId).catch(() => {});
    this.notes.setBook(info.bookId).catch(() => {});
    const lib = info.library || {};
    const patch = { title: this.book.title, author: this.book.author || '' };
    api.call('updateLibrary', info.bookId, patch).catch(() => {});
    if (!lib.cover) this._makeCover(info.bookId).catch(() => {});
    this.vocab.render();
    this.study.render();
  }

  _teardown() {
    this.tts.stop();
    this.practice.close();
    if (this.view === this.flow) this.flow.close();
    if (this.view === this.pdf) this.pdf.close();
    this.view = null;
    this.book = null;
    this.hidePairHandle();
    this.lightbox.close();
    this.imageWin.close();
  }

  async closeBook() {
    if (this.view) await this.savePosition();
    if (this.info) api.call('closeBook', this.info.bookId).catch(() => {});
    this._teardown();
    this.info = null;
    this.bookData = null;
    this.lastPos = null;
    document.body.classList.add('no-book');
    document.body.classList.remove('is-pdf');
    document.getElementById('book-title').textContent = '双语阅读器';
    document.getElementById('chapter-title').textContent = '';
    document.title = '双语阅读器';
    this.toc.render();
    this.bookmarks.render();
    this.search.reset();
    this.ai.setBook('').catch(() => {});
    this.notes.setBook('').catch(() => {});
    this.glossary.key = '';
    this.glossary.render();
    this.hideVocabTip();
    await this.reloadState();
    this.library.render();
    this.updateStatus();
    this.study.render();
  }

  // 回译 / 听写 practice from the reading position (PDF: 听写 only)
  startPractice(mode, from = null) {
    if (!this.view) { toast('请先打开一本书'); return Promise.resolve(false); }
    const m = this.view === this.pdf ? 'dictate' : mode || this.settings.practiceMode || 'translate';
    return this.practice.start(m, from);
  }

  async _makeCover(bookId) {
    let url = null;
    if (this.book && this.book.coverUrl) {
      const img = new Image();
      img.src = this.book.coverUrl;
      await img.decode();
      const c = document.createElement('canvas');
      c.width = 150; c.height = 210;
      const ctx = c.getContext('2d');
      const k = Math.max(150 / img.naturalWidth, 210 / img.naturalHeight);
      const w = img.naturalWidth * k;
      const h = img.naturalHeight * k;
      ctx.drawImage(img, (150 - w) / 2, (210 - h) / 2, w, h);
      url = c.toDataURL('image/jpeg', 0.82);
    } else if (this.view === this.pdf && this.pdf.pdf) {
      const page = await this.pdf.pdf.getPage(1);
      const vp0 = page.getViewport({ scale: 1 });
      const vp = page.getViewport({ scale: 150 / vp0.width });
      const c = document.createElement('canvas');
      c.width = Math.ceil(vp.width); c.height = Math.ceil(vp.height);
      await page.render({ canvas: c, canvasContext: c.getContext('2d'), viewport: vp }).promise;
      url = c.toDataURL('image/jpeg', 0.8);
    }
    if (url && this.info && this.info.bookId === bookId) await api.call('updateLibrary', bookId, { cover: url });
  }

  // ------------------------------------------------------------------ positions & history
  onChapterShown(view, plan) {
    this.updateModeUi();
    this.updateStatus();
    this.toc.highlight();
    const q = this.search.query;
    if (q && view === this.flow) view.highlightAll(q, this.search.opts);
    this.applyLearning(view);
    this.tts.onViewChanged();
    void plan;
  }

  // vocabulary underlines, note highlights and the chapter glossary for the chapter on screen
  applyLearning(view) {
    if (view === this.flow && view.doc) {
      view.applyVocab(this.settings.vocabHighlight !== false ? this.vocabForms : null);
      this.notes.paint();
    }
    this.glossary.refresh();
  }

  async refreshVocabForms() {
    try { this.vocabForms = await api.call('vocabForms'); } catch { this.vocabForms = []; }
    if (this.view === this.flow && this.flow.doc) this.flow.applyVocab(this.settings.vocabHighlight !== false ? this.vocabForms : null);
  }

  showVocabTip(v, rect) {
    let tip = this._vtip;
    if (!tip) {
      tip = this._vtip = el('div', { id: 'vocab-tip', hidden: true });
      document.body.append(tip);
    }
    if (this._vtipFor !== v) {
      tip.replaceChildren(
        el('div', { class: 'vt-head' }, el('b', {}, v.word), el('span', { class: 'vt-state ' + v.state }, STATE_LABEL[v.state] || '')),
        v.def ? el('div', { class: 'vt-def' }, v.def) : el('div', { class: 'vt-def muted' }, '双击查看释义'));
      this._vtipFor = v;
    }
    tip.hidden = false;
    const w = tip.offsetWidth;
    const h = tip.offsetHeight;
    let top = rect.top - h - 6;
    if (top < 44) top = rect.bottom + 6;
    tip.style.left = Math.max(8, Math.min(window.innerWidth - w - 8, rect.left)) + 'px';
    tip.style.top = top + 'px';
  }

  hideVocabTip() {
    if (this._vtip) this._vtip.hidden = true;
    this._vtipFor = null;
  }

  toggleBlur() {
    const order = ['', 'zh', 'en'];
    this.setBlur(order[(order.indexOf(this.settings.blurMode || '') + 1) % order.length]);
  }

  setBlur(mode) {
    const was = this.settings.blurMode || '';
    this.settings.blurMode = mode || '';
    this.saveSettingsSoon();
    this.flow.setBlur(mode);
    this.updateModeUi();
    const f = this.flow;
    const ok = this.view === f && f.plan && f.plan.bilingual && ['two', 'stack'].includes(f.effMode);
    if (!mode) { if (was) this.flashStatus('已关闭遮挡自测'); }
    else if (ok) this.flashStatus(`遮挡自测：已遮住${mode === 'zh' ? '中文' : '英文'}，读完后点击被遮住的段落查看（F7 切换）`);
    else this.flashStatus('遮挡自测在“双栏”或“上下对照”模式下生效');
  }

  onPositionChange(pos) {
    if (!pos) return;
    this.lastPos = pos;
    this.updateStatus();
    this.tocHighlightSoon();
    if (this.view === this.pdf) this.glossarySoon(); // PDF: terms of the current page
  }

  async savePosition() {
    if (!this.view || !this.info) return;
    const pos = this.view.getPosition();
    if (!pos) return;
    this.bookData.position = pos;
    const patch = { position: pos };
    if (this.view === this.flow) patch.mode = this.flow.mode;
    try {
      await api.call('saveBookData', this.info.bookId, patch);
      await api.call('updateLibrary', this.info.bookId, { progress: pos.percent || 0, posLabel: this.posLabel(pos), lastRead: Date.now() });
    } catch { /* ignore */ }
  }

  saveBookData(patch) {
    Object.assign(this.bookData, patch);
    if (this.info) api.call('saveBookData', this.info.bookId, patch).catch(() => {});
  }

  posLabel(pos) {
    if (!pos) return '';
    if (pos.kind === 'pdf') return `第 ${pos.page} 页`;
    return (this.book && this.book.chapterTitles && this.book.chapterTitles[pos.index]) || '';
  }

  pushHistory(pos) {
    if (!pos) return;
    this.history.push(pos);
    if (this.history.length > 60) this.history.shift();
  }

  showBackPill() {
    const b = document.getElementById('back-pill');
    b.hidden = !this.history.length;
    clearTimeout(this._pillTimer);
    this._pillTimer = setTimeout(() => { b.hidden = true; }, 45000);
  }

  hideBackPill() { document.getElementById('back-pill').hidden = true; }

  async goBack() {
    const pos = this.history.pop();
    if (!pos) { this.flashStatus('没有可返回的位置'); return; }
    await this.jumpTo(pos, true);
    if (!this.history.length) this.hideBackPill();
  }

  async jumpTo(pos, isBack = false) {
    if (!pos || !this.view) return;
    if (!isBack) this.pushHistory(this.view.getPosition());
    if (pos.kind === 'pdf' && this.view === this.pdf) this.pdf.goTo(pos);
    else if (pos.kind === 'flow' && this.view === this.flow) await this.flow.goTo(pos);
    this.refocusReader();
  }

  async gotoToc(node) {
    if (!this.view) return;
    this.pushHistory(this.view.getPosition());
    if (this.view === this.pdf) {
      if (node.page) this.pdf.goTo({ page: node.page, dest: node.dest });
      else if (node.url) this.openExternal(node.url);
      return;
    }
    if (node.spine == null) { toast('目录项指向的内容不在书中'); return; }
    if (node.spine === this.flow.index) {
      this.flow.restore(node.fragment ? { fragment: node.fragment } : {});
      this.flow._scrolled(true);
    } else await this.flow.show(node.spine, node.fragment ? { fragment: node.fragment } : {});
    this.refocusReader();
  }

  async gotoSearchHit(hit) {
    if (this.view !== this.flow) return;
    this.pushHistory(this.flow.getPosition());
    if (hit.index === this.flow.index) this.flow.gotoSearchHit(hit);
    else await this.flow.show(hit.index, { search: hit });
  }

  gotoPdfHit(page, q, opts) {
    this.pushHistory(this.pdf.getPosition());
    this.pdf.goTo({ page });
    this.pdf.find(q, opts);
  }

  searchStep(dir) {
    const q = this.search.query;
    if (!q) { this.showPanel('search'); return; }
    if (this.view === this.flow) {
      if (!this.flow.stepSearch(dir)) this.flashStatus(dir > 0 ? '本章后面没有更多结果' : '本章前面没有更多结果');
    } else if (this.view === this.pdf) this.pdf.find(q, this.search.opts, true, dir < 0);
  }

  pdfFindCount(c) {
    if (c && this.search.query) this.search.status.textContent = `共 ${c.total} 处（当前第 ${c.current} 处）`;
  }

  // ------------------------------------------------------------------ modes
  async setMode(mode) {
    if (!this.book) { this.settings.defaultMode = mode; this.applySettings(); toast('新打开的书将使用“' + MODE_LABEL[mode] + '”'); return; }
    if (this.view !== this.flow) { toast('PDF 保持原页版式，不支持对照模式切换'); return; }
    if (mode !== 'two') this.settings.lastNonTwoMode = mode;
    await this.flow.setMode(mode);
    this.saveBookData({ mode });
    this.updateModeUi();
    this.updateStatus();
    if (this.flow.plan && !this.flow.plan.bilingual && mode !== 'original') this.flashStatus('本章未检测到中英对照内容，按原书排版显示');
    this.saveSettingsSoon();
  }

  toggleTwo() {
    if (this.view === this.pdf) { toast('PDF 不支持双栏对照'); return; }
    const cur = this.view === this.flow ? this.flow.mode : this.settings.defaultMode;
    if (cur === 'two') this.setMode(this.settings.lastNonTwoMode && this.settings.lastNonTwoMode !== 'two' ? this.settings.lastNonTwoMode : 'original');
    else { this.settings.lastNonTwoMode = cur; this.setMode('two'); }
  }

  toggleCompact() {
    this.settings.dictCompact = !this.settings.dictCompact;
    this.applySettings();
    this.flashStatus(this.settings.dictCompact ? '只看释义：开' : '只看释义：关');
  }

  toggleClean(force) {
    const on = force == null ? !document.body.classList.contains('clean') : force;
    document.body.classList.toggle('clean', on);
    this.closeMenus();
    this.hidePairHandle();
    if (on) this.flashStatus('简洁模式：按 F9 或 Esc 退出');
    this.refocusReader();
  }

  updateModeUi() {
    const isFlow = this.view === this.flow;
    const mode = isFlow ? this.flow.mode : this.settings.defaultMode;
    const isPdf = this.view === this.pdf;
    for (const b of $$('#mode-switch button')) {
      b.classList.toggle('on', !isPdf && b.dataset.mode === mode);
      b.disabled = isPdf;
    }
    document.getElementById('mode-switch').title = isPdf ? 'PDF 保持原页版式，不能切换对照方式' : '中英对照显示方式';
    const eff = isFlow ? this.flow.effMode : null;
    document.getElementById('mode-switch').classList.toggle('degraded', isFlow && mode !== 'original' && eff === 'original');
    $('#btn-compact-state') && ($('#btn-compact-state').textContent = this.settings.dictCompact ? '开' : '关');
    document.getElementById('dict-compact').classList.toggle('on', !!this.settings.dictCompact);
    const blur = document.getElementById('btn-blur');
    if (blur) {
      const m = this.settings.blurMode || '';
      blur.classList.toggle('on', !!m);
      blur.dataset.state = m === 'zh' ? '中' : m === 'en' ? '英' : '';
      blur.title = m ? `遮挡自测：遮住${m === 'zh' ? '中文' : '英文'}（F7 切换）` : '遮挡自测：遮住译文，读完再看（F7）';
    }
  }

  // ------------------------------------------------------------------ status bar
  updateStatus() {
    const ch = document.getElementById('st-chapter');
    const pos = document.getElementById('st-pos');
    const pairs = document.getElementById('st-pairs');
    const mode = document.getElementById('st-mode');
    const zoom = document.getElementById('st-zoom');
    const title = document.getElementById('chapter-title');
    if (!this.book || !this.view) {
      ch.textContent = ''; pos.textContent = ''; pairs.textContent = ''; mode.textContent = ''; zoom.textContent = ''; title.textContent = '';
      this._updateLeft(null);
      return;
    }
    const p = this.lastPos;
    if (this.view === this.pdf) {
      const n = this.pdf.pages;
      ch.textContent = p ? `第 ${p.page} / ${n} 页` : '';
      pos.textContent = p ? Math.round(p.percent * 100) + '%' : '';
      pairs.textContent = '';
      mode.textContent = 'PDF 原版式';
      zoom.textContent = this.pdf.viewer ? Math.round(this.pdf.viewer.currentScale * 100) + '%' : '';
      title.textContent = p ? ` · 第 ${p.page} 页` : '';
      this._updateLeft(null);
      return;
    }
    const idx = this.flow.index;
    const t = this.book.chapterTitles[idx] || '';
    ch.textContent = this.book.spine.length > 1 ? `${t}（${idx + 1}/${this.book.spine.length}）` : t;
    title.textContent = t && t !== this.book.title ? ' · ' + t : '';
    pos.textContent = p ? Math.round((p.percent || 0) * 100) + '%' : '';
    const plan = this.flow.plan;
    pairs.textContent = plan ? (plan.bilingual ? `中英对照 ${plan.stats.paired} 组` : '未检测到对照') : '';
    mode.textContent = MODE_LABEL[this.flow.effMode] + (this.flow.effMode !== this.flow.mode ? '（' + MODE_LABEL[this.flow.mode] + '不适用）' : '');
    zoom.textContent = this.settings.fontSize + 'px';
    this._updateLeft(p);
  }

  // ------------------------------------------------------------------ time left in the chapter
  // English words / Chinese characters per block of the chapter on screen (cached per page)
  _chapterText() {
    const v = this.flow;
    if (this.view !== v || !v.doc) return null;
    if (this._ct && this._ct.doc === v.doc) return this._ct;
    const per = new Map();
    for (const e of v.doc.querySelectorAll('[data-bidx]')) {
      if (e.querySelector('[data-bidx]') || e.closest('.br-ui')) continue;
      const b = +e.dataset.bidx;
      const st = textStats(e.textContent || '');
      const lang = e.dataset.lang || '';
      const cur = per.get(b) || { w: 0, h: 0 };
      // English text: words; Chinese text: characters
      if (lang !== 'zh') cur.w += st.words;
      if (lang !== 'en') cur.h += st.han;
      per.set(b, cur);
    }
    const blocks = [...per.entries()].sort((a, b) => a[0] - b[0]);
    let w = 0;
    let h = 0;
    for (const [, x] of blocks) { w += x.w; h += x.h; }
    this._ct = { doc: v.doc, blocks, words: w, han: h };
    return this._ct;
  }

  // what is left after a reading position: { words, han, total }
  _textLeft(pos) {
    const ct = this._chapterText();
    if (!ct || !pos || pos.bidx == null) return null;
    let words = 0;
    let han = 0;
    for (const [b, x] of ct.blocks) {
      if (b < pos.bidx) continue;
      const k = b === pos.bidx ? 1 - (pos.frac || 0) : 1;
      words += x.w * k;
      han += x.h * k;
    }
    return { words: Math.round(words), han: Math.round(han), ct };
  }

  // the estimate is in Chinese characters when only Chinese is shown (or the chapter has no English)
  _leftUnit(ct) { return this.flow.effMode === 'zh' || ct.words < ct.han / 6 ? 'han' : 'words'; }

  // every 30 s while reading: how fast the reading position moves (learns 词/分钟)
  sampleReadingSpeed() {
    const s = this.settings;
    if (!s || this.view !== this.flow || !this.flow.doc || document.hidden || this.modalOpen || this.tts.active) { this._rs = null; return; }
    if (Date.now() - (this.study.lastAct || 0) > 120000) { this._rs = null; return; } // away from the computer
    const pos = this.flow.getPosition();
    const left = this._textLeft(pos);
    if (!left) { this._rs = null; return; }
    const unit = this._leftUnit(left.ct);
    const done = (unit === 'han' ? left.ct.han - left.han : left.ct.words - left.words);
    const now = Date.now();
    const prev = this._rs;
    this._rs = { doc: left.ct.doc, unit, done, t: now };
    if (!prev || prev.doc !== left.ct.doc || prev.unit !== unit) return;
    const min = (now - prev.t) / 60000;
    const d = done - prev.done;
    if (min <= 0 || min > 1.5 || d <= 0) return;
    const rate = d / min;
    const [lo, hi] = unit === 'han' ? [60, 1500] : [25, 700];
    if (rate < lo || rate > hi) { this._acc = null; return; } // a jump, or reading something else
    const acc = this._acc || (this._acc = { d: 0, m: 0 });
    acc.d += d;
    acc.m += min;
    if (acc.m < 3) return;
    const key = unit === 'han' ? 'readCpm' : 'readWpm';
    const old = +s[key] || (unit === 'han' ? 350 : 150);
    s[key] = Math.round(old * 0.7 + (acc.d / acc.m) * 0.3);
    this._acc = null;
    this.saveSettingsSoon();
  }

  _updateLeft(pos) {
    const node = document.getElementById('st-left');
    if (!node) return;
    const left = this.view === this.flow ? this._textLeft(pos) : null;
    if (!left || (!left.ct.words && !left.ct.han)) { node.textContent = ''; node.title = ''; return; }
    const unit = this._leftUnit(left.ct);
    const n = unit === 'han' ? left.han : left.words;
    const speed = unit === 'han' ? +this.settings.readCpm || 350 : +this.settings.readWpm || 150;
    const min = n / speed;
    node.textContent = n < (unit === 'han' ? 60 : 25) ? '本章快读完了' : min < 1 ? '本章还剩不到 1 分钟' : min < 60 ? `本章约剩 ${Math.ceil(min)} 分钟` : `本章约剩 ${Math.floor(min / 60)} 小时 ${Math.ceil(min % 60)} 分`;
    node.title = `剩余约 ${n.toLocaleString('en-US')} 个${unit === 'han' ? '汉字' : '英文词'}，按 ${speed} ${unit === 'han' ? '字' : '词'}/分钟估算（会按你的实际阅读速度自动调整）`;
  }

  flashStatus(msg) {
    const f = document.getElementById('st-flash');
    f.textContent = msg;
    f.classList.add('show');
    clearTimeout(this._flashTimer);
    this._flashTimer = setTimeout(() => f.classList.remove('show'), 2400);
    if (document.body.classList.contains('clean')) toast(msg, { ms: 1600 });
  }

  toast(msg, type = 'info', ms) { toast(msg, { type, ms }); }

  overscrollHint(frac, dir) {
    const h = document.getElementById('overscroll-hint');
    if (!frac) { h.classList.remove('show'); return; }
    h.textContent = dir === 'next' ? '继续向下滚动进入下一章' : '继续向上滚动回到上一章';
    h.classList.toggle('top', dir === 'prev');
    h.style.setProperty('--p', Math.min(1, frac));
    h.classList.add('show');
  }

  // ------------------------------------------------------------------ dictionary
  // quiet: not counted in the statistics and the lookup history (e.g. browsing the history itself)
  async lookup(text, ctx, { quiet = false } = {}) {
    const q = String(text || '').replace(/\s+/g, ' ').trim();
    if (!q) return;
    const token = ++this.lookupToken;
    if (this.settings.autoOpenDict || document.body.classList.contains('clean')) {
      if (!this.settings.rightOpen || this.settings.rightTab !== 'dict') { this.settings.rightOpen = true; this.settings.rightTab = 'dict'; this.applyPanels(); }
    }
    let result;
    try {
      result = await api.call('lookup', q, { ...(ctx ? { sentence: ctx.sentence, offset: ctx.offset } : {}), book: this.book ? this.book.title : '', noStats: quiet });
    } catch (e) {
      toast('查词失败：' + e.message, { type: 'error' });
      return;
    }
    if (token !== this.lookupToken) return;
    document.body.classList.add('has-lookup');
    await this.dict.show(result, ctx);
  }

  bookExamples(word, exclude, forms) {
    if (this.view !== this.flow || !this.flow.doc || !word || word.includes(' ')) return [];
    const doc = this.flow.doc;
    const re = formsRegex(word, forms, 'i');
    if (!re) return [];
    const out = [];
    const ex = (exclude || '').replace(/\s+/g, ' ').trim();
    for (const e of doc.querySelectorAll('[data-lang="en"]')) {
      if (e.querySelector('[data-lang]')) continue;
      const text = textNodes(e, true).map((n) => n.data).join('');
      if (!re.test(text)) continue;
      for (const s of sentences(text, 'en')) {
        const st = s.text.replace(/\s+/g, ' ');
        if (re.test(st) && st !== ex && st.length < 400 && !out.includes(st)) out.push(st);
        if (out.length >= 3) return out;
      }
    }
    return out;
  }

  speak(word) { this.speakText(word); }

  async refreshVocab() {
    await this.vocab.refresh();
    await this.refreshVocabForms();
    this.study.refresh();
    this.glossary.refresh().catch(() => {}); // 本章生词
  }

  // the English voice for reading aloud (设置 → 学习 → 朗读), or null
  pickVoice() {
    let voices = [];
    try { voices = window.speechSynthesis.getVoices() || []; } catch { voices = []; }
    const pref = this.settings.ttsVoice;
    const v = (pref && voices.find((x) => x.name === pref)) || voices.find((x) => /^en[-_]US/i.test(x.lang)) || voices.find((x) => /^en/i.test(x.lang)) || null;
    if (!v && voices.length && !this._noEnVoice) {
      this._noEnVoice = true;
      toast('没有找到英文语音，朗读可能不准确。可在 Windows“设置 → 时间和语言 → 语音”中添加英语语音。', { ms: 6000 });
    }
    return v;
  }

  // Read text aloud with the system voices (English voice, rate and voice from 设置 → 学习).
  speakText(text, { lang = 'en-US' } = {}) {
    const synth = window.speechSynthesis;
    if (!synth) { toast('系统不支持语音朗读'); return false; }
    try {
      if (this.tts.active) this.tts.stop();
      synth.cancel();
      const t = String(text || '').replace(/\s+/g, ' ').trim();
      if (!t) return false;
      const v = lang.startsWith('en') ? this.pickVoice() : null;
      const chunks = [];
      for (const s of t.match(/[^.!?;。！？；]+[.!?;。！？；]*\s*/g) || [t]) {
        if (chunks.length && (chunks[chunks.length - 1] + s).length < 220) chunks[chunks.length - 1] += s;
        else chunks.push(s);
      }
      for (const c of chunks) {
        const u = new SpeechSynthesisUtterance(c.trim());
        if (v) u.voice = v;
        u.lang = v ? v.lang : lang;
        u.rate = +this.settings.ttsRate || 0.9;
        synth.speak(u);
      }
      return true;
    } catch {
      toast('朗读失败');
      return false;
    }
  }

  stopSpeaking() {
    if (this.tts.active) this.tts.stop();
    try { window.speechSynthesis.cancel(); } catch { /* ignore */ }
  }

  updateTtsButton() {
    const b = document.getElementById('btn-tts');
    if (!b) return;
    b.classList.toggle('on', this.tts.active);
    b.title = this.tts.active ? '停止连续朗读（Ctrl+Shift+U）' : '连续朗读英文，边听边读（Ctrl+Shift+U）';
  }

  get speaking() { try { return !!(window.speechSynthesis && (window.speechSynthesis.speaking || window.speechSynthesis.pending)); } catch { return false; } }

  // ------------------------------------------------------------------ bookmarks
  addBookmark() {
    if (!this.view) { toast('请先打开一本书'); return; }
    const pos = this.view.getPosition();
    if (!pos) return;
    let excerpt = '';
    if (this.view === this.flow) {
      const b = this.flow._blockAtTop();
      excerpt = b ? (b.textContent || '').replace(/\s+/g, ' ').trim().slice(0, 90) : '';
    }
    const bm = { id: Date.now().toString(36), pos, label: this.posLabel(pos) || '书签', excerpt, created: Date.now() };
    const list = [...(this.bookData.bookmarks || []), bm];
    this.saveBookData({ bookmarks: list });
    this.bookmarks.render();
    this.flashStatus('已添加书签');
    toast('已添加书签：' + bm.label);
  }

  removeBookmark(id) {
    const list = (this.bookData.bookmarks || []).filter((b) => b.id !== id);
    this.saveBookData({ bookmarks: list });
    this.bookmarks.render();
  }

  // ------------------------------------------------------------------ context menus
  async copyOut(text, html) {
    if (!text) { toast('没有可复制的内容'); return; }
    window.__lastClipboard = text;
    try {
      if (api.isElectron) await api.call('clipboardWrite', { text, html: html || '' });
      else await navigator.clipboard.writeText(text);
    } catch { /* test harness without clipboard permission */ }
    this.flashStatus(`已复制 ${text.length} 个字符`);
  }

  openBookMenu(info) {
    const { view, selText, item, image, link, target } = info;
    const items = [];
    const bilingual = view.plan && view.plan.bilingual;
    const short = selText.trim();
    if (short) {
      items.push({ label: '复制', hint: 'Ctrl+C', action: () => { const r = view.copyText(view.doc.documentElement.dataset.brSel || 'all', target); this.copyOut(r.text, r.html); } });
    }
    items.push({ label: short ? '复制英文' : '复制本段英文', disabled: !bilingual && !short, action: () => { const r = view.copyText('en', target); this.copyOut(r.text, r.html); } });
    items.push({ label: short ? '复制中文' : '复制本段中文', disabled: !bilingual && !short, action: () => { const r = view.copyText('zh', target); this.copyOut(r.text, r.html); } });
    items.push({ label: short ? '复制双语（按组）' : '复制本组双语', disabled: !bilingual, action: () => { const r = view.copyText('both', target); this.copyOut(r.text); } });
    items.push('-');
    const word = short && short.length <= 60 ? short : (info.word ? info.word.word : '');
    if (word) {
      const ctxRange = info.range || (info.word && info.word.range);
      items.push({ label: `查词“${word.length > 24 ? word.slice(0, 24) + '…' : word}”`, action: () => this.lookup(word, ctxRange ? view.contextFor(ctxRange) : null) });
      items.push({ label: '查词并加入生词本', action: async () => { await this.lookup(word, ctxRange ? view.contextFor(ctxRange) : null); await this.dict.addVocab(); } });
      items.push('-');
    }
    if (short) {
      items.push({ label: '高亮标注', action: () => this.notes.addFromSelection(false) });
      items.push({ label: '高亮并写笔记…', action: () => this.notes.addFromSelection(true) });
      items.push('-');
    }
    if (this.tts.active) items.push({ label: '停止连续朗读', hint: 'Ctrl+Shift+U', action: () => this.tts.stop() });
    else if (this.speaking) items.push({ label: '停止朗读', action: () => this.stopSpeaking() });
    else items.push({ label: short ? '朗读所选' : '朗读本段', action: () => this.speakText(short ? info.selText : this._aiSource(view, target, '', 'en').text) });
    const at = info.range ? { node: info.range.startContainer, offset: info.range.startOffset } : info.caret || (info.word && info.word.range ? { node: info.word.range.startContainer, offset: info.word.range.startOffset } : { node: target, offset: 0 });
    if (!this.tts.active) items.push({ label: '从这里开始连续朗读', hint: 'Ctrl+Shift+U', action: () => this.tts.start(at) });
    items.push({ label: '练习', submenu: [
      { label: '回译：看中文写英文（从本段开始）', disabled: !bilingual, action: () => this.practice.start('translate', at) },
      { label: '听写：听英文写下来（从这里开始）', action: () => this.practice.start('dictate', at) },
    ] });
    items.push({ label: short ? 'AI 解释所选' : 'AI 解释本段', hint: this.ai.providerShort(), action: () => this.ai.quickAction('explain', this._aiSource(view, target, info.selText, 'both')) });
    items.push({ label: short ? 'AI 翻译所选' : 'AI 翻译本段', action: () => this.ai.quickAction('translate', this._aiSource(view, target, info.selText, 'en')) });
    items.push({ label: short ? 'AI 长难句解析' : 'AI 解析本段句子', action: () => this.ai.quickAction('analyze', this._aiSource(view, target, info.selText, 'en')) });
    if (short) items.push({ label: '引用到 AI 对话', action: () => this.ai.attachSelection({ text: info.selText, kind: 'selection' }) });
    items.push('-');
    if (image) {
      items.push({ label: '放大图片', hint: '单击图片', action: () => view.openImage(image) });
      items.push({ label: 'AI 解读图片', hint: this.ai.providerShort(), action: () => view.explainImage(image) });
    }
    if (link) {
      const href = link.getAttribute('href') || '';
      items.push({ label: /^https?:/i.test(href) ? '在浏览器中打开链接' : '跳转到链接位置', action: () => view._followLink(link) });
    }
    if (image || link) items.push('-');
    items.push({ label: '在此添加书签', hint: 'Ctrl+D', action: () => this.addBookmark() });
    if (item && view.effMode !== 'original') {
      items.push({ label: '配对调整', submenu: this.alignItems(view, item, target) });
    }
    items.push({ label: '显示模式', submenu: Object.entries(MODE_LABEL).map(([m, l]) => ({ label: l, checked: view.mode === m, action: () => this.setMode(m) })) });
    openMenu(info.x, info.y, items);
  }

  alignItems(view, item, target) {
    const seg = item.seg;
    const gi = item.gi;
    const n = seg.groups.length;
    const g = seg.groups[gi];
    const nx = seg.groups[gi + 1];
    const at = target ? view.unitIndexInGroup(item, target) : null;
    const list = [
      { header: `本组：英文 ${g.en.length} 段 · 中文 ${g.zh.length} 段${seg.overridden ? '（已手动调整）' : ''}` },
      { label: '与下一组合并', disabled: gi >= n - 1, action: () => view.alignOp(item, 'merge-next') },
      { label: '与上一组合并', disabled: gi === 0, action: () => view.alignOp(item, 'merge-prev') },
      { label: '拆分为逐段对应', disabled: g.en.length <= 1 && g.zh.length <= 1, action: () => view.alignOp(item, 'split') },
    ];
    if (at && at.index > 0) list.push({ label: `从这段${at.lang === 'en' ? '英文' : '中文'}起拆成新组`, action: () => view.alignOp(item, 'split-at', at) });
    list.push('-',
      { label: '英文末段移到下一组', disabled: g.en.length < 1, action: () => view.alignOp(item, 'en-down') },
      { label: '下一组英文首段移入本组', disabled: !nx || nx.en.length < 1, action: () => view.alignOp(item, 'en-up') },
      { label: '中文末段移到下一组', disabled: g.zh.length < 1, action: () => view.alignOp(item, 'zh-down') },
      { label: '下一组中文首段移入本组', disabled: !nx || nx.zh.length < 1, action: () => view.alignOp(item, 'zh-up') },
      '-',
      { label: '恢复本段自动配对', disabled: !seg.overridden, action: () => view.resetAlign('seg', item) },
      { label: '恢复本章全部自动配对', action: () => view.resetAlign('chapter') });
    return list;
  }

  openAlignMenu(x, y, view, item, target) {
    openMenu(x, y, this.alignItems(view, item, target), { minWidth: 230 });
  }

  openPdfMenu(info) {
    const { selText, view } = info;
    const short = selText.trim();
    const items = [
      { label: '复制', hint: 'Ctrl+C', disabled: !short, action: () => this.copyOut(short) },
      '-',
      { label: short ? `查词“${short.length > 24 ? short.slice(0, 24) + '…' : short}”` : '查词', disabled: !short || short.length > 60, action: () => this.lookup(short, info.range ? view.contextFor(info.range) : null) },
      { label: '查词并加入生词本', disabled: !short || short.length > 60, action: async () => { await this.lookup(short, info.range ? view.contextFor(info.range) : null); await this.dict.addVocab(); } },
      '-',
      this.speaking || this.tts.active ? { label: this.tts.active ? '停止连续朗读' : '停止朗读', action: () => this.stopSpeaking() } : { label: '朗读所选', disabled: !short, action: () => this.speakText(selText) },
      this.tts.active ? null : { label: '从这里开始连续朗读', hint: 'Ctrl+Shift+U', action: () => this.tts.start(info.range ? { node: info.range.startContainer, offset: info.range.startOffset, page: info.at && info.at.page } : info.at ? { page: info.at.page, clientY: info.y } : null) },
      { label: '听写练习（从这里开始）', hint: 'Ctrl+Shift+P', action: () => this.practice.start('dictate', info.range ? { node: info.range.startContainer, offset: info.range.startOffset, page: info.at && info.at.page } : info.at ? { page: info.at.page, clientY: info.y } : null) },
      { label: 'AI 解释所选', hint: this.ai.providerShort(), disabled: !short, action: () => this.ai.quickAction('explain', { text: selText, kind: 'selection' }) },
      { label: 'AI 翻译所选', disabled: !short, action: () => this.ai.quickAction('translate', { text: selText, kind: 'selection' }) },
      { label: 'AI 长难句解析', disabled: !short, action: () => this.ai.quickAction('analyze', { text: selText, kind: 'selection' }) },
      '-',
      { label: '放大查看（图片 / 图表）', hint: '双击图片', disabled: !info.at, action: () => info.at && view.zoomAt(info.at.page, info.at.x, info.at.y, info.at.cssWidth) },
      { label: 'AI 解读此处的图表', hint: this.ai.providerShort(), disabled: !info.at, action: () => info.at && view.explainAt(info.at.page, info.at.x, info.at.y) },
      '-',
      { label: '在此添加书签', hint: 'Ctrl+D', action: () => this.addBookmark() },
      { label: '适合宽度', action: () => this.pdf.setScale('page-width') },
      { label: '适合整页', action: () => this.pdf.setScale('page-fit') },
      { label: '实际大小', action: () => this.pdf.setScale(1) },
    ];
    openMenu(info.x, info.y, items);
  }

  // ------------------------------------------------------------------ pairing handle / column drag
  showPairHandle(view, item, row) {
    if (document.body.classList.contains('clean')) return;
    clearTimeout(this._phTimer);
    const ph = document.getElementById('pair-handle');
    const ch = document.getElementById('col-handle');
    const fr = view.frame.getBoundingClientRect();
    const rr = row.getBoundingClientRect();
    this._phItem = item;
    this._phView = view;
    let x;
    const a = item.enCell && item.enCell.getBoundingClientRect();
    const b = item.zhCell && item.zhCell.getBoundingClientRect();
    // columns can be stacked in a narrow window even in 双栏 mode
    const sideBySide = view.effMode === 'two' && a && b && (a.right <= b.left + 2 || b.right <= a.left + 2);
    if (sideBySide) {
      const left = Math.min(a.right, b.right);
      const right = Math.max(a.left, b.left);
      x = (left + right) / 2;
      ch.hidden = false;
      ch.style.left = fr.left + x - 4 + 'px';
      ch.style.top = fr.top + 'px';
      ch.style.height = fr.height + 'px';
      this._colRow = { left: fr.left + rr.left, right: fr.left + rr.right, view };
      ph.style.left = fr.left + x - 9 + 'px';
    } else {
      ch.hidden = true;
      ph.style.left = fr.left + Math.max(2, rr.left - 22) + 'px';
    }
    ph.style.top = fr.top + Math.max(0, rr.top) + 'px';
    ph.hidden = rr.bottom < 0 || rr.top > fr.height;
    ph.classList.toggle('manual', !!item.seg.overridden);
    ph.title = `配对调整（英 ${item.en.length} · 中 ${item.zh.length}）`;
  }

  hidePairHandle(soft) {
    const doHide = () => {
      document.getElementById('pair-handle').hidden = true;
      if (!this._colDragging) document.getElementById('col-handle').hidden = true;
    };
    clearTimeout(this._phTimer);
    if (soft) this._phTimer = setTimeout(doHide, 350); else doHide();
  }

  _dragColumns(e) {
    if (!this._colRow) return;
    e.preventDefault();
    const cover = el('div', { class: 'drag-cover col' });
    document.body.append(cover);
    this._colDragging = true;
    const { left, right } = this._colRow;
    const move = (ev) => {
      const ratio = clamp(Math.round(((ev.clientX - left) / Math.max(1, right - left)) * 100), 25, 75);
      this.settings.colRatio = this.settings.zhLeft ? 100 - ratio : ratio;
      this.flow.applySettings(this.settings);
      document.getElementById('col-handle').style.left = ev.clientX - 4 + 'px';
      this.flashStatus(`中英栏宽 ${this.settings.colRatio} : ${100 - this.settings.colRatio}`);
    };
    const up = () => {
      cover.remove();
      this._colDragging = false;
      window.removeEventListener('mousemove', move);
      window.removeEventListener('mouseup', up);
      this.hidePairHandle();
      this.saveSettingsSoon();
    };
    window.addEventListener('mousemove', move);
    window.addEventListener('mouseup', up);
  }

  // ------------------------------------------------------------------ keyboard
  onKeyDown(e, origin) {
    if (this.lightbox.onKey(e)) return;
    const k = e.key;
    if (k === 'Escape') {
      if (isMenuOpen()) closeMenu();
      else if (this.popoverOpen) closePopover(this);
      else if (this.modalOpen) closeModal(this);
      else if (document.body.classList.contains('clean')) this.toggleClean(false);
      else if (this.search.query) { this.search.reset(); this.flow.clearHighlights(); this.pdf.clearFind(); }
      else if (this.tts.active) this.tts.stop();
      else return;
      e.preventDefault();
      return;
    }
    if (['F6', 'F7', 'F8', 'F9', 'F11', 'F12'].includes(k)) { e.preventDefault(); this.handleShortcut(k); return; }
    if (e.altKey && (k === 'ArrowUp' || k === 'ArrowLeft')) { e.preventDefault(); this.goBack(); return; }
    if (k === 'F3') { e.preventDefault(); this.searchStep(e.shiftKey ? -1 : 1); return; }
    if (this.modalOpen || isEditable(e.target)) return;
    const ctrl = e.ctrlKey || e.metaKey;
    const lk = k.length === 1 ? k.toLowerCase() : k;
    if (ctrl) {
      if (lk === 'o') { e.preventDefault(); this.pickAndOpen(); return; }
      if (lk === 'f') { e.preventDefault(); this.showPanel('search'); return; }
      if (lk === 'd') { e.preventDefault(); this.addBookmark(); return; }
      if (lk === 'b') { e.preventDefault(); this.togglePanel('left'); return; }
      if (lk === 'l') { e.preventDefault(); this.togglePanel('right'); return; }
      if (lk === 'j') { e.preventDefault(); this.openAi(); return; }
      if (lk === 'r') { e.preventDefault(); this.study.startReview(); return; }
      if (lk === 'u' && e.shiftKey) { e.preventDefault(); this.tts.toggle(); return; }
      if (lk === 'p' && e.shiftKey) { e.preventDefault(); this.startPractice(); return; }
      if (k === '=' || k === '+') { e.preventDefault(); this.zoom(1); return; }
      if (k === '-') { e.preventDefault(); this.zoom(-1); return; }
      if (k === '0') { e.preventDefault(); this.zoom(0); return; }
      if (k === 'ArrowRight' && this.view) { e.preventDefault(); if (this.view === this.flow) this.flow.next(); else this.pdf.page(1); return; }
      if (k === 'ArrowLeft' && this.view) { e.preventDefault(); if (this.view === this.flow) this.flow.prev(false); else this.pdf.page(-1); return; }
      return;
    }
    if (!this.view) return;
    if (this.view === this.flow) {
      const doc = this.flow.doc;
      if (!doc) return;
      const se = doc.scrollingElement;
      const h = this.flow.win.innerHeight;
      if ((k === 'PageDown' || (k === ' ' && !e.shiftKey)) && se.scrollTop + h >= se.scrollHeight - 2) { e.preventDefault(); this.flow.next(); return; }
      if ((k === 'PageUp' || (k === ' ' && e.shiftKey)) && se.scrollTop <= 0) { e.preventDefault(); this.flow.prev(true); return; }
      if (origin === 'main') {
        const map = { ArrowDown: 60, ArrowUp: -60, PageDown: h - 48, PageUp: -(h - 48), ' ': e.shiftKey ? -(h - 48) : h - 48 };
        if (k in map) { e.preventDefault(); se.scrollBy({ top: map[k] }); }
        else if (k === 'Home') se.scrollTop = 0;
        else if (k === 'End') se.scrollTop = se.scrollHeight;
      }
    }
  }

  handleShortcut(k) {
    if (this.practice.open && (k === 'F6' || k === 'F7' || k === 'F9')) return;
    if (k === 'F6') this.toggleTwo();
    else if (k === 'F7') this.toggleBlur();
    else if (k === 'F8') this.toggleCompact();
    else if (k === 'F9') this.toggleClean();
    else if (k === 'F11') api.call('win', 'fullscreen').catch(() => {});
    else if (k === 'F12') api.call('win', 'devtools').catch(() => {});
    else if (k === 'Escape') this.onKeyDown(new KeyboardEvent('keydown', { key: 'Escape' }), 'main');
    else if (k === 'back') this.goBack();
  }

  zoom(dir) {
    if (this.view === this.pdf) {
      if (dir === 0) this.pdf.setScale('page-width'); else this.pdf.zoom(dir > 0 ? 1.15 : 1 / 1.15);
      return;
    }
    if (dir === 0) this.settings.fontSize = DEFAULTS.fontSize;
    else this.settings.fontSize = clamp(this.settings.fontSize + dir, 10, 40);
    this.applySettings();
    this.flashStatus('字号 ' + this.settings.fontSize + 'px');
  }

  openSettings(tab) { openSettings(this, tab); }

  refocusReader() {
    if (this.view === this.flow && this.flow.win) { try { this.flow.win.focus(); } catch { /* ignore */ } }
    else if (this.view === this.pdf) this.pdf.container.focus();
  }

  // ------------------------------------------------------------------ drag & drop
  onDragOver(e) {
    if (e.dataTransfer && [...e.dataTransfer.types].includes('Files')) {
      document.getElementById('drop-overlay').hidden = false;
      clearTimeout(this._dropTimer);
      this._dropTimer = setTimeout(() => this.hideDrop(), 400);
    }
  }

  hideDrop() { document.getElementById('drop-overlay').hidden = true; }

  async onDrop(e) {
    e.preventDefault();
    this.hideDrop();
    const files = [...((e.dataTransfer && e.dataTransfer.files) || [])];
    const paths = files.map((f) => api.pathForFile(f)).filter(Boolean);
    if (!paths.length) { if (files.length) toast('无法获取文件路径'); return; }
    const dicts = paths.filter((p) => DICT_RE.test(p));
    const books = paths.filter((p) => BOOK_RE.test(p));
    if (dicts.length) await importDicts(this, 'any', dicts);
    if (books.length) await this.openPath(books[0]);
    else if (!dicts.length) toast('不支持的文件类型（支持 EPUB、PDF、HTML；词库支持 MDX、CSV）');
  }

  // ------------------------------------------------------------------ misc
  async openExternal(url) {
    const ok = await this.confirm(`在浏览器中打开外部链接？\n${url}`);
    if (!ok) return;
    if (api.isElectron) api.call('openExternal', url); else window.open(url, '_blank', 'noopener');
  }

  onWindowState(s) {
    const b = document.getElementById('win-max');
    if (b) {
      b.innerHTML = icon(s && s.maximized ? 'restore' : 'max', 16);
      b.title = s && s.maximized ? '还原' : '最大化';
    }
    document.body.classList.toggle('maximized', !!(s && s.maximized));
    document.body.classList.toggle('fullscreen', !!(s && s.fullscreen));
  }

  async beforeClose() {
    try {
      await this.study.flush();
      await this.savePosition();
      await api.call('saveSettings', this.settings);
    } finally {
      api.call('closeReady').catch(() => {});
    }
  }

  prompt(title, value = '', { multiline = false } = {}) {
    return new Promise((resolve) => {
      const modal = document.getElementById('modal');
      const input = multiline ? el('textarea', { rows: 4 }) : el('input', { type: 'text' });
      input.value = value;
      const done = (v) => { modal.hidden = true; modal.replaceChildren(); this.modalOpen = false; resolve(v); this.refocusReader(); };
      input.addEventListener('keydown', (e) => {
        e.stopPropagation();
        if (e.key === 'Enter' && (!multiline || e.ctrlKey)) done(input.value);
        if (e.key === 'Escape') done(null);
      });
      modal.replaceChildren(el('div', { class: 'modal-box small' },
        el('div', { class: 'modal-head' }, el('span', {}, title)),
        el('div', { class: 'modal-pad' }, input),
        el('div', { class: 'modal-foot' }, el('button', { onclick: () => done(null) }, '取消'), el('button', { class: 'primary', onclick: () => done(input.value) }, '确定'))));
      modal.hidden = false;
      modal.onclick = (e) => { if (e.target === modal) done(null); };
      this.modalOpen = true;
      setTimeout(() => { input.focus(); input.select && input.select(); }, 20);
    });
  }

  confirm(text) {
    return new Promise((resolve) => {
      const modal = document.getElementById('modal');
      const done = (v) => { modal.hidden = true; modal.replaceChildren(); this.modalOpen = false; resolve(v); this.refocusReader(); };
      const ok = el('button', { class: 'primary', onclick: () => done(true) }, '确定');
      modal.replaceChildren(el('div', { class: 'modal-box small' },
        el('div', { class: 'modal-pad pre' }, text),
        el('div', { class: 'modal-foot' }, el('button', { onclick: () => done(false) }, '取消'), ok)));
      modal.hidden = false;
      modal.onclick = (e) => { if (e.target === modal) done(false); };
      this.modalOpen = true;
      setTimeout(() => ok.focus(), 20);
    });
  }
}

const app = new App();
window.app = app;
app.init().catch((e) => {
  console.error(e);
  toast('启动失败：' + e.message, { type: 'error', ms: 8000 });
});

export { escapeHtml };
