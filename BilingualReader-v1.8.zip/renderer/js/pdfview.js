// PDF view built on pdf.js (original page layout, text layer, links, outline, search).
import { clamp, debounce, throttle, toast } from './util.js';
import { sentenceAt, hasHan } from './textlang.js';

let pdfjsLib = null;
let viewerLib = null;

async function loadLibs() {
  if (pdfjsLib) return;
  pdfjsLib = await import('../vendor/pdfjs/build/pdf.mjs');
  globalThis.pdfjsLib = pdfjsLib;
  pdfjsLib.GlobalWorkerOptions.workerSrc = new URL('../vendor/pdfjs/build/pdf.worker.mjs', import.meta.url).href;
  viewerLib = await import('../vendor/pdfjs/web/pdf_viewer.mjs');
}

export class PdfView {
  constructor(app) {
    this.app = app;
    this.host = document.getElementById('pdf-host');
    this.container = document.getElementById('pdf-container');
    this.viewerEl = document.getElementById('pdf-viewer');
    this.pdf = null;
    this.viewer = null;
    this.saveSoon = debounce(() => this.app.savePosition(), 900);
    this.textCache = new Map();
    this._rects = new Map();
  }

  async open(info, target) {
    await loadLibs();
    this.close();
    this.host.hidden = false;
    const { EventBus, PDFLinkService, PDFFindController, PDFViewer, LinkTarget } = viewerLib;
    const eventBus = new EventBus();
    const linkService = new PDFLinkService({ eventBus, externalLinkTarget: LinkTarget.BLANK });
    const findController = new PDFFindController({ eventBus, linkService });
    // a fresh scroll container for each document: pdf.js leaves its own listeners on the old one
    const fresh = this.container.cloneNode(false);
    const fv = this.viewerEl.cloneNode(false);
    fresh.append(fv);
    this.container.replaceWith(fresh);
    this.container = fresh;
    this.viewerEl = fv;
    const viewer = new PDFViewer({
      container: this.container,
      viewer: this.viewerEl,
      eventBus,
      linkService,
      findController,
      textLayerMode: 1,
      annotationMode: pdfjsLib.AnnotationMode.ENABLE,
      removePageBorders: false,
    });
    linkService.setViewer(viewer);
    // record jumps so Alt+↑ can return
    const origGo = linkService.goToDestination.bind(linkService);
    linkService.goToDestination = async (dest) => {
      this.app.pushHistory(this.getPosition());
      this.app.showBackPill();
      return origGo(dest);
    };
    const origPage = linkService.goToPage.bind(linkService);
    linkService.goToPage = (val) => {
      this.app.pushHistory(this.getPosition());
      this.app.showBackPill();
      return origPage(val);
    };
    this.eventBus = eventBus;
    this.linkService = linkService;
    this.findController = findController;
    this.viewer = viewer;

    const url = new URL(info.entryUrl, location.href).href;
    const base = new URL('../vendor/pdfjs/', import.meta.url).href;
    const task = pdfjsLib.getDocument({
      url,
      cMapUrl: base + 'cmaps/',
      cMapPacked: true,
      standardFontDataUrl: base + 'standard_fonts/',
      wasmUrl: base + 'wasm/',
      iccUrl: base + 'iccs/',
      isEvalSupported: false,
      enableXfa: false,
    });
    this.task = task;
    let pdf;
    try {
      pdf = await task.promise;
    } catch (e) {
      this.host.hidden = true;
      throw new Error(e && e.name === 'PasswordException' ? '该 PDF 有密码保护，暂不支持' : 'PDF 打开失败：' + (e && e.message || e));
    }
    this.pdf = pdf;
    viewer.setDocument(pdf);
    linkService.setDocument(pdf, null);
    await new Promise((resolve) => eventBus.on('pagesinit', resolve, { once: true }));
    viewer.currentScaleValue = this.app.settings.pdfScale || 'page-width';
    this.app.applyPdfTheme();
    eventBus.on('updateviewarea', throttle(() => this._moved(), 150));
    eventBus.on('scalechanging', () => { this.app.settings.pdfScale = viewer.currentScaleValue; this.app.saveSettingsSoon(); this.app.updateStatus(); });
    eventBus.on('textlayerrendered', (e) => this._wireTextLayer(e.source && e.source.div));
    eventBus.on('updatefindmatchescount', (e) => this.app.pdfFindCount(e.matchesCount));
    let meta = {};
    try { meta = await pdf.getMetadata(); } catch { /* ignore */ }
    // PDF metadata titles are often placeholders ("untitled", "Microsoft Word - x.docx"): use the file name then
    let title = String((meta.info && meta.info.Title) || '').trim().replace(/^Microsoft (?:Word|PowerPoint|Excel) - /i, '').replace(/\.(?:docx?|pptx?|xlsx?|indd|tex)$/i, '').trim();
    if (!title || /^(?:untitled(?: document)?|unknown|no title|document\d*|无标题|未命名)$/i.test(title)) title = info.name.replace(/\.pdf$/i, '');
    const author = (meta.info && meta.info.Author) || '';
    let toc = [];
    try { toc = await this._outline(); } catch { toc = []; }
    this.book = { kind: 'pdf', format: 'pdf', title, author, toc, pages: pdf.numPages };
    if (target && target.page) this.goTo(target);
    this.container.addEventListener('dblclick', this._dbl = (e) => this._onDblClick(e));
    this.container.addEventListener('mouseup', this._up = (e) => this._onMouseUp(e));
    this.container.addEventListener('contextmenu', this._ctx = (e) => this._onContextMenu(e));
    this.container.addEventListener('mousedown', this._down = (e) => { this._downAt = { x: e.clientX, y: e.clientY, t: Date.now() }; this.app.closeMenus(); this.app.dismissOverlay(); if (e.button === 3) { e.preventDefault(); this.app.goBack(); } });
    // (mouseup, not click: pdf.js moves its text-layer helper element under the mouse while a caret is
    // in the text, and then no click event comes)
    this.container.addEventListener('mouseup', this._clickImg = (e) => this._onClickImage(e));
    // (when the mouse rests: pages passing under it while scrolling are not analysed)
    this.container.addEventListener('mousemove', this._moveImg = debounce((e) => this._hoverImage(e), 120));
    this.container.addEventListener('click', this._click = (e) => {
      const a = e.target.closest('a[href]');
      if (a && /^https?:|^mailto:/i.test(a.getAttribute('href'))) {
        e.preventDefault();
        e.stopPropagation();
        this.app.openExternal(a.href);
      }
    }, true);
    this._moved(true);
    return this.book;
  }

  async _outline() {
    const outline = await this.pdf.getOutline();
    if (!outline || !outline.length) {
      const n = this.pdf.numPages;
      const step = n > 60 ? 10 : 1;
      const out = [];
      for (let p = 1; p <= n; p += step) out.push({ label: `第 ${p} 页`, page: p, children: [] });
      return n > 1 ? out : [];
    }
    const resolve = async (dest) => {
      try {
        let d = dest;
        if (typeof d === 'string') d = await this.pdf.getDestination(d);
        if (!Array.isArray(d)) return null;
        const ref = d[0];
        const idx = typeof ref === 'object' ? await this.pdf.getPageIndex(ref) : ref;
        return { page: idx + 1, dest: d };
      } catch { return null; }
    };
    const walk = async (items, depth) => {
      const out = [];
      for (const it of items) {
        const r = it.dest ? await resolve(it.dest) : null;
        out.push({ label: (it.title || '').trim() || '（无标题）', page: r ? r.page : null, dest: r ? r.dest : null, url: it.url || null, depth, children: it.items && it.items.length ? await walk(it.items, depth + 1) : [] });
      }
      return out;
    };
    return walk(outline, 0);
  }

  close() {
    this._rects = new Map();
    this._rectsDone = new Map();
    this._hoverPage = null;
    if (this.task) { try { this.task.destroy(); } catch { /* ignore */ } }
    this.task = null;
    if (this.pdf) { try { this.pdf.destroy(); } catch { /* ignore */ } }
    this.pdf = null;
    if (this.viewer) { try { this.viewer.setDocument(null); } catch { /* ignore */ } }
    this.viewer = null;
    this.viewerEl.replaceChildren();
    this.host.hidden = true;
    for (const [ev, fn] of [['dblclick', this._dbl], ['mouseup', this._up], ['contextmenu', this._ctx], ['mousedown', this._down], ['click', this._click], ['mouseup', this._clickImg], ['mousemove', this._moveImg]]) {
      if (fn) this.container.removeEventListener(ev, fn, ev === 'click');
    }
    this.textCache.clear();
  }

  getPosition() {
    if (!this.viewer || !this.pdf) return null;
    const loc = this.viewer._location;
    const page = loc && loc.pageNumber ? loc.pageNumber : this.viewer.currentPageNumber;
    const n = this.pdf.numPages;
    const pos = { kind: 'pdf', page, percent: clamp((page - 1) / Math.max(1, n - 1), 0, 1) };
    if (loc && loc.pageNumber === page) { pos.top = loc.top; pos.left = loc.left; }
    const c = this.container;
    pos.scrollFrac = c.scrollHeight > c.clientHeight ? c.scrollTop / (c.scrollHeight - c.clientHeight) : 0;
    return pos;
  }

  goTo(pos) {
    if (!this.viewer || !pos) return;
    if (pos.dest) { this.viewer.scrollPageIntoView({ pageNumber: pos.page, destArray: pos.dest }); return; }
    const page = clamp(pos.page || 1, 1, this.pdf.numPages);
    if (pos.top != null) {
      this.viewer.scrollPageIntoView({ pageNumber: page, destArray: [null, { name: 'XYZ' }, pos.left || 0, pos.top, null], allowNegativeOffset: true });
    } else {
      this.viewer.currentPageNumber = page;
    }
  }

  _moved(initial) {
    const pos = this.getPosition();
    if (!pos) return;
    this.app.onPositionChange(pos);
    if (!initial) this.saveSoon();
  }

  setScale(v) {
    if (!this.viewer) return;
    if (typeof v === 'number') this.viewer.currentScale = clamp(v, 0.25, 6);
    else this.viewer.currentScaleValue = v;
  }

  zoom(f) {
    if (!this.viewer) return;
    this.setScale(this.viewer.currentScale * f);
  }

  page(dir) {
    if (!this.viewer) return;
    const c = this.container;
    c.scrollBy({ top: dir * (c.clientHeight - 40) });
  }

  // ------------------------------------------------ text layer / lookups
  _wireTextLayer(div) {
    if (!div) return;
    div.classList.add('br-pdf-text');
  }

  _context(range) {
    const span = range.startContainer.parentElement;
    const layer = span && span.closest('.textLayer');
    if (!layer) return { sentence: '', offset: 0 };
    const spans = [...layer.querySelectorAll('span[role="presentation"], span:not(:has(span))')];
    let text = '';
    let offset = -1;
    for (const s of spans) {
      if (s === span || s.contains(range.startContainer)) offset = text.length + range.startOffset;
      text += s.textContent + (/\s$/.test(s.textContent) ? '' : ' ');
    }
    if (offset < 0) offset = 0;
    const lang = hasHan(range.toString()) ? 'zh' : 'en';
    const st = sentenceAt(text, offset, lang);
    const before = text.slice(st.start, offset).replace(/\s+/g, ' ');
    return { sentence: st.text.replace(/\s+/g, ' ').trim().slice(0, 600), offset: before.trimStart().length, lang, chapter: `第 ${this.viewer.currentPageNumber} 页`, pos: this.getPosition() };
  }

  // a click on a picture of the page (not on its text, not a drag or a selection) opens it in the viewer.
  // Pictures covering most of the page (scanned pages, page backgrounds) and tiny ones are left out:
  // use the right-click menu "放大查看" there.
  _onClickImage(e) {
    if (e.button !== 0 || e.detail > 1 || !this.pdf) return;
    const d = this._downAt;
    if (!d || Date.now() - d.t > 1500 || Math.hypot(e.clientX - d.x, e.clientY - d.y) > 4) return;
    const t = e.target;
    if (t.closest && t.closest('.textLayer span, a, .annotationLayer section, button, input, select, textarea')) return;
    const sel = document.getSelection();
    if (sel && !sel.isCollapsed && this.container.contains(sel.anchorNode)) return;
    const at = this.pointAt(e.clientX, e.clientY);
    if (!at) return;
    this.imageRects(at.page).then((rects) => {
      const hit = rects.filter((r) => at.x >= r.x && at.x <= r.x + r.w && at.y >= r.y && at.y <= r.y + r.h && r.w * r.h <= 0.6 && r.w * r.h >= 0.003);
      if (hit.length) this.zoomAt(at.page, at.x, at.y, at.cssWidth);
    }).catch(() => {});
  }

  _onDblClick(e) {
    const sel = document.getSelection();
    const text = sel && sel.rangeCount && this.container.contains(sel.anchorNode) ? sel.toString().trim() : '';
    if (!text || !this.app.settings.lookupDblClick) return;
    if (text && text.length <= 60) this.app.lookup(text, this._context(sel.getRangeAt(0)));
  }

  // ------------------------------------------------ image viewer
  // page number and position (0..1 of the page) under a point of the window
  pointAt(x, y) {
    const els = document.elementsFromPoint(x, y);
    const pageEl = els.map((n) => n.closest && n.closest('.page[data-page-number]')).find(Boolean);
    if (!pageEl) return null;
    const box = (pageEl.querySelector('.canvasWrapper') || pageEl).getBoundingClientRect();
    if (!box.width || !box.height) return null;
    return { page: +pageEl.dataset.pageNumber, x: clamp((x - box.left) / box.width, 0, 1), y: clamp((y - box.top) / box.height, 0, 1), cssWidth: box.width };
  }

  // rectangles (0..1 of the page) where the page draws pictures, worked out from its drawing operations
  // (one computation per page, shared by concurrent callers; the finished lists are also kept in
  // _rectsDone for the mouse cursor)
  imageRects(n) {
    if (!this._rects) this._rects = new Map();
    if (!this._rectsDone) this._rectsDone = new Map();
    if (!this._rects.has(n)) {
      if (this._rects.size > 60) { this._rects.clear(); this._rectsDone.clear(); }
      const p = this._computeRects(n).then((r) => { if (this._rects.get(n) === p) this._rectsDone.set(n, r); return r; });
      p.catch(() => { if (this._rects.get(n) === p) this._rects.delete(n); });
      this._rects.set(n, p);
    }
    return this._rects.get(n);
  }

  async _computeRects(n) {
    const page = await this.pdf.getPage(n);
    const vp = page.getViewport({ scale: 1, rotation: this.viewer ? this.viewer.pagesRotation : 0 });
    const ops = await page.getOperatorList();
    const O = pdfjsLib.OPS;
    const paint = new Set([O.paintImageXObject, O.paintInlineImageXObject, O.paintImageMaskXObject].filter((x) => x != null));
    const mul = (a, b) => [a[0] * b[0] + a[2] * b[1], a[1] * b[0] + a[3] * b[1], a[0] * b[2] + a[2] * b[3], a[1] * b[2] + a[3] * b[3], a[0] * b[4] + a[2] * b[5] + a[4], a[1] * b[4] + a[3] * b[5] + a[5]];
    let m = [1, 0, 0, 1, 0, 0];
    const stack = [];
    const rects = [];
    for (let i = 0; i < ops.fnArray.length; i++) {
      const fn = ops.fnArray[i];
      const args = ops.argsArray[i];
      if (fn === O.save) stack.push(m);
      else if (fn === O.restore) m = stack.pop() || [1, 0, 0, 1, 0, 0];
      else if (fn === O.transform) m = mul(m, args);
      else if (fn === O.paintFormXObjectBegin) {
        stack.push(m);
        const fm = args && args[0];
        if (fm && fm.length === 6) m = mul(m, Array.from(fm));
      } else if (fn === O.paintFormXObjectEnd) m = stack.pop() || m;
      else if (paint.has(fn)) {
        const pts = [[0, 0], [1, 0], [0, 1], [1, 1]].map(([x, y]) => vp.convertToViewportPoint(m[0] * x + m[2] * y + m[4], m[1] * x + m[3] * y + m[5]));
        const xs = pts.map((p) => p[0]);
        const ys = pts.map((p) => p[1]);
        const x0 = Math.max(0, Math.min(...xs));
        const x1 = Math.min(vp.width, Math.max(...xs));
        const y0 = Math.max(0, Math.min(...ys));
        const y1 = Math.min(vp.height, Math.max(...ys));
        const w = x1 - x0;
        const h = y1 - y0;
        // skip tiny pictures and whole-page backgrounds (scanned pages)
        if (w > 36 && h > 36 && w * h < vp.width * vp.height * 0.85) rects.push({ x: x0 / vp.width, y: y0 / vp.height, w: w / vp.width, h: h / vp.height });
      }
    }
    return rects;
  }

  // a zoom-in mouse cursor over the pictures a click opens
  _hoverImage(e) {
    if (e.buttons || !this.pdf) return;
    const at = this.pointAt(e.clientX, e.clientY);
    const pageEl = at ? this.viewerEl.querySelector(`.page[data-page-number="${at.page}"]`) : null;
    let hit = false;
    if (at) {
      const rects = this._rectsDone && this._rectsDone.get(at.page);
      if (rects) hit = rects.some((r) => at.x >= r.x && at.x <= r.x + r.w && at.y >= r.y && at.y <= r.y + r.h && r.w * r.h <= 0.6 && r.w * r.h >= 0.003);
      else this.imageRects(at.page).catch(() => {});
    }
    if (this._hoverPage && this._hoverPage !== pageEl) this._hoverPage.classList.remove('br-pic-hover');
    if (pageEl) pageEl.classList.toggle('br-pic-hover', hit);
    this._hoverPage = pageEl;
  }

  // a page drawn at high resolution (width ≈ targetW px, at most 24 megapixels)
  async renderPageCanvas(n, targetW = 3200) {
    const page = await this.pdf.getPage(n);
    const rotation = this.viewer ? this.viewer.pagesRotation : 0;
    const base = page.getViewport({ scale: 1, rotation });
    let scale = Math.min(6, targetW / base.width);
    const area = base.width * base.height * scale * scale;
    if (area > 24e6) scale *= Math.sqrt(24e6 / area);
    const vp = page.getViewport({ scale, rotation });
    const canvas = document.createElement('canvas');
    canvas.width = Math.floor(vp.width);
    canvas.height = Math.floor(vp.height);
    await page.render({ canvas, viewport: vp }).promise;
    return canvas;
  }

  // a page rendered at high resolution as an image (object URL)
  async renderPage(n) {
    const canvas = await this.renderPageCanvas(n);
    const blob = await new Promise((res, rej) => canvas.toBlob((b) => (b ? res(b) : rej(new Error('无法生成页面图片'))), 'image/png'));
    const width = canvas.width;
    canvas.width = 0;
    canvas.height = 0;
    return { src: URL.createObjectURL(blob), width };
  }

  // asks the AI about the picture at (x, y) of page n, or about the area around that point
  async explainAt(n, x, y) {
    if (!this.pdf) return;
    try {
      let r = null;
      try {
        const rects = await this.imageRects(n);
        r = rects.filter((q) => x >= q.x && x <= q.x + q.w && y >= q.y && y <= q.y + q.h).sort((a, b) => a.w * a.h - b.w * b.h)[0] || null;
      } catch { r = null; }
      if (r) r = { x: Math.max(0, r.x - 0.01), y: Math.max(0, r.y - 0.01), w: Math.min(1 - Math.max(0, r.x - 0.01), r.w + 0.02), h: Math.min(1 - Math.max(0, r.y - 0.01), r.h + 0.02) };
      else {
        // no picture there (vector chart, table …): the area around the point
        const w = 0.6;
        const h = 0.36;
        r = { x: clamp(x - w / 2, 0, 1 - w), y: clamp(y - h / 2, 0, 1 - h), w, h };
      }
      toast('正在准备图片…', { ms: 1500 });
      const page = await this.renderPageCanvas(n, Math.min(4800, 1800 / r.w));
      const sx = r.x * page.width;
      const sy = r.y * page.height;
      const sw = r.w * page.width;
      const sh = r.h * page.height;
      const k = Math.min(1, 1600 / Math.max(sw, sh));
      const c = document.createElement('canvas');
      c.width = Math.max(1, Math.round(sw * k));
      c.height = Math.max(1, Math.round(sh * k));
      const g = c.getContext('2d');
      g.fillStyle = '#fff';
      g.fillRect(0, 0, c.width, c.height);
      g.drawImage(page, sx, sy, sw, sh, 0, 0, c.width, c.height);
      page.width = 0;
      page.height = 0;
      this.app.ai.askImage({ dataUrl: c.toDataURL('image/jpeg', 0.9), title: `第 ${n} 页` });
    } catch (e) {
      toast('无法读取这一页的图片：' + e.message, { type: 'error' });
    }
  }

  // image viewer on page n at (x, y): the picture there fills the window, otherwise the spot is shown enlarged;
  // ← → move through the pages
  async zoomAt(n, x, y, cssWidth) {
    if (!this.pdf) return;
    const pageEl = this.viewerEl.querySelector(`.page[data-page-number="${n}"]`);
    const shownW = cssWidth || (pageEl ? pageEl.getBoundingClientRect().width : 800);
    let rect = null;
    try {
      const rects = await this.imageRects(n);
      rect = rects.filter((r) => x >= r.x && x <= r.x + r.w && y >= r.y && y <= r.y + r.h).sort((a, b) => a.w * a.h - b.w * b.h)[0] || null;
    } catch { rect = null; }
    const title = (this.book && this.book.title) || 'PDF';
    const items = [];
    for (let p = 1; p <= this.pdf.numPages; p++) {
      items.push({
        title: `${title} · 第 ${p} 页`,
        name: `${title} 第${p}页`,
        load: async () => {
          const r = await this.renderPage(p);
          let focus = null;
          if (p === n) {
            focus = rect
              ? { x: Math.max(0, rect.x - 0.01), y: Math.max(0, rect.y - 0.01), w: Math.min(1, rect.w + 0.02), h: Math.min(1, rect.h + 0.02) }
              : { x, y, scale: (2 * shownW) / r.width };
          }
          return { src: r.src, revoke: true, focus };
        },
      });
    }
    this.app.showImages(items, n - 1);
  }

  _onMouseUp(e) {
    if (e.button === 0) setTimeout(() => { const s = document.getSelection(); if (s && !s.isCollapsed && this.container.contains(s.anchorNode)) this.app.noteSelection(this, s.toString()); }, 0);
    if (e.button !== 0 || e.detail >= 2 || !this.app.settings.lookupSelection) return;
    setTimeout(() => {
      const sel = document.getSelection();
      if (!sel || sel.isCollapsed || !this.container.contains(sel.anchorNode)) return;
      const text = sel.toString().replace(/\s+/g, ' ').trim();
      const ok = hasHan(text) ? text.length <= 8 : /[A-Za-z]/.test(text) && text.split(' ').length <= 6 && text.length <= 60;
      if (ok) this.app.lookup(text, this._context(sel.getRangeAt(0)));
    }, 10);
  }

  _onContextMenu(e) {
    e.preventDefault();
    const sel = document.getSelection();
    const selText = sel && !sel.isCollapsed && this.container.contains(sel.anchorNode) ? sel.toString() : '';
    this.app.openPdfMenu({ x: e.clientX, y: e.clientY, view: this, selText, range: selText ? sel.getRangeAt(0) : null, at: this.pointAt(e.clientX, e.clientY) });
  }

  contextFor(range) { return this._context(range); }

  // ------------------------------------------------ search
  async pageText(i) {
    if (this.textCache.has(i)) return this.textCache.get(i);
    const page = await this.pdf.getPage(i);
    const tc = await page.getTextContent();
    let t = '';
    for (const it of tc.items) {
      if (!('str' in it)) continue;
      t += it.str + (it.hasEOL ? '\n' : '');
    }
    this.textCache.set(i, t);
    return t;
  }

  find(query, opts = {}, again = false, prev = false) {
    if (!this.eventBus) return;
    this.eventBus.dispatch('find', {
      source: this,
      type: again ? 'again' : '',
      query,
      caseSensitive: !!opts.caseSensitive,
      entireWord: !!opts.wholeWord,
      highlightAll: true,
      findPrevious: prev,
      matchDiacritics: false,
    });
  }

  clearFind() {
    if (this.eventBus) this.eventBus.dispatch('findbarclose', { source: this });
  }

  get pages() { return this.pdf ? this.pdf.numPages : 0; }
}
