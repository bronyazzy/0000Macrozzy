// Settings model, typography / theme popovers and the settings dialog (incl. dictionary manager).
import { el, toast } from './util.js';
import * as api from './api.js';
import { REVIEW_MODES } from './study.js';

export const DEFAULTS = {
  fontSize: 18,
  lineHeight: 1.75,
  paraSpacing: 0.7,
  pageWidth: 1180,
  colRatio: 50,
  gutter: 36,
  overrideTypography: true,
  fontEn: '',
  fontZh: '',
  zhColor: '',
  zhLeft: false,
  showPairSep: true,
  theme: 'light',
  customBg: '#f4efe6',
  customFg: '#2b2b2b',
  eyeCare: false,
  eyeCareStrength: 22,
  defaultMode: 'two',
  lastNonTwoMode: 'original',
  dictCompact: false,
  lookupDblClick: true,
  imageWindow: true,
  lookupSelection: true,
  autoOpenDict: true,
  reopenLast: true,
  pdfScale: 'page-width',
  leftOpen: true,
  leftWidth: 270,
  leftTab: 'toc',
  rightOpen: true,
  rightWidth: 340,
  rightTab: 'dict',
  // learning
  vocabHighlight: true,
  srsNewPerDay: 20,
  reviewSpeak: true,
  ttsRate: 0.9,
  ttsVoice: '',
  ttsShadow: false,
  reviewMode: 'mixed',
  readWpm: 150,
  readCpm: 350,
  blurMode: '',
  practiceMode: 'translate',
  goalRead: 30,
  goalPractice: 0,
  goalDoneDay: '',
};

export const THEMES = {
  light: { label: '白色', bg: '#ffffff', fg: '#1f2328', link: '#1a5fb4', ui: 'light' },
  sepia: { label: '米黄', bg: '#f6efe1', fg: '#3b3127', link: '#8a4b0f', ui: 'light' },
  green: { label: '护眼绿', bg: '#cce8cf', fg: '#1e2b1f', link: '#1d5e2f', ui: 'light' },
  gray: { label: '浅灰', bg: '#ececec', fg: '#222222', link: '#1a5fb4', ui: 'light' },
  dark: { label: '夜间', bg: '#1e1f22', fg: '#c9ccd1', link: '#7fb0ff', ui: 'dark' },
};

export const FONTS_EN = [['', '原书字体'], ['Georgia, serif', 'Georgia'], ['"Times New Roman", serif', 'Times New Roman'], ['Cambria, serif', 'Cambria'],
  ['"Palatino Linotype", Palatino, serif', 'Palatino'], ['"Segoe UI", sans-serif', 'Segoe UI'], ['Calibri, sans-serif', 'Calibri'], ['Arial, sans-serif', 'Arial'],
  ['Verdana, sans-serif', 'Verdana'], ['Consolas, monospace', 'Consolas']];
export const FONTS_ZH = [['', '原书字体'], ['"Microsoft YaHei", "微软雅黑", sans-serif', '微软雅黑'], ['SimSun, "宋体", serif', '宋体'], ['SimHei, "黑体", sans-serif', '黑体'],
  ['KaiTi, "楷体", serif', '楷体'], ['FangSong, "仿宋", serif', '仿宋'], ['"Source Han Serif SC", "Noto Serif CJK SC", "思源宋体", serif', '思源宋体'],
  ['"Source Han Sans SC", "Noto Sans CJK SC", "思源黑体", sans-serif', '思源黑体'], ['DengXian, "等线", sans-serif', '等线']];
export const ZH_COLORS = [['', '跟随正文'], ['#5b6470', '灰色'], ['#2f5d8a', '蓝色'], ['#7a4a1d', '棕色'], ['#2e6b3b', '绿色']];

function row(label, control, hint) {
  return el('label', { class: 'set-row' }, el('span', { class: 'set-label' }, label), control, hint ? el('span', { class: 'set-hint' }, hint) : null);
}

function slider(app, key, min, max, step, fmt) {
  const out = el('span', { class: 'set-val' }, fmt(app.settings[key]));
  const input = el('input', { type: 'range', min, max, step, value: app.settings[key] });
  input.addEventListener('input', () => {
    app.settings[key] = +input.value;
    out.textContent = fmt(+input.value);
    app.applySettings();
  });
  return el('span', { class: 'set-ctl' }, input, out);
}

function select(app, key, options, after) {
  const s = el('select', {}, options.map(([v, l]) => el('option', { value: v }, l)));
  s.value = app.settings[key] || '';
  s.addEventListener('change', () => { app.settings[key] = s.value; app.applySettings(); if (after) after(); });
  return s;
}

function check(app, key, after) {
  const c = el('input', { type: 'checkbox' });
  c.checked = !!app.settings[key];
  c.addEventListener('change', () => { app.settings[key] = c.checked; app.applySettings(); if (after) after(); });
  return c;
}

export function typographyControls(app) {
  const s = app.settings;
  const fs = el('span', { class: 'set-val big' }, s.fontSize + 'px');
  const bump = (d) => { s.fontSize = Math.max(10, Math.min(40, s.fontSize + d)); fs.textContent = s.fontSize + 'px'; app.applySettings(); };
  return [
    row('字号', el('span', { class: 'set-ctl' }, el('button', { class: 'small-btn', onclick: () => bump(-1) }, 'A−'), fs, el('button', { class: 'small-btn', onclick: () => bump(1) }, 'A+'))),
    row('行距', slider(app, 'lineHeight', 1.1, 2.6, 0.05, (v) => (+v).toFixed(2))),
    row('段距', slider(app, 'paraSpacing', 0, 2, 0.1, (v) => (+v).toFixed(1) + 'em')),
    row('版心宽度', slider(app, 'pageWidth', 560, 2400, 20, (v) => v + 'px')),
    row('中英栏宽', slider(app, 'colRatio', 25, 75, 1, (v) => `英 ${v} : 中 ${100 - v}`)),
    row('栏间距', slider(app, 'gutter', 8, 120, 2, (v) => v + 'px')),
    row('英文字体', select(app, 'fontEn', FONTS_EN)),
    row('中文字体', select(app, 'fontZh', FONTS_ZH)),
    row('上下对照中文颜色', select(app, 'zhColor', ZH_COLORS)),
    row('覆盖原书字号行距', check(app, 'overrideTypography')),
    row('显示配对分隔线', check(app, 'showPairSep')),
    row('双栏左侧显示中文', check(app, 'zhLeft')),
  ];
}

export function themeControls(app) {
  const s = app.settings;
  const chips = el('div', { class: 'theme-chips' });
  const renderChips = () => {
    chips.replaceChildren(...Object.entries(THEMES).map(([k, t]) => el('button', {
      class: 'theme-chip' + (s.theme === k ? ' on' : ''),
      style: { background: t.bg, color: t.fg },
      title: t.label,
      onclick: () => { s.theme = k; app.applySettings(); renderChips(); },
    }, t.label)), el('button', {
      class: 'theme-chip' + (s.theme === 'custom' ? ' on' : ''),
      style: { background: s.customBg, color: s.customFg },
      onclick: () => { s.theme = 'custom'; app.applySettings(); renderChips(); },
    }, '自定义'));
  };
  renderChips();
  const bg = el('input', { type: 'color', value: s.customBg });
  const fg = el('input', { type: 'color', value: s.customFg });
  bg.addEventListener('input', () => { s.customBg = bg.value; s.theme = 'custom'; app.applySettings(); renderChips(); });
  fg.addEventListener('input', () => { s.customFg = fg.value; s.theme = 'custom'; app.applySettings(); renderChips(); });
  const eye = el('input', { type: 'checkbox' });
  eye.checked = !!s.eyeCare;
  eye.addEventListener('change', () => { s.eyeCare = eye.checked; app.applySettings(); });
  return [
    el('div', { class: 'set-sub' }, '背景'),
    chips,
    row('自定义背景 / 文字', el('span', { class: 'set-ctl' }, bg, fg)),
    el('div', { class: 'set-sub' }, '护眼'),
    row('护眼模式', eye, '柔和绿底 + 暖色滤镜（PDF 也生效）'),
    row('暖色强度', slider(app, 'eyeCareStrength', 0, 60, 1, (v) => v + '%')),
  ];
}

export function openPopover(app, anchor, title, controls) {
  const pop = document.getElementById('popover');
  pop.replaceChildren(el('div', { class: 'pop-title' }, title), ...controls);
  pop.hidden = false;
  const r = anchor.getBoundingClientRect();
  pop.style.top = r.bottom + 6 + 'px';
  const w = pop.offsetWidth;
  pop.style.left = Math.max(8, Math.min(window.innerWidth - w - 8, r.right - w)) + 'px';
  app.popoverOpen = true;
}

export function closePopover(app) {
  const pop = document.getElementById('popover');
  if (!pop.hidden) {
    pop.hidden = true;
    app.popoverOpen = false;
    app.saveSettingsSoon();
  }
}

// ---------------------------------------------------------------- settings dialog
export function openSettings(app, tab = 'read') {
  const modal = document.getElementById('modal');
  const tabs = [['read', '阅读'], ['theme', '背景与护眼'], ['dict', '词典'], ['learn', '学习'], ['ai', 'AI 对话'], ['keys', '快捷键'], ['about', '关于']];
  const body = el('div', { class: 'modal-body' });
  const nav = el('div', { class: 'modal-nav' });
  const show = (t) => {
    for (const b of nav.children) b.classList.toggle('on', b.dataset.t === t);
    body.replaceChildren(...renderTab(app, t));
  };
  for (const [t, label] of tabs) nav.append(el('button', { dataset: { t }, onclick: () => show(t) }, label));
  const box = el('div', { class: 'modal-box settings' },
    el('div', { class: 'modal-head' }, el('span', {}, '设置'), el('button', { class: 'icon-btn', onclick: () => closeModal(app) }, '✕')),
    el('div', { class: 'modal-main' }, nav, body));
  modal.replaceChildren(box);
  modal.hidden = false;
  modal.onclick = (e) => { if (e.target === modal) closeModal(app); };
  app.modalOpen = true;
  show(tab);
}

export function closeModal(app) {
  const modal = document.getElementById('modal');
  if (modal.hidden) return;
  modal.hidden = true;
  modal.replaceChildren();
  app.modalOpen = false;
  app.saveSettingsSoon();
  app.refocusReader();
}

function renderTab(app, t) {
  const s = app.settings;
  if (t === 'read') {
    return [
      el('div', { class: 'set-sub' }, '排版'),
      ...typographyControls(app),
      el('div', { class: 'set-sub' }, '对照与查词'),
      row('新书默认显示', select(app, 'defaultMode', [['two', '左右双栏'], ['stack', '上下对照'], ['original', '原书排版'], ['en', '仅英文'], ['zh', '仅中文']])),
      row('双击查词', check(app, 'lookupDblClick')),
      row('选中短语自动查词', check(app, 'lookupSelection'), '选中 6 个词以内的英文或 8 个字以内的中文'),
      row('查词时自动打开词典栏', check(app, 'autoOpenDict')),
      el('div', { class: 'set-sub' }, '图片与启动'),
      row('在单独的窗口中看图', check(app, 'imageWindow'), '单击书中的图片，在新窗口里放大查看，可以一边看图一边读书（也可以拖到第二块屏幕上）；关闭后在阅读窗口内全屏查看'),
      row('启动时打开上次的书', check(app, 'reopenLast')),
    ];
  }
  if (t === 'theme') return themeControls(app);
  if (t === 'dict') return dictTab(app);
  if (t === 'ai') return aiTab(app);
  if (t === 'learn') return learnTab(app);
  if (t === 'keys') {
    const keys = [
      ['F6', '切换左右双栏（再按回到之前的模式）'], ['F8', '切换“只看释义”'], ['F9', '进入 / 退出简洁无边框模式'], ['Esc', '关闭大图 / 菜单；退出简洁模式'],
      ['Alt + ↑', '跳转后返回原位置（也可用 Alt + ←、鼠标侧键）'], ['Ctrl + C', '复制选中内容（从英文栏拖选只复制英文，中文栏同理）'],
      ['Ctrl + O', '打开文件'], ['Ctrl + F', '全书搜索'], ['F3 / Shift + F3', '下一个 / 上一个搜索结果'], ['Ctrl + D', '添加书签'],
      ['Ctrl + B', '显示 / 隐藏左侧栏'], ['Ctrl + L', '显示 / 隐藏词典栏'], ['Ctrl + J', '打开 AI 对话'], ['Enter / Shift + Enter', 'AI 对话：发送 / 换行'],
      ['F7', '遮挡自测：遮住中文 → 遮住英文 → 关闭'], ['Ctrl + R', '开始复习生词'], ['空格 / 1–4 / R', '复习时：显示答案 / 忘了·模糊·记得·简单 / 朗读'],
      ['Enter', '拼写复习：检查答案；答完后采用建议的评分'], ['Ctrl + Shift + U', '连续朗读英文 / 停止（朗读时 Esc 也可停止）'],
      ['Ctrl + Shift + P', '练习：回译 / 听写（从当前位置开始）'], ['Ctrl + Enter / Enter', '回译：对照原文 / 听写：检查；检查后 Enter 下一段'], ['Ctrl + R', '听写时：再听一遍'],
      ['单击图片', '放大查看图片（EPUB、HTML 和 PDF；PDF 中矢量图表可右键「放大查看」）'], ['滚轮 / 拖动 / 双击', '看图时：缩放 / 移动 / 放大或还原'],
      ['F 或 F11', '看图窗口：全屏 / 还原（Esc 关闭窗口）'],
      ['← → · 0 · 1 · R', '看图时：上一张 / 下一张 · 适合窗口 · 原始尺寸 · 旋转'], ['Ctrl + C / Ctrl + S', '看图时：复制图片 / 保存图片'], ['A', '看图时：AI 解读这张图'],
      ['Ctrl + = / −', '放大 / 缩小字号（PDF 为缩放）'],
      ['Ctrl + → / ←', '下一章 / 上一章（PDF 为翻页）'], ['PgDn / 空格', '向下翻屏，章末自动进入下一章'], ['F11', '全屏'], ['F12', '开发者工具'],
    ];
    return [el('table', { class: 'keys' }, keys.map(([k, d]) => el('tr', {}, el('td', {}, el('kbd', {}, k)), el('td', {}, d))))];
  }
  if (t === 'about') {
    return [
      el('div', { class: 'about' },
        el('h3', {}, '双语阅读器'),
        el('p', {}, '离线中英对照阅读：EPUB / PDF / HTML，按语言复制、插图放大与跳转、金融词典与生词本。'),
        el('p', {}, '学习：生词间隔复习（认词 / 拼写）、回译与听写练习（AI 点评）、本章生词与术语、每日目标与学习日历、查词记录、学习统计、正文标出生词、遮挡自测、高亮笔记、AI 长难句解析与出题自测、AI 解读图表、连续朗读与跟读、本章剩余阅读时间、学习数据备份。'),
        el('p', { class: 'muted' }, 'PDF 渲染：pdf.js (Apache-2.0)。所有数据保存在本机；只有使用 AI 对话时才会把问题和所附文字发送给你选择的 AI 服务（本机模型除外）。'),
        el('p', { class: 'muted' }, '数据目录：' + (app.state.userDataDir || '（应用数据目录）'))),
    ];
  }
  return [];
}

function learnTab(app) {
  const s = app.settings;
  const hl = el('input', { type: 'checkbox' });
  hl.checked = s.vocabHighlight !== false;
  hl.addEventListener('change', () => { s.vocabHighlight = hl.checked; app.saveSettingsSoon(); app.refreshVocabForms(); });
  const perDay = el('select', {}, [5, 10, 15, 20, 30, 50, 100].map((n) => el('option', { value: String(n) }, n + ' 个')));
  perDay.value = String(s.srsNewPerDay || 20);
  perDay.addEventListener('change', () => { s.srsNewPerDay = +perDay.value; app.saveSettingsSoon(); app.study.render(); });
  const rmode = el('select', {}, REVIEW_MODES.map(([v, l]) => el('option', { value: v }, l)));
  rmode.value = REVIEW_MODES.some((m) => m[0] === s.reviewMode) ? s.reviewMode : 'mixed';
  rmode.addEventListener('change', () => { s.reviewMode = rmode.value; app.saveSettingsSoon(); });
  const say = el('input', { type: 'checkbox' });
  say.checked = s.reviewSpeak !== false;
  say.addEventListener('change', () => { s.reviewSpeak = say.checked; app.saveSettingsSoon(); });
  // (a value that is not in the list, e.g. from a backup, is offered too)
  const choices = (list, cur, unit) => [...new Set([...list, cur])].sort((a, b) => a - b).map((n) => el('option', { value: String(n) }, n ? n + unit : '不设置'));
  const readNow = s.goalRead == null ? 30 : Math.max(0, Math.round(+s.goalRead) || 0);
  const goalRead = el('select', {}, choices([0, 10, 15, 20, 30, 45, 60, 90, 120], readNow, ' 分钟'));
  goalRead.value = String(readNow);
  goalRead.addEventListener('change', () => { s.goalRead = +goalRead.value; app.saveSettingsSoon(); app.study.render(); app.study._checkGoal(); });
  const prNow = Math.max(0, Math.round(+s.goalPractice) || 0);
  const goalPr = el('select', {}, choices([0, 5, 10, 20, 30, 50], prNow, ' 次'));
  goalPr.value = String(prNow);
  goalPr.addEventListener('change', () => { s.goalPractice = +goalPr.value; app.saveSettingsSoon(); app.study.render(); app.study._checkGoal(); });
  const blur = el('select', {}, [['', '关闭'], ['zh', '遮住中文（先读英文）'], ['en', '遮住英文（先看中文，练习回译）']].map(([v, l]) => el('option', { value: v }, l)));
  blur.value = s.blurMode || '';
  blur.addEventListener('change', () => app.setBlur(blur.value));
  const voice = el('select', {});
  const fillVoices = () => {
    let vs = [];
    try { vs = (window.speechSynthesis && window.speechSynthesis.getVoices()) || []; } catch { vs = []; }
    const en = vs.filter((v) => /^en/i.test(v.lang));
    voice.replaceChildren(el('option', { value: '' }, '自动（美式英语优先）'), ...en.map((v) => el('option', { value: v.name }, `${v.name}（${v.lang}）`)));
    voice.value = s.ttsVoice || '';
  };
  fillVoices();
  try { window.speechSynthesis.addEventListener('voiceschanged', fillVoices, { once: true }); } catch { /* ignore */ }
  voice.addEventListener('change', () => { s.ttsVoice = voice.value; app.saveSettingsSoon(); });
  const rateOut = el('span', { class: 'set-val' }, (+s.ttsRate || 0.9).toFixed(2) + '×');
  const rate = el('input', { type: 'range', min: '0.5', max: '2', step: '0.05', value: String(+s.ttsRate || 0.9) });
  rate.addEventListener('input', () => { s.ttsRate = +rate.value; rateOut.textContent = s.ttsRate.toFixed(2) + '×'; app.saveSettingsSoon(); if (app.tts.active) app.tts._renderBar(); });
  const shadow = el('input', { type: 'checkbox' });
  shadow.checked = !!s.ttsShadow;
  shadow.addEventListener('change', () => { s.ttsShadow = shadow.checked; app.saveSettingsSoon(); if (app.tts.active) app.tts._renderBar(); });
  return [
    el('div', { class: 'set-sub' }, '生词与复习'),
    row('在正文中标出生词', hl, '生词本里的词（含各种变形）加虚线下划线，鼠标停留显示释义'),
    row('每天新学单词', perDay, '复习时每天最多引入的新词数量；到期要复习的词不受限制'),
    row('复习方式', rmode, '拼写：看中文释义和挖空的例句写出英文，支持各种词形；复习时右上角也可以切换'),
    row('复习时自动朗读', say),
    el('div', { class: 'set-hint block' }, '复习采用间隔重复：选“记得 / 简单”的词会隔得越来越久再出现，选“忘了”的词会在本轮和近期重复。复习入口：右侧“生词本”或 Ctrl+R。'),
    el('div', { class: 'set-sub' }, '每日目标'),
    row('每天阅读', goalRead, '生词本页的学习卡片显示今天的进度，达成时提示一次；学习统计的日历里会标出读满的日子'),
    row('每天练习', goalPr, '回译或听写，每检查一段 / 一句算一次'),
    el('div', { class: 'set-hint block' }, '练习：在正文右键 → 练习，或按 Ctrl+Shift+P。回译：看书里的中文译文写英文，再和原文逐词对照，可以让 AI 点评；听写：一句一句朗读英文，写下听到的句子，标出漏掉和写错的词（PDF 也可以）。'),
    el('div', { class: 'set-sub' }, '遮挡自测'),
    row('遮挡方式', blur, '双栏 / 上下对照时生效；点击被遮住的段落即可显示，F7 快速切换'),
    el('div', { class: 'set-sub' }, '朗读'),
    row('英文语音', voice, 'Windows 自带的语音，可在系统“设置 → 时间和语言 → 语音”中添加'),
    el('label', { class: 'set-row' }, el('span', { class: 'set-label' }, '语速'), rate, rateOut,
      el('button', { class: 'small-btn', onclick: (e) => { e.preventDefault(); app.speakText('The bid-ask spread is the cost of immediacy.'); } }, '试听')),
    row('跟读停顿', shadow, '连续朗读时每句读完停一会儿，跟着说一遍（shadowing）'),
    el('div', { class: 'set-hint block' }, '连续朗读：点工具栏的喇叭按钮或按 Ctrl+Shift+U，从当前位置一句一句朗读英文并高亮，自动翻页；也可在正文右键“从这里开始连续朗读”。'),
    ...backupSection(app),
  ];
}

// learning data: one file with the vocabulary (and review progress), statistics, lookups, notes,
// bookmarks / positions, settings and AI chats
function backupSection(app) {
  const msg = el('span', { class: 'set-hint inline', dataset: { backupMsg: '' } }, app.settings.lastBackup ? '上次备份：' + new Date(app.settings.lastBackup).toLocaleString('zh-CN', { hour12: false }) : '');
  const say = (summary, prefix) => `${prefix}生词 ${summary.vocab} 个 · 笔记 ${summary.notes} 条 · 书签 ${summary.bookmarks} 个 · 学习记录 ${summary.days} 天 · 查词记录 ${summary.lookups} 个`;
  const backup = async () => {
    const d = new Date();
    const name = `双语阅读器-学习数据-${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}.json`;
    try {
      let s;
      if (api.isElectron) {
        const p = await api.call('pickSave', name, [{ name: '学习数据备份', extensions: ['json'] }]);
        if (!p) return;
        s = await api.call('backupExport', p);
      } else {
        const data = await api.call('backupData');
        const a = document.createElement('a');
        a.href = URL.createObjectURL(new Blob([JSON.stringify(data)], { type: 'application/json' }));
        a.download = name;
        a.click();
        setTimeout(() => URL.revokeObjectURL(a.href), 4000);
        s = await api.call('backupInspect', data);
      }
      app.settings.lastBackup = Date.now();
      app.saveSettingsSoon();
      msg.textContent = say(s, '已备份：');
      toast('学习数据已备份' + (s.file ? '到 ' + s.file : ''), { ms: 4000 });
    } catch (e) {
      toast('备份失败：' + e.message, { type: 'error' });
    }
  };
  const file = el('input', { type: 'file', accept: '.json,application/json', hidden: true });
  file.addEventListener('change', async () => {
    const f = file.files && file.files[0];
    file.value = '';
    if (!f) return;
    let text;
    let s;
    try {
      text = await f.text();
      s = await api.call('backupInspect', text);
    } catch (e) {
      toast(e.message, { type: 'error', ms: 5000 });
      return;
    }
    const when = s.created ? new Date(s.created).toLocaleString('zh-CN', { hour12: false }) : '未知时间';
    const ok = await app.confirm(`恢复 ${when} 的学习数据备份？\n\n${say(s, '')}${s.chats ? ' · AI 对话 ' + s.chats + ' 本书' : ''}\n\n当前的生词本、学习记录、笔记、书签和设置会被备份里的内容替换。恢复前会自动把现在的数据另存一份（数据文件夹 → backups），恢复后阅读器会重新载入。`);
    if (!ok) { app.openSettings('learn'); return; }
    app.restoreBackup(text);
  });
  return [
    el('div', { class: 'set-sub' }, '学习数据备份'),
    el('div', { class: 'set-hint block' }, '把生词本（含复习进度）、学习统计、查词记录、笔记、书签与阅读位置、设置和 AI 对话记录保存成一个文件，换电脑或重装后可以恢复。不包含 API Key、词典文件和书籍本身。'),
    el('div', { class: 'set-row backup-row' },
      el('span', { class: 'set-label' }, ''),
      el('button', { class: 'small-btn primary', onclick: (e) => { e.preventDefault(); backup(); } }, '备份到文件…'),
      el('button', { class: 'small-btn', onclick: (e) => { e.preventDefault(); file.click(); } }, '从备份恢复…'),
      file),
    el('div', { class: 'set-row' }, el('span', { class: 'set-label' }, ''), msg),
  ];
}

function aiTab(app) {
  const wrap = el('div', { class: 'ai-set' });
  let editing = null; // id of the service whose editor is open, or 'new'
  const msgs = {}; // last status line per service
  const refresh = async () => { await app.ai.reloadConfig(); render(); };
  const stop = (x) => { x.addEventListener('keydown', (e) => e.stopPropagation()); return x; };
  const status = (id, text, cls = '') => { msgs[id] = { text, cls }; const n = wrap.querySelector(`[data-msg="${id}"]`); if (n) { n.textContent = text; n.className = 'set-hint prov-msg ' + cls; } };
  const msgEl = (id) => el('div', { class: 'set-hint prov-msg ' + ((msgs[id] && msgs[id].cls) || ''), dataset: { msg: id } }, (msgs[id] && msgs[id].text) || '');
  const armed = (label, armedLabel, fn) => el('button', { class: 'small-btn', onclick: async (e) => {
    const b = e.currentTarget;
    if (b.dataset.armed !== '1') { b.dataset.armed = '1'; b.textContent = armedLabel; return; }
    await fn();
  } }, label);

  // key editor of a built-in service
  const keyEditor = (p) => {
    const input = stop(el('input', { type: 'password', placeholder: p.hasKey ? '输入新的 Key 以更换' : `粘贴 ${p.name} API Key（${p.keyPlaceholder}）`, autocomplete: 'off', spellcheck: 'false' }));
    const save = async () => {
      const k = input.value.trim();
      if (!k) { input.focus(); return; }
      status(p.id, '正在验证…');
      try {
        const r = await app.ai.saveKey(k, p.id);
        msgs[p.id] = { text: r.warning || '已保存，可以在 AI 对话中使用了', cls: r.warning ? 'warn' : 'ok' };
        editing = null;
        render();
      } catch (e) { status(p.id, e.message, 'err'); }
    };
    const test = async () => {
      status(p.id, '正在连接…');
      try {
        const r = await api.call('aiTest', input.value.trim(), p.id);
        status(p.id, `连接正常，可用模型 ${r.count} 个`, 'ok');
      } catch (e) { status(p.id, e.message, 'err'); }
    };
    input.addEventListener('keydown', (e) => { if (e.key === 'Enter') save(); });
    setTimeout(() => input.focus(), 30);
    return el('div', { class: 'prov-edit' },
      el('div', { class: 'set-ctl wide' }, input, el('button', { class: 'small-btn primary', onclick: save }, '保存'), el('button', { class: 'small-btn', onclick: test }, '测试连接')),
      p.keyUrl ? el('a', { href: '#', class: 'prov-link', onclick: (e) => { e.preventDefault(); app.openExternal(p.keyUrl); } }, `获取 ${p.name} API Key →`) : null);
  };

  // form for an OpenAI / Anthropic compatible service (new or existing)
  const customForm = (p) => {
    const c = app.ai.cfg || {};
    const presets = c.presets || [];
    const isNew = !p;
    const f = {
      preset: el('select', {}, [el('option', { value: '' }, '选择常用服务…'), ...presets.map((x) => el('option', { value: x.id }, x.name))]),
      name: stop(el('input', { type: 'text', placeholder: '例如 Kimi', value: p ? p.name : '' })),
      type: el('select', {}, el('option', { value: 'openai' }, 'OpenAI 兼容（/chat/completions）'), el('option', { value: 'anthropic' }, 'Anthropic 兼容（/messages）')),
      base: stop(el('input', { type: 'text', placeholder: 'https://…/v1', spellcheck: 'false', value: p ? p.baseUrl : '' })),
      key: stop(el('input', { type: 'password', autocomplete: 'off', spellcheck: 'false', placeholder: p ? (p.hasKey ? '已保存 ' + p.keyHint + '，留空则不修改' : '没有 Key 时留空') : 'API Key（本机服务可以不填）' })),
      model: stop(el('input', { type: 'text', spellcheck: 'false', placeholder: '获取不到模型列表时填写，例如 glm-5.1', value: p && p.models.some((m) => m.manual) ? p.model : '' })),
      noKey: el('input', { type: 'checkbox' }),
    };
    f.type.value = p ? p.type : 'openai';
    f.noKey.checked = p ? p.noKey : false;
    const note = el('div', { class: 'set-hint block' });
    const id = p ? p.id : 'new';
    f.preset.addEventListener('change', () => {
      const x = presets.find((y) => y.id === f.preset.value);
      if (!x) return;
      if (x.base) f.base.value = x.base;
      if (!/^custom/.test(x.id)) f.name.value = x.name.replace(/（.*?）/g, '');
      f.type.value = x.type || 'openai';
      f.noKey.checked = !!x.noKey;
      note.textContent = x.note || '';
    });
    const data = () => ({ id: p ? p.id : undefined, name: f.name.value.trim() || (presets.find((y) => y.id === f.preset.value) || {}).name || '', type: f.type.value, baseUrl: f.base.value.trim(), key: f.key.value.trim(), model: f.model.value.trim(), noKey: f.noKey.checked, preset: f.preset.value });
    const save = async () => {
      const d = data();
      status(id, '正在保存…');
      try {
        const cfg = await api.call('aiSaveProvider', d);
        app.ai.cfg = cfg;
        let line = { text: '已保存', cls: 'ok' };
        try {
          const list = await api.call('aiModels', true, cfg.id);
          line = { text: `已保存，可用模型 ${list.length} 个`, cls: 'ok' };
        } catch (e) {
          line = d.model ? { text: '已保存（该服务不提供模型列表，将使用填写的模型名称）', cls: 'ok' } : { text: '已保存，但获取模型列表失败：' + e.message + ' 可以在“模型名称”中手动填写。', cls: 'warn' };
        }
        msgs[cfg.id] = line;
        editing = line.cls === 'warn' ? cfg.id : null;
        await refresh();
      } catch (e) { status(id, e.message, 'err'); }
    };
    const test = async () => {
      const d = data();
      status(id, '正在连接…');
      try {
        const r = await api.call('aiTest', d.key, p ? p.id : '', { baseUrl: d.baseUrl, type: d.type, name: d.name, model: d.model, noKey: d.noKey || (!d.key && !(p && p.hasKey)) });
        status(id, r.noList ? '连接正常（该服务不提供模型列表）' : `连接正常，可用模型 ${r.count} 个${r.models.length ? '：' + r.models.slice(0, 3).join('、') + (r.count > 3 ? ' …' : '') : ''}`, 'ok');
      } catch (e) { status(id, e.message, 'err'); }
    };
    const line = (label, ctl, hint) => el('div', { class: 'set-row' }, el('span', { class: 'set-label' }, label), el('span', { class: 'set-ctl wide' }, ctl), hint ? el('span', { class: 'set-hint' }, hint) : null);
    return el('div', { class: 'prov-edit form' },
      isNew ? line('常用服务', f.preset) : null,
      note,
      line('名称', f.name),
      line('接口协议', f.type),
      line('接口地址', f.base),
      line('API Key', f.key),
      el('label', { class: 'set-row' }, el('span', { class: 'set-label' }, ''), el('span', { class: 'set-ctl' }, f.noKey, ' 这个服务不需要 Key（本机 Ollama / LM Studio）')),
      line('模型名称', f.model),
      el('div', { class: 'prov-actions' },
        el('button', { class: 'small-btn primary', onclick: save }, '保存'),
        el('button', { class: 'small-btn', onclick: test }, '测试连接'),
        el('button', { class: 'small-btn', onclick: () => { editing = null; render(); } }, '取消')),
      p ? null : msgEl('new'));
  };

  const provRow = (p, c) => {
    const st = p.noKey ? '本机服务，不需要 Key' : p.hasKey ? `已保存：${p.keyHint}${p.keyProtected ? '（Windows 加密）' : ''}` : p.keyBroken ? 'Key 无法解密，请重新填写' : '未设置';
    const isCur = p.ready && p.id === c.provider;
    return el('div', { class: 'prov' + (p.ready ? ' ready' : '') + (isCur ? ' cur' : ''), dataset: { id: p.id } },
      el('div', { class: 'prov-head' },
        el('span', { class: 'prov-name' }, p.name),
        isCur ? el('span', { class: 'prov-cur' }, '正在使用') : null,
        el('span', { class: 'prov-status' + (p.ready ? ' ok' : '') }, st),
        el('span', { class: 'grow' }),
        p.ready && !isCur ? el('button', { class: 'small-btn', onclick: async () => { await app.ai.saveConfig({ provider: p.id }); render(); toast('已切换到 ' + p.name); } }, '使用') : null,
        el('button', { class: 'small-btn', onclick: () => { editing = editing === p.id ? null : p.id; render(); } }, p.custom ? '编辑' : p.hasKey ? '更换 Key' : '填写 Key'),
        p.custom
          ? armed('删除', '确认删除', async () => { app.ai.cfg = await api.call('aiRemoveProvider', p.id); app.ai._renderSetup(); app.ai._renderBar(); render(); })
          : p.hasKey ? armed('删除 Key', '确认删除', async () => { app.ai.cfg = await api.call('aiRemoveProvider', p.id); delete msgs[p.id]; app.ai._renderSetup(); app.ai._renderBar(); render(); }) : null),
      p.custom ? el('div', { class: 'prov-sub' }, `${p.type === 'anthropic' ? 'Anthropic 兼容' : 'OpenAI 兼容'} · ${p.baseUrl}`) : null,
      editing === p.id ? (p.custom ? customForm(p) : keyEditor(p)) : null,
      msgEl(p.id));
  };

  const render = () => {
    const c = app.ai.cfg || {};
    const provs = c.providers || [];
    const modelSel = el('select', {});
    app.ai.fillModelSelect(modelSel, { other: false });
    modelSel.addEventListener('change', async () => { await app.ai.onModelPick(modelSel); render(); });
    const think = el('select', {}, [['', '默认（由服务决定；DeepSeek 默认会深度思考）'], ['off', '关闭：回答最快'], ['low', '低'], ['medium', '中'], ['high', '高：更深入、更慢']].map(([v, l]) => el('option', { value: v }, l)));
    think.value = c.thinking || '';
    think.addEventListener('change', () => app.ai.saveConfig({ thinking: think.value }));
    const sys = stop(el('textarea', { rows: 6, class: 'ai-sys' }));
    sys.value = c.system || '';
    sys.addEventListener('change', () => app.ai.saveConfig({ system: sys.value }));
    const base = stop(el('input', { type: 'text', placeholder: c.defaultBaseUrl || '', spellcheck: 'false' }));
    base.value = c.baseUrl || '';
    base.addEventListener('change', async () => { try { await app.ai.saveConfig({ baseUrl: base.value }); } catch (e) { toast(e.message, { type: 'error' }); } });
    const chk = (key, label) => {
      const x = el('input', { type: 'checkbox' });
      x.checked = c[key] !== false;
      x.addEventListener('change', () => app.ai.saveConfig({ [key]: x.checked }));
      return row(label, x);
    };
    wrap.replaceChildren(
      el('div', { class: 'set-sub' }, 'AI 服务与 API Key'),
      el('div', { class: 'prov-list' }, provs.map((p) => provRow(p, c))),
      editing === 'new'
        ? customForm(null)
        : el('div', { class: 'prov-add' }, el('button', { class: 'small-btn', onclick: () => { editing = 'new'; delete msgs.new; render(); } }, '＋ 添加其他服务'),
          el('span', { class: 'set-hint' }, 'Kimi、通义千问、智谱 GLM、硅基流动、OpenRouter、xAI，或本机的 Ollama / LM Studio 等')),
      el('div', { class: 'set-hint block' }, '可以同时保存多个服务，在 AI 对话顶部随时切换。Key 只保存在本机并用 Windows 加密；提问时请求直接发送到对应的服务商（本机模型不联网），会使用系统代理设置。'),
      el('div', { class: 'set-sub' }, '模型与回答'),
      el('div', { class: 'set-row' }, el('span', { class: 'set-label' }, '当前模型'), el('span', { class: 'set-ctl wide' }, modelSel,
        el('button', { class: 'small-btn', disabled: !c.hasKey, onclick: async () => { await app.ai.refreshModels(true); render(); } }, '刷新列表'))),
      row('思考程度', think, '先思考再回答：更准确，但更慢、更费 token。不支持的模型会自动按默认方式回答'),
      el('div', { class: 'set-row top' }, el('span', { class: 'set-label' }, '系统提示词'), el('span', { class: 'set-ctl wide col' }, sys,
        el('button', { class: 'small-btn', onclick: async () => { await app.ai.saveConfig({ system: '' }); render(); } }, '恢复默认'))),
      chk('includeBook', '告诉模型正在读的书名和章节'),
      chk('saveHistory', '保存每本书的对话记录'),
      el('div', { class: 'set-sub' }, '高级'),
      el('div', { class: 'set-row' }, el('span', { class: 'set-label' }, 'Gemini 接口地址'), el('span', { class: 'set-ctl wide' }, base,
        el('button', { class: 'small-btn', onclick: async () => { await app.ai.saveConfig({ baseUrl: '' }); render(); } }, '默认'))),
      el('div', { class: 'set-hint block' }, '一般不用改；只有通过自建中转服务访问 Gemini 时才需要填写。其他服务的中转地址可以用“添加其他服务”。'));
  };
  if (!app.ai.cfg) app.ai.reloadConfig().then(render);
  render();
  return [wrap];
}

function dictTab(app) {
  const wrap = el('div', { class: 'dict-mgr' });
  const render = () => {
    const list = app.state.dicts || [];
    wrap.replaceChildren(
      el('div', { class: 'set-sub' }, '词典顺序决定显示顺序（内置金融词典的金融释义总是优先展示）'),
      el('div', { class: 'dm-list' }, list.map((d, i) => el('div', { class: 'dm-item' + (d.enabled === false ? ' off' : '') },
        el('input', { type: 'checkbox', checked: d.enabled !== false, onchange: async (e) => { app.state.dicts = await api.call('dictSetEnabled', d.id, e.target.checked); render(); } }),
        el('div', { class: 'dm-info' },
          el('div', { class: 'dm-name' }, d.name, el('span', { class: 'dm-type' }, d.type === 'builtin' ? '内置' : d.type.toUpperCase())),
          el('div', { class: 'dm-meta' }, [d.count ? d.count + ' 条' : '', d.missing ? '⚠ 文件不存在：' + d.path : (d.path || d.source || ''), d.mdds && d.mdds.length ? `含 ${d.mdds.length} 个 MDD` : ''].filter(Boolean).join(' · '))),
        el('button', { class: 'icon-btn', title: '上移', disabled: i === 0, onclick: async () => { app.state.dicts = await api.call('dictMove', d.id, -1); render(); } }, '↑'),
        el('button', { class: 'icon-btn', title: '下移', disabled: i === list.length - 1, onclick: async () => { app.state.dicts = await api.call('dictMove', d.id, 1); render(); } }, '↓'),
        el('button', { class: 'icon-btn', title: '重命名', onclick: async () => { const n = await app.prompt('词典名称', d.name); if (n) { app.state.dicts = await api.call('dictRename', d.id, n); render(); } } }, '✎'),
        d.type !== 'builtin' ? el('button', { class: 'icon-btn', title: '移除', onclick: async () => { app.state.dicts = await api.call('dictRemove', d.id); render(); toast('已移除 ' + d.name); } }, '🗑') : el('span', { class: 'icon-btn ph' })))),
      el('div', { class: 'dm-actions' },
        el('button', { class: 'primary', onclick: () => importDicts(app, 'mdx').then(render) }, '导入 MDX / MDD 词典'),
        el('button', { onclick: () => importDicts(app, 'csv').then(render) }, '导入 CSV 词库')),
      el('div', { class: 'set-hint block' },
        'MDX：选择 .mdx 文件，同目录下同名的 .mdd（含 .1.mdd 等分卷）和 .css 会自动加载。',
        el('br'),
        'CSV：第一列单词，第二列释义；也可带表头（单词, 音标, 释义, 例句, 备注）。支持 UTF-8 和 GBK 编码（Excel 另存的 CSV）。'));
  };
  render();
  return [wrap];
}

export async function importDicts(app, kind, paths) {
  if (!paths) {
    if (!api.isElectron) {
      const p = await app.prompt('词典文件的完整路径', '');
      paths = p ? [p] : [];
    } else {
      paths = await api.call('pickDicts', kind);
    }
  }
  if (!paths || !paths.length) return;
  for (const p of paths) {
    try {
      app.toast('正在导入 ' + p.split(/[\\/]/).pop() + '…', 'info', 8000);
      const r = await api.call('dictImport', p);
      toast(r.duplicate ? `“${r.name}”已经导入过` : `已导入“${r.name}”，共 ${r.count || 0} 条`);
    } catch (e) {
      toast('导入失败：' + e.message, { type: 'error', ms: 6000 });
    }
  }
  app.state.dicts = await api.call('dictList');
}
