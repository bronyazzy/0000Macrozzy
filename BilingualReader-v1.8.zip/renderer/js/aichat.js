// AI chat panel: service + model picker (Gemini, DeepSeek, OpenAI, Claude, compatible / local services),
// streaming answers rendered as Markdown with the model's reasoning, reading context (selection / paragraph /
// chapter), quizzes, per-book history. Network calls happen in the backend.
import { el, toast } from './util.js';
import * as api from './api.js';
import { renderMarkdown } from './markdown.js';
import { icon } from './icons.js';

function quizMarkdown(qz) {
  return [`**${qz.title || '本章自测'}**`, '', ...qz.questions.map((q, k) => [
    `${k + 1}. ${q.q}`, ...q.options.map((o, j) => `   ${'ABCDEF'[j]}. ${o}`), `   答案：${'ABCDEF'[q.answer]}。${q.explain || ''}`, '',
  ].join('\n'))].join('\n');
}

const THINK = [['', '思考：默认'], ['off', '思考：关闭'], ['low', '思考：低'], ['medium', '思考：中'], ['high', '思考：高']];
const NO_KEY_MSG = '请先设置 AI 服务的 API Key（设置 → AI 对话）';
const SETUP_IDS = ['gemini', 'deepseek', 'openai', 'anthropic'];
const MAX_QUOTE = 24000;
const MAX_CHAPTER = 90000;

export class AiPanel {
  constructor(app) {
    this.app = app;
    this.root = document.getElementById('tab-ai');
    this.cfg = null;
    this.messages = [];
    this.bookId = '';
    this.job = null; // { id, msg }
    this.attach = null; // { text }
    this.seq = 0;
    this._raf = 0;
    api.on('ai-event', (e) => this._onEvent(e));
    this._build();
  }

  // ------------------------------------------------------------------ layout
  _build() {
    this.modelSel = el('select', { class: 'ai-model', title: '选择 AI 服务和模型（在 设置 → AI 对话 中添加更多服务）' });
    this.modelSel.addEventListener('change', () => this.onModelPick(this.modelSel));
    this.thinkSel = el('select', { class: 'ai-think', title: '思考程度：先思考再回答，更准确但更慢。“默认”由服务决定（DeepSeek 默认会深度思考），“关闭”回答最快' }, THINK.map(([v, l]) => el('option', { value: v }, l)));
    this.thinkSel.addEventListener('change', () => this.saveConfig({ thinking: this.thinkSel.value }));
    this.refreshBtn = el('button', { class: 'icon-btn', title: '刷新模型列表', onclick: () => this.refreshModels(true) }, '⟳');
    const newBtn = el('button', { class: 'icon-btn ai-new', title: '新对话（清空当前对话）', onclick: () => this.newChat() });
    newBtn.innerHTML = icon('newchat', 16);
    this.bar = el('div', { class: 'ai-bar' }, this.modelSel, this.refreshBtn, this.thinkSel, newBtn);
    this.setup = el('div', { class: 'ai-setup', hidden: true });
    this.list = el('div', { class: 'ai-msgs' });
    this.list.addEventListener('click', (e) => this._onListClick(e));
    this.attachEl = el('div', { class: 'ai-attach', hidden: true });
    this.sumBtn = el('button', { class: 'chip', title: '把本章正文发给模型做总结', onclick: () => this.summarize() }, '总结本章');
    this.quizBtn = el('button', { class: 'chip', title: '根据本章内容出 5 道选择题，点选作答并查看解析', onclick: () => this.quiz() }, '出题自测');
    this.quick = el('div', { class: 'ai-quick' },
      el('button', { class: 'chip', title: '解释书中选中的文字', onclick: () => this.quickAction('explain') }, '解释所选'),
      el('button', { class: 'chip', title: '翻译书中选中的文字', onclick: () => this.quickAction('translate') }, '翻译所选'),
      el('button', { class: 'chip', title: '分析选中句子的主干、从句和修饰成分', onclick: () => this.quickAction('analyze') }, '长难句'),
      el('button', { class: 'chip', title: '把选中的文字附在下一个问题里', onclick: () => this.attachSelection() }, '引用所选'),
      this.sumBtn, this.quizBtn);
    this.input = el('textarea', { class: 'ai-input', rows: 3, placeholder: '输入问题，Enter 发送，Shift+Enter 换行', spellcheck: 'false' });
    this.input.addEventListener('keydown', (e) => this._onKey(e));
    this.sendBtn = el('button', { class: 'primary ai-send', onclick: () => (this.job ? this.stop() : this.send()) }, '发送');
    this.compose = el('div', { class: 'ai-compose' }, this.attachEl, this.quick, el('div', { class: 'ai-inrow' }, this.input, this.sendBtn));
    this.root.replaceChildren(this.bar, this.setup, this.list, this.compose);
  }

  async init() {
    await this.reloadConfig();
    await this.setBook(this.app.info ? this.app.info.bookId : '');
    if (this.cfg && this.cfg.hasKey && !(this.cfg.models || []).length) this.refreshModels(false, true);
  }

  // ------------------------------------------------------------------ services and models
  _prov(id) { return ((this.cfg && this.cfg.providers) || []).find((p) => p.id === id) || null; }

  providerShort(id) {
    const p = this._prov(id || (this.cfg && this.cfg.provider));
    return p ? p.short : 'AI';
  }

  // grouped <option>s of every usable service; sel._opts maps option values to { provider, model }
  // (other: false leaves out “输入其他模型名…”, which needs the prompt dialog)
  fillModelSelect(sel, { other = true } = {}) {
    const c = this.cfg || {};
    const ready = (c.providers || []).filter((p) => p.ready);
    const many = ready.length > 1;
    const opts = [];
    const groups = ready.map((p) => {
      const list = (p.models || []).slice(0, 120);
      if (p.model && !list.some((m) => m.id === p.model)) list.unshift({ id: p.model });
      const og = el('optgroup', { label: p.name });
      for (const m of list) {
        opts.push({ provider: p.id, model: m.id });
        og.append(el('option', { value: String(opts.length - 1), title: [m.name && m.name !== m.id ? m.name : '', m.desc].filter(Boolean).join('\n') }, (many ? p.short + ' · ' : '') + m.id));
      }
      if (other) {
        opts.push({ provider: p.id, model: '', other: true });
        og.append(el('option', { value: String(opts.length - 1) }, (many ? p.short + ' · ' : '') + '输入其他模型名…'));
      }
      return og;
    });
    sel.replaceChildren(...(groups.length ? groups : [el('option', { value: '' }, '（还没有可用的 AI 服务）')]));
    const cur = opts.findIndex((o) => !o.other && o.provider === c.provider && o.model === c.model);
    sel.value = cur >= 0 ? String(cur) : '';
    sel._opts = opts;
  }

  async onModelPick(sel) {
    const o = sel._opts && sel._opts[+sel.value];
    if (!o) return;
    if (o.other) {
      const p = this._prov(o.provider);
      const name = await this.app.prompt(`输入 ${p ? p.name : ''} 的模型名称（例如服务商文档中的 model 名）`, '');
      if (!name || !name.trim()) { this._renderBar(); return; }
      await this.saveConfig({ provider: o.provider, model: name.trim(), addModel: true });
      toast(`已切换到 ${this.providerShort(o.provider)} · ${name.trim()}`);
      return;
    }
    await this.saveConfig({ provider: o.provider, model: o.model });
    const p = this._prov(o.provider);
    if (p && !(p.models || []).length && !p.custom) this.refreshModels(false, true, o.provider);
  }

  async reloadConfig() {
    try { this.cfg = await api.call('aiConfig'); } catch (e) { this.cfg = null; console.error(e); }
    this._renderBar();
    this._renderSetup();
  }

  onShow() {
    this._renderBar();
    this._scrollBottom(true);
    // keys may have been changed elsewhere (settings, key files)
    if (!this.job) this.reloadConfig();
  }

  focus() { setTimeout(() => this.input.focus(), 30); }

  _renderBar() {
    const c = this.cfg || {};
    this.fillModelSelect(this.modelSel);
    this.modelSel.title = c.hasKey ? `当前：${c.providerName} · ${c.model}（在 设置 → AI 对话 中添加更多服务）` : '还没有可用的 AI 服务';
    this.thinkSel.value = c.thinking || '';
    this.bar.classList.toggle('off', !c.hasKey);
    this.sumBtn.textContent = this.app.view === this.app.pdf ? '总结本页' : '总结本章';
  }

  // shown in the panel while no AI service can be used: choose a service and paste its key
  _renderSetup() {
    const c = this.cfg || {};
    const need = !c.hasKey;
    this.setup.hidden = !need;
    this.compose.classList.toggle('off', need);
    if (!need) { this.setup.replaceChildren(); return; }
    const provs = (c.providers || []).filter((p) => SETUP_IDS.includes(p.id));
    if (!this._setupPid || !provs.some((p) => p.id === this._setupPid)) this._setupPid = (provs.find((p) => p.id === c.provider) || provs[0] || {}).id;
    const cur = () => provs.find((p) => p.id === this._setupPid) || provs[0] || {};
    const pick = el('select', { class: 'ai-setup-prov' }, provs.map((p) => el('option', { value: p.id }, p.name)));
    pick.value = this._setupPid || '';
    const input = el('input', { type: 'password', autocomplete: 'off', spellcheck: 'false' });
    const msg = el('div', { class: 'ai-setup-msg' });
    const link = el('a', { href: '#', onclick: (e) => { e.preventDefault(); if (cur().keyUrl) this.app.openExternal(cur().keyUrl); } });
    const sync = () => {
      const p = cur();
      input.placeholder = `粘贴 API Key（${p.keyPlaceholder || ''}）`;
      link.textContent = `获取 ${p.name || ''} API Key →`;
      link.hidden = !p.keyUrl;
    };
    pick.addEventListener('change', () => { this._setupPid = pick.value; msg.textContent = ''; sync(); input.focus(); });
    sync();
    const btn = el('button', { class: 'primary' }, '保存');
    const save = async () => {
      const k = input.value.trim();
      if (!k) { input.focus(); return; }
      btn.disabled = true;
      msg.className = 'ai-setup-msg';
      msg.textContent = '正在验证…';
      try {
        const r = await this.saveKey(k, pick.value);
        if (r.warning) { msg.className = 'ai-setup-msg warn'; msg.textContent = r.warning; } else toast('已保存 API Key');
      } catch (e) {
        msg.className = 'ai-setup-msg err';
        msg.textContent = e.message;
      } finally {
        btn.disabled = false;
      }
    };
    btn.addEventListener('click', save);
    input.addEventListener('keydown', (e) => { e.stopPropagation(); if (e.key === 'Enter') save(); });
    const broken = (c.providers || []).some((p) => p.keyBroken);
    this.setup.replaceChildren(
      el('div', { class: 'ai-setup-title' }, '使用 AI 对话需要一个 AI 服务的 API Key'),
      el('div', { class: 'muted' }, broken ? '之前保存的 Key 无法解密（可能换了 Windows 账户），请重新填写。' : 'Key 只保存在本机，并用 Windows 加密保存。'),
      el('div', { class: 'ai-setup-row' }, el('span', { class: 'lbl' }, '服务'), pick),
      el('div', { class: 'ai-setup-row' }, input, btn),
      msg,
      link,
      el('div', { class: 'muted small' }, 'Kimi、通义千问、智谱 GLM、OpenRouter、本机 Ollama 等其他服务：',
        el('a', { href: '#', onclick: (e) => { e.preventDefault(); this.app.openSettings('ai'); } }, '设置 → AI 对话 → 添加其他服务')));
  }

  // verify (when possible) and store the key of a service; used by the panel and the settings dialog
  async saveKey(k, pid) {
    const id = pid || (this.cfg && this.cfg.provider) || 'gemini';
    let warning = '';
    try {
      await api.call('aiTest', k, id);
    } catch (e) {
      if (/无效|过期|格式|权限|余额/.test(e.message)) throw e;
      warning = '已保存，但暂时无法验证：' + e.message;
    }
    this.cfg = await api.call('aiSetKey', k, id);
    if (!warning) await this.refreshModels(true, true, id);
    this._renderSetup();
    this._renderBar();
    this.render();
    return { warning };
  }

  async saveConfig(patch) {
    const had = !!(this.cfg && this.cfg.hasKey);
    try {
      this.cfg = await api.call('aiSaveConfig', patch);
    } catch (e) {
      toast(e.message, { type: 'error' });
    }
    this._renderBar();
    this._renderSetup();
    if (had !== !!(this.cfg && this.cfg.hasKey)) this.render();
    return this.cfg;
  }

  async refreshModels(force, quiet, pid) {
    if (!this.cfg) return;
    const id = pid || this.cfg.provider;
    const p = this._prov(id);
    if (!p || !p.ready) return;
    this.refreshBtn.disabled = true;
    this.refreshBtn.classList.add('spin');
    try {
      const list = await api.call('aiModels', !!force, id);
      this.cfg = await api.call('aiConfig');
      this._renderBar();
      if (!quiet) toast(`${p.name}：已获取 ${list.length} 个可用模型`);
    } catch (e) {
      if (!quiet) toast('获取模型列表失败：' + e.message, { type: 'error', ms: 7000 });
      else console.warn(e.message);
    } finally {
      this.refreshBtn.disabled = false;
      this.refreshBtn.classList.remove('spin');
    }
  }

  // ------------------------------------------------------------------ conversations
  async setBook(bookId) {
    if (this.job) this.stop();
    this.bookId = bookId || '';
    this.attach = null;
    const seq = (this._bookSeq = (this._bookSeq || 0) + 1);
    let list = [];
    try { list = await api.call('aiHistory', this.bookId || '_global'); } catch { list = []; }
    if (seq !== this._bookSeq) return; // another book was opened meanwhile
    this.messages = list;
    this.render();
    this._renderBar();
  }

  newChat() {
    if (this.job) this.stop();
    this.messages = [];
    this.attach = null;
    this._persist();
    this.render();
    this.input.focus();
  }

  _persist() {
    const list = this.messages.filter((m) => !m.pending);
    api.call('aiSaveHistory', this.bookId || '_global', list).catch(() => {});
  }

  _system() {
    const c = this.cfg || {};
    let s = c.system || c.defaultSystem || '';
    if (c.includeBook !== false && this.app.book) {
      const title = this.app.book.title || '';
      const pos = this.app.view && this.app.view.getPosition ? this.app.view.getPosition() : null;
      const where = pos ? this.app.posLabel(pos) : '';
      s += `\n\n用户正在阅读：《${title}》${where ? '，' + where : ''}。`;
    }
    return s;
  }

  // conversation so far; answers of another service / model are sent as plain text (no Gemini signatures)
  _contents(upTo) {
    const c = this.cfg || {};
    const out = [];
    for (const m of this.messages) {
      if (m === upTo) break;
      if (m.role === 'user') {
        let parts = m.parts && m.parts.length ? m.parts : [{ text: m.text || '' }];
        // a chat restored from history keeps only the preview of a picture: send that instead
        if (m.images && m.images.length && !parts.some((p) => p.inlineData)) {
          parts = [...parts, ...m.images.map((s) => /^data:(image\/[\w+.-]+);base64,(.+)$/.exec(s)).filter(Boolean).map((x) => ({ inlineData: { mimeType: x[1], data: x[2] } }))];
        }
        out.push({ role: 'user', parts });
      }
      else if (!m.error && ((m.parts && m.parts.length) || m.text)) {
        const same = (m.provider || 'gemini') === c.provider && !!m.model && !!c.model && (m.model === c.model || m.model.startsWith(c.model));
        out.push({ role: 'model', parts: same && m.parts && m.parts.length ? m.parts : [{ text: m.text || '' }] });
      }
    }
    return out;
  }

  // send(typed?, { title, quote, prompt })
  async send(typed, extra = {}) {
    if (this.job) return;
    if (!this.cfg || !this.cfg.hasKey) {
      this.app.openAi();
      toast(NO_KEY_MSG);
      return;
    }
    const fromBox = typed == null;
    const text = fromBox ? this.input.value.trim() : String(typed || '');
    const attach = extra.prompt ? null : this.attach;
    if (!text && !attach && !extra.prompt) return;
    let prompt = extra.prompt || text;
    if (attach) prompt = (text || '请解释下面这段内容。') + '\n\n"""\n' + attach.text + '\n"""';
    const user = {
      role: 'user',
      text: extra.prompt ? text : text,
      title: extra.title || '',
      quote: extra.quote != null ? extra.quote : attach ? attach.text.slice(0, 600) : '',
      parts: [{ text: prompt }, ...(extra.image ? [{ inlineData: extra.image }] : [])],
      images: extra.images || undefined,
      at: Date.now(),
    };
    if (fromBox) this.input.value = '';
    this.attach = null;
    this.messages.push(user);
    const answer = { role: 'model', text: '', parts: [], provider: this.cfg.provider, model: this.cfg.model, at: Date.now(), pending: true };
    this.messages.push(answer);
    this.render();
    await this._start(answer, extra.onUpdate);
  }

  // A question asked from elsewhere (the practice window): the answer goes into the chat as usual and is
  // also handed to onUpdate(message, done) while it streams. False when no AI service is set up or busy.
  ask(prompt, { title = '', quote = '', onUpdate } = {}) {
    if (!this.cfg || !this.cfg.hasKey || this.job) return false;
    this.send('', { title, quote, prompt, onUpdate }).catch((e) => console.error(e));
    return true;
  }

  async _start(answer, onUpdate) {
    const id = 'c' + Date.now().toString(36) + '-' + (++this.seq);
    const contents = this._contents(answer);
    this.job = { id, msg: answer, onUpdate };
    this._busy(true);
    try {
      await api.call('aiChat', id, { provider: this.cfg.provider, model: this.cfg.model, thinking: this.cfg.thinking || '', system: this._system(), contents });
    } catch (e) {
      this._finish(id, { type: 'error', message: e.message });
    }
  }

  stop() {
    if (!this.job) return;
    const id = this.job.id;
    api.call('aiCancel', id).catch(() => {});
    // the backend answers with an 'aborted' event; make sure the UI never stays busy
    setTimeout(() => { if (this.job && this.job.id === id) this._finish(id, { type: 'aborted' }); }, 4000);
  }

  regenerate(i) {
    if (this.job) return;
    const m = this.messages[i];
    if (!m || m.role !== 'model' || i !== this.messages.length - 1) return;
    if (m.kind === 'quiz') {
      // a new set of questions instead of a chat answer to the quiz request
      const u = this.messages[i - 1];
      this.messages.splice(u && u.role === 'user' ? i - 1 : i);
      this.render();
      this.quiz();
      return;
    }
    const answer = { role: 'model', text: '', parts: [], provider: this.cfg.provider, model: this.cfg.model, at: Date.now(), pending: true };
    this.messages[i] = answer;
    this.render();
    this._start(answer);
  }

  _onEvent(e) {
    if (!e || !this.job || e.id !== this.job.id) return;
    if (e.type === 'delta') {
      this.job.msg.text += e.text || '';
      this._scheduleStream();
      if (this.job.onUpdate) { try { this.job.onUpdate(this.job.msg, false); } catch (err) { console.error(err); } }
      return;
    }
    if (e.type === 'thought') {
      this.job.msg.thought = (this.job.msg.thought || '') + (e.text || '');
      this._scheduleStream();
      return;
    }
    this._finish(e.id, e);
  }

  _finish(id, e) {
    if (!this.job || this.job.id !== id) return;
    const job = this.job;
    const m = job.msg;
    this.job = null;
    delete m.pending;
    if (e.thought) m.thought = e.thought;
    if (e.provider) m.provider = e.provider;
    if (e.type === 'done') {
      m.text = e.text || m.text;
      m.parts = e.parts || [];
      if (e.model) m.model = e.model;
      if (e.note) m.note = e.note;
      if (e.usage) m.usage = e.usage;
    } else if (e.type === 'aborted') {
      if (e.text) m.text = e.text;
      m.parts = e.parts || (m.text ? [{ text: m.text }] : []);
      m.note = '已停止';
    } else {
      if (e.text) m.text = e.text;
      m.parts = e.parts || [];
      m.error = e.message || '出错了';
    }
    this._busy(false);
    this.render();
    this._persist();
    if (job.onUpdate) { try { job.onUpdate(m, true); } catch (err) { console.error(err); } }
  }

  _busy(on) {
    this.sendBtn.textContent = on ? '停止' : '发送';
    this.sendBtn.classList.toggle('stop', on);
    this.root.classList.toggle('busy', on);
  }

  // ------------------------------------------------------------------ reading context
  selectionOrToast() {
    const sel = this.app.aiSelection();
    if (!sel || !sel.text.trim()) {
      toast('请先在书中选中一段文字（或在段落上点右键选择“AI 解释本段”）');
      return null;
    }
    return sel;
  }

  quickAction(kind, src) {
    const sel = src || this.selectionOrToast();
    if (!sel) return;
    const text = sel.text.trim().slice(0, MAX_QUOTE);
    const what = sel.kind === 'paragraph' ? '这一段' : '所选内容';
    const prompts = {
      translate: `请把下面${what}翻译成准确、通顺的简体中文，术语后用括号保留英文原文；如果原文是中文，请译成英文。只输出译文和必要的术语说明。`,
      explain: `请结合金融 / 交易语境解释下面${what}：说明它的意思、其中的关键术语和前后逻辑。`,
      analyze: `请帮我读懂下面${what}中的英文长难句：\n1. 标出每个句子的主干（主语、谓语、宾语或表语）；\n2. 逐个说明从句、非谓语动词、介词短语等修饰成分，以及它们修饰的对象（可以用缩进分层展示）；\n3. 解释其中的金融术语和难懂的搭配；\n4. 最后给出准确、通顺的中文翻译。`,
    };
    const titles = { translate: '翻译', explain: '解释', analyze: '长难句解析：' };
    this.app.openAi(false);
    this.send('', { title: titles[kind] + what, quote: text.slice(0, 600), prompt: prompts[kind] + '\n\n"""\n' + text + '\n"""' });
  }

  attachSelection(src) {
    const sel = src || this.selectionOrToast();
    if (!sel) return;
    this.attach = { text: sel.text.trim().slice(0, MAX_QUOTE) };
    this._renderAttach();
    this.app.openAi();
  }

  askWord(word, ctx) {
    const w = String(word || '').trim();
    if (!w) return;
    const s = ctx && ctx.sentence ? ctx.sentence : '';
    let p;
    if (s) {
      p = `“${w}”在下面这句话里是什么意思？请结合金融 / 交易语境给出准确的中文释义，并说明它在句中的含义和用法。\n\n原句：${s}`;
      if (ctx.sentenceZh) p += `\n参考译文：${ctx.sentenceZh}`;
    } else {
      p = `请解释英文单词或短语“${w}”在金融 / 交易领域的含义、常见搭配，并给两个例句（附中文翻译）。`;
    }
    this.app.openAi(false);
    this.send('', { title: `解释“${w}”`, quote: s, prompt: p });
  }

  async summarize() {
    let r;
    try { r = await this.app.aiChapterText(); } catch (e) { toast('读取正文失败：' + e.message, { type: 'error' }); return; }
    if (!r || !r.text || r.text.trim().length < 30) { toast('没有可总结的正文'); return; }
    const long = r.text.length > MAX_CHAPTER;
    const body = r.text.slice(0, MAX_CHAPTER);
    this.app.openAi(false);
    this.send('', {
      title: '总结' + r.label,
      quote: '',
      prompt: `请用简体中文总结下面${r.label}的内容：先用两三句话概括主旨，再分点列出核心概念、结论和关键术语（术语保留英文）。${long ? '（正文较长，这里只附上了前面一部分。）' : ''}\n\n"""\n${body}\n"""`,
    });
  }

  // Multiple-choice self-test about the chapter (structured JSON from the model), answered in the panel.
  async quiz() {
    if (this.job) return;
    if (!this.cfg || !this.cfg.hasKey) { this.app.openAi(); toast(NO_KEY_MSG); return; }
    let r;
    try { r = await this.app.aiChapterText(); } catch (e) { toast('读取正文失败：' + e.message, { type: 'error' }); return; }
    if (!r || !r.text || r.text.trim().length < 80) { toast('没有足够的正文用来出题'); return; }
    this.app.openAi(false);
    const user = { role: 'user', title: '出题自测：' + r.label, text: '', parts: [{ text: `请根据${r.label}的内容出 5 道单项选择题。` }], at: Date.now() };
    const answer = { role: 'model', text: '', parts: [], provider: this.cfg.provider, model: this.cfg.model, at: Date.now(), pending: true, kind: 'quiz' };
    this.messages.push(user, answer);
    const id = 'q' + Date.now().toString(36) + '-' + (++this.seq);
    this.job = { id, msg: answer };
    this._busy(true);
    this.render();
    try {
      const q = await api.call('aiQuiz', { id, provider: this.cfg.provider, model: this.cfg.model, thinking: this.cfg.thinking || '', text: r.text.slice(0, 90000), count: 5 });
      if (!this.job || this.job.id !== id) return;
      answer.quiz = { title: q.title || '本章自测', questions: q.questions, picks: [] };
      answer.text = quizMarkdown(answer.quiz);
      answer.parts = [{ text: answer.text }];
      answer.model = q.model || answer.model;
      this._finish(id, { type: 'done', text: answer.text, parts: answer.parts, model: answer.model, provider: q.provider });
    } catch (e) {
      if (/已停止/.test(e.message)) this._finish(id, { type: 'aborted' });
      else this._finish(id, { type: 'error', message: e.message });
    }
  }

  _quizEl(m, i) {
    const qz = m.quiz;
    const picks = qz.picks || (qz.picks = []);
    const answered = qz.questions.filter((_, k) => picks[k] != null).length;
    const right = qz.questions.filter((q, k) => picks[k] === q.answer).length;
    return el('div', { class: 'ai-quiz', dataset: { i: String(i) } },
      el('div', { class: 'qz-title' }, qz.title || '本章自测', el('span', { class: 'qz-score' }, answered ? `　${right} / ${qz.questions.length}` : '')),
      ...qz.questions.map((q, k) => {
        const p = picks[k];
        return el('div', { class: 'qz-q' + (p != null ? (p === q.answer ? ' ok' : ' bad') : '') },
          el('div', { class: 'qz-stem' }, `${k + 1}. ${q.q}`),
          el('div', { class: 'qz-opts' }, q.options.map((o, j) => el('button', {
            class: 'qz-opt' + (p != null && j === q.answer ? ' right' : '') + (p === j && j !== q.answer ? ' wrong' : ''),
            disabled: p != null, dataset: { q: String(k), o: String(j) },
          }, `${'ABCDEF'[j]}. ${o}`))),
          p != null ? el('div', { class: 'qz-exp' }, (p === q.answer ? '✓ 答对了。' : `✗ 正确答案是 ${'ABCDEF'[q.answer]}。`) + (q.explain ? ' ' + q.explain : '')) : null);
      }),
      answered === qz.questions.length ? el('div', { class: 'qz-end' },
        `得分 ${right} / ${qz.questions.length}　`,
        el('button', { class: 'small-btn', dataset: { act: 'quiz-again' } }, '再出一组')) : null);
  }

  _pick(i, k, j) {
    const m = this.messages[i];
    if (!m || !m.quiz || (m.quiz.picks || [])[k] != null) return;
    m.quiz.picks[k] = j;
    const node = this.list.querySelector(`.ai-msg[data-i="${i}"] .ai-quiz`);
    if (node) node.replaceWith(this._quizEl(m, i));
    this._persist();
  }

  // ------------------------------------------------------------------ rendering
  _renderAttach() {
    if (!this.attach) { this.attachEl.hidden = true; this.attachEl.replaceChildren(); return; }
    this.attachEl.hidden = false;
    const t = this.attach.text.replace(/\s+/g, ' ');
    this.attachEl.replaceChildren(
      el('span', { class: 'lbl' }, '附带：'),
      el('span', { class: 'txt', title: this.attach.text.slice(0, 1200) }, t.length > 60 ? t.slice(0, 60) + '…' : t),
      el('button', { class: 'icon-btn', title: '不附带', onclick: () => { this.attach = null; this._renderAttach(); } }, '✕'));
  }

  render() {
    this._renderAttach();
    if (!this.messages.length) {
      this.list.replaceChildren(el('div', { class: 'ai-empty' },
        el('div', { class: 'ai-empty-title' }, '和 AI 讨论正在读的内容' + (this.cfg && this.cfg.hasKey ? `（${this.cfg.providerName}）` : '')),
        el('ul', {},
          el('li', {}, '在书中选中文字，点下方“解释所选”“翻译所选”'),
          el('li', {}, '读不懂的英文长句：选中后点“长难句”，拆出主干、从句和修饰成分并翻译'),
          el('li', {}, '段落右键：AI 解释 / 翻译 / 解析本段；词典栏“问 AI”'),
          el('li', {}, '“总结本章”会把本章正文发给模型；“出题自测”根据本章出选择题，点选作答看解析'),
          el('li', {}, '顶部可以切换服务和模型（Gemini、DeepSeek、OpenAI、Claude、本机模型等）；“思考”控制先思考再回答的程度'),
          el('li', {}, 'Ctrl+J 打开 AI 对话；回答可复制、重新生成'))));
      return;
    }
    this.list.replaceChildren(...this.messages.map((m, i) => (m.role === 'user' ? this._userEl(m, i) : this._modelEl(m, i))));
    this._scrollBottom(true);
  }

  _userEl(m, i) {
    return el('div', { class: 'ai-msg user', dataset: { i: String(i) } },
      el('div', { class: 'ai-bubble' },
        m.title ? el('div', { class: 'ai-title' }, m.title) : null,
        m.images && m.images.length ? el('div', { class: 'ai-imgs' }, m.images.map((src, k) => el('img', { src, alt: '图片', title: '点击放大', onclick: () => {
          // the picture that was sent (this session) or its preview (chat from the history)
          const full = (m.parts || []).filter((p) => p.inlineData)[k];
          this.app.showImage(full ? `data:${full.inlineData.mimeType};base64,${full.inlineData.data}` : src, { title: m.title || '图片' });
        } }))) : null,
        m.quote ? el('div', { class: 'ai-quote', title: '点击展开 / 收起' }, m.quote) : null,
        m.text ? el('div', { class: 'ai-text' }, m.text) : null));
  }

  // Ask the model to explain a picture (book figure, PDF figure or region). dataUrl: data:image/...;base64
  async askImage({ dataUrl, caption, title } = {}) {
    const m = /^data:(image\/(?:png|jpeg|webp|gif));base64,([A-Za-z0-9+/=]+)$/.exec(String(dataUrl || ''));
    if (!m) { toast('无法读取这张图片', { type: 'error' }); return; }
    if (this.job) { this.app.openAi(false); toast('请等当前回答结束'); return; }
    if (!this.cfg || !this.cfg.hasKey) { this.app.openAi(); toast(NO_KEY_MSG); return; }
    let thumb = '';
    try { thumb = await shrinkDataUrl(dataUrl, 420); } catch { thumb = ''; }
    const cap = [caption && caption.en, caption && caption.zh].filter(Boolean).join('\n');
    const prompt = [
      '请帮我读懂这张交易 / 金融教材里的图表，用简体中文回答：',
      '1. 图里画的是什么：坐标轴、数据、指标、图例；',
      '2. 关键的形态、信号或数字，以及它们说明了什么；',
      '3. 结合图注和教材内容，这张图想让读者学到什么，对实际交易有什么启示；',
      '4. 图中英文标注和术语的中文意思（术语后保留英文原文）。',
      cap ? '\n图注：\n' + cap : '',
    ].filter(Boolean).join('\n');
    this.app.openAi(false);
    await this.send('', { title: '解读图表' + (title ? '：' + String(title).slice(0, 40) : ''), quote: cap.slice(0, 300), prompt, image: { mimeType: m[1], data: m[2] }, images: thumb ? [thumb] : undefined });
  }

  // the model's reasoning (DeepSeek, Claude, local reasoning models …), folded
  _thoughtEl(m) {
    const live = m.pending && !m.text;
    const n = (m.thought || '').length;
    const d = el('details', { class: 'ai-thought' + (live ? ' live' : '') },
      el('summary', {}, live ? `正在思考…（${n} 字）` : `思考过程（${n} 字）`),
      el('div', { class: 'ai-thought-body' }, m.thought || ''));
    d.addEventListener('toggle', () => { m._thoughtOpen = d.open; });
    if (m._thoughtOpen) d.open = true;
    return d;
  }

  _modelTag(m) {
    if (!m.model) return '';
    if (!m.provider) return m.model;
    return this.providerShort(m.provider) + ' · ' + m.model;
  }

  _modelEl(m, i) {
    const last = i === this.messages.length - 1;
    const body = m.quiz ? this._quizEl(m, i) : el('div', { class: 'ai-md', html: m.text ? renderMarkdown(m.text) : '' });
    if (m.pending && !m.text && !m.thought) body.append(el('span', { class: 'ai-typing' }, m.kind === 'quiz' ? '正在出题' : '正在思考'));
    const node = el('div', { class: 'ai-msg model' + (m.pending ? ' streaming' : '') + (m.error ? ' failed' : ''), dataset: { i: String(i) } }, m.thought ? this._thoughtEl(m) : null, body);
    if (m.note) node.append(el('div', { class: 'ai-note' }, m.note));
    if (m.error) {
      // key / balance / model problems: offer the place where they are fixed
      const fix = /API Key|余额|找不到模型|模型名称|接口地址|设置 → AI 对话/.test(m.error);
      node.append(el('div', { class: 'ai-err' }, m.error,
        fix ? el('div', { class: 'ai-err-act' }, el('a', { href: '#', onclick: (e) => { e.preventDefault(); this.app.openSettings('ai'); } }, '打开 设置 → AI 对话')) : null));
    }
    if (!m.pending) {
      node.append(el('div', { class: 'ai-meta' },
        el('span', { class: 'ai-model-tag', title: m.usage ? `输入 ${m.usage.prompt} · 输出 ${m.usage.output}${m.usage.thoughts ? ' · 思考 ' + m.usage.thoughts : ''} tokens` : '' }, this._modelTag(m)),
        el('span', { class: 'grow' }),
        m.text ? el('button', { class: 'icon-btn', title: '复制回答', dataset: { act: 'copy' } }, '⧉') : null,
        last ? el('button', { class: 'icon-btn', title: m.error ? '重试' : '重新生成', dataset: { act: 'regen' } }, '↻') : null));
    }
    return node;
  }

  _scheduleStream() {
    if (this._raf) return;
    this._raf = requestAnimationFrame(() => {
      this._raf = 0;
      if (!this.job) return;
      const m = this.job.msg;
      const i = this.messages.indexOf(m);
      const msgEl = this.list.querySelector(`.ai-msg[data-i="${i}"]`);
      const node = msgEl && msgEl.querySelector('.ai-md');
      if (!node) { this.render(); return; }
      const stick = this._nearBottom();
      if (m.thought) {
        const th = msgEl.querySelector('.ai-thought');
        if (!th) this.render();
        else {
          const live = !m.text;
          th.classList.toggle('live', live);
          th.querySelector('summary').textContent = live ? `正在思考…（${m.thought.length} 字）` : `思考过程（${m.thought.length} 字）`;
          th.querySelector('.ai-thought-body').textContent = m.thought;
          const typing = node.querySelector('.ai-typing');
          if (typing) typing.remove();
        }
      }
      if (m.text) node.innerHTML = renderMarkdown(m.text);
      if (stick) this._scrollBottom();
    });
  }

  _nearBottom() {
    const l = this.list;
    return l.scrollHeight - l.scrollTop - l.clientHeight < 80;
  }

  _scrollBottom(force) {
    if (force || this._nearBottom()) this.list.scrollTop = this.list.scrollHeight;
  }

  _onListClick(e) {
    const a = e.target.closest('a[data-ext]');
    if (a) { e.preventDefault(); this.app.openExternal(a.getAttribute('href')); return; }
    const q = e.target.closest('.ai-quote');
    if (q) { q.classList.toggle('open'); return; }
    const opt = e.target.closest('.qz-opt');
    if (opt) { this._pick(+opt.closest('.ai-msg').dataset.i, +opt.dataset.q, +opt.dataset.o); return; }
    const btn = e.target.closest('[data-act]');
    if (!btn) return;
    if (btn.dataset.act === 'quiz-again') { this.quiz(); return; }
    const i = +btn.closest('.ai-msg').dataset.i;
    const m = this.messages[i];
    if (!m) return;
    if (btn.dataset.act === 'copy') this.app.copyOut(m.text);
    else if (btn.dataset.act === 'regen') this.regenerate(i);
  }

  _onKey(e) {
    e.stopPropagation();
    if (e.key === 'Enter' && !e.shiftKey && !e.isComposing && e.keyCode !== 229) {
      e.preventDefault();
      if (!this.job) this.send();
    } else if (e.key === 'Escape') {
      this.input.blur();
      this.app.refocusReader();
    } else if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'j') {
      e.preventDefault();
    }
  }
}

// a smaller JPEG copy of a picture (previews kept in the chat history)
function shrinkDataUrl(src, max) {
  return new Promise((res, rej) => {
    const im = new Image();
    im.onload = () => {
      const k = Math.min(1, max / Math.max(im.naturalWidth || 1, im.naturalHeight || 1));
      const c = document.createElement('canvas');
      c.width = Math.max(1, Math.round((im.naturalWidth || 1) * k));
      c.height = Math.max(1, Math.round((im.naturalHeight || 1) * k));
      const g = c.getContext('2d');
      g.fillStyle = '#fff';
      g.fillRect(0, 0, c.width, c.height);
      g.drawImage(im, 0, 0, c.width, c.height);
      res(c.toDataURL('image/jpeg', 0.82));
    };
    im.onerror = () => rej(new Error('图片无法读取'));
    im.src = src;
  });
}
