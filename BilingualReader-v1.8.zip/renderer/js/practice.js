// 练习 with the book's own text:
//  - 回译: the Chinese translation of a paragraph is shown, the learner writes the English and compares it
//    with the original word by word (key words used); AI can comment on the attempt
//  - 听写: an English sentence is read aloud, the learner writes it down; missed and wrong words are
//    marked, any word of the sentence can be looked up and added to the vocabulary book
// The material is the chapter on screen (回译 needs a bilingual chapter); 听写 also works on PDF pages.
import { el, toast, escapeHtml } from './util.js';
import * as api from './api.js';
import { hasHan, sentences } from './textlang.js';
import { readableText, englishSentences, spoken, PdfSource } from './readaloud.js';
import { renderMarkdown } from './markdown.js';
import { shortDefOf } from './study.js';
import { icon } from './icons.js';

export const PRACTICE_MODES = [['translate', '回译'], ['dictate', '听写']];
const MIN_WORDS = 4; // shorter pieces (headings, labels) are left out
const MAX_DICTATE = 40; // words of a dictation sentence
const LONG = 70; // a longer paragraph is practised a few sentences at a time…
const CHUNK = 45; // …of about this many words

// ---------------------------------------------------------------- comparing an answer with the original
const WORD = /[A-Za-z0-9]+(?:['’.][A-Za-z0-9]+)*/g;
// words that do not count for "key words" (回译 is judged on the words that carry the meaning)
const STOP = new Set(('a an the of to in on at by for from with as and or but nor so if than then that this these those there here ' +
  'it its is are was were be been being am do does did done has have had having will would can could may might shall should must ' +
  'not no into onto over under about up out off which who whom whose what when where why how all any each both such more most ' +
  'other some own same very just also only they them their he him his she her we us our you your i me my one').split(' '));

export function wordTokens(text) {
  const out = [];
  const s = String(text || '');
  WORD.lastIndex = 0;
  let m;
  while ((m = WORD.exec(s))) out.push({ w: m[0], s: m.index, e: m.index + m[0].length });
  return out;
}

const low = (w) => w.toLowerCase().replace(/’/g, "'");

// A rough English stem, so that "hedges / hedged / hedging" match "hedge" when an answer is compared
// loosely (回译: the meaning matters more than the exact form).
export function stem(w) {
  let k = low(w).replace(/'s$/, '');
  if (/\d/.test(k) || k.length <= 3) return k;
  if (k.endsWith('ies') && k.length > 4) k = k.slice(0, -3) + 'y';
  else if (k.endsWith('ing') && k.length > 5) k = k.slice(0, -3);
  else if (k.endsWith('ed') && k.length > 4) k = k.slice(0, -2);
  else if (/(?:ss|x|z|ch|sh)es$/.test(k)) k = k.slice(0, -2);
  else if (k.endsWith('s') && !k.endsWith('ss')) k = k.slice(0, -1);
  if (k.length > 3 && /([b-df-hj-np-tv-z])\1$/.test(k)) k = k.slice(0, -1); // stopp(ed) → stop
  if (k.length > 3 && k.endsWith('e')) k = k.slice(0, -1); // hedge / hedg(ing)
  return k;
}

// Word-by-word comparison (longest common subsequence). Marks tok.ok on both sides and counts.
export function compareWords(ref, answer, loose) {
  const A = wordTokens(ref);
  const B = wordTokens(answer).slice(0, 1500);
  const key = loose ? (t) => stem(t.w) : (t) => low(t.w);
  const ka = A.map(key);
  const kb = B.map(key);
  const n = A.length;
  const m = B.length;
  const L = [];
  for (let i = 0; i <= n; i++) L.push(new Uint16Array(m + 1));
  for (let i = n - 1; i >= 0; i--) {
    for (let j = m - 1; j >= 0; j--) L[i][j] = ka[i] === kb[j] ? L[i + 1][j + 1] + 1 : Math.max(L[i + 1][j], L[i][j + 1]);
  }
  for (let i = 0, j = 0; i < n && j < m;) {
    if (ka[i] === kb[j]) { A[i].ok = true; B[j].ok = true; i++; j++; }
    else if (L[i + 1][j] >= L[i][j + 1]) i++;
    else j++;
  }
  const content = A.filter((t) => !STOP.has(low(t.w)));
  const keyWords = content.length ? content : A;
  return {
    ref: A,
    ans: B,
    total: A.length,
    matched: A.filter((t) => t.ok).length,
    keyTotal: keyWords.length,
    keyMatched: keyWords.filter((t) => t.ok).length,
    extra: B.filter((t) => !t.ok).length,
  };
}

// the text with every word in a span: matched words plain, the others marked with cls
function markedHtml(text, toks, cls) {
  const gap = (s) => escapeHtml(s).replace(/\n/g, '<br>');
  let out = '';
  let at = 0;
  for (const t of toks) {
    out += gap(text.slice(at, t.s)) + `<span class="pw ${t.ok ? 'ok' : cls}" data-w="${escapeHtml(t.w)}">${escapeHtml(t.w)}</span>`;
    at = t.e;
  }
  return out + gap(text.slice(at));
}

// first letters only: "The b__-a__ s_____ is …"
export function initials(text) {
  let out = '';
  let at = 0;
  for (const t of wordTokens(text)) {
    out += text.slice(at, t.s) + (/^\d/.test(t.w) ? t.w : t.w[0] + '_'.repeat(t.w.length - 1));
    at = t.e;
  }
  return out + text.slice(at);
}

// ---------------------------------------------------------------- material from the chapter on screen
const isHeading = (g) => [...g.en, ...g.zh].some((u) => /^h[1-6]$/.test(((u.leaf || u.el) || {}).localName || ''));

// text of one language of a paragraph group (one line per paragraph)
function groupText(view, g, lang) {
  let els;
  if (view.effMode !== 'original') {
    const cell = lang === 'en' ? g.enCell : g.zhCell;
    els = cell ? [...cell.children] : [];
  } else els = (g[lang] || []).map((u) => u.seg || u.el).filter(Boolean);
  return els.map((e) => readableText(e)).filter(Boolean).join('\n');
}

// the group of an element, quickly (the Chinese cell of a row belongs to the same group)
function groupLookup(view) {
  const plan = view.plan;
  if (!plan || !plan.groups) return () => null;
  if (view.effMode !== 'original') {
    const byRow = new Map(plan.groups.map((g) => [g.row, g]));
    return (e) => {
      const row = e && e.closest ? e.closest('.br-row.br-group') : null;
      return (row && byRow.get(row)) || null;
    };
  }
  return (e) => view.groupFor(e);
}

// 回译: paragraphs with their translation (a long one a few sentences at a time, when both languages
// have the same number of sentences)
function translateUnits(view) {
  const plan = view.plan;
  if (!view.doc || !plan || !plan.bilingual) return [];
  const out = [];
  for (const g of plan.groups) {
    if (!g.en.length || !g.zh.length || isHeading(g)) continue;
    const en = groupText(view, g, 'en');
    const zh = groupText(view, g, 'zh');
    const n = wordTokens(en).length;
    if (n < MIN_WORDS || !hasHan(zh)) continue;
    if (n > LONG) {
      const es = sentences(en.replace(/\n/g, ' '), 'en');
      const zs = sentences(zh.replace(/\n/g, ''), 'zh');
      if (es.length > 1 && es.length === zs.length) {
        let ce = [];
        let cz = [];
        let cw = 0;
        const flush = () => {
          if (ce.length) out.push({ g, en: ce.join(' '), zh: cz.join(''), part: true });
          ce = [];
          cz = [];
          cw = 0;
        };
        es.forEach((s, k) => {
          const w = wordTokens(s.text).length;
          if (cw && cw + w > CHUNK) flush();
          ce.push(s.text);
          cz.push(zs[k].text);
          cw += w;
        });
        flush();
        continue;
      }
    }
    out.push({ g, en, zh });
  }
  return out;
}

// 听写: English sentences of the chapter (also when only the Chinese is shown: nothing to peek at)
function dictateUnits(view) {
  const doc = view.doc;
  if (!doc || !doc.body) return [];
  const find = groupLookup(view);
  const blocks = [...doc.querySelectorAll('[data-lang="en"]')].filter((e) => !e.querySelector('[data-lang="en"]') &&
    !/^h[1-6]$/.test(e.localName) && !e.closest('.br-ui, .br-chapter-nav, table, h1, h2, h3, h4, h5, h6'));
  const out = [];
  for (const b of blocks) {
    const text = readableText(b);
    if (!text) continue;
    const ss = englishSentences(text);
    const g = find(b);
    ss.forEach((s, si) => {
      const t = text.slice(s.start, s.end).trim();
      const n = wordTokens(t).length;
      if (n >= MIN_WORDS && n <= MAX_DICTATE) out.push({ en: spoken(t, false).say, block: b, g, si, sn: ss.length, start: s.start });
    });
  }
  return out;
}

// the element a piece of material starts at
function anchorOf(view, u) {
  if (u.block) return u.block;
  if (u.g) {
    if (view.effMode !== 'original') return u.g.enCell || u.g.row || null;
    const f = u.g.en[0];
    return (f && (f.seg || f.el)) || null;
  }
  return null;
}

// where to begin: the paragraph (or sentence) of the point, else the first piece after it
function startIndex(view, units, from, mode) {
  if (!units.length) return 0;
  let node = from && from.node;
  if (!node && !(from && from.atStart)) node = view._blockAtTop ? view._blockAtTop() : null;
  if (!node) return 0;
  const elx = node.nodeType === 1 ? node : node.parentElement;
  if (!elx) return 0;
  if (mode === 'dictate' && from && from.node) {
    const blk = elx.closest('[data-lang="en"]');
    const mine = blk ? units.filter((u) => u.block === blk) : [];
    if (mine.length) {
      let before = 0;
      try {
        const r = view.doc.createRange();
        r.setStart(blk, 0);
        r.setEnd(from.node, from.offset || 0);
        before = r.toString().replace(/\s+/g, ' ').trimStart().length;
      } catch { before = 0; }
      return units.indexOf([...mine].reverse().find((u) => u.start <= before) || mine[0]);
    }
  }
  const g = groupLookup(view)(elx);
  if (g) {
    const k = units.findIndex((u) => u.g === g);
    if (k >= 0) return k;
  }
  for (let k = 0; k < units.length; k++) {
    const a = anchorOf(view, units[k]);
    if (a && (a === elx || a.contains(elx) || elx.contains(a) || (elx.compareDocumentPosition(a) & Node.DOCUMENT_POSITION_FOLLOWING))) return k;
  }
  return 0;
}

// ---------------------------------------------------------------- the practice window
export class PracticeSession {
  constructor(app) {
    this.app = app;
    this.root = document.getElementById('practice');
    this.open = false;
    this.slow = false;
    this.tok = 0;
    this.card = null;
    this.onKey = (e) => this._key(e);
  }

  get isPdf() { return this.view === this.app.pdf; }

  // mode: 'translate' | 'dictate'; from: { node, offset } (a point in the book) or null (where the reader is)
  async start(mode, from) {
    const app = this.app;
    if (!app.view || !app.book) { toast('请先打开一本书'); return false; }
    if (this.open) this.close();
    if (app.tts.active) app.tts.stop();
    this.view = app.view;
    let m = mode === 'dictate' ? 'dictate' : 'translate';
    if (m === 'translate' && !this._canTranslate()) {
      toast(this.isPdf ? 'PDF 没有中英配对的段落，先做听写练习' : '本章没有中英对照的段落（回译需要中英对照的内容），先做听写练习', { ms: 3500 });
      m = 'dictate';
    }
    const r = await this._build(m, from);
    if (!r.units.length) {
      toast(m === 'dictate' ? (this.isPdf ? '这一页附近没有可以听写的英文句子（扫描版 PDF 没有文字层）' : '本章没有可以听写的英文句子') : '本章没有可以回译的段落');
      return false;
    }
    this.mode = m;
    app.settings.practiceMode = m;
    app.saveSettingsSoon();
    this.units = r.units;
    this.i = r.i;
    this.res = { translate: { n: 0, key: 0, keyOk: 0 }, dictate: { n: 0, perfect: 0, words: 0, ok: 0 } };
    this.open = true;
    app.modalOpen = true;
    app.closeMenus();
    this.root.hidden = false;
    this._listen(true);
    this._show();
    return true;
  }

  close() {
    if (!this.open) return;
    // an answer not checked yet is kept: it comes back when the same piece is practised again
    const c = this.card;
    if (c && !c.checked && this.input && this.input.value.trim()) this.draft = { en: c.u.en, text: this.input.value };
    this.open = false;
    this.card = null;
    this._stopSpeech();
    this.root.hidden = true;
    this.root.replaceChildren();
    this.app.modalOpen = false;
    this._listen(false);
    this.app.study.refresh();
    this.app.refocusReader();
  }

  _listen(on) {
    const f = on ? 'addEventListener' : 'removeEventListener';
    document[f]('keydown', this.onKey, true);
    for (const fr of document.querySelectorAll('iframe')) try { fr.contentDocument[f]('keydown', this.onKey, true); } catch { /* ignore */ }
  }

  _canTranslate() { return !this.isPdf && !!(this.view.plan && this.view.plan.bilingual); }

  async _build(mode, from) {
    const v = this.view;
    if (v === this.app.pdf) {
      this.pdfSrc = new PdfSource(v);
      let r;
      try { r = await this.pdfSrc.begin(from); } catch { r = { list: [], i: 0 }; }
      const units = this._pdfUnits(r.list);
      let i = units.findIndex((u) => u.k >= r.i);
      if (i < 0) i = Math.max(0, units.length - 1);
      return { units, i };
    }
    const units = mode === 'translate' ? translateUnits(v) : dictateUnits(v);
    return { units, i: startIndex(v, units, from, mode) };
  }

  _pdfUnits(list) {
    return (list || []).map((s) => ({ en: spoken(s.text, true).say, page: s.page, k: s.k }))
      .filter((u) => { const n = wordTokens(u.en).length; return n >= MIN_WORDS && n <= MAX_DICTATE; });
  }

  _chapterTitle() {
    const v = this.view;
    if (this.isPdf) return '';
    return (v.book && v.book.chapterTitles && v.book.chapterTitles[v.index]) || '';
  }

  _where(u) { return this.isPdf ? `第 ${u.page} 页` : this._chapterTitle(); }

  _frame(...body) {
    const n = this.units ? this.units.length : 0;
    const pct = n ? Math.round((Math.min(this.i, n) / n) * 100) : 100;
    const mode = el('select', { class: 'rv-mode pr-mode', title: this.isPdf ? 'PDF 只能做听写练习' : '练习方式（从当前这一段换）' },
      PRACTICE_MODES.map(([v, l]) => el('option', { value: v }, l)));
    mode.value = this.mode;
    mode.disabled = this.isPdf;
    mode.addEventListener('change', () => this.switchMode(mode.value));
    this.root.replaceChildren(el('div', { class: 'rv-box pr-box', tabindex: '-1' },
      el('div', { class: 'rv-head' },
        el('span', { class: 'rv-title' }, this.mode === 'dictate' ? '听写练习' : '回译练习'),
        el('span', { class: 'rv-prog' }, n && this.i < n ? `${this.i + 1} / ${n}` : ''),
        el('div', { class: 'rv-bar' }, el('i', { style: { width: pct + '%' } })),
        mode,
        el('button', { class: 'icon-btn', title: '结束练习（Esc）', onclick: () => this.close() }, '✕')),
      ...body));
  }

  _show() {
    if (!this.open) return;
    if (this.i >= this.units.length) {
      if (this.isPdf) this._nextPage();
      else this._end();
      return;
    }
    const u = this.units[this.i];
    if (this.mode === 'dictate') this._dictateCard(u);
    else this._translateCard(u);
  }

  _preButtons() {
    const d = this.mode === 'dictate';
    this.btnEl.replaceChildren(
      el('button', { onclick: () => this._next() }, '跳过'),
      el('button', { onclick: () => this._hint() }, d ? '显示首字母' : '提示关键词'),
      el('button', { class: 'primary', onclick: () => this._check() }, d ? '检查（Enter）' : '对照原文（Ctrl+Enter）'));
  }

  // ---------- cards
  _translateCard(u) {
    const c = { u, checked: false, hints: 0 };
    this.card = c;
    this.input = el('textarea', { class: 'pr-input', rows: '4', spellcheck: 'false', autocomplete: 'off', placeholder: '用英文写出这段话，写完按 Ctrl+Enter 对照原文' });
    this.hintEl = el('div', { class: 'pr-hint' });
    this.resEl = el('div', { class: 'pr-result', hidden: true });
    this.btnEl = el('div', { class: 'rv-btns' });
    this._preButtons();
    this._frame(
      el('div', { class: 'rv-card pr-card' },
        el('div', { class: 'pr-label' }, el('span', {}, '中文（书中的译文）'),
          u.part ? el('span', { class: 'pr-tag', title: '这一段比较长，按句子分成几次练习' }, '长段 · 分句') : null,
          el('span', { class: 'grow' }), el('span', { class: 'pr-src' }, this._where(u))),
        el('div', { class: 'pr-zh' }, u.zh),
        this.input, this.hintEl, this.resEl),
      this.btnEl);
    this._restoreDraft(u);
    setTimeout(() => { if (this.card === c) this.input.focus(); }, 0);
  }

  _restoreDraft(u) {
    if (this.draft && this.draft.en === u.en) this.input.value = this.draft.text;
    this.draft = null;
  }

  _dictateCard(u) {
    const c = { u, checked: false, plays: 0, hints: 0 };
    this.card = c;
    this.input = el('textarea', { class: 'pr-input one', rows: '2', spellcheck: 'false', autocomplete: 'off', placeholder: '写下听到的英文句子，Enter 检查（Ctrl+R 再听一遍）' });
    this.metaEl = el('div', { class: 'pr-meta' });
    this.slowBtn = el('button', { class: 'small-btn pr-slow' + (this.slow ? ' on' : ''), title: '用较慢的语速播放', onclick: () => { this.slow = !this.slow; this.slowBtn.classList.toggle('on', this.slow); this._play(); this.input.focus(); } }, '慢速');
    this.hintEl = el('div', { class: 'pr-hint' });
    this.resEl = el('div', { class: 'pr-result', hidden: true });
    this.btnEl = el('div', { class: 'rv-btns' });
    this._preButtons();
    this._frame(
      el('div', { class: 'rv-card pr-card' },
        el('div', { class: 'pr-label' }, el('span', {}, '听写：听一句，写一句'), el('span', { class: 'grow' }), el('span', { class: 'pr-src' }, this._where(u))),
        el('div', { class: 'pr-play-row' },
          el('button', { class: 'pr-play', title: '播放（Ctrl+R）', html: icon('play', 28), onclick: () => { this._play(); this.input.focus(); } }),
          this.slowBtn),
        this.metaEl,
        this.input, this.hintEl, this.resEl),
      this.btnEl);
    this._restoreDraft(u);
    setTimeout(() => { if (this.card === c) this.input.focus(); }, 0);
    this._play();
  }

  _meta() {
    const c = this.card;
    if (!c || !this.metaEl || this.mode !== 'dictate') return;
    this.metaEl.textContent = `共 ${wordTokens(c.u.en).length} 个词` + (c.plays ? ` · 已播放 ${c.plays} 次` : '');
  }

  // ---------- speech (听写)
  _play() {
    const c = this.card;
    if (!c || this.mode !== 'dictate') return;
    const synth = window.speechSynthesis;
    if (!synth) { toast('系统不支持语音朗读'); return; }
    try { synth.cancel(); } catch { /* ignore */ }
    const tok = ++this.tok;
    clearTimeout(this._playT);
    // (Chromium sometimes drops an utterance queued right after cancel())
    this._playT = setTimeout(() => {
      if (tok !== this.tok || this.card !== c || !this.open) return;
      const u = new SpeechSynthesisUtterance(c.u.en);
      const v = this.app.pickVoice();
      if (v) { u.voice = v; u.lang = v.lang; } else u.lang = 'en-US';
      const base = +this.app.settings.ttsRate || 0.9;
      u.rate = this.slow ? Math.max(0.5, Math.round(base * 70) / 100) : base;
      this.utt = u; // keep a reference: Chromium may otherwise drop the events
      try { synth.speak(u); } catch { toast('朗读失败'); }
    }, 60);
    c.plays++;
    this._meta();
  }

  _stopSpeech() {
    this.tok++;
    clearTimeout(this._playT);
    try { if (window.speechSynthesis) window.speechSynthesis.cancel(); } catch { /* ignore */ }
  }

  // ---------- hints
  async _hint() {
    const c = this.card;
    if (!c || c.checked) return;
    c.hints++;
    if (this.mode === 'dictate') {
      this.hintEl.textContent = '首字母：' + initials(c.u.en);
      this.input.focus();
      return;
    }
    // 回译: the finance terms of the original (with their Chinese), then its longer words
    if (!c.terms) {
      let terms = [];
      try { terms = await api.call('glossary', c.u.en); } catch { terms = []; }
      if (this.card !== c) return;
      const list = [];
      const seen = [];
      for (const t of terms) {
        const k = t.w.toLowerCase();
        if (seen.includes(k)) continue;
        seen.push(k);
        list.push(t.w + (t.fin ? `（${t.fin}）` : ''));
      }
      for (const t of wordTokens(c.u.en)) {
        const k = low(t.w);
        if (t.w.length < 7 || STOP.has(k) || seen.some((s) => s.includes(k) || k.includes(s) || stem(s) === stem(k))) continue;
        seen.push(k);
        list.push(t.w);
      }
      c.terms = list;
    }
    if (!c.terms.length) this.hintEl.textContent = '这一段没有需要提示的关键词，试着写写看';
    else {
      const n = Math.min(c.terms.length, c.hints * 3);
      this.hintEl.textContent = '提示：' + c.terms.slice(0, n).join(' · ') + (n < c.terms.length ? '　…（再点一次多看几个）' : '');
    }
    this.input.focus();
  }

  // ---------- checking
  _check() {
    const c = this.card;
    if (!c || c.checked) return;
    const ans = this.input.value.trim();
    if (!ans) {
      this.hintEl.textContent = this.mode === 'dictate' ? '先写下听到的句子（没听清可以按 Ctrl+R 再听）' : '先用英文写一写，再对照原文';
      this.input.focus();
      return;
    }
    c.checked = true;
    c.answer = ans;
    const loose = this.mode === 'translate';
    const d = compareWords(c.u.en, ans, loose);
    const good = loose ? d.keyTotal > 0 && d.keyMatched / d.keyTotal >= 0.6 : d.matched === d.total && !d.extra;
    if (loose) { const t = this.res.translate; t.n++; t.key += d.keyTotal; t.keyOk += d.keyMatched; }
    else { const t = this.res.dictate; t.n++; t.words += d.total; t.ok += d.matched; if (good) t.perfect++; }
    api.call('statsPractice', this.mode, good).catch(() => {});
    this.input.hidden = true;
    this._result(c, d, good);
    this.btnEl.replaceChildren(
      el('button', { onclick: () => this._retry() }, this.mode === 'dictate' ? '再听写一遍' : '再写一遍'),
      el('button', { class: 'primary', onclick: () => this._next() }, (this.mode === 'dictate' ? '下一句' : '下一段') + '（Enter）'));
    this.root.querySelector('.rv-box').focus();
  }

  _result(c, d, good) {
    const u = c.u;
    const dict = this.mode === 'dictate';
    const pct = (a, b) => (b ? Math.round((a / b) * 100) : 0);
    let score;
    if (dict) {
      score = el('div', { class: 'pr-score' + (good ? ' good' : '') },
        good ? '✓ 全对' : `听对 ${d.matched} / ${d.total} 个词` + (d.extra ? `，多写或写错 ${d.extra} 处` : ''));
    } else {
      const p = pct(d.keyMatched, d.keyTotal);
      score = el('div', { class: 'pr-score' + (good ? ' good' : '') },
        el('span', {}, `用到原文关键词 ${p}%`),
        el('span', { class: 'meter' }, el('i', { style: { width: p + '%' } })),
        el('span', { class: 'muted' }, `${d.keyMatched} / ${d.keyTotal} 个（只比较用词；意思和语法可以让 AI 点评）`));
    }
    this.defEl = el('div', { class: 'pr-def', hidden: true });
    this.aiEl = el('div', { class: 'pr-ai ai-md', hidden: true });
    const zh = dict ? this._zhOf(u) : '';
    const ref = el('div', { class: 'pr-text ref', html: markedHtml(u.en, d.ref, 'miss'), title: '点任意一个词查释义' });
    ref.addEventListener('click', (e) => { const w = e.target.closest('.pw'); if (w) this._word(w.dataset.w, u); });
    this.resEl.replaceChildren(...[
      score,
      el('div', { class: 'pr-sec' }, dict ? '原句（红色是没写出来的词）' : '原文（红色是你没有用到的词）'),
      ref,
      el('div', { class: 'pr-sec' }, '你写的' + (d.extra ? '（划掉的是原文里没有的）' : '')),
      el('div', { class: 'pr-text ans', html: markedHtml(c.answer, d.ans, 'extra') }),
      zh ? el('div', { class: 'pr-sec' }, '译文') : null,
      zh ? el('div', { class: 'pr-zh small' }, zh) : null,
      this.defEl,
      el('div', { class: 'pr-acts' },
        el('button', { class: 'small-btn', onclick: () => (dict ? this._play() : this.app.speakText(u.en)) }, dict ? '🔊 再听原句' : '🔊 朗读原文'),
        dict ? null : el('button', { class: 'small-btn', title: '让 AI 指出漏译、错译和语法问题，并给出更地道的说法', onclick: () => this._aiReview() }, '✦ AI 点评'),
        el('button', { class: 'small-btn', onclick: () => this.app.copyOut(u.en) }, '复制原文'),
        this._posOf(u) ? el('button', { class: 'small-btn', title: '关闭练习，跳到书中的这一段（Alt+↑ 返回）', onclick: () => this._jump(u) }, '跳到原文') : null),
      this.aiEl,
    ].filter(Boolean));
    this.resEl.hidden = false;
    this.hintEl.textContent = '';
  }

  _retry() {
    const c = this.card;
    if (!c || !c.checked) return;
    c.checked = false;
    c.answer = '';
    this.input.value = '';
    this.input.hidden = false;
    this.resEl.hidden = true;
    this.resEl.replaceChildren();
    this.hintEl.textContent = '';
    this._preButtons();
    this.input.focus();
    if (this.mode === 'dictate') this._play();
  }

  _next() {
    this._stopSpeech();
    this.i++;
    this._show();
  }

  // the translation of a dictation sentence (the sentence of the paired paragraph, or the paragraph)
  _zhOf(u) {
    if (!u.g || !u.block || !u.block.isConnected) return '';
    const zh = groupText(this.view, u.g, 'zh');
    if (!zh) return '';
    if (u.g.en.length === 1) {
      const zs = sentences(zh.replace(/\n/g, ''), 'zh');
      if (zs.length === u.sn && zs[u.si]) return zs[u.si].text;
    }
    return zh.length > 400 ? zh.slice(0, 400) + '…' : zh;
  }

  // ---------- a word of the original: meaning, add to the vocabulary book
  async _word(w, u) {
    const box = this.defEl;
    if (!box || !w) return;
    box.hidden = false;
    box.replaceChildren(el('span', { class: 'muted' }, `正在查 ${w} …`));
    let r = null;
    try { r = await api.call('lookup', w, { noStats: true }); } catch { r = null; }
    if (box !== this.defEl) return;
    const head = (r && (r.headword || r.query)) || w;
    const def = shortDefOf(r);
    const sentence = this._sentenceWith(u.en, w);
    box.replaceChildren(
      el('b', { class: 'pr-def-w' }, head),
      el('span', { class: 'pr-def-text' }, def || '词典里没有找到释义'),
      el('span', { class: 'grow' }),
      el('button', { class: 'icon-btn', title: '朗读', onclick: () => this.app.speak(head) }, '🔊'),
      el('button', { class: 'small-btn', title: '连同这句原文一起加入生词本', onclick: () => this._addVocab(head, def, sentence, u) }, '＋生词本'));
  }

  _sentenceWith(text, w) {
    const re = new RegExp('(?<![A-Za-z])' + w.replace(/[.*+?^${}()|[\]\\]/g, '\\$&') + '(?![A-Za-z])', 'i');
    const s = sentences(text, 'en').find((x) => re.test(x.text));
    return (s ? s.text : text).slice(0, 400);
  }

  async _addVocab(word, def, sentence, u) {
    let sentenceZh = '';
    if (this.mode === 'dictate') sentenceZh = this._zhOf(u);
    else if (u.zh) {
      const es = sentences(u.en, 'en');
      const zs = sentences(u.zh, 'zh');
      const k = es.findIndex((x) => x.text === sentence);
      sentenceZh = k >= 0 && es.length === zs.length ? zs[k].text : u.zh.length <= 400 ? u.zh : '';
    }
    try {
      const res = await api.call('vocabAdd', {
        word, def, sentence, sentenceZh,
        bookId: this.app.info ? this.app.info.bookId : '', bookTitle: this.app.book ? this.app.book.title : '',
        chapter: this._chapterTitle(), pos: this._posOf(u),
      });
      toast(res.duplicate ? '生词本里已有这条（同一原句）' : '已加入生词本：' + word);
      this.app.refreshVocab().catch(() => {});
    } catch (e) {
      toast('加入失败：' + e.message, { type: 'error' });
    }
  }

  // reading position of a piece of material
  _posOf(u) {
    const v = this.view;
    if (this.isPdf) return u.page ? { kind: 'pdf', page: u.page, percent: v.pages ? (u.page - 1) / v.pages : 0 } : null;
    const a = anchorOf(v, u);
    const b = a && a.isConnected && (a.closest('[data-bidx]') || a.querySelector('[data-bidx]'));
    if (!b) return null;
    const n = (v.book && v.book.spine.length) || 1;
    return { kind: 'flow', index: v.index, bidx: +b.dataset.bidx, frac: 0, percent: Math.min(1, v.index / n) };
  }

  _jump(u) {
    const v = this.view;
    const pos = this._posOf(u);
    const a = anchorOf(v, u);
    this.close();
    if (!pos) return;
    Promise.resolve(this.app.jumpTo(pos)).then(() => {
      if (!this.isPdf && a && a.isConnected) v.flash(a);
      this.app.showBackPill();
    }).catch(() => {});
  }

  // ---------- AI comments on a 回译 attempt (answer shown in the card, and kept in the AI chat)
  _aiReview() {
    const c = this.card;
    if (!c || !c.checked || this.mode !== 'translate') return;
    const ai = this.app.ai;
    const box = this.aiEl;
    box.hidden = false;
    const say = (t) => box.replaceChildren(el('div', { class: 'muted' }, t));
    if (!ai.cfg || !ai.cfg.hasKey) { say('还没有设置 AI 服务：在 设置 → AI 对话 中填写 API Key（Gemini、DeepSeek、OpenAI、Claude 或本机模型）后再试。'); return; }
    if (ai.job) { say('AI 正在回答另一个问题，请稍后再点。'); return; }
    say('AI 正在点评…');
    const prompt = '我在用英汉对照的交易教材做“回译”练习：先看书里的中文译文，自己写出英文，再和英文原文对照。请点评我的英文：\n' +
      '1. 意思是否准确、完整：指出漏译、错译的地方；\n' +
      '2. 语法、拼写和用词的问题：逐条列出，并给出改正后的写法；\n' +
      '3. 原文里有哪些值得学习的地道表达或金融术语用法；\n' +
      '4. 最后给出 0–10 分的评分和一句简短的建议。\n' +
      '请用简体中文回答，简洁、有条理。\n\n' +
      `中文译文：\n"""\n${c.u.zh}\n"""\n\n英文原文：\n"""\n${c.u.en}\n"""\n\n我的英文：\n"""\n${c.answer}\n"""`;
    const ok = ai.ask(prompt, {
      title: '回译点评',
      quote: c.answer.slice(0, 600),
      onUpdate: (m, done) => {
        if (this.card !== c || !box.isConnected) return;
        if (m.error) { box.replaceChildren(el('div', { class: 'pr-ai-err' }, 'AI 点评失败：' + m.error)); return; }
        if (m.text) box.innerHTML = renderMarkdown(m.text);
        else if (done) say(m.note || '没有收到回答');
        if (done) box.append(el('div', { class: 'pr-ai-foot muted' }, '（这次点评也保存在右侧“AI 对话”里，可以接着追问）'));
      },
    });
    if (!ok) say('现在不能使用 AI，请到右侧“AI 对话”查看。');
  }

  // ---------- switching between 回译 and 听写 (at the same place)
  async switchMode(m) {
    if (!this.open || m === this.mode) return;
    if (m === 'translate' && !this._canTranslate()) {
      toast(this.isPdf ? 'PDF 只能做听写练习' : '本章没有中英对照的段落，不能回译');
      this._show();
      return;
    }
    const u = this.units[Math.min(this.i, this.units.length - 1)];
    const a = u ? anchorOf(this.view, u) : null;
    this._stopSpeech();
    const r = await this._build(m, a ? { node: a, offset: 0 } : null);
    if (!this.open) return;
    if (!r.units.length) {
      toast(m === 'dictate' ? '本章没有可以听写的英文句子' : '本章没有可以回译的段落');
      this._show();
      return;
    }
    this.mode = m;
    this.app.settings.practiceMode = m;
    this.app.saveSettingsSoon();
    this.units = r.units;
    this.i = r.i;
    this._show();
  }

  // ---------- end of the chapter / page
  async _nextPage() {
    this.card = null;
    this._frame(el('div', { class: 'rv-card' }, el('div', { class: 'rv-sum muted' }, '翻到下一页…')));
    let r = null;
    for (let k = 0; k < 10; k++) {
      try { r = this.pdfSrc ? await this.pdfSrc.advance() : null; } catch { r = null; }
      if (!this.open) return;
      if (!r) break;
      const units = this._pdfUnits(r.list);
      if (units.length) { this.units = units; this.i = 0; this._show(); return; }
    }
    this._end(true);
  }

  _summary() {
    const t = this.res.translate;
    const d = this.res.dictate;
    const out = [];
    if (t.n) out.push(`回译 ${t.n} 段，平均用到原文关键词 ${Math.round((t.keyOk / Math.max(1, t.key)) * 100)}%。`);
    if (d.n) out.push(`听写 ${d.n} 句，全对 ${d.perfect} 句，听对 ${Math.round((d.ok / Math.max(1, d.words)) * 100)}% 的词。`);
    return out;
  }

  _end(lastPage) {
    this.card = null;
    this._stopSpeech();
    const v = this.view;
    const more = !this.isPdf && v.book && v.index < v.book.spine.length - 1;
    const lines = this._summary();
    this._frame(
      el('div', { class: 'rv-card rv-done' },
        el('div', { class: 'rv-word' }, this.isPdf ? (lastPage ? '🎉 已经练到最后一页' : '🎉 练完了') : '🎉 这一章练完了'),
        ...(lines.length ? lines : ['这次没有检查过的练习。']).map((l) => el('div', { class: 'rv-sum' }, l)),
        el('div', { class: 'rv-sum muted' }, '练习次数计入今天的学习统计。')),
      el('div', { class: 'rv-btns' },
        more ? el('button', { onclick: () => this._nextChapter() }, '下一章继续') : null,
        el('button', { class: 'primary', onclick: () => this.close() }, '完成（Enter）')));
  }

  async _nextChapter() {
    const v = this.view;
    for (let k = 0; k < 8 && v.book && v.index < v.book.spine.length - 1; k++) {
      this._frame(el('div', { class: 'rv-card' }, el('div', { class: 'rv-sum muted' }, '正在打开下一章…')));
      await v.show(v.index + 1, {});
      if (!this.open) return;
      this._listen(true); // the new chapter page
      if (this.mode === 'translate' && !this._canTranslate()) continue;
      const r = await this._build(this.mode, { atStart: true });
      if (!this.open) return;
      if (r.units.length) { this.units = r.units; this.i = 0; this._show(); return; }
    }
    toast('后面没有可以练习的章节了');
    this.units = [];
    this.i = 0;
    this._end();
  }

  // ---------- keys (taken before the reader sees them)
  _key(e) {
    if (!this.open || e.isComposing || e.keyCode === 229) return; // (typing with an input method)
    const k = e.key;
    const stop = () => { e.preventDefault(); e.stopPropagation(); };
    if (k === 'Escape') { stop(); this.close(); return; }
    if (k === 'F6' || k === 'F7' || k === 'F9') { stop(); return; } // the page must stay as it is
    if (e.target && e.target.closest && e.target.closest('.pr-mode')) return;
    const c = this.card;
    const ctrl = e.ctrlKey || e.metaKey;
    if (!c) {
      if (k === 'Enter') { stop(); const b = this.root.querySelector('.rv-btns button.primary'); if (b) b.click(); }
      return;
    }
    if (ctrl && k.toLowerCase() === 'r') { stop(); if (this.mode === 'dictate') this._play(); return; }
    if (!c.checked) {
      if (k === 'Enter' && (ctrl || (this.mode === 'dictate' && !e.shiftKey))) { stop(); this._check(); }
      return;
    }
    if (k === 'Enter' && !e.shiftKey && !(e.target && e.target.closest && e.target.closest('.pr-acts, .pr-def'))) { stop(); this._next(); }
  }
}
