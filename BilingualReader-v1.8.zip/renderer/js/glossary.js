// "术语" tab: finance terms of the built-in dictionary that occur in the current chapter (or PDF page),
// with their Chinese meaning; click to find them in the text, add them to the vocabulary book.
// Above them, the 本章生词: words of the vocabulary book that occur in the chapter (a run-through of them
// does not change their review schedule).
import { el, toast } from './util.js';
import * as api from './api.js';
import { STATE_LABEL } from './vocabstate.js';

// changes when words are added to / removed from the vocabulary book
const vocabSig = (list) => (list || []).length + '|' + (list || []).slice(0, 60).map((x) => x.id).join(',');

export class GlossaryPanel {
  constructor(app) {
    this.app = app;
    this.root = document.getElementById('tab-glossary');
    this.items = [];
    this.vocabHere = [];
    this.text = '';
    this._vsig = null;
    this.key = '';
    this.label = '';
    this.onlyNew = false;
    this.root.addEventListener('click', (e) => this._onClick(e));
  }

  _key() {
    const a = this.app;
    if (!a.info || !a.view) return '';
    if (a.view === a.flow) return a.info.bookId + ':c' + a.flow.index;
    return a.info.bookId + ':p' + (a.pdf.viewer ? a.pdf.viewer.currentPageNumber : 0);
  }

  // recomputed when the chapter changes, but only while the tab is visible
  async refresh(force) {
    if (this.root.hidden && !force) return;
    const key = this._key();
    if (!key) { this.items = []; this.vocabHere = []; this.text = ''; this.key = ''; this.render(); return; }
    if (!force && key === this.key) {
      let list = null;
      try { list = await api.call('vocabList'); } catch { list = null; }
      if (!list) return;
      const sig = vocabSig(list);
      if (sig !== this._vsig) {
        this._vsig = sig;
        await this._loadVocab();
        if (this._key() !== key) return;
        this.syncVocab(list, true);
      } else this.syncVocab(list);
      return;
    }
    this.key = key;
    this.root.replaceChildren(el('div', { class: 'empty-tip' }, '正在整理本章术语…'));
    let r = null;
    try { r = await this.app.aiChapterText(); } catch { r = null; }
    if (this._key() !== key) return;
    this.label = r ? r.label.replace(/（.*$/, '') : '';
    this.text = r && r.text ? r.text : '';
    try { this.items = this.text ? await api.call('glossary', this.text) : []; } catch (e) { this.items = []; toast('术语整理失败：' + e.message, { type: 'error' }); }
    this._vsig = null;
    await this._loadVocab();
    if (this._key() === key) this.render();
  }

  async _loadVocab() {
    try { this.vocabHere = this.text ? await api.call('chapterVocab', this.text) : []; } catch { this.vocabHere = []; }
  }

  // keep the ✓ marks in step with the vocabulary book (words added / removed elsewhere)
  syncVocab(list, render) {
    const set = new Set((list || []).map((x) => String(x.word || '').toLowerCase()));
    let changed = !!render;
    for (const x of this.items) {
      const v = set.has(x.w.toLowerCase());
      if (v !== !!x.inVocab) { x.inVocab = v; changed = true; }
    }
    if (changed && !this.root.hidden) this.render();
  }

  // 本章生词: chips (colour = review state); click shows the word in the text and its meaning
  _vocabBlock() {
    const list = this.vocabHere || [];
    if (!list.length) return null;
    return el('div', { class: 'gl-vocab' },
      el('div', { class: 'gl-vhead' },
        el('b', {}, `本章生词 ${list.length} 个`),
        el('span', { class: 'muted' }, '生词本里的词'),
        el('span', { class: 'grow' }),
        el('button', { class: 'small-btn', dataset: { act: 'vreview' }, title: '把这些词过一遍（认词 / 拼写），不影响复习安排' }, '过一遍')),
      el('div', { class: 'gl-vlist' }, list.map((x, i) => el('button', {
        class: 'chip gl-v ' + (x.state || 'new'),
        dataset: { act: 'vshow', v: String(i) },
        title: `${x.def || '（没有保存释义）'}\n本章出现 ${x.count} 次 · ${STATE_LABEL[x.state] || '新词'}\n点击：在正文中找到并查词`,
      }, x.word, x.count > 1 ? el('small', {}, ' ×' + x.count) : null))));
  }

  render() {
    if (!this.app.info) {
      this.root.replaceChildren(el('div', { class: 'empty-tip' }, '打开一本书后，这里会列出本章出现的金融术语和中文含义。'));
      return;
    }
    const pending = this.items.filter((x) => !x.inVocab);
    const list = this.onlyNew ? pending : this.items;
    const only = el('input', { type: 'checkbox' });
    only.checked = this.onlyNew;
    only.addEventListener('change', () => { this.onlyNew = only.checked; this.render(); });
    const tools = el('div', { class: 'tab-tools gl-tools' },
      el('div', { class: 'gl-sum' }, `${this.label || '本章'}：${this.items.length} 个金融术语`,
        this.app.view === this.app.pdf ? el('button', { class: 'small-btn', dataset: { act: 'refresh' }, title: '按当前页重新整理' }, '刷新') : null),
      el('div', { class: 'gl-row' },
        el('label', { class: 'gl-only' }, only, ' 只看未加入生词本'),
        el('span', { class: 'grow' }),
        el('button', { class: 'small-btn', disabled: !pending.length, dataset: { act: 'addall' } }, `全部加入（${pending.length}）`)));
    const vb = this._vocabBlock();
    if (!this.items.length) {
      this.root.replaceChildren(...[vb, tools, el('div', { class: 'empty-tip' }, '本章没有找到内置金融词典里的术语。')].filter(Boolean));
      return;
    }
    this.root.replaceChildren(...[vb, tools].filter(Boolean), ...list.map((x, i) => el('div', { class: 'gl-item' + (x.inVocab ? ' in' : ''), dataset: { i: String(this.items.indexOf(x)) } },
      el('div', { class: 'gl-head' },
        el('a', { href: '#', class: 'gl-w', dataset: { act: 'show' }, title: '在正文中找到并查词' }, x.w),
        x.ph ? el('span', { class: 'gl-ph' }, x.ph) : null,
        el('span', { class: 'gl-count', title: '出现次数' }, '×' + x.count),
        el('span', { class: 'grow' }),
        el('button', { class: 'icon-btn', title: '朗读', dataset: { act: 'say' } }, '🔊'),
        x.inVocab ? el('span', { class: 'gl-in', title: '已在生词本' }, '✓')
          : el('button', { class: 'icon-btn', title: '加入生词本（连同第一次出现的句子）', dataset: { act: 'add' } }, '＋')),
      el('div', { class: 'gl-fin' }, x.fin),
      void i)));
  }

  async add(x, quiet) {
    try {
      await api.call('vocabAdd', {
        word: x.w, phonetic: x.ph, def: x.fin, sentence: x.sentence || '',
        bookId: this.app.info ? this.app.info.bookId : '', bookTitle: this.app.book ? this.app.book.title : '',
        chapter: this.label || '', pos: this.app.view && this.app.view.getPosition ? this.app.view.getPosition() : null,
      });
      x.inVocab = true;
      if (!quiet) toast('已加入生词本：' + x.w);
    } catch (e) {
      toast('加入失败：' + e.message, { type: 'error' });
    }
  }

  async _onClick(e) {
    const btn = e.target.closest('[data-act]');
    if (!btn) return;
    e.preventDefault();
    const act = btn.dataset.act;
    if (act === 'refresh') { this.refresh(true); return; }
    if (act === 'vreview') {
      // the saved sentence, or the one in this chapter
      const items = (this.vocabHere || []).map((x) => ({ ...x, sentence: x.sentence || x.here, sentenceZh: x.sentence ? x.sentenceZh : '' }));
      this.app.study.review.start({ items, title: '本章生词' });
      return;
    }
    if (act === 'vshow') {
      const x = (this.vocabHere || [])[+btn.dataset.v];
      if (!x) return;
      if (this.app.view === this.app.flow) {
        const r = this.app.flow.revealForms(x.word, x.forms);
        this.app.lookup(x.word, r ? this.app.flow.contextFor(r) : { sentence: x.here }, { quiet: true });
      } else this.app.lookup(x.word, { sentence: x.here }, { quiet: true });
      return;
    }
    if (act === 'addall') {
      const pending = this.items.filter((x) => !x.inVocab);
      if (pending.length > 15 && !(await this.app.confirm(`把本章 ${pending.length} 个术语全部加入生词本？`))) return;
      for (const x of pending) await this.add(x, true);
      toast(`已加入 ${pending.length} 个术语`);
      this.render();
      this.app.refreshVocab();
      return;
    }
    const item = btn.closest('.gl-item');
    const x = item && this.items[+item.dataset.i];
    if (!x) return;
    if (act === 'say') this.app.speak(x.w);
    else if (act === 'add') { await this.add(x); this.render(); this.app.refreshVocab(); }
    else if (act === 'show') {
      if (this.app.view === this.app.flow) {
        const r = this.app.flow.revealForms(x.w, x.forms);
        this.app.lookup(x.w, r ? this.app.flow.contextFor(r) : { sentence: x.sentence });
      } else this.app.lookup(x.w, { sentence: x.sentence });
    }
  }
}
