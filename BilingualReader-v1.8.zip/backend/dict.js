'use strict';
// Dictionary manager: built-in finance glossary + user CSV glossaries + user MDX/MDD dictionaries.
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const { MDict } = require('./mdict');
const { parseCsvDictionary } = require('./csvdict');
const { analyze, phraseCandidates, inflections } = require('./lemma');

const BUILTIN_ID = 'builtin';
const HAN = /[㐀-鿿豈-﫿]/;

function loadBuiltin(dataDir) {
  const entries = [];
  let text = '';
  let files = [];
  try { files = fs.readdirSync(dataDir).filter((f) => /^finance-dict.*\.txt$/i.test(f)).sort(); } catch { files = []; }
  for (const f of files) {
    try { text += '\n' + fs.readFileSync(path.join(dataDir, f), 'utf8'); } catch { /* ignore */ }
  }
  const seenW = new Set();
  for (const raw of text.split(/\r?\n/)) {
    const line = raw.trim();
    if (!line || line.startsWith('#')) continue;
    const f = line.split('|').map((s) => s.trim());
    if (!f[0]) continue;
    const e = {
      w: f[0],
      ph: f[1] || '',
      pos: f[2] || '',
      fin: splitList(f[3], /\s*;\s*/),
      gen: splitList(f[4], /\s*;\s*/),
      ex: splitList(f[5], /\s*;;\s*/).map((x) => {
        const i = x.indexOf('//');
        return i < 0 ? [x.trim(), ''] : [x.slice(0, i).trim(), x.slice(i + 2).trim()];
      }),
      rel: splitList(f[6], /\s*,\s*/),
      alt: splitList(f[7], /\s*,\s*/),
    };
    if (seenW.has(e.w.toLowerCase())) continue;
    seenW.add(e.w.toLowerCase());
    entries.push(e);
  }
  const index = new Map();
  for (const e of entries) {
    for (const k of [e.w, ...e.alt]) {
      const lk = k.toLowerCase();
      if (!index.has(lk)) index.set(lk, e);
    }
  }
  return { entries, index };
}

function splitList(s, re) {
  if (!s) return [];
  return s.split(re).map((x) => x.trim()).filter(Boolean);
}

function normalizeQuery(q) {
  return String(q || '')
    .replace(/[­​‌‍﻿]/g, '')
    .replace(/[’‘`´]/g, "'")
    .replace(/[“”«»"]/g, '')
    .replace(/\s+/g, ' ')
    .replace(/^[\s.,;:!?()[\]{}<>'*_~—–-]+|[\s.,;:!?()[\]{}<>'*_~—–-]+$/g, '')
    .trim();
}

function newId(prefix) {
  return prefix + '-' + crypto.randomBytes(5).toString('hex');
}

class DictManager {
  constructor({ store, appDir }) {
    this.store = store;
    this.appDir = appDir;
    this.builtin = loadBuiltin(path.join(appDir, 'data'));
    this.mdx = new Map();
    this.csv = new Map();
  }

  _config() {
    const cfg = this.store.get('dicts', { list: [] });
    if (!cfg.list.some((d) => d.id === BUILTIN_ID)) {
      cfg.list.unshift({ id: BUILTIN_ID, type: 'builtin', name: '内置金融交易词典', enabled: true });
    }
    return cfg;
  }

  _save(cfg) { this.store.set('dicts', cfg); }

  list() {
    const cfg = this._config();
    return cfg.list.map((d) => {
      const info = { ...d };
      if (d.type === 'builtin') info.count = this.builtin.entries.length;
      if (d.type === 'mdx') {
        info.missing = !fs.existsSync(d.path);
        const loaded = this.mdx.get(d.id);
        if (loaded && loaded.mdx._keysLoaded) info.count = loaded.mdx.keys.length;
      }
      return info;
    });
  }

  importMdx(file) {
    const ext = path.extname(file).toLowerCase();
    if (ext === '.mdd') {
      const mdxPath = file.replace(/(\.\d+)?\.mdd$/i, '.mdx');
      if (fs.existsSync(mdxPath)) file = mdxPath;
      else throw new Error('请选择 .mdx 文件（.mdd 资源文件会自动随同名 .mdx 加载）');
    }
    const cfg = this._config();
    const existing = cfg.list.find((d) => d.type === 'mdx' && d.path && path.resolve(d.path) === path.resolve(file));
    if (existing) return { ...existing, duplicate: true };
    const mdx = new MDict(file);
    let count = 0;
    try {
      mdx.load();
      count = mdx.keys.length;
    } finally {
      mdx.close();
    }
    const mdds = this._findMdds(file);
    const name = mdx.title || path.basename(file, path.extname(file));
    const entry = { id: newId('mdx'), type: 'mdx', name, path: file, mdds, enabled: true, count };
    cfg.list.push(entry);
    this._save(cfg);
    return entry;
  }

  _findMdds(mdxPath) {
    const dir = path.dirname(mdxPath);
    const base = path.basename(mdxPath, path.extname(mdxPath));
    let files = [];
    try { files = fs.readdirSync(dir); } catch { return []; }
    const re = new RegExp('^' + base.replace(/[.*+?^${}()|[\]\\]/g, '\\$&') + '(\\.(\\d+))?\\.mdd$', 'i');
    return files
      .map((f) => ({ f, m: re.exec(f) }))
      .filter((x) => x.m)
      .sort((a, b) => (+(a.m[2] || 0)) - (+(b.m[2] || 0)))
      .map((x) => path.join(dir, x.f));
  }

  importCsv(file) {
    const buf = fs.readFileSync(file);
    const { entries } = parseCsvDictionary(buf);
    if (!entries.length) throw new Error('没有从该文件读取到词条。请确认第一列是单词、第二列是释义（可带表头：单词,音标,释义,例句）。');
    const cfg = this._config();
    const existing = cfg.list.find((d) => d.type === 'csv' && d.source && path.resolve(d.source) === path.resolve(file));
    if (existing) {
      this.store.set('csvdicts/' + existing.id, { entries }, true);
      existing.count = entries.length;
      this._save(cfg);
      this.csv.delete(existing.id);
      return { ...existing, updated: true };
    }
    const id = newId('csv');
    this.store.set('csvdicts/' + id, { entries }, true);
    const entry = { id, type: 'csv', name: path.basename(file, path.extname(file)), source: file, enabled: true, count: entries.length };
    cfg.list.push(entry);
    this._save(cfg);
    this.csv.delete(id);
    return entry;
  }

  remove(id) {
    if (id === BUILTIN_ID) throw new Error('内置词典不能删除，可以停用');
    const cfg = this._config();
    const d = cfg.list.find((x) => x.id === id);
    cfg.list = cfg.list.filter((x) => x.id !== id);
    this._save(cfg);
    const m = this.mdx.get(id);
    if (m) { m.mdx.close(); m.mdds.forEach((x) => x.close()); this.mdx.delete(id); }
    if (d && d.type === 'csv') { this.store.remove('csvdicts/' + id); this.csv.delete(id); }
    return this.list();
  }

  setEnabled(id, enabled) {
    const cfg = this._config();
    const d = cfg.list.find((x) => x.id === id);
    if (d) d.enabled = !!enabled;
    this._save(cfg);
    return this.list();
  }

  move(id, delta) {
    const cfg = this._config();
    const i = cfg.list.findIndex((x) => x.id === id);
    const j = i + delta;
    if (i >= 0 && j >= 0 && j < cfg.list.length) {
      const [d] = cfg.list.splice(i, 1);
      cfg.list.splice(j, 0, d);
      this._save(cfg);
    }
    return this.list();
  }

  rename(id, name) {
    const cfg = this._config();
    const d = cfg.list.find((x) => x.id === id);
    if (d && name) d.name = String(name).slice(0, 60);
    this._save(cfg);
    return this.list();
  }

  // Opens the enabled MDX dictionaries (reads their word index) one at a time with pauses in between,
  // so the first lookup after starting the reader does not have to wait for a large dictionary.
  warmup(done) {
    const list = this._config().list.filter((d) => d.type === 'mdx' && d.enabled !== false && !this.mdx.has(d.id) && d.path && fs.existsSync(d.path));
    const next = () => {
      const d = list.shift();
      if (!d) { if (done) done(); return; }
      try { this._getMdx(d); } catch (e) { console.error('词典预载失败', d.name, e.message); }
      setTimeout(next, 150);
    };
    next();
  }

  _getMdx(d) {
    let m = this.mdx.get(d.id);
    if (m) return m;
    const mdx = new MDict(d.path);
    mdx.load();
    const mdds = [];
    for (const p of d.mdds || this._findMdds(d.path)) {
      try { mdds.push(new MDict(p, { isMdd: true })); } catch (e) { console.error('MDD 打开失败', p, e.message); }
    }
    m = { mdx, mdds, dir: path.dirname(d.path), base: path.basename(d.path, path.extname(d.path)) };
    this.mdx.set(d.id, m);
    return m;
  }

  _getCsv(d) {
    let c = this.csv.get(d.id);
    if (c) return c;
    const data = this.store.get('csvdicts/' + d.id, { entries: [] });
    const index = new Map();
    for (const e of data.entries) {
      const k = e.w.toLowerCase().trim();
      const arr = index.get(k);
      if (arr) arr.push(e); else index.set(k, [e]);
    }
    c = { entries: data.entries, index };
    this.csv.set(d.id, c);
    return c;
  }

  _enabled() {
    return this._config().list.filter((d) => d.enabled !== false);
  }

  // Does dictionary d contain the headword w? (phrases may also match MDX keys that differ only in punctuation)
  _has(d, w, multi) {
    const lk = String(w).toLowerCase();
    if (d.type === 'builtin') return this.builtin.index.has(lk);
    if (d.type === 'csv') return this._getCsv(d).index.has(lk);
    if (d.type === 'mdx') {
      if (!fs.existsSync(d.path)) return false;
      const m = this._getMdx(d);
      return m.mdx.has(w) || (multi && m.mdx.findStripped(w).length > 0);
    }
    return false;
  }

  lookup(query, ctx = {}) {
    const q = normalizeQuery(query);
    const result = { query: q, headword: null, sections: [], phrases: [], reverse: [], errors: [], morph: null, alt: null, forms: [] };
    if (!q || q.length > 80) return result;
    if (HAN.test(q)) {
      result.reverse = this.reverseLookup(q);
      return result;
    }
    const multi = /\s/.test(q);
    // candidates, best first: the word itself, then base forms (hedged -> hedge, sold -> sell, companies -> company)
    const cands = multi
      ? phraseCandidates(q).map((w, i) => ({ w, key: '', label: '', score: i < 2 ? 100 - i : 90 }))
      : analyze(q).cands;
    const enabled = this._enabled();
    const hitCache = new Map();
    const anyHas = (w) => {
      if (!hitCache.has(w)) {
        let ok = false;
        for (const d of enabled) {
          try { if (this._has(d, w, multi)) { ok = true; break; } } catch { /* reported below */ }
        }
        hitCache.set(w, ok);
      }
      return hitCache.get(w);
    };
    for (const d of enabled) {
      try {
        if (d.type === 'mdx' && !fs.existsSync(d.path)) { result.errors.push(d.name + '：词典文件不存在'); continue; }
        for (const c of cands) {
          if (!this._has(d, c.w, multi)) continue;
          const sec = this._section(d, c.w);
          if (!sec) continue;
          sec.matched = c.w;
          sec.label = c.label || '';
          result.sections.push(sec);
          break;
        }
      } catch (e) {
        result.errors.push(d.name + '：' + e.message);
      }
    }
    const exact = cands.find((c) => c.score >= 99 && anyHas(c.w));
    const lemma = cands.find((c) => c.score < 99 && c.key && anyHas(c.w));
    if (result.sections.length) {
      const main = (exact && result.sections.find((s) => s.matched === exact.w)) || (lemma && result.sections.find((s) => s.matched === lemma.w)) || result.sections[0];
      result.headword = main.headword;
    }
    if (!multi && lemma && lemma.w.toLowerCase() !== q.toLowerCase()) {
      let label = lemma.label;
      if (lemma.key === 's') {
        // the built-in glossary knows the part of speech: margins -> 复数, hedges (v.) -> 第三人称单数
        const e = this.builtin.index.get(lemma.w.toLowerCase());
        const pos = e ? String(e.pos || '') : '';
        if (/\bn\./.test(pos) && !/\bv\./.test(pos)) label = '复数';
        else if (/\bv\./.test(pos) && !/\bn\./.test(pos)) label = '第三人称单数';
      }
      const shown = String(result.headword || '').toLowerCase() === lemma.w.toLowerCase(); // e.g. an MDX @@@LINK hedged -> hedge
      if (!exact || shown) result.morph = { form: q, lemma: lemma.w, label };
      else if (lemma.score >= 95 || ((lemma.key === 'ed' || lemma.key === 'ing') && lemma.score >= 88)) {
        result.alt = { form: q, lemma: lemma.w, label };
      }
    }
    const forms = new Set([q.toLowerCase()]);
    for (const w of [result.headword, lemma && lemma.w].filter(Boolean)) for (const f of inflections(w)) forms.add(f);
    result.forms = [...forms].slice(0, 80);
    if (!multi && ctx && ctx.sentence) result.phrases = this.findPhrases(q, ctx);
    return result;
  }

  _section(d, w) {
    if (d.type === 'builtin') {
      const e = this.builtin.index.get(w.toLowerCase());
      return e ? { type: 'builtin', dictId: d.id, dictName: d.name, headword: e.w, ph: e.ph, pos: e.pos, fin: e.fin, gen: e.gen, ex: e.ex, rel: e.rel } : null;
    }
    if (d.type === 'csv') {
      const items = this._getCsv(d).index.get(w.toLowerCase());
      return items ? { type: 'csv', dictId: d.id, dictName: d.name, headword: items[0].w, items: items.slice(0, 5) } : null;
    }
    if (d.type === 'mdx') {
      const m = this._getMdx(d);
      const recs = m.mdx.lookup(w);
      if (!recs.length) return null;
      const html = recs.slice(0, 3).map((r) => cleanMdxHtml(r.text)).join('<hr class="br-dict-sep">');
      return { type: 'mdx', dictId: d.id, dictName: d.name, headword: recs[0].key, key: w, html, hasMdd: m.mdds.length > 0 };
    }
    return null;
  }

  // Finance/CSV/MDX phrases in the sentence that contain the clicked word.
  findPhrases(word, ctx) {
    const sentence = String(ctx.sentence || '');
    const tokens = [];
    const re = /[A-Za-z][A-Za-z'’-]*[A-Za-z]|[A-Za-z]/g;
    let m;
    while ((m = re.exec(sentence))) tokens.push({ t: m[0], s: m.index, e: m.index + m[0].length });
    if (tokens.length < 2) return [];
    let idx = -1;
    const off = typeof ctx.offset === 'number' ? ctx.offset : -1;
    if (off >= 0) idx = tokens.findIndex((t) => off >= t.s && off <= t.e);
    if (idx < 0) idx = tokens.findIndex((t) => t.t.toLowerCase() === word.toLowerCase());
    if (idx < 0) return [];
    const found = [];
    const seen = new Set();
    const enabled = this._enabled();
    for (let n = 4; n >= 2; n--) {
      for (let st = Math.max(0, idx - n + 1); st <= idx && st + n <= tokens.length; st++) {
        const phrase = tokens.slice(st, st + n).map((t) => t.t).join(' ');
        for (const cand of phraseCandidates(phrase)) {
          const lk = cand.toLowerCase();
          if (seen.has(lk)) continue;
          let hit = null;
          for (const d of enabled) {
            if (d.type === 'builtin') {
              const e = this.builtin.index.get(lk);
              if (e) { hit = { phrase: e.w, brief: e.fin[0] || e.gen[0] || '', dictName: d.name }; break; }
            } else if (d.type === 'csv') {
              const items = this._getCsv(d).index.get(lk);
              if (items) { hit = { phrase: items[0].w, brief: items[0].def || '', dictName: d.name }; break; }
            } else if (d.type === 'mdx' && fs.existsSync(d.path)) {
              try {
                const mm = this._getMdx(d);
                if (mm.mdx.has(lk)) { hit = { phrase: cand, brief: '', dictName: d.name }; break; }
              } catch { /* ignore */ }
            }
          }
          if (hit) {
            seen.add(lk);
            found.push(hit);
            break;
          }
        }
        if (found.length >= 4) return found;
      }
    }
    return found;
  }

  reverseLookup(q) {
    const out = [];
    for (const e of this.builtin.entries) {
      const sense = [...e.fin, ...e.gen].find((s) => s.includes(q));
      if (sense) out.push({ w: e.w, ph: e.ph, sense, dictName: '内置金融交易词典', exact: [...e.fin, ...e.gen].some((s) => s.split(/[；，、（(]/)[0] === q) });
      if (out.length >= 40) break;
    }
    for (const d of this._enabled()) {
      if (d.type !== 'csv') continue;
      const c = this._getCsv(d);
      for (const e of c.entries) {
        if (e.def && e.def.includes(q)) out.push({ w: e.w, ph: e.ph || '', sense: e.def, dictName: d.name, exact: e.def.split(/[；;，,、]/)[0].trim() === q });
        if (out.length >= 80) break;
      }
    }
    out.sort((a, b) => (b.exact ? 1 : 0) - (a.exact ? 1 : 0) || a.w.length - b.w.length);
    return out.slice(0, 40);
  }

  resource(dictId, resPath) {
    const d = this._config().list.find((x) => x.id === dictId);
    if (!d || d.type !== 'mdx') return null;
    let rel = String(resPath || '').replace(/\\/g, '/').replace(/^\/+/, '');
    if (!rel) return null;
    const m = this._getMdx(d);
    // 1) files next to the .mdx (css/js/fonts are usually shipped this way)
    const full = path.resolve(m.dir, rel);
    if (full.startsWith(path.resolve(m.dir) + path.sep) && fs.existsSync(full) && fs.statSync(full).isFile()) {
      return fs.readFileSync(full);
    }
    // 2) resources packed in .mdd files
    for (const mdd of m.mdds) {
      try {
        const data = mdd.resource(rel);
        if (data) return Buffer.from(data);
      } catch (e) { console.error('MDD 读取失败', e.message); }
    }
    return null;
  }

  entryPage(dictId, key, fid) {
    const d = this._config().list.find((x) => x.id === dictId);
    if (!d || d.type !== 'mdx') return null;
    const m = this._getMdx(d);
    const recs = m.mdx.lookup(key);
    const html = recs.length ? recs.slice(0, 3).map((r) => cleanMdxHtml(r.text)).join('<hr class="br-dict-sep">') : '<p>（无内容）</p>';
    let extraCss = '';
    for (const name of [m.base + '.css', 'style.css']) {
      if (fs.existsSync(path.join(m.dir, name)) && !html.includes(name)) {
        extraCss += `<link rel="stylesheet" href="${encodeURI(name)}">`;
        break;
      }
    }
    return '<!DOCTYPE html><html><head><meta charset="utf-8">' +
      `<base href="/dictres/${encodeURIComponent(dictId)}/">` +
      '<link rel="stylesheet" href="/css/dict-frame.css">' + extraCss +
      `<script src="/js/dict-frame.js" data-fid="${String(fid || '').replace(/[^\w-]/g, '')}"></script>` +
      '</head><body>' + html + '</body></html>';
  }

  closeAll() {
    for (const m of this.mdx.values()) { m.mdx.close(); m.mdds.forEach((x) => x.close()); }
    this.mdx.clear();
  }
}

function cleanMdxHtml(text) {
  return String(text)
    .replace(/(src|href)\s*=\s*(["'])file:\/\/\/?/gi, '$1=$2')
    .replace(/(src|href)\s*=\s*(["'])\/+(?![/])/gi, '$1=$2');
}

module.exports = { DictManager, normalizeQuery, loadBuiltin };
