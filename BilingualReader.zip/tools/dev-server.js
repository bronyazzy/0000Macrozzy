'use strict';
// Development / test harness: serves the renderer + backend routes over HTTP so the UI can be
// exercised in an ordinary Chromium (Playwright). Electron-only calls are stubbed.
//   node tools/dev-server.js [port] [userDataDir]
const http = require('http');
const path = require('path');
const { Service, API_METHODS } = require('../backend/service');

const port = +(process.argv[2] || 8765);
const userDataDir = process.argv[3] || path.join(require('os').tmpdir(), 'bireader-dev');
const appDir = path.resolve(__dirname, '..');
const service = new Service({ userDataDir, appDir });
const stubs = {
  getPending: () => null,
  pickBook: () => [],
  pickDicts: () => [],
  pickSave: () => null,
  clipboardWrite: (o) => { stubs.clipboard = o; return true; },
  openExternal: (u) => { stubs.external = u; return true; },
  showInFolder: () => true,
  win: () => true,
  closeReady: () => true,
};

const server = http.createServer(async (req, res) => {
  try {
    const url = new URL(req.url, 'http://localhost');
    if (url.pathname.startsWith('/api/') && req.method === 'POST') {
      const method = url.pathname.slice(5);
      let body = '';
      for await (const chunk of req) body += chunk;
      const args = body ? JSON.parse(body) : [];
      let result;
      if (API_METHODS.includes(method)) result = await service[method](...args);
      else if (stubs[method]) result = await stubs[method](...args);
      else throw new Error('unknown method ' + method);
      res.writeHead(200, { 'content-type': 'application/json; charset=utf-8' });
      res.end(JSON.stringify({ result: result === undefined ? null : result }));
      return;
    }
    if (url.pathname === '/__stubs') {
      res.writeHead(200, { 'content-type': 'application/json' });
      res.end(JSON.stringify({ clipboard: stubs.clipboard || null, external: stubs.external || null }));
      return;
    }
    const r = service.handle(url.pathname, url.search);
    res.writeHead(r.status, { 'cache-control': 'no-store', ...r.headers });
    res.end(r.body);
  } catch (e) {
    res.writeHead(200, { 'content-type': 'application/json; charset=utf-8' });
    res.end(JSON.stringify({ error: String(e && e.message || e) }));
  }
});
server.listen(port, '127.0.0.1', () => console.log('dev server on http://127.0.0.1:' + port + '  data=' + userDataDir));
process.on('SIGTERM', () => { service.shutdown(); process.exit(0); });
process.on('SIGINT', () => { service.shutdown(); process.exit(0); });
