// Settings model, typography / theme popovers and the settings dialog (incl. dictionary manager).
import { el, toast } from './util.js';
import * as api from './api.js';

export const DEFAULTS = {
  fontSize: 18,
  lineHeight: 1.75,
  paraSpacing: 0.7,
  pageWidth: 1180,
  colRatio: 50,
  gutter: 36,
  overrideTypography: true,
  fontEn: '',
  fontZh: '',
  zhColor: '',
  zhLeft: false,
  showPairSep: true,
  theme: 'light',
  customBg: '#f4efe6',
  customFg: '#2b2b2b',
  eyeCare: false,
  eyeCareStrength: 22,
  defaultMode: 'two',
  lastNonTwoMode: 'original',
  dictCompact: false,
  lookupDblClick: true,
  lookupSelection: true,
  autoOpenDict: true,
  reopenLast: true,
  pdfScale: 'page-width',
  leftOpen: true,
  leftWidth: 270,
  leftTab: 'toc',
  rightOpen: true,
  rightWidth: 340,
  rightTab: 'dict',
};

export const THEMES = {
  light: { label: '白色', bg: '#ffffff', fg: '#1f2328', link: '#1a5fb4', ui: 'light' },
  sepia: { label: '米黄', bg: '#f6efe1', fg: '#3b3127', link: '#8a4b0f', ui: 'light' },
  green: { label: '护眼绿', bg: '#cce8cf', fg: '#1e2b1f', link: '#1d5e2f', ui: 'light' },
  gray: { label: '浅灰', bg: '#ececec', fg: '#222222', link: '#1a5fb4', ui: 'light' },
  dark: { label: '夜间', bg: '#1e1f22', fg: '#c9ccd1', link: '#7fb0ff', ui: 'dark' },
};

export const FONTS_EN = [['', '原书字体'], ['Georgia, serif', 'Georgia'], ['"Times New Roman", serif', 'Times New Roman'], ['Cambria, serif', 'Cambria'],
  ['"Palatino Linotype", Palatino, serif', 'Palatino'], ['"Segoe UI", sans-serif', 'Segoe UI'], ['Calibri, sans-serif', 'Calibri'], ['Arial, sans-serif', 'Arial'],
  ['Verdana, sans-serif', 'Verdana'], ['Consolas, monospace', 'Consolas']];
export const FONTS_ZH = [['', '原书字体'], ['"Microsoft YaHei", "微软雅黑", sans-serif', '微软雅黑'], ['SimSun, "宋体", serif', '宋体'], ['SimHei, "黑体", sans-serif', '黑体'],
  ['KaiTi, "楷体", serif', '楷体'], ['FangSong, "仿宋", serif', '仿宋'], ['"Source Han Serif SC", "Noto Serif CJK SC", "思源宋体", serif', '思源宋体'],
  ['"Source Han Sans SC", "Noto Sans CJK SC", "思源黑体", sans-serif', '思源黑体'], ['DengXian, "等线", sans-serif', '等线']];
export const ZH_COLORS = [['', '跟随正文'], ['#5b6470', '灰色'], ['#2f5d8a', '蓝色'], ['#7a4a1d', '棕色'], ['#2e6b3b', '绿色']];

function row(label, control, hint) {
  return el('label', { class: 'set-row' }, el('span', { class: 'set-label' }, label), control, hint ? el('span', { class: 'set-hint' }, hint) : null);
}

function slider(app, key, min, max, step, fmt) {
  const out = el('span', { class: 'set-val' }, fmt(app.settings[key]));
  const input = el('input', { type: 'range', min, max, step, value: app.settings[key] });
  input.addEventListener('input', () => {
    app.settings[key] = +input.value;
    out.textContent = fmt(+input.value);
    app.applySettings();
  });
  return el('span', { class: 'set-ctl' }, input, out);
}

function select(app, key, options, after) {
  const s = el('select', {}, options.map(([v, l]) => el('option', { value: v }, l)));
  s.value = app.settings[key] || '';
  s.addEventListener('change', () => { app.settings[key] = s.value; app.applySettings(); if (after) after(); });
  return s;
}

function check(app, key, after) {
  const c = el('input', { type: 'checkbox' });
  c.checked = !!app.settings[key];
  c.addEventListener('change', () => { app.settings[key] = c.checked; app.applySettings(); if (after) after(); });
  return c;
}

export function typographyControls(app) {
  const s = app.settings;
  const fs = el('span', { class: 'set-val big' }, s.fontSize + 'px');
  const bump = (d) => { s.fontSize = Math.max(10, Math.min(40, s.fontSize + d)); fs.textContent = s.fontSize + 'px'; app.applySettings(); };
  return [
    row('字号', el('span', { class: 'set-ctl' }, el('button', { class: 'small-btn', onclick: () => bump(-1) }, 'A−'), fs, el('button', { class: 'small-btn', onclick: () => bump(1) }, 'A+'))),
    row('行距', slider(app, 'lineHeight', 1.1, 2.6, 0.05, (v) => (+v).toFixed(2))),
    row('段距', slider(app, 'paraSpacing', 0, 2, 0.1, (v) => (+v).toFixed(1) + 'em')),
    row('版心宽度', slider(app, 'pageWidth', 560, 2400, 20, (v) => v + 'px')),
    row('中英栏宽', slider(app, 'colRatio', 25, 75, 1, (v) => `英 ${v} : 中 ${100 - v}`)),
    row('栏间距', slider(app, 'gutter', 8, 120, 2, (v) => v + 'px')),
    row('英文字体', select(app, 'fontEn', FONTS_EN)),
    row('中文字体', select(app, 'fontZh', FONTS_ZH)),
    row('上下对照中文颜色', select(app, 'zhColor', ZH_COLORS)),
    row('覆盖原书字号行距', check(app, 'overrideTypography')),
    row('显示配对分隔线', check(app, 'showPairSep')),
    row('双栏左侧显示中文', check(app, 'zhLeft')),
  ];
}

export function themeControls(app) {
  const s = app.settings;
  const chips = el('div', { class: 'theme-chips' });
  const renderChips = () => {
    chips.replaceChildren(...Object.entries(THEMES).map(([k, t]) => el('button', {
      class: 'theme-chip' + (s.theme === k ? ' on' : ''),
      style: { background: t.bg, color: t.fg },
      title: t.label,
      onclick: () => { s.theme = k; app.applySettings(); renderChips(); },
    }, t.label)), el('button', {
      class: 'theme-chip' + (s.theme === 'custom' ? ' on' : ''),
      style: { background: s.customBg, color: s.customFg },
      onclick: () => { s.theme = 'custom'; app.applySettings(); renderChips(); },
    }, '自定义'));
  };
  renderChips();
  const bg = el('input', { type: 'color', value: s.customBg });
  const fg = el('input', { type: 'color', value: s.customFg });
  bg.addEventListener('input', () => { s.customBg = bg.value; s.theme = 'custom'; app.applySettings(); renderChips(); });
  fg.addEventListener('input', () => { s.customFg = fg.value; s.theme = 'custom'; app.applySettings(); renderChips(); });
  const eye = el('input', { type: 'checkbox' });
  eye.checked = !!s.eyeCare;
  eye.addEventListener('change', () => { s.eyeCare = eye.checked; app.applySettings(); });
  return [
    el('div', { class: 'set-sub' }, '背景'),
    chips,
    row('自定义背景 / 文字', el('span', { class: 'set-ctl' }, bg, fg)),
    el('div', { class: 'set-sub' }, '护眼'),
    row('护眼模式', eye, '柔和绿底 + 暖色滤镜（PDF 也生效）'),
    row('暖色强度', slider(app, 'eyeCareStrength', 0, 60, 1, (v) => v + '%')),
  ];
}

export function openPopover(app, anchor, title, controls) {
  const pop = document.getElementById('popover');
  pop.replaceChildren(el('div', { class: 'pop-title' }, title), ...controls);
  pop.hidden = false;
  const r = anchor.getBoundingClientRect();
  pop.style.top = r.bottom + 6 + 'px';
  const w = pop.offsetWidth;
  pop.style.left = Math.max(8, Math.min(window.innerWidth - w - 8, r.right - w)) + 'px';
  app.popoverOpen = true;
}

export function closePopover(app) {
  const pop = document.getElementById('popover');
  if (!pop.hidden) {
    pop.hidden = true;
    app.popoverOpen = false;
    app.saveSettingsSoon();
  }
}

// ---------------------------------------------------------------- settings dialog
export function openSettings(app, tab = 'read') {
  const modal = document.getElementById('modal');
  const tabs = [['read', '阅读'], ['theme', '背景与护眼'], ['dict', '词典'], ['keys', '快捷键'], ['about', '关于']];
  const body = el('div', { class: 'modal-body' });
  const nav = el('div', { class: 'modal-nav' });
  const show = (t) => {
    for (const b of nav.children) b.classList.toggle('on', b.dataset.t === t);
    body.replaceChildren(...renderTab(app, t));
  };
  for (const [t, label] of tabs) nav.append(el('button', { dataset: { t }, onclick: () => show(t) }, label));
  const box = el('div', { class: 'modal-box settings' },
    el('div', { class: 'modal-head' }, el('span', {}, '设置'), el('button', { class: 'icon-btn', onclick: () => closeModal(app) }, '✕')),
    el('div', { class: 'modal-main' }, nav, body));
  modal.replaceChildren(box);
  modal.hidden = false;
  modal.onclick = (e) => { if (e.target === modal) closeModal(app); };
  app.modalOpen = true;
  show(tab);
}

export function closeModal(app) {
  const modal = document.getElementById('modal');
  if (modal.hidden) return;
  modal.hidden = true;
  modal.replaceChildren();
  app.modalOpen = false;
  app.saveSettingsSoon();
  app.refocusReader();
}

function renderTab(app, t) {
  const s = app.settings;
  if (t === 'read') {
    return [
      el('div', { class: 'set-sub' }, '排版'),
      ...typographyControls(app),
      el('div', { class: 'set-sub' }, '对照与查词'),
      row('新书默认显示', select(app, 'defaultMode', [['two', '左右双栏'], ['stack', '上下对照'], ['original', '原书排版'], ['en', '仅英文'], ['zh', '仅中文']])),
      row('双击查词', check(app, 'lookupDblClick')),
      row('选中短语自动查词', check(app, 'lookupSelection'), '选中 6 个词以内的英文或 8 个字以内的中文'),
      row('查词时自动打开词典栏', check(app, 'autoOpenDict')),
      row('启动时打开上次的书', check(app, 'reopenLast')),
    ];
  }
  if (t === 'theme') return themeControls(app);
  if (t === 'dict') return dictTab(app);
  if (t === 'keys') {
    const keys = [
      ['F6', '切换左右双栏（再按回到之前的模式）'], ['F8', '切换“只看释义”'], ['F9', '进入 / 退出简洁无边框模式'], ['Esc', '关闭大图 / 菜单；退出简洁模式'],
      ['Alt + ↑', '跳转后返回原位置（也可用 Alt + ←、鼠标侧键）'], ['Ctrl + C', '复制选中内容（从英文栏拖选只复制英文，中文栏同理）'],
      ['Ctrl + O', '打开文件'], ['Ctrl + F', '全书搜索'], ['F3 / Shift + F3', '下一个 / 上一个搜索结果'], ['Ctrl + D', '添加书签'],
      ['Ctrl + B', '显示 / 隐藏左侧栏'], ['Ctrl + L', '显示 / 隐藏词典栏'], ['Ctrl + = / −', '放大 / 缩小字号（PDF 为缩放）'],
      ['Ctrl + → / ←', '下一章 / 上一章（PDF 为翻页）'], ['PgDn / 空格', '向下翻屏，章末自动进入下一章'], ['F11', '全屏'], ['F12', '开发者工具'],
    ];
    return [el('table', { class: 'keys' }, keys.map(([k, d]) => el('tr', {}, el('td', {}, el('kbd', {}, k)), el('td', {}, d))))];
  }
  if (t === 'about') {
    return [
      el('div', { class: 'about' },
        el('h3', {}, '双语阅读器'),
        el('p', {}, '离线中英对照阅读：EPUB / PDF / HTML，按语言复制、插图放大与跳转、金融词典与生词本。'),
        el('p', { class: 'muted' }, 'PDF 渲染：pdf.js (Apache-2.0)。所有数据保存在本机，不联网。'),
        el('p', { class: 'muted' }, '数据目录：' + (app.state.userDataDir || '（应用数据目录）'))),
    ];
  }
  return [];
}

function dictTab(app) {
  const wrap = el('div', { class: 'dict-mgr' });
  const render = () => {
    const list = app.state.dicts || [];
    wrap.replaceChildren(
      el('div', { class: 'set-sub' }, '词典顺序决定显示顺序（内置金融词典的金融释义总是优先展示）'),
      el('div', { class: 'dm-list' }, list.map((d, i) => el('div', { class: 'dm-item' + (d.enabled === false ? ' off' : '') },
        el('input', { type: 'checkbox', checked: d.enabled !== false, onchange: async (e) => { app.state.dicts = await api.call('dictSetEnabled', d.id, e.target.checked); render(); } }),
        el('div', { class: 'dm-info' },
          el('div', { class: 'dm-name' }, d.name, el('span', { class: 'dm-type' }, d.type === 'builtin' ? '内置' : d.type.toUpperCase())),
          el('div', { class: 'dm-meta' }, [d.count ? d.count + ' 条' : '', d.missing ? '⚠ 文件不存在：' + d.path : (d.path || d.source || ''), d.mdds && d.mdds.length ? `含 ${d.mdds.length} 个 MDD` : ''].filter(Boolean).join(' · '))),
        el('button', { class: 'icon-btn', title: '上移', disabled: i === 0, onclick: async () => { app.state.dicts = await api.call('dictMove', d.id, -1); render(); } }, '↑'),
        el('button', { class: 'icon-btn', title: '下移', disabled: i === list.length - 1, onclick: async () => { app.state.dicts = await api.call('dictMove', d.id, 1); render(); } }, '↓'),
        el('button', { class: 'icon-btn', title: '重命名', onclick: async () => { const n = await app.prompt('词典名称', d.name); if (n) { app.state.dicts = await api.call('dictRename', d.id, n); render(); } } }, '✎'),
        d.type !== 'builtin' ? el('button', { class: 'icon-btn', title: '移除', onclick: async () => { app.state.dicts = await api.call('dictRemove', d.id); render(); toast('已移除 ' + d.name); } }, '🗑') : el('span', { class: 'icon-btn ph' })))),
      el('div', { class: 'dm-actions' },
        el('button', { class: 'primary', onclick: () => importDicts(app, 'mdx').then(render) }, '导入 MDX / MDD 词典'),
        el('button', { onclick: () => importDicts(app, 'csv').then(render) }, '导入 CSV 词库')),
      el('div', { class: 'set-hint block' },
        'MDX：选择 .mdx 文件，同目录下同名的 .mdd（含 .1.mdd 等分卷）和 .css 会自动加载。',
        el('br'),
        'CSV：第一列单词，第二列释义；也可带表头（单词, 音标, 释义, 例句, 备注）。支持 UTF-8 和 GBK 编码（Excel 另存的 CSV）。'));
  };
  render();
  return [wrap];
}

export async function importDicts(app, kind, paths) {
  if (!paths) {
    if (!api.isElectron) {
      const p = await app.prompt('词典文件的完整路径', '');
      paths = p ? [p] : [];
    } else {
      paths = await api.call('pickDicts', kind);
    }
  }
  if (!paths || !paths.length) return;
  for (const p of paths) {
    try {
      app.toast('正在导入 ' + p.split(/[\\/]/).pop() + '…', 'info', 8000);
      const r = await api.call('dictImport', p);
      toast(r.duplicate ? `“${r.name}”已经导入过` : `已导入“${r.name}”，共 ${r.count || 0} 条`);
    } catch (e) {
      toast('导入失败：' + e.message, { type: 'error', ms: 6000 });
    }
  }
  app.state.dicts = await api.call('dictList');
}
