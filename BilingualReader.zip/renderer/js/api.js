// Bridge to the backend: Electron IPC (window.bridge from preload.js) or the HTTP test harness.
const bridge = window.bridge || null;
export const isElectron = !!bridge;

export async function call(method, ...args) {
  if (bridge) return bridge.call(method, ...args);
  const r = await fetch('/api/' + method, { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify(args) });
  const j = await r.json();
  if (j.error) throw new Error(j.error);
  return j.result;
}

const handlers = {};
export function on(channel, cb) {
  if (bridge) bridge.on(channel, cb);
  else (handlers[channel] = handlers[channel] || []).push(cb);
}

// Test harness hook: window.__emit('open-file', path)
window.__emit = (channel, ...args) => (handlers[channel] || []).forEach((cb) => cb(...args));

export function pathForFile(file) {
  if (bridge && bridge.pathForFile) {
    try { return bridge.pathForFile(file); } catch { return null; }
  }
  return file && file.path ? file.path : null;
}
