// PDF view built on pdf.js (original page layout, text layer, links, outline, search).
import { clamp, debounce, throttle } from './util.js';
import { sentenceAt, hasHan } from './textlang.js';

let pdfjsLib = null;
let viewerLib = null;

async function loadLibs() {
  if (pdfjsLib) return;
  pdfjsLib = await import('../vendor/pdfjs/build/pdf.mjs');
  globalThis.pdfjsLib = pdfjsLib;
  pdfjsLib.GlobalWorkerOptions.workerSrc = new URL('../vendor/pdfjs/build/pdf.worker.mjs', import.meta.url).href;
  viewerLib = await import('../vendor/pdfjs/web/pdf_viewer.mjs');
}

export class PdfView {
  constructor(app) {
    this.app = app;
    this.host = document.getElementById('pdf-host');
    this.container = document.getElementById('pdf-container');
    this.viewerEl = document.getElementById('pdf-viewer');
    this.pdf = null;
    this.viewer = null;
    this.saveSoon = debounce(() => this.app.savePosition(), 900);
    this.textCache = new Map();
  }

  async open(info, target) {
    await loadLibs();
    this.close();
    this.host.hidden = false;
    const { EventBus, PDFLinkService, PDFFindController, PDFViewer, LinkTarget } = viewerLib;
    const eventBus = new EventBus();
    const linkService = new PDFLinkService({ eventBus, externalLinkTarget: LinkTarget.BLANK });
    const findController = new PDFFindController({ eventBus, linkService });
    this.viewerEl.replaceChildren();
    const viewer = new PDFViewer({
      container: this.container,
      viewer: this.viewerEl,
      eventBus,
      linkService,
      findController,
      textLayerMode: 1,
      annotationMode: pdfjsLib.AnnotationMode.ENABLE,
      removePageBorders: false,
    });
    linkService.setViewer(viewer);
    // record jumps so Alt+↑ can return
    const origGo = linkService.goToDestination.bind(linkService);
    linkService.goToDestination = async (dest) => {
      this.app.pushHistory(this.getPosition());
      this.app.showBackPill();
      return origGo(dest);
    };
    const origPage = linkService.goToPage.bind(linkService);
    linkService.goToPage = (val) => {
      this.app.pushHistory(this.getPosition());
      this.app.showBackPill();
      return origPage(val);
    };
    this.eventBus = eventBus;
    this.linkService = linkService;
    this.findController = findController;
    this.viewer = viewer;

    const url = new URL(info.entryUrl, location.href).href;
    const base = new URL('../vendor/pdfjs/', import.meta.url).href;
    const task = pdfjsLib.getDocument({
      url,
      cMapUrl: base + 'cmaps/',
      cMapPacked: true,
      standardFontDataUrl: base + 'standard_fonts/',
      wasmUrl: base + 'wasm/',
      iccUrl: base + 'iccs/',
      isEvalSupported: false,
      enableXfa: false,
    });
    this.task = task;
    let pdf;
    try {
      pdf = await task.promise;
    } catch (e) {
      this.host.hidden = true;
      throw new Error(e && e.name === 'PasswordException' ? '该 PDF 有密码保护，暂不支持' : 'PDF 打开失败：' + (e && e.message || e));
    }
    this.pdf = pdf;
    viewer.setDocument(pdf);
    linkService.setDocument(pdf, null);
    await new Promise((resolve) => eventBus.on('pagesinit', resolve, { once: true }));
    viewer.currentScaleValue = this.app.settings.pdfScale || 'page-width';
    this.app.applyPdfTheme();
    eventBus.on('updateviewarea', throttle(() => this._moved(), 150));
    eventBus.on('scalechanging', () => { this.app.settings.pdfScale = viewer.currentScaleValue; this.app.saveSettingsSoon(); this.app.updateStatus(); });
    eventBus.on('textlayerrendered', (e) => this._wireTextLayer(e.source && e.source.div));
    eventBus.on('updatefindmatchescount', (e) => this.app.pdfFindCount(e.matchesCount));
    let meta = {};
    try { meta = await pdf.getMetadata(); } catch { /* ignore */ }
    const title = (meta.info && meta.info.Title && String(meta.info.Title).trim()) || info.name.replace(/\.pdf$/i, '');
    const author = (meta.info && meta.info.Author) || '';
    let toc = [];
    try { toc = await this._outline(); } catch { toc = []; }
    this.book = { kind: 'pdf', format: 'pdf', title, author, toc, pages: pdf.numPages };
    if (target && target.page) this.goTo(target);
    this.container.addEventListener('dblclick', this._dbl = (e) => this._onDblClick(e));
    this.container.addEventListener('mouseup', this._up = (e) => this._onMouseUp(e));
    this.container.addEventListener('contextmenu', this._ctx = (e) => this._onContextMenu(e));
    this.container.addEventListener('mousedown', this._down = (e) => { this.app.closeMenus(); if (e.button === 3) { e.preventDefault(); this.app.goBack(); } });
    this.container.addEventListener('click', this._click = (e) => {
      const a = e.target.closest('a[href]');
      if (a && /^https?:|^mailto:/i.test(a.getAttribute('href'))) {
        e.preventDefault();
        e.stopPropagation();
        this.app.openExternal(a.href);
      }
    }, true);
    this._moved(true);
    return this.book;
  }

  async _outline() {
    const outline = await this.pdf.getOutline();
    if (!outline || !outline.length) {
      const n = this.pdf.numPages;
      const step = n > 60 ? 10 : 1;
      const out = [];
      for (let p = 1; p <= n; p += step) out.push({ label: `第 ${p} 页`, page: p, children: [] });
      return n > 1 ? out : [];
    }
    const resolve = async (dest) => {
      try {
        let d = dest;
        if (typeof d === 'string') d = await this.pdf.getDestination(d);
        if (!Array.isArray(d)) return null;
        const ref = d[0];
        const idx = typeof ref === 'object' ? await this.pdf.getPageIndex(ref) : ref;
        return { page: idx + 1, dest: d };
      } catch { return null; }
    };
    const walk = async (items, depth) => {
      const out = [];
      for (const it of items) {
        const r = it.dest ? await resolve(it.dest) : null;
        out.push({ label: (it.title || '').trim() || '（无标题）', page: r ? r.page : null, dest: r ? r.dest : null, url: it.url || null, depth, children: it.items && it.items.length ? await walk(it.items, depth + 1) : [] });
      }
      return out;
    };
    return walk(outline, 0);
  }

  close() {
    if (this.task) { try { this.task.destroy(); } catch { /* ignore */ } }
    this.task = null;
    if (this.pdf) { try { this.pdf.destroy(); } catch { /* ignore */ } }
    this.pdf = null;
    if (this.viewer) { try { this.viewer.setDocument(null); } catch { /* ignore */ } }
    this.viewer = null;
    this.viewerEl.replaceChildren();
    this.host.hidden = true;
    for (const [ev, fn] of [['dblclick', this._dbl], ['mouseup', this._up], ['contextmenu', this._ctx], ['mousedown', this._down], ['click', this._click]]) {
      if (fn) this.container.removeEventListener(ev, fn, ev === 'click');
    }
    this.textCache.clear();
  }

  getPosition() {
    if (!this.viewer || !this.pdf) return null;
    const loc = this.viewer._location;
    const page = loc && loc.pageNumber ? loc.pageNumber : this.viewer.currentPageNumber;
    const n = this.pdf.numPages;
    const pos = { kind: 'pdf', page, percent: clamp((page - 1) / Math.max(1, n - 1), 0, 1) };
    if (loc && loc.pageNumber === page) { pos.top = loc.top; pos.left = loc.left; }
    const c = this.container;
    pos.scrollFrac = c.scrollHeight > c.clientHeight ? c.scrollTop / (c.scrollHeight - c.clientHeight) : 0;
    return pos;
  }

  goTo(pos) {
    if (!this.viewer || !pos) return;
    if (pos.dest) { this.viewer.scrollPageIntoView({ pageNumber: pos.page, destArray: pos.dest }); return; }
    const page = clamp(pos.page || 1, 1, this.pdf.numPages);
    if (pos.top != null) {
      this.viewer.scrollPageIntoView({ pageNumber: page, destArray: [null, { name: 'XYZ' }, pos.left || 0, pos.top, null], allowNegativeOffset: true });
    } else {
      this.viewer.currentPageNumber = page;
    }
  }

  _moved(initial) {
    const pos = this.getPosition();
    if (!pos) return;
    this.app.onPositionChange(pos);
    if (!initial) this.saveSoon();
  }

  setScale(v) {
    if (!this.viewer) return;
    if (typeof v === 'number') this.viewer.currentScale = clamp(v, 0.25, 6);
    else this.viewer.currentScaleValue = v;
  }

  zoom(f) {
    if (!this.viewer) return;
    this.setScale(this.viewer.currentScale * f);
  }

  page(dir) {
    if (!this.viewer) return;
    const c = this.container;
    c.scrollBy({ top: dir * (c.clientHeight - 40) });
  }

  // ------------------------------------------------ text layer / lookups
  _wireTextLayer(div) {
    if (!div) return;
    div.classList.add('br-pdf-text');
  }

  _context(range) {
    const span = range.startContainer.parentElement;
    const layer = span && span.closest('.textLayer');
    if (!layer) return { sentence: '', offset: 0 };
    const spans = [...layer.querySelectorAll('span[role="presentation"], span:not(:has(span))')];
    let text = '';
    let offset = -1;
    for (const s of spans) {
      if (s === span || s.contains(range.startContainer)) offset = text.length + range.startOffset;
      text += s.textContent + (/\s$/.test(s.textContent) ? '' : ' ');
    }
    if (offset < 0) offset = 0;
    const lang = hasHan(range.toString()) ? 'zh' : 'en';
    const st = sentenceAt(text, offset, lang);
    const before = text.slice(st.start, offset).replace(/\s+/g, ' ');
    return { sentence: st.text.replace(/\s+/g, ' ').trim().slice(0, 600), offset: before.trimStart().length, lang, chapter: `第 ${this.viewer.currentPageNumber} 页`, pos: this.getPosition() };
  }

  _onDblClick() {
    if (!this.app.settings.lookupDblClick) return;
    const sel = document.getSelection();
    if (!sel || !sel.rangeCount || !this.container.contains(sel.anchorNode)) return;
    const text = sel.toString().trim();
    if (text && text.length <= 60) this.app.lookup(text, this._context(sel.getRangeAt(0)));
  }

  _onMouseUp(e) {
    if (e.button !== 0 || e.detail >= 2 || !this.app.settings.lookupSelection) return;
    setTimeout(() => {
      const sel = document.getSelection();
      if (!sel || sel.isCollapsed || !this.container.contains(sel.anchorNode)) return;
      const text = sel.toString().replace(/\s+/g, ' ').trim();
      const ok = hasHan(text) ? text.length <= 8 : /[A-Za-z]/.test(text) && text.split(' ').length <= 6 && text.length <= 60;
      if (ok) this.app.lookup(text, this._context(sel.getRangeAt(0)));
    }, 10);
  }

  _onContextMenu(e) {
    e.preventDefault();
    const sel = document.getSelection();
    const selText = sel && !sel.isCollapsed && this.container.contains(sel.anchorNode) ? sel.toString() : '';
    this.app.openPdfMenu({ x: e.clientX, y: e.clientY, view: this, selText, range: selText ? sel.getRangeAt(0) : null });
  }

  contextFor(range) { return this._context(range); }

  // ------------------------------------------------ search
  async pageText(i) {
    if (this.textCache.has(i)) return this.textCache.get(i);
    const page = await this.pdf.getPage(i);
    const tc = await page.getTextContent();
    let t = '';
    for (const it of tc.items) {
      if (!('str' in it)) continue;
      t += it.str + (it.hasEOL ? '\n' : '');
    }
    this.textCache.set(i, t);
    return t;
  }

  find(query, opts = {}, again = false, prev = false) {
    if (!this.eventBus) return;
    this.eventBus.dispatch('find', {
      source: this,
      type: again ? 'again' : '',
      query,
      caseSensitive: !!opts.caseSensitive,
      entireWord: !!opts.wholeWord,
      highlightAll: true,
      findPrevious: prev,
      matchDiacritics: false,
    });
  }

  clearFind() {
    if (this.eventBus) this.eventBus.dispatch('findbarclose', { source: this });
  }

  get pages() { return this.pdf ? this.pdf.numPages : 0; }
}
