'use strict';
// Electron main process: window, app:// protocol (UI + book + dictionary resources), IPC.
const { app, BrowserWindow, protocol, ipcMain, dialog, shell, clipboard, Menu, screen } = require('electron');
const path = require('path');
const fs = require('fs');
const { Service, API_METHODS } = require('./backend/service');

protocol.registerSchemesAsPrivileged([
  { scheme: 'app', privileges: { standard: true, secure: true, supportFetchAPI: true, corsEnabled: true, stream: true } },
]);

const BOOK_RE = /\.(epub|pdf|html?|xhtml?|xht|shtml)$/i;
let win = null;
let service = null;
let pendingFile = null;
let closeReady = false;
let closeTimer = null;
let boundsTimer = null;

function fileArg(argv) {
  for (const a of (argv || []).slice(1)) {
    if (!a || a.startsWith('-')) continue;
    try {
      if (BOOK_RE.test(a) && fs.existsSync(a)) return path.resolve(a);
    } catch { /* ignore */ }
  }
  return null;
}

if (!app.requestSingleInstanceLock()) {
  app.quit();
} else {
  app.on('second-instance', (_e, argv) => {
    const f = fileArg(argv);
    if (!win) return;
    if (win.isMinimized()) win.restore();
    win.focus();
    if (f) win.webContents.send('open-file', f);
  });
  app.whenReady().then(init);
}

function init() {
  if (process.platform === 'win32') app.setAppUserModelId('BilingualReader');
  Menu.setApplicationMenu(null);
  const userData = path.join(app.getPath('userData'), 'data');
  service = new Service({ userDataDir: userData, appDir: __dirname });
  service.userDataDir = userData;

  protocol.handle('app', async (request) => {
    try {
      const url = new URL(request.url);
      if (url.host !== 'ui') return new Response('not found', { status: 404 });
      const r = service.handle(url.pathname, url.search);
      return new Response(r.body, { status: r.status, headers: r.headers });
    } catch (e) {
      return new Response(String(e && e.message || e), { status: 500 });
    }
  });

  const electronApi = {
    getPending: () => { const f = pendingFile; pendingFile = null; return f; },
    pickBook: async () => {
      const r = await dialog.showOpenDialog(win, {
        title: '打开书籍',
        properties: ['openFile'],
        filters: [{ name: '书籍（EPUB、PDF、HTML）', extensions: ['epub', 'pdf', 'html', 'htm', 'xhtml', 'xht'] }, { name: '所有文件', extensions: ['*'] }],
      });
      return r.canceled ? [] : r.filePaths;
    },
    pickDicts: async (kind) => {
      const filters = kind === 'csv'
        ? [{ name: 'CSV / TSV 词库', extensions: ['csv', 'tsv', 'txt'] }]
        : [{ name: 'MDict 词典', extensions: ['mdx'] }];
      const r = await dialog.showOpenDialog(win, { title: kind === 'csv' ? '导入 CSV 词库' : '导入 MDX 词典', properties: ['openFile', 'multiSelections'], filters });
      return r.canceled ? [] : r.filePaths;
    },
    pickSave: async (name, filters) => {
      const r = await dialog.showSaveDialog(win, { defaultPath: path.join(app.getPath('documents'), name || '导出.txt'), filters: filters || [] });
      return r.canceled ? null : r.filePath;
    },
    clipboardWrite: (o) => {
      const text = String((o && o.text) || '');
      if (o && o.html) clipboard.write({ text, html: String(o.html) }); else clipboard.writeText(text);
      return true;
    },
    openExternal: (url) => { if (/^(https?|mailto):/i.test(String(url))) shell.openExternal(String(url)); return true; },
    showInFolder: (p) => { if (p && fs.existsSync(p)) shell.showItemInFolder(p); return true; },
    win: (action) => {
      if (!win) return null;
      if (action === 'minimize') win.minimize();
      else if (action === 'maximize') { if (win.isMaximized()) win.unmaximize(); else win.maximize(); }
      else if (action === 'close') win.close();
      else if (action === 'fullscreen') win.setFullScreen(!win.isFullScreen());
      else if (action === 'devtools') win.webContents.toggleDevTools();
      return windowState();
    },
    closeReady: () => {
      closeReady = true;
      clearTimeout(closeTimer);
      if (win) setImmediate(() => win && win.close());
      return true;
    },
  };

  ipcMain.handle('api', async (event, method, args) => {
    if (!win || event.sender !== win.webContents) throw new Error('forbidden');
    const a = Array.isArray(args) ? args : [];
    if (method === 'getState') return { ...service.getState(), userDataDir: userData };
    if (API_METHODS.includes(method)) return service[method](...a);
    if (Object.prototype.hasOwnProperty.call(electronApi, method)) return electronApi[method](...a);
    throw new Error('未知的调用：' + method);
  });

  pendingFile = fileArg(process.argv);
  createWindow();
}

function windowState() {
  return win ? { maximized: win.isMaximized(), fullscreen: win.isFullScreen() } : null;
}

function sendState() {
  if (win) win.webContents.send('window-state', windowState());
}

function visibleBounds(b) {
  if (!b || !b.width || !b.height) return null;
  const area = screen.getDisplayMatching(b).workArea;
  const ix = Math.max(0, Math.min(b.x + b.width, area.x + area.width) - Math.max(b.x, area.x));
  const iy = Math.max(0, Math.min(b.y + b.height, area.y + area.height) - Math.max(b.y, area.y));
  if (ix < 120 || iy < 80) return null;
  return { x: b.x, y: b.y, width: Math.min(b.width, area.width), height: Math.min(b.height, area.height) };
}

function saveBounds() {
  if (!win || win.isDestroyed()) return;
  const b = win.getNormalBounds();
  service.store.set('window', { ...b, maximized: win.isMaximized() });
}

function createWindow() {
  const saved = service.store.get('window', {});
  const b = visibleBounds(saved);
  win = new BrowserWindow({
    width: b ? b.width : 1380,
    height: b ? b.height : 880,
    x: b ? b.x : undefined,
    y: b ? b.y : undefined,
    minWidth: 760,
    minHeight: 480,
    frame: false,
    show: false,
    backgroundColor: '#f3f4f6',
    title: '双语阅读器',
    icon: path.join(__dirname, 'assets', process.platform === 'win32' ? 'icon.ico' : 'icon.png'),
    webPreferences: {
      preload: path.join(__dirname, 'preload.js'),
      contextIsolation: true,
      nodeIntegration: false,
      sandbox: false,
      spellcheck: false,
      webviewTag: false,
    },
  });
  if (saved && saved.maximized) win.maximize();
  win.loadURL('app://ui/index.html');
  win.once('ready-to-show', () => win.show());
  win.webContents.on('did-finish-load', sendState);
  for (const ev of ['maximize', 'unmaximize', 'enter-full-screen', 'leave-full-screen']) win.on(ev, sendState);
  for (const ev of ['resize', 'move']) win.on(ev, () => { clearTimeout(boundsTimer); boundsTimer = setTimeout(saveBounds, 600); });

  win.on('close', (e) => {
    saveBounds();
    if (closeReady) return;
    e.preventDefault();
    win.webContents.send('before-close');
    clearTimeout(closeTimer);
    closeTimer = setTimeout(() => { closeReady = true; if (win) win.close(); }, 1500);
  });
  win.on('closed', () => { win = null; });

  win.webContents.setWindowOpenHandler(({ url }) => {
    if (/^https?:/i.test(url)) shell.openExternal(url);
    return { action: 'deny' };
  });
  win.webContents.on('will-navigate', (e, url) => {
    if (!String(url).startsWith('app://ui/')) e.preventDefault();
  });
  win.webContents.on('will-frame-navigate', (e) => {
    const url = String(e.url || '');
    if (!url.startsWith('app://ui/') && url !== 'about:blank' && !url.startsWith('about:srcdoc')) e.preventDefault();
  });
  win.webContents.on('before-input-event', (e, input) => {
    if (input.type !== 'keyDown') return;
    const k = input.key;
    if (['F6', 'F8', 'F9', 'F11', 'F12'].includes(k) && !input.control && !input.alt && !input.meta) {
      e.preventDefault();
      if (k === 'F11') { win.setFullScreen(!win.isFullScreen()); return; }
      if (k === 'F12') { win.webContents.toggleDevTools(); return; }
      win.webContents.send('shortcut', k);
      return;
    }
    if (input.alt && !input.control && (k === 'ArrowUp' || k === 'ArrowLeft')) {
      e.preventDefault();
      win.webContents.send('shortcut', 'back');
    }
  });
  win.on('app-command', (_e, cmd) => {
    if (cmd === 'browser-backward') win.webContents.send('shortcut', 'back');
  });
}

app.on('before-quit', () => { if (service) service.flush(); });
app.on('window-all-closed', () => {
  if (service) service.shutdown();
  app.quit();
});
