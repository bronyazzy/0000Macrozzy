'use strict';
// Exposes a minimal, typed bridge to the renderer (window.bridge).
const { contextBridge, ipcRenderer, webUtils } = require('electron');

const CHANNELS = new Set(['open-file', 'shortcut', 'before-close', 'window-state']);

function cleanError(e) {
  const msg = String((e && e.message) || e).replace(/^Error invoking remote method '[^']+':\s*(Error:\s*)?/, '');
  return new Error(msg);
}

contextBridge.exposeInMainWorld('bridge', {
  call: (method, ...args) => ipcRenderer.invoke('api', String(method), args).catch((e) => { throw cleanError(e); }),
  on: (channel, cb) => {
    if (!CHANNELS.has(channel) || typeof cb !== 'function') return;
    ipcRenderer.on(channel, (_event, ...a) => cb(...a));
  },
  pathForFile: (file) => {
    try { return webUtils.getPathForFile(file); } catch { return null; }
  },
});
