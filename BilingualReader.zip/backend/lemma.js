'use strict';
// Light-weight English lemmatizer: generates base-form candidates in priority order.

const IRREGULAR = {
  went: 'go', gone: 'go', goes: 'go', was: 'be', were: 'be', been: 'be', is: 'be', are: 'be', am: 'be',
  had: 'have', has: 'have', did: 'do', does: 'do', done: 'do', made: 'make', said: 'say', got: 'get', gotten: 'get',
  bought: 'buy', sold: 'sell', fell: 'fall', fallen: 'fall', rose: 'rise', risen: 'rise', held: 'hold',
  lost: 'lose', paid: 'pay', spent: 'spend', built: 'build', led: 'lead', lent: 'lend', dealt: 'deal',
  drove: 'drive', driven: 'drive', began: 'begin', begun: 'begin', brought: 'bring', caught: 'catch',
  chose: 'choose', chosen: 'choose', drew: 'draw', drawn: 'draw', fed: 'feed', felt: 'feel', found: 'find',
  forgot: 'forget', forgotten: 'forget', froze: 'freeze', frozen: 'freeze', gave: 'give', given: 'give',
  grew: 'grow', grown: 'grow', knew: 'know', known: 'know', laid: 'lay', left: 'leave', meant: 'mean',
  met: 'meet', ran: 'run', saw: 'see', seen: 'see', sent: 'send', shook: 'shake', shaken: 'shake',
  shot: 'shoot', showed: 'show', shown: 'show', spoke: 'speak', spoken: 'speak', stood: 'stand',
  stole: 'steal', stolen: 'steal', struck: 'strike', swung: 'swing', took: 'take', taken: 'take',
  taught: 'teach', thought: 'think', threw: 'throw', thrown: 'throw', told: 'tell', understood: 'understand',
  won: 'win', wrote: 'write', written: 'write', woke: 'wake', wore: 'wear', worn: 'wear', withdrew: 'withdraw',
  withdrawn: 'withdraw', overtook: 'overtake', overtaken: 'overtake', undertook: 'undertake', foresaw: 'foresee',
  foreseen: 'foresee', sought: 'seek', fought: 'fight', bent: 'bend', bled: 'bleed', bore: 'bear', borne: 'bear',
  broke: 'break', broken: 'break', became: 'become', fled: 'flee', flew: 'fly', flown: 'fly', hid: 'hide',
  hidden: 'hide', kept: 'keep', lay: 'lie', lain: 'lie', rode: 'ride', ridden: 'ride', rang: 'ring', rung: 'ring',
  sank: 'sink', sunk: 'sink', slid: 'slide', spun: 'spin', sprang: 'spring', sprung: 'spring', stuck: 'stick',
  swept: 'sweep', swore: 'swear', sworn: 'swear', tore: 'tear', torn: 'tear', wound: 'wind', upheld: 'uphold',
  better: 'good', best: 'good', worse: 'bad', worst: 'bad', more: 'many', most: 'many', less: 'little', least: 'little',
  further: 'far', farther: 'far', furthest: 'far', men: 'man', women: 'woman', children: 'child', people: 'person',
  feet: 'foot', teeth: 'tooth', mice: 'mouse', indices: 'index', appendices: 'appendix', matrices: 'matrix',
  vertices: 'vertex', analyses: 'analysis', crises: 'crisis', theses: 'thesis', hypotheses: 'hypothesis',
  syntheses: 'synthesis', diagnoses: 'diagnosis', criteria: 'criterion', phenomena: 'phenomenon', data: 'data',
  media: 'medium', bases: 'basis', axes: 'axis', lives: 'life', halves: 'half', selves: 'self', shelves: 'shelf',
  thieves: 'thief', wolves: 'wolf', knives: 'knife', leaves: 'leaf', loaves: 'loaf', calves: 'calf',
  quanta: 'quantum', maxima: 'maximum', minima: 'minimum', optima: 'optimum', formulae: 'formula',
  stimuli: 'stimulus', radii: 'radius', foci: 'focus', nuclei: 'nucleus', alumni: 'alumnus',
};

const VOWELS = /[aeiou]/;

function candidates(word) {
  const out = [];
  const add = (w) => { if (w && w.length > 1 && !out.includes(w)) out.push(w); };
  let w = String(word || '').trim();
  w = w.replace(/[’‘`´]/g, "'").replace(/^[^\p{L}\p{N}]+|[^\p{L}\p{N}]+$/gu, '');
  if (!w) return out;
  add(w);
  const lw = w.toLowerCase();
  add(lw);
  let base = lw.replace(/'s$|s'$/, (m) => (m === "s'" ? 's' : ''));
  add(base);
  if (IRREGULAR[base]) add(IRREGULAR[base]);
  const tryAdd = (stem) => { if (stem && stem.length >= 2) add(stem); };
  const b = base;
  // plural / 3rd person
  if (/ies$/.test(b)) tryAdd(b.slice(0, -3) + 'y');
  if (/(ses|xes|zes|ches|shes|oes)$/.test(b)) tryAdd(b.slice(0, -2));
  if (/ves$/.test(b)) { tryAdd(b.slice(0, -3) + 'f'); tryAdd(b.slice(0, -3) + 'fe'); }
  if (/s$/.test(b) && !/ss$/.test(b)) tryAdd(b.slice(0, -1));
  if (/es$/.test(b)) tryAdd(b.slice(0, -2));
  // past tense / participle
  if (/ied$/.test(b)) tryAdd(b.slice(0, -3) + 'y');
  if (/ed$/.test(b)) {
    const s = b.slice(0, -2);
    tryAdd(s + 'e');
    tryAdd(s);
    if (/([bcdfghjklmnprstvz])\1$/.test(s)) tryAdd(s.slice(0, -1));
    tryAdd(b.slice(0, -1));
  }
  // -ing
  if (/ing$/.test(b) && b.length > 5) {
    const s = b.slice(0, -3);
    if (/ying$/.test(b)) tryAdd(s);
    tryAdd(s);
    tryAdd(s + 'e');
    if (/([bcdfghjklmnprstvz])\1$/.test(s)) tryAdd(s.slice(0, -1));
    if (/ying$/.test(b)) tryAdd(b.slice(0, -4) + 'ie');
  }
  // comparative / superlative
  if (/ier$/.test(b)) tryAdd(b.slice(0, -3) + 'y');
  if (/iest$/.test(b)) tryAdd(b.slice(0, -4) + 'y');
  if (/er$/.test(b) && b.length > 4) { const s = b.slice(0, -2); tryAdd(s); tryAdd(s + 'e'); if (/([bcdfgklmnprtv])\1$/.test(s)) tryAdd(s.slice(0, -1)); }
  if (/est$/.test(b) && b.length > 5) { const s = b.slice(0, -3); tryAdd(s); tryAdd(s + 'e'); if (/([bcdfgklmnprtv])\1$/.test(s)) tryAdd(s.slice(0, -1)); }
  // adverbs
  if (/ily$/.test(b)) tryAdd(b.slice(0, -3) + 'y');
  if (/ly$/.test(b) && b.length > 4) tryAdd(b.slice(0, -2));
  if (/ally$/.test(b)) tryAdd(b.slice(0, -4));
  // hyphenated / spaced variants
  if (b.includes('-')) { add(b.replace(/-/g, ' ')); add(b.replace(/-/g, '')); }
  return out.filter((x) => VOWELS.test(x) || /^[a-z]{1,5}$/i.test(x) || /[^a-z]/i.test(x) || x === lw);
}

// Lemmatize only the last word of a phrase ("moving averages" -> "moving average").
function phraseCandidates(phrase) {
  const p = String(phrase || '').trim().replace(/\s+/g, ' ');
  const out = [p, p.toLowerCase()];
  const parts = p.toLowerCase().split(' ');
  if (parts.length > 1) {
    const last = parts.pop();
    for (const c of candidates(last).slice(1)) out.push([...parts, c].join(' '));
    out.push(p.toLowerCase().replace(/-/g, ' '));
  }
  return [...new Set(out)];
}

module.exports = { candidates, phraseCandidates };
