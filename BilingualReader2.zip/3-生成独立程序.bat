@echo off
rem Builds a portable dist\BilingualReader\BilingualReader.exe with its own icon.
rem tools\make-portable.js is run by the downloaded Electron in Node mode, so Node.js is not needed.
setlocal
cd /d "%~dp0"
title BilingualReader - Build portable exe
set "PSEXE=%SystemRoot%\System32\WindowsPowerShell\v1.0\powershell.exe"
if not exist "%PSEXE%" set "PSEXE=powershell.exe"
"%PSEXE%" -NoProfile -ExecutionPolicy Bypass -File "%~dp0tools\setup.ps1" -NoPrompt
if errorlevel 1 goto failed
set "ELECTRON_RUN_AS_NODE=1"
"%~dp0runtime\electron.exe" "%~dp0tools\make-portable.js"
if errorlevel 1 goto failed
set "ELECTRON_RUN_AS_NODE="
explorer "%~dp0dist\BilingualReader"
echo.
pause
exit /b 0

:failed
echo.
pause
exit /b 1
