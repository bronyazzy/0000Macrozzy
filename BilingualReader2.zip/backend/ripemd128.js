'use strict';
// RIPEMD-128 (needed to decrypt the key-block index of MDict files with Encrypted="2").

const R = [
  0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15,
  7, 4, 13, 1, 10, 6, 15, 3, 12, 0, 9, 5, 2, 14, 11, 8,
  3, 10, 14, 4, 9, 15, 8, 1, 2, 7, 0, 6, 13, 11, 5, 12,
  1, 9, 11, 10, 0, 8, 12, 4, 13, 3, 7, 15, 14, 5, 6, 2];
const RP = [
  5, 14, 7, 0, 9, 2, 11, 4, 13, 6, 15, 8, 1, 10, 3, 12,
  6, 11, 3, 7, 0, 13, 5, 10, 14, 15, 8, 12, 4, 9, 1, 2,
  15, 5, 1, 3, 7, 14, 6, 9, 11, 8, 12, 2, 10, 0, 4, 13,
  8, 6, 4, 1, 3, 11, 15, 0, 5, 12, 2, 13, 9, 7, 10, 14];
const S = [
  11, 14, 15, 12, 5, 8, 7, 9, 11, 13, 14, 15, 6, 7, 9, 8,
  7, 6, 8, 13, 11, 9, 7, 15, 7, 12, 15, 9, 11, 7, 13, 12,
  11, 13, 6, 7, 14, 9, 13, 15, 14, 8, 13, 6, 5, 12, 7, 5,
  11, 12, 14, 15, 14, 15, 9, 8, 9, 14, 5, 6, 8, 6, 5, 12];
const SP = [
  8, 9, 9, 11, 13, 15, 15, 5, 7, 7, 8, 11, 14, 14, 12, 6,
  9, 13, 15, 7, 12, 8, 9, 11, 7, 7, 12, 7, 6, 15, 13, 11,
  9, 7, 15, 11, 8, 6, 6, 14, 12, 13, 5, 14, 13, 13, 7, 5,
  15, 5, 8, 11, 14, 14, 6, 14, 6, 9, 12, 9, 12, 5, 15, 8];
const K = [0x00000000, 0x5a827999, 0x6ed9eba1, 0x8f1bbcdc];
const KP = [0x50a28be6, 0x5c4dd124, 0x6d703ef3, 0x00000000];

function f(j, x, y, z) {
  if (j < 16) return x ^ y ^ z;
  if (j < 32) return (x & y) | (~x & z);
  if (j < 48) return (x | ~y) ^ z;
  return (x & z) | (y & ~z);
}
const rol = (x, n) => (x << n) | (x >>> (32 - n));

function ripemd128(input) {
  const msg = input instanceof Uint8Array ? input : new Uint8Array(input);
  const len = msg.length;
  const total = (((len + 8) >>> 6) + 1) * 64;
  const buf = new Uint8Array(total);
  buf.set(msg);
  buf[len] = 0x80;
  const dv = new DataView(buf.buffer);
  const bits = len * 8;
  dv.setUint32(total - 8, bits >>> 0, true);
  dv.setUint32(total - 4, Math.floor(bits / 0x100000000) >>> 0, true);
  let h0 = 0x67452301, h1 = 0xefcdab89, h2 = 0x98badcfe, h3 = 0x10325476;
  const X = new Int32Array(16);
  for (let off = 0; off < total; off += 64) {
    for (let i = 0; i < 16; i++) X[i] = dv.getInt32(off + i * 4, true);
    let A = h0, B = h1, C = h2, D = h3;
    let Ap = h0, Bp = h1, Cp = h2, Dp = h3;
    for (let j = 0; j < 64; j++) {
      let T = rol((A + f(j, B, C, D) + X[R[j]] + K[j >> 4]) | 0, S[j]);
      A = D; D = C; C = B; B = T;
      T = rol((Ap + f(63 - j, Bp, Cp, Dp) + X[RP[j]] + KP[j >> 4]) | 0, SP[j]);
      Ap = Dp; Dp = Cp; Cp = Bp; Bp = T;
    }
    const T = (h1 + C + Dp) | 0;
    h1 = (h2 + D + Ap) | 0;
    h2 = (h3 + A + Bp) | 0;
    h3 = (h0 + B + Cp) | 0;
    h0 = T;
  }
  const out = new Uint8Array(16);
  const odv = new DataView(out.buffer);
  odv.setUint32(0, h0 >>> 0, true);
  odv.setUint32(4, h1 >>> 0, true);
  odv.setUint32(8, h2 >>> 0, true);
  odv.setUint32(12, h3 >>> 0, true);
  return out;
}

module.exports = { ripemd128 };
