'use strict';
// CSV / TSV glossary import. Handles UTF-8 (with/without BOM), UTF-16 and GBK/GB18030
// (the default encoding of CSV files saved by Chinese Excel).

function decodeBuffer(buf) {
  if (buf.length >= 3 && buf[0] === 0xef && buf[1] === 0xbb && buf[2] === 0xbf) return buf.subarray(3).toString('utf8');
  if (buf.length >= 2 && buf[0] === 0xff && buf[1] === 0xfe) return new TextDecoder('utf-16le').decode(buf.subarray(2));
  if (buf.length >= 2 && buf[0] === 0xfe && buf[1] === 0xff) return new TextDecoder('utf-16be').decode(buf.subarray(2));
  try {
    return new TextDecoder('utf-8', { fatal: true }).decode(buf);
  } catch {
    try { return new TextDecoder('gb18030').decode(buf); } catch { return buf.toString('latin1'); }
  }
}

function detectDelimiter(text) {
  const line = (text.split(/\r?\n/).find((l) => l.trim()) || '');
  let inQ = false;
  const counts = { ',': 0, '\t': 0, ';': 0, '|': 0 };
  for (const ch of line) {
    if (ch === '"') inQ = !inQ;
    else if (!inQ && ch in counts) counts[ch]++;
  }
  let best = ',';
  for (const d of ['\t', ',', ';', '|']) if (counts[d] > counts[best]) best = d;
  return best;
}

function parseCsv(text, delim) {
  delim = delim || detectDelimiter(text);
  const rows = [];
  let row = [];
  let field = '';
  let inQ = false;
  for (let i = 0; i < text.length; i++) {
    const ch = text[i];
    if (inQ) {
      if (ch === '"') {
        if (text[i + 1] === '"') { field += '"'; i++; } else inQ = false;
      } else field += ch;
    } else if (ch === '"' && field.trim() === '') {
      inQ = true;
      field = '';
    } else if (ch === delim) {
      row.push(field); field = '';
    } else if (ch === '\n' || ch === '\r') {
      if (ch === '\r' && text[i + 1] === '\n') i++;
      row.push(field); field = '';
      if (row.some((c) => c.trim() !== '')) rows.push(row);
      row = [];
    } else field += ch;
  }
  row.push(field);
  if (row.some((c) => c.trim() !== '')) rows.push(row);
  return rows;
}

const HEADER_MAP = [
  ['w', /^(word|words|term|terms|headword|entry|vocab|vocabulary|english|en|单词|词条|词汇|英文|英语|术语|生词|词语|短语)$/i],
  ['ph', /^(phonetic|phonetics|pron|pronunciation|ipa|音标|读音|发音)$/i],
  ['pos', /^(pos|part of speech|词性)$/i],
  ['def', /^(definition|definitions|meaning|meanings|translation|chinese|cn|zh|释义|解释|中文|翻译|含义|意思|中文释义|词义)$/i],
  ['ex', /^(example|examples|sentence|sentences|例句|示例|例子|原句)$/i],
  ['note', /^(note|notes|remark|comment|备注|说明|注释|笔记)$/i],
];

function looksPhonetic(s) {
  s = String(s || '').trim();
  return /^[/[].{1,60}[/\]]$/.test(s) || /[ˈˌəɪʊæɑɔʌθðŋʃʒː]/.test(s) && s.length < 60;
}

function rowsToEntries(rows) {
  if (!rows.length) return { entries: [], columns: null };
  let cols = null;
  const first = rows[0].map((c) => c.trim());
  const mapped = {};
  first.forEach((h, i) => {
    for (const [key, re] of HEADER_MAP) {
      if (re.test(h) && mapped[key] === undefined) { mapped[key] = i; break; }
    }
  });
  let start = 0;
  if (mapped.w !== undefined && (mapped.def !== undefined || Object.keys(mapped).length >= 2)) {
    cols = mapped;
    start = 1;
  } else {
    // No header: word, [phonetic], definition, example...
    cols = { w: 0 };
    const sample = rows.slice(0, 30);
    const phCol1 = sample.filter((r) => looksPhonetic(r[1])).length > sample.length * 0.5;
    if (phCol1) { cols.ph = 1; cols.def = 2; cols.ex = 3; } else { cols.def = 1; cols.ex = 2; cols.note = 3; }
  }
  const entries = [];
  for (let r = start; r < rows.length; r++) {
    const row = rows[r];
    const get = (k) => (cols[k] !== undefined ? String(row[cols[k]] || '').trim() : '');
    const w = get('w');
    if (!w) continue;
    const e = { w };
    const ph = get('ph'); if (ph) e.ph = ph;
    const pos = get('pos'); if (pos) e.pos = pos;
    const def = get('def'); if (def) e.def = def;
    const ex = get('ex'); if (ex) e.ex = ex;
    const note = get('note'); if (note) e.note = note;
    if (!e.def && !e.ex && !e.note) {
      // fall back: join the remaining columns
      const rest = row.filter((_, i) => i !== cols.w).map((s) => String(s).trim()).filter(Boolean).join('；');
      if (!rest) continue;
      e.def = rest;
    }
    entries.push(e);
  }
  return { entries, columns: cols };
}

function parseCsvDictionary(buf) {
  const text = decodeBuffer(buf);
  const rows = parseCsv(text);
  return rowsToEntries(rows);
}

module.exports = { parseCsvDictionary, parseCsv, decodeBuffer, detectDelimiter };
