'use strict';
// Gemini API (Google AI Studio keys, including the newer "AQ." auth keys): model list and streaming chat
// over REST + server-sent events. The key is sent in the x-goog-api-key header. Network calls go through an
// injected fetch (Electron's net.fetch in the app, so the Windows / system proxy settings are honoured).
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

const DEFAULT_BASE = 'https://generativelanguage.googleapis.com/v1beta';
const DEFAULT_MODEL = 'gemini-3.8-flash';
const KEY_FILE = 'gemini-api-key.txt';
const DEFAULT_SYSTEM = [
  '你是一位金融与交易教材的阅读助手，帮助中文读者读懂英文或中英对照的交易、投资、金融教材。',
  '- 用简体中文回答；专业术语在中文后给出英文原文，例如：久期（duration）。',
  '- 先给结论，再分点解释；涉及公式时说明每个变量的含义。',
  '- 解释词句时结合原文上下文和金融含义；翻译要准确、通顺，保留数字、单位和专有名词。',
  '- 不确定的内容直接说明，不要编造。',
].join('\n');
const THINKING = new Set(['', 'low', 'medium', 'high']);

class AiError extends Error {
  constructor(message, info = {}) {
    super(message);
    Object.assign(this, info);
  }
}

function maskKey(k) {
  const s = String(k || '');
  if (!s) return '';
  return s.length <= 12 ? '••••' : s.slice(0, 5) + '…' + s.slice(-4);
}

function validKey(k) {
  return /^[A-Za-z0-9._~\-]{20,400}$/.test(k);
}

function errorInfo(body) {
  try {
    const j = JSON.parse(body);
    const e = j.error || (Array.isArray(j) && j[0] && j[0].error) || {};
    const reason = ((e.details || []).find((d) => d && d.reason) || {}).reason || '';
    return { msg: String(e.message || ''), status: String(e.status || ''), reason };
  } catch {
    return { msg: String(body || '').replace(/<[^>]+>/g, ' ').replace(/\s+/g, ' ').trim().slice(0, 300), status: '', reason: '' };
  }
}

function describeHttpError(status, body, model) {
  const { msg, status: st, reason } = errorInfo(body);
  const all = msg + ' ' + reason + ' ' + st;
  if (/API_KEY_INVALID|API key not valid|API_KEY_EXPIRED|expired/i.test(all)) return 'API Key 无效或已过期，请在「设置 → AI 对话」中重新填写。';
  if (/location is not supported|User location/i.test(all)) return '当前所在地区不能使用 Gemini API：' + msg;
  if (status === 401 || status === 403) return `API Key 没有访问权限（${status}${reason ? '，' + reason : ''}）：${msg || '请确认 Key 有效并已启用 Gemini API'}`;
  if (status === 404) return `找不到模型“${model || ''}”。请点模型列表旁的刷新按钮，重新选择一个模型。${msg ? '\n' + msg : ''}`;
  if (status === 429) return `请求太频繁或额度已用完（429）。${msg || '请稍后再试。'}`;
  if (status >= 500) return `Gemini 服务暂时不可用（${status}），请稍后再试。${msg ? '\n' + msg : ''}`;
  return `请求失败（${status}${st ? ' ' + st : ''}）：${msg || '未知错误'}`;
}

function describeNetError(e) {
  const m = String((e && e.cause && (e.cause.code || e.cause.message)) || (e && e.message) || e);
  return `无法连接 Gemini 服务（${m}）。请检查网络；使用代理 / VPN 时请打开「系统代理」。`;
}

// ---------------------------------------------------------------- models

const NON_CHAT = /(?:embed|imagen|veo|tts|aqa|audio|live|image|robotics|computer-use|lyria|omni|transcri|learnlm|bison|gecko)/i;

function modelRank(id) {
  const v = /^gemini-(\d+(?:\.\d+)?)/.exec(id);
  const fam = /flash-lite|lite/.test(id) ? 2 : /flash/.test(id) ? 1 : /pro/.test(id) ? 0 : 3;
  const pre = /preview|exp|latest|-\d{2,}/.test(id) ? 1 : 0;
  return { gemini: id.startsWith('gemini') ? 0 : 1, ver: v ? parseFloat(v[1]) : 0, fam, pre };
}

function sortModels(list) {
  return list.sort((a, b) => {
    const x = modelRank(a.id);
    const y = modelRank(b.id);
    return x.gemini - y.gemini || y.ver - x.ver || x.fam - y.fam || x.pre - y.pre || a.id.localeCompare(b.id);
  });
}

function shapeModels(raw) {
  const out = [];
  const seen = new Set();
  for (const m of raw || []) {
    const id = String((m && m.name) || '').replace(/^models\//, '');
    if (!id || seen.has(id)) continue;
    const methods = m.supportedGenerationMethods || m.supportedActions || [];
    if (methods.length && !methods.includes('generateContent')) continue;
    if (NON_CHAT.test(id)) continue;
    seen.add(id);
    out.push({
      id,
      name: String(m.displayName || id),
      desc: String(m.description || '').slice(0, 300),
      input: m.inputTokenLimit || 0,
      output: m.outputTokenLimit || 0,
      thinking: !!m.thinking,
    });
  }
  return sortModels(out);
}

function pickDefaultModel(models) {
  if (!models.length) return DEFAULT_MODEL;
  if (models.some((m) => m.id === DEFAULT_MODEL)) return DEFAULT_MODEL;
  const stable = models.filter((m) => !modelRank(m.id).pre);
  return ((stable.find((m) => /flash/.test(m.id) && !/lite/.test(m.id))) || stable[0] || models[0]).id;
}

// ---------------------------------------------------------------- REST client

class GeminiClient {
  constructor({ fetch: f, baseUrl } = {}) {
    this.fetch = f || globalThis.fetch;
    this.base = String(baseUrl || DEFAULT_BASE).replace(/\/+$/, '');
  }

  async _request(url, init, model) {
    let res;
    try {
      res = await this.fetch(url, init);
    } catch (e) {
      if (init.signal && init.signal.aborted) throw new AiError('已停止', { aborted: true });
      throw new AiError(describeNetError(e), { network: true });
    }
    if (!res.ok) {
      let body = '';
      try { body = await res.text(); } catch { /* ignore */ }
      throw new AiError(describeHttpError(res.status, body, model), { status: res.status });
    }
    return res;
  }

  async listModels(key, signal) {
    const all = [];
    let token = '';
    for (let page = 0; page < 6; page++) {
      const url = `${this.base}/models?pageSize=1000${token ? '&pageToken=' + encodeURIComponent(token) : ''}`;
      const res = await this._request(url, { method: 'GET', headers: { 'x-goog-api-key': key }, signal });
      const j = await res.json();
      all.push(...(j.models || []));
      token = j.nextPageToken || '';
      if (!token) break;
    }
    return shapeModels(all);
  }

  // Yields every GenerateContentResponse chunk of a streamGenerateContent call.
  async *stream({ key, model, body, signal }) {
    const url = `${this.base}/models/${encodeURIComponent(model)}:streamGenerateContent?alt=sse`;
    const res = await this._request(url, {
      method: 'POST',
      headers: { 'content-type': 'application/json', 'x-goog-api-key': key },
      body: JSON.stringify(body),
      signal,
    }, model);
    if (!res.body) throw new AiError('Gemini 返回了空响应');
    const reader = res.body.getReader();
    // stop reading as soon as the user presses 停止, even if the fetch implementation ignores the signal
    const onAbort = () => { try { reader.cancel().catch(() => {}); } catch { /* ignore */ } };
    if (signal) signal.addEventListener('abort', onAbort, { once: true });
    const dec = new TextDecoder();
    let buf = '';
    const parseBlock = (block) => {
      const data = block.split(/\r?\n/).filter((l) => l.startsWith('data:')).map((l) => l.slice(5).replace(/^ /, '')).join('\n').trim();
      if (!data || data === '[DONE]') return null;
      let j;
      try { j = JSON.parse(data); } catch { return null; }
      if (j && j.error) throw new AiError(describeHttpError(j.error.code || 500, JSON.stringify(j), model), { status: j.error.code });
      return j;
    };
    try {
      for (;;) {
        const { value, done } = await reader.read();
        if (signal && signal.aborted) throw new AiError('已停止', { aborted: true });
        if (done) break;
        buf += dec.decode(value, { stream: true });
        let m;
        while ((m = /\r?\n\r?\n/.exec(buf))) {
          const block = buf.slice(0, m.index);
          buf = buf.slice(m.index + m[0].length);
          const j = parseBlock(block);
          if (j) yield j;
        }
      }
      buf += dec.decode();
      if (buf.trim()) {
        const j = parseBlock(buf);
        if (j) yield j;
      }
    } catch (e) {
      if (signal && signal.aborted) throw new AiError('已停止', { aborted: true });
      if (e instanceof AiError) throw e;
      throw new AiError(describeNetError(e), { network: true });
    } finally {
      if (signal) signal.removeEventListener('abort', onAbort);
      try { reader.releaseLock(); } catch { /* ignore */ }
    }
  }
}

// ---------------------------------------------------------------- manager (settings, key, chats)

const FINISH_NOTE = {
  MAX_TOKENS: '回答达到长度上限，被截断了。',
  SAFETY: '回答被安全策略拦截。',
  PROHIBITED_CONTENT: '回答被安全策略拦截。',
  BLOCKLIST: '回答被安全策略拦截。',
  SPII: '回答因涉及敏感个人信息被拦截。',
  RECITATION: '回答可能大段引用受版权保护的内容，已被中止。',
  CONTINUATION: '回答较长，已在中途结束。',
  LANGUAGE: '模型不支持这种语言的请求。',
};

const plainSecrets = {
  kind: 'plain',
  encrypt: (s) => 'plain:' + Buffer.from(String(s), 'utf8').toString('base64'),
  decrypt: (v) => (String(v).startsWith('plain:') ? Buffer.from(String(v).slice(6), 'base64').toString('utf8') : ''),
};

class AiManager {
  constructor({ store, appDir, emit }) {
    this.store = store;
    this.appDir = appDir;
    this.emit = emit || (() => {});
    this.secrets = plainSecrets;
    this.fetch = globalThis.fetch;
    this.jobs = new Map();
  }

  setSecrets(s) { if (s && s.encrypt && s.decrypt) this.secrets = s; }
  setFetch(f) { if (typeof f === 'function') this.fetch = f; }

  _cfg() { return this.store.get('ai', {}); }
  _save(cfg) { this.store.set('ai', cfg, true); }
  _client() {
    const cfg = this._cfg();
    return new GeminiClient({ fetch: this.fetch, baseUrl: cfg.baseUrl || process.env.BR_GEMINI_BASE || DEFAULT_BASE });
  }

  getKey() {
    const c = this._cfg();
    if (!c.keyEnc) return '';
    try { return this.secrets.decrypt(c.keyEnc) || ''; } catch { return ''; }
  }

  _keyId(key) { return key ? crypto.createHash('sha256').update(key).digest('hex').slice(0, 12) : ''; }

  config() {
    const c = this._cfg();
    const key = this.getKey();
    const cache = c.modelCache && c.modelCache.keyId === this._keyId(key) ? c.modelCache : null;
    return {
      hasKey: !!key,
      keyHint: maskKey(key),
      keyProtected: !!(c.keyEnc && !String(c.keyEnc).startsWith('plain:')),
      keyBroken: !!(c.keyEnc && !key),
      model: c.model || (cache ? pickDefaultModel(cache.models) : DEFAULT_MODEL),
      thinking: THINKING.has(c.thinking) ? c.thinking : '',
      system: typeof c.system === 'string' && c.system.trim() ? c.system : DEFAULT_SYSTEM,
      defaultSystem: DEFAULT_SYSTEM,
      baseUrl: c.baseUrl || '',
      defaultBaseUrl: DEFAULT_BASE,
      includeBook: c.includeBook !== false,
      saveHistory: c.saveHistory !== false,
      models: cache ? cache.models : [],
      modelsAt: cache ? cache.at : 0,
    };
  }

  saveConfig(patch) {
    const c = this._cfg();
    const p = patch || {};
    if (typeof p.model === 'string') c.model = p.model.trim().replace(/^models\//, '').slice(0, 120);
    if (typeof p.thinking === 'string' && THINKING.has(p.thinking)) c.thinking = p.thinking;
    if (typeof p.system === 'string') c.system = p.system.trim() === DEFAULT_SYSTEM.trim() ? '' : p.system.slice(0, 8000);
    if (typeof p.baseUrl === 'string') {
      const u = p.baseUrl.trim().replace(/\/+$/, '');
      if (u && !/^https?:\/\/[^\s]+$/i.test(u)) throw new Error('接口地址必须以 http:// 或 https:// 开头');
      c.baseUrl = u === DEFAULT_BASE ? '' : u;
      delete c.modelCache;
    }
    if (typeof p.includeBook === 'boolean') c.includeBook = p.includeBook;
    if (typeof p.saveHistory === 'boolean') c.saveHistory = p.saveHistory;
    this._save(c);
    return this.config();
  }

  setKey(key) {
    const k = String(key || '').trim();
    const c = this._cfg();
    if (!k) {
      delete c.keyEnc;
      delete c.modelCache;
      this._save(c);
      return this.config();
    }
    if (!validKey(k)) throw new Error('API Key 格式不对（应为一串字母、数字和 . _ - 组成的字符，中间没有空格）');
    c.keyEnc = this.secrets.encrypt(k);
    delete c.modelCache;
    this._save(c);
    return this.config();
  }

  // One-time import of <appDir>/gemini-api-key.txt: the key is stored encrypted, then the file is deleted.
  importKeyFile() {
    const file = path.join(this.appDir, KEY_FILE);
    if (!fs.existsSync(file)) return false;
    let imported = false;
    try {
      const k = fs.readFileSync(file, 'utf8').replace(/^﻿/, '').split(/\r?\n/).map((s) => s.trim()).find((s) => s && !s.startsWith('#')) || '';
      if (k && validKey(k) && !this.getKey()) {
        this.setKey(k);
        imported = true;
      }
    } catch (e) {
      console.error('导入 API Key 文件失败：', e.message);
    }
    try { fs.unlinkSync(file); } catch { /* read-only folder: leave it */ }
    return imported;
  }

  async models(refresh) {
    const key = this.getKey();
    if (!key) throw new Error('还没有设置 Gemini API Key');
    const c = this._cfg();
    const keyId = this._keyId(key);
    if (!refresh && c.modelCache && c.modelCache.keyId === keyId && c.modelCache.models.length && Date.now() - c.modelCache.at < 7 * 86400e3) {
      return c.modelCache.models;
    }
    const models = await this._client().listModels(key);
    const c2 = this._cfg();
    c2.modelCache = { keyId, at: Date.now(), models };
    if (!c2.model || !models.some((m) => m.id === c2.model)) c2.model = pickDefaultModel(models);
    this._save(c2);
    return models;
  }

  async test(key) {
    const k = String(key || '').trim() || this.getKey();
    if (!k) throw new Error('请先填写 API Key');
    if (!validKey(k)) throw new Error('API Key 格式不对');
    const models = await this._client().listModels(k);
    return { ok: true, count: models.length, models: models.slice(0, 6).map((m) => m.id) };
  }

  // Starts a streaming chat; progress arrives as 'ai-event' events {id, type: delta|done|error|aborted, ...}.
  chat(id, req) {
    id = String(id || '');
    if (!id) throw new Error('缺少请求编号');
    const key = this.getKey();
    if (!key) throw new Error('还没有设置 Gemini API Key（设置 → AI 对话）');
    const r = req || {};
    const model = String(r.model || this.config().model || DEFAULT_MODEL).replace(/^models\//, '');
    const contents = normalizeContents(r.contents);
    if (!contents.length || contents[contents.length - 1].role !== 'user') throw new Error('没有要发送的问题');
    const body = { contents };
    const system = String(r.system || '').trim();
    if (system) body.systemInstruction = { parts: [{ text: system }] };
    const thinking = THINKING.has(r.thinking) ? r.thinking : '';
    if (thinking) body.generationConfig = { thinkingConfig: { thinkingLevel: thinking } };
    const ac = new AbortController();
    this.jobs.set(id, ac);
    this._run(id, model, key, body, ac).finally(() => this.jobs.delete(id));
    return { started: true, model };
  }

  async _run(id, model, key, body, ac) {
    const parts = [];
    let text = '';
    let finish = '';
    let usage = null;
    let modelVersion = '';
    let blocked = '';
    const addPart = (p) => {
      if (!p || p.thought) return; // thought summaries are not requested / not shown
      if (typeof p.text === 'string') {
        text += p.text;
        const last = parts[parts.length - 1];
        // never merge a part that carries a thought signature with another part
        if (p.thoughtSignature) parts.push({ text: p.text, thoughtSignature: p.thoughtSignature });
        else if (last && typeof last.text === 'string' && !last.thoughtSignature) last.text += p.text;
        else parts.push({ text: p.text });
        if (p.text) this.emit('ai-event', { id, type: 'delta', text: p.text });
      } else if (p.thoughtSignature) {
        parts.push(p);
      }
    };
    try {
      for await (const chunk of this._client().stream({ key, model, body, signal: ac.signal })) {
        if (chunk.promptFeedback && chunk.promptFeedback.blockReason) blocked = chunk.promptFeedback.blockReason;
        const cand = (chunk.candidates || [])[0];
        if (cand) {
          for (const p of (cand.content && cand.content.parts) || []) addPart(p);
          if (cand.finishReason) finish = cand.finishReason;
        }
        if (chunk.usageMetadata) usage = chunk.usageMetadata;
        if (chunk.modelVersion) modelVersion = chunk.modelVersion;
      }
      if (blocked && !text) throw new AiError('问题被安全策略拦截（' + blocked + '），请换一种问法。');
      if (!text && !parts.length) throw new AiError('模型没有返回内容' + (finish && finish !== 'STOP' ? '（' + finish + '）' : '') + '，请重试或换一个模型。');
      const note = finish && finish !== 'STOP' ? FINISH_NOTE[finish] || '回答提前结束（' + finish + '）。' : '';
      this.emit('ai-event', { id, type: 'done', parts, text, finish, note, usage: shapeUsage(usage), model: modelVersion || model });
    } catch (e) {
      if (e && e.aborted) this.emit('ai-event', { id, type: 'aborted', parts, text, model });
      else this.emit('ai-event', { id, type: 'error', message: String((e && e.message) || e), parts, text, model });
    }
  }

  cancel(id) {
    const ac = this.jobs.get(String(id || ''));
    if (ac) ac.abort();
    return !!ac;
  }

  cancelAll() { for (const ac of this.jobs.values()) ac.abort(); }

  history(bookId) {
    return this.store.get('ai-chats/' + safeId(bookId), { messages: [] }).messages || [];
  }

  saveHistory(bookId, messages) {
    if (this._cfg().saveHistory === false) return false;
    const list = (Array.isArray(messages) ? messages : []).slice(-80).map((m) => ({
      role: m.role === 'model' ? 'model' : 'user',
      text: String(m.text || '').slice(0, 60000),
      parts: Array.isArray(m.parts) ? m.parts.filter((p) => p && (typeof p.text === 'string' || p.thoughtSignature)).slice(0, 400) : undefined,
      quote: m.quote ? String(m.quote).slice(0, 600) : undefined,
      title: m.title ? String(m.title).slice(0, 80) : undefined,
      model: m.model ? String(m.model).slice(0, 80) : undefined,
      note: m.note ? String(m.note).slice(0, 200) : undefined,
      error: m.error ? String(m.error).slice(0, 600) : undefined,
      at: +m.at || Date.now(),
    }));
    this.store.set('ai-chats/' + safeId(bookId), { messages: list });
    return true;
  }
}

function safeId(id) {
  return String(id || '_global').replace(/[^A-Za-z0-9_-]/g, '_').slice(0, 64) || '_global';
}

function shapeUsage(u) {
  if (!u) return null;
  return { prompt: u.promptTokenCount || 0, output: u.candidatesTokenCount || 0, thoughts: u.thoughtsTokenCount || 0, total: u.totalTokenCount || 0 };
}

// user/model turns with non-empty parts; consecutive turns of the same role are merged
function normalizeContents(list) {
  const out = [];
  for (const c of Array.isArray(list) ? list : []) {
    const role = c && c.role === 'model' ? 'model' : 'user';
    const parts = (Array.isArray(c && c.parts) ? c.parts : [])
      .filter((p) => p && (typeof p.text === 'string' || p.thoughtSignature))
      .map((p) => {
        const q = { text: String(p.text || '') };
        if (p.thoughtSignature) q.thoughtSignature = String(p.thoughtSignature);
        return q;
      })
      .filter((p) => p.text || p.thoughtSignature);
    if (!parts.length) continue;
    const last = out[out.length - 1];
    if (last && last.role === role) last.parts.push(...parts);
    else out.push({ role, parts });
  }
  while (out.length && out[0].role !== 'user') out.shift();
  return out;
}

module.exports = { AiManager, GeminiClient, AiError, shapeModels, pickDefaultModel, describeHttpError, normalizeContents, DEFAULT_SYSTEM, DEFAULT_MODEL, DEFAULT_BASE, KEY_FILE };
