'use strict';
// Small JSON document store with debounced, atomic writes.
const fs = require('fs');
const path = require('path');

class Store {
  constructor(dir) {
    this.dir = dir;
    fs.mkdirSync(dir, { recursive: true });
    this.cache = new Map();
    this.timers = new Map();
  }

  file(name) {
    const safe = String(name).replace(/[^a-zA-Z0-9_\-/.]/g, '_').replace(/\.\.+/g, '_');
    return path.join(this.dir, safe + '.json');
  }

  get(name, def) {
    if (this.cache.has(name)) return this.cache.get(name);
    const f = this.file(name);
    let value;
    for (const candidate of [f, f + '.bak']) {
      try {
        value = JSON.parse(fs.readFileSync(candidate, 'utf8'));
        break;
      } catch { /* try next */ }
    }
    if (value === undefined) value = typeof def === 'function' ? def() : clone(def);
    this.cache.set(name, value);
    return value;
  }

  set(name, value, immediate = false) {
    this.cache.set(name, value);
    if (immediate) {
      this._cancel(name);
      this._write(name);
      return;
    }
    this._cancel(name);
    this.timers.set(name, setTimeout(() => {
      this.timers.delete(name);
      this._write(name);
    }, 400));
  }

  update(name, def, fn) {
    const v = this.get(name, def);
    const r = fn(v);
    this.set(name, r === undefined ? v : r);
    return r === undefined ? v : r;
  }

  remove(name) {
    this._cancel(name);
    this.cache.delete(name);
    for (const f of [this.file(name), this.file(name) + '.bak']) {
      try { fs.unlinkSync(f); } catch { /* ignore */ }
    }
  }

  _cancel(name) {
    const t = this.timers.get(name);
    if (t) { clearTimeout(t); this.timers.delete(name); }
  }

  _write(name) {
    if (!this.cache.has(name)) return;
    const f = this.file(name);
    const data = JSON.stringify(this.cache.get(name));
    try {
      fs.mkdirSync(path.dirname(f), { recursive: true });
      const tmp = f + '.tmp';
      fs.writeFileSync(tmp, data, 'utf8');
      try { if (fs.existsSync(f)) fs.copyFileSync(f, f + '.bak'); } catch { /* ignore */ }
      try {
        fs.renameSync(tmp, f);
      } catch {
        fs.writeFileSync(f, data, 'utf8');
        try { fs.unlinkSync(tmp); } catch { /* ignore */ }
      }
    } catch (e) {
      console.error('写入数据失败', f, e);
    }
  }

  flush() {
    for (const name of [...this.timers.keys()]) {
      this._cancel(name);
      this._write(name);
    }
  }
}

function clone(v) {
  return v === undefined ? undefined : JSON.parse(JSON.stringify(v));
}

module.exports = { Store };
