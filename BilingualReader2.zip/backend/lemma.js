'use strict';
// English morphology for dictionary lookup.
//   analyze(word)        inflected form -> base-form candidates, best first, each with a grammatical label
//   candidates(word)     the same as plain strings (the word itself first)
//   phraseCandidates(p)  lemmatises the first / last word of a short phrase ("moving averages" -> "moving average")
//   inflections(lemma)   base form -> its inflected forms (for highlighting and example search)

const LABEL = {
  pl: '复数', s3: '第三人称单数', s: '复数 / 第三人称单数', pres: '现在时', past: '过去式', pp: '过去分词',
  ed: '过去式 / 过去分词', ing: '现在分词 / 动名词', cmp: '比较级', sup: '最高级', er: '比较级 / -er 派生词',
  adv: '副词', poss: '所有格', spell: '英式拼写',
};

// Irregular verbs: "base past participle", alternatives separated by "/".
const VERBS = `
arise arose arisen|awake awoke awoken|be was/were been|bear bore borne/born|beat beat beaten|become became become|
begin began begun|bend bent bent|bet bet bet|bid bid bid|bind bound bound|bite bit bitten|bleed bled bled|blow blew blown|
break broke broken|breed bred bred|bring brought brought|broadcast broadcast broadcast|build built built|
burn burnt/burned burnt/burned|burst burst burst|buy bought bought|cast cast cast|catch caught caught|choose chose chosen|
cling clung clung|come came come|cost cost cost|creep crept crept|cut cut cut|deal dealt dealt|dig dug dug|do did done|
draw drew drawn|dream dreamt/dreamed dreamt/dreamed|drink drank drunk|drive drove driven|dwell dwelt dwelt|eat ate eaten|
fall fell fallen|feed fed fed|feel felt felt|fight fought fought|find found found|flee fled fled|fling flung flung|fly flew flown|
forbid forbade forbidden|forecast forecast/forecasted forecast/forecasted|foresee foresaw foreseen|foretell foretold foretold|
forget forgot forgotten|forgive forgave forgiven|forgo forwent forgone|freeze froze frozen|get got got/gotten|give gave given|
go went gone|grind ground ground|grow grew grown|hang hung/hanged hung/hanged|have had had|hear heard heard|hide hid hidden|
hit hit hit|hold held held|hurt hurt hurt|input input/inputted input/inputted|keep kept kept|kneel knelt knelt|know knew known|
lay laid laid|lead led led|lean leant/leaned leant/leaned|leap leapt/leaped leapt/leaped|learn learnt/learned learnt/learned|
leave left left|lend lent lent|let let let|lie lay lain|light lit/lighted lit/lighted|lose lost lost|make made made|mean meant meant|
meet met met|mislead misled misled|mistake mistook mistaken|misunderstand misunderstood misunderstood|offset offset offset|
outbid outbid outbid|outdo outdid outdone|outgrow outgrew outgrown|output output/outputted output/outputted|outrun outran outrun|
outsell outsold outsold|overcome overcame overcome|overdo overdid overdone|overdraw overdrew overdrawn|overhear overheard overheard|
overpay overpaid overpaid|override overrode overridden|overrun overran overrun|oversee oversaw overseen|oversell oversold oversold|
overshoot overshot overshot|overtake overtook overtaken|overthrow overthrew overthrown|pay paid paid|prove proved proven/proved|
put put put|quit quit quit|read read read|rebuild rebuilt rebuilt|redo redid redone|repay repaid repaid|reset reset reset|
resell resold resold|rethink rethought rethought|ride rode ridden|ring rang rung|rise rose risen|run ran run|say said said|
see saw seen|seek sought sought|sell sold sold|send sent sent|set set set|sew sewed sewn/sewed|shake shook shaken|shed shed shed|
shine shone shone|shoot shot shot|show showed shown/showed|shrink shrank shrunk|shut shut shut|sing sang sung|sink sank sunk|
sit sat sat|sleep slept slept|slide slid slid|sling slung slung|slit slit slit|smell smelt/smelled smelt/smelled|speak spoke spoken|
speed sped sped|spell spelt/spelled spelt/spelled|spend spent spent|spill spilt/spilled spilt/spilled|spin spun spun|spit spat spat|
split split split|spoil spoilt/spoiled spoilt/spoiled|spread spread spread|spring sprang sprung|stand stood stood|steal stole stolen|
stick stuck stuck|sting stung stung|stink stank stunk|stride strode stridden|strike struck struck|string strung strung|
strive strove striven|sublet sublet sublet|swear swore sworn|sweep swept swept|swell swelled swollen/swelled|swim swam swum|
swing swung swung|take took taken|teach taught taught|tear tore torn|tell told told|think thought thought|throw threw thrown|
thrust thrust thrust|tread trod trodden|undercut undercut undercut|undergo underwent undergone|underlie underlay underlain|
underpay underpaid underpaid|undersell undersold undersold|understand understood understood|undertake undertook undertaken|
underwrite underwrote underwritten|undo undid undone|unwind unwound unwound|uphold upheld upheld|upset upset upset|wake woke woken|
wear wore worn|weave wove woven|weep wept wept|win won won|wind wound wound|withdraw withdrew withdrawn|withhold withheld withheld|
withstand withstood withstood|wring wrung wrung|write wrote written`;

// Irregular plurals: "plural singular[/other[:label]]".
const NOUNS = `
men man|women woman|children child|people person|feet foot|teeth tooth|geese goose|mice mouse|oxen ox|indices index|
appendices appendix|matrices matrix|vertices vertex|vortices vortex|analyses analysis/analyse:s3|crises crisis|theses thesis|
hypotheses hypothesis|syntheses synthesis|diagnoses diagnosis|parentheses parenthesis|emphases emphasis|prognoses prognosis|
bases basis/base|axes axis/axe|criteria criterion|phenomena phenomenon|data datum|media medium|strata stratum|
curricula curriculum|memoranda memorandum|quanta quantum|maxima maximum|minima minimum|optima optimum|spectra spectrum|
formulae formula|stimuli stimulus|radii radius|foci focus|nuclei nucleus|alumni alumnus|fungi fungus|cacti cactus|syllabi syllabus|
loci locus|lives life/live:s3|wives wife|knives knife|halves half/halve:s3|selves self|shelves shelf/shelve:s3|thieves thief|
wolves wolf|leaves leave:s3/leaf:pl|loaves loaf|calves calf|elves elf|scarves scarf|wharves wharf|dice die|pence penny|
addenda addendum|errata erratum|bacteria bacterium|millennia millennium|consortia consortium|moratoria moratorium|
referenda referendum|symposia symposium|corpora corpus|genera genus`;

const SPECIAL = {
  am: [['be', 'pres']], is: [['be', 's3']], are: [['be', 'pres']], being: [['be', 'ing']], has: [['have', 's3']],
  having: [['have', 'ing']], does: [['do', 's3']], doing: [['do', 'ing']], goes: [['go', 's3']], going: [['go', 'ing']],
  could: [['can', 'past']], would: [['will', 'past']], should: [['shall', 'past']], might: [['may', 'past']],
  better: [['good', 'cmp'], ['well', 'cmp']], best: [['good', 'sup'], ['well', 'sup']], worse: [['bad', 'cmp'], ['ill', 'cmp']],
  worst: [['bad', 'sup']], more: [['much', 'cmp'], ['many', 'cmp']], most: [['much', 'sup'], ['many', 'sup']],
  less: [['little', 'cmp']], least: [['little', 'sup']], further: [['far', 'cmp']], farther: [['far', 'cmp']],
  furthest: [['far', 'sup']], farthest: [['far', 'sup']], elder: [['old', 'cmp']], eldest: [['old', 'sup']],
};

// British -> American spellings tried as a last resort.
const SPELL_WORDS = {
  programme: 'program', programmes: 'programs', cheque: 'check', cheques: 'checks', grey: 'gray', tonne: 'ton', tonnes: 'tons',
  aluminium: 'aluminum', mould: 'mold', plough: 'plow', storey: 'story', kerb: 'curb', tyre: 'tire', tyres: 'tires',
  jewellery: 'jewelry', manoeuvre: 'maneuver', sceptical: 'skeptical', practise: 'practice', enquiry: 'inquiry',
  enquiries: 'inquiries', judgement: 'judgment', judgements: 'judgments', ageing: 'aging', fulfil: 'fulfill', enrol: 'enroll',
  instalment: 'installment', instalments: 'installments', skilful: 'skillful', acknowledgement: 'acknowledgment', catalogue: 'catalog',
  dialogue: 'dialog', analogue: 'analog', defence: 'defense', licence: 'license', offence: 'offense', pretence: 'pretense',
};

// irregular verbs that also have a regular homonym or regular past (lie -> lied, wind -> winded)
const REGULAR_TOO = new Set(['lie', 'wind', 'shine', 'speed', 'cost', 'broadcast', 'forecast', 'wet', 'knit', 'quit', 'bid', 'fit', 'wake']);
const IRR = new Map(); // form -> [[base, labelKey]]
const FORMS = new Map(); // base -> Set(forms)
const VERB_BASES = new Set();
function addIrr(form, base, key) {
  if (!form || !base) return;
  if (form !== base) {
    const arr = IRR.get(form) || [];
    if (!arr.some(([b]) => b === base)) arr.push([base, key]);
    IRR.set(form, arr);
  }
  if (!FORMS.has(base)) FORMS.set(base, new Set());
  FORMS.get(base).add(form);
}
for (const line of VERBS.split('|')) {
  const [base, past, pp] = line.trim().split(/\s+/);
  if (!base || !past || !pp) continue;
  VERB_BASES.add(base);
  const pasts = past.split('/');
  const pps = pp.split('/');
  for (const f of new Set([...pasts, ...pps])) addIrr(f, base, pasts.includes(f) && pps.includes(f) ? 'ed' : pasts.includes(f) ? 'past' : 'pp');
}
for (const line of NOUNS.split('|')) {
  const [plural, sing] = line.trim().split(/\s+/);
  if (!plural || !sing) continue;
  sing.split('/').forEach((x, i) => {
    const [b, k] = x.split(':');
    addIrr(plural, b, k || (i ? 's' : 'pl'));
  });
}
for (const [form, list] of Object.entries(SPECIAL)) for (const [b, k] of list) addIrr(form, b, k);

const isV = (c) => c === 'a' || c === 'e' || c === 'i' || c === 'o' || c === 'u';
const isC = (c) => !!c && c >= 'a' && c <= 'z' && !isV(c);
const vowelGroups = (s) => (s.match(/[aeiouy]+/g) || []).length;
const doubled = (s) => s.length >= 3 && s[s.length - 1] === s[s.length - 2] && isC(s[s.length - 1]);

// Did the base most likely end in a silent "e" that was dropped before -ed / -ing / -er?
function wantsE(s) {
  if (s.length <= 2) return true; // us(e), ow(e), ag(e)
  if (/[cvzu]$/.test(s)) return true; // pric(e), mov(e), realiz(e), continu(e)
  if (/(?:dg|rg|lg|th)$/.test(s)) return true; // hedg(e), charg(e), bulg(e), bath(e)
  if (/[aeu]ng$/.test(s)) return true; // chang(e), rang(e), lung(e), challeng(e)
  if (/[bcdfgkptz]l$/.test(s)) return true; // settl(e), handl(e), doubl(e)
  if (/[aeiou]{2}[sz]$/.test(s)) return true; // rais(e), eas(e), caus(e), choos(e)
  // one-syllable consonant-vowel-consonant stems double the consonant when the base has no "e":
  // hop -> hopping, so "hoping" must come from hope (rat-ing -> rate, trad-ing -> trade)
  if (vowelGroups(s) === 1 && /[^aeiou][aeiou][^aeiouwxy]$/.test(s)) return true;
  return false;
}

function cleanWord(word) {
  return String(word == null ? '' : word)
    .replace(/[­​‌‍﻿]/g, '')
    .replace(/[’‘`´ʼ]/g, "'")
    .replace(/^[^\p{L}\p{N}]+|[^\p{L}\p{N}']+$/gu, '')
    .replace(/^'+|(?<!s)'+$/g, '')
    .trim();
}

function analyze(word) {
  const raw = cleanWord(word);
  const res = { input: raw, cands: [] };
  if (!raw) return res;
  const seen = new Map();
  const add = (w, key, score) => {
    if (!w || w.length < 2) return;
    if (!/[aeiouy]/i.test(w) && w.toLowerCase() !== raw.toLowerCase()) return;
    const prev = seen.get(w);
    if (prev) {
      if (score > prev.score) { prev.score = score; prev.key = key || ''; }
      return;
    }
    const c = { w, key: key || '', score };
    seen.set(w, c);
    res.cands.push(c);
  };
  add(raw, '', 100);
  const lw = raw.toLowerCase();
  add(lw, '', 99);
  if (/\s/.test(lw)) return finish(res);

  let b = lw;
  let delta = 0;
  if (/'s$/.test(b)) { b = b.slice(0, -2); add(b, 'poss', 97); delta = 2; }
  else if (/s'$/.test(b)) { b = b.slice(0, -1); add(b, 'poss', 97); delta = 2; }
  b = b.replace(/'/g, '');
  if (b.length < 2) return finish(res);
  const put = (w, key, score) => {
    // regular -ed never applies to irregular verbs (seed is not "see" + d)
    if (key === 'ed' && VERB_BASES.has(w) && !REGULAR_TOO.has(w) && !(FORMS.get(w) || new Set()).has(b)) return;
    add(w, key, score - delta);
  };

  if (IRR.has(b)) {
    for (const [base, key] of IRR.get(b)) put(base, key, 95);
  } else {
    sRule(b, put);
    edRule(b, put);
    ingRule(b, put);
    erRule(b, put);
    lyRule(b, put);
  }

  // British spellings (analyse -> analyze, colour -> color, centre -> center)
  const top = res.cands.filter((c) => c.score < 99).slice(0, 3).map((c) => c.w);
  for (const w of [lw, ...top]) {
    for (const v of spellVariants(w)) add(v, w === lw ? 'spell' : (seen.get(w) || {}).key || 'spell', 40);
  }
  if (lw.includes('-')) { add(lw.replace(/-/g, ' '), '', 45); add(lw.replace(/-/g, ''), '', 44); }
  return finish(res);
}

function finish(res) {
  res.cands.sort((a, b) => b.score - a.score);
  for (const c of res.cands) c.label = LABEL[c.key] || '';
  return res;
}

function sRule(b, put) {
  if (b.length < 3 || !b.endsWith('s') || /(?:ss|us|is)$/.test(b)) return;
  if (b.endsWith('ies') && b.length >= 4) {
    const y = b.slice(0, -3) + 'y';
    const ie = b.slice(0, -1);
    if (b.length <= 5) { put(ie, 's', 92); put(y, 's', 88); } else { put(y, 's', 92); put(ie, 's', 86); }
    return;
  }
  if (b.endsWith('ves') && b.length >= 5) {
    put(b.slice(0, -1), 's', 92);
    put(b.slice(0, -3) + 'f', 'pl', 84);
    put(b.slice(0, -3) + 'fe', 'pl', 83);
    return;
  }
  if (b.endsWith('es') && b.length >= 4) {
    const st = b.slice(0, -2);
    if (/(?:ss|x|zz|z|ch|sh)$/.test(st)) {
      put(st, 's', 92);
      if (st.endsWith('zz')) put(st.slice(0, -1), 's', 89); // quizzes -> quiz
      put(b.slice(0, -1), 's', 88);
      return;
    }
    if (st.endsWith('o') && st.length >= 4) { put(st, 's', 91); put(b.slice(0, -1), 's', 90); return; } // heroes / canoes
    if (st.endsWith('o')) { put(b.slice(0, -1), 's', 92); put(st, 's', 88); return; } // shoes, toes, foes
    if (/[^s]s$/.test(st) && st.length >= 3) { put(b.slice(0, -1), 's', 92); put(st, 's', 90); return; }
  }
  put(b.slice(0, -1), 's', 92);
}

function edRule(b, put) {
  if (b.length < 4 || !b.endsWith('ed')) return;
  const s = b.slice(0, -2);
  if (!/[aeiouy]/.test(s)) return;
  if (b.endsWith('ied') && b.length >= 5) {
    const y = b.slice(0, -3) + 'y';
    const ie = b.slice(0, -1);
    if (b.length <= 5) { put(ie, 'ed', 92); put(y, 'ed', 88); } else { put(y, 'ed', 92); put(ie, 'ed', 86); }
    return;
  }
  if (s.endsWith('e')) {
    if (b.length >= 5) { put(b.slice(0, -1), 'ed', 92); put(s, 'ed', 86); } // agreed -> agree, freed -> free
    return;
  }
  stemRule(s, 'ed', put);
}

function ingRule(b, put) {
  if (b.length < 5 || !b.endsWith('ing')) return;
  const s = b.slice(0, -3);
  if (s.length < 2 || !/[aeiouy]/.test(s)) return; // bring, string, thing
  if (b.endsWith('ying')) {
    const ie = b.slice(0, -4) + 'ie';
    if (b.length <= 6) { put(ie, 'ing', 92); put(s, 'ing', 90); } else { put(s, 'ing', 92); put(ie, 'ing', 86); }
    return;
  }
  if (s.endsWith('e')) { put(s, 'ing', 92); return; } // seeing, agreeing, dyeing
  stemRule(s, 'ing', put);
}

// shared by -ed and -ing: doubled consonants, -ck- (panicked), silent "e"
function stemRule(s, key, put) {
  if (s.endsWith('ck') && s.length >= 4) { put(s, key, 92); put(s.slice(0, -1), key, 87); return; }
  if (doubled(s)) {
    const und = s.slice(0, -1);
    if ('lsfz'.includes(s[s.length - 1]) || und.length <= 2) { put(s, key, 92); put(und, key, 89); } // selling, added / travelled
    else { put(und, key, 92); put(s, key, 88); } // stopped, running
    return;
  }
  if (wantsE(s)) { put(s + 'e', key, 92); put(s, key, 88); } else { put(s, key, 92); put(s + 'e', key, 88); }
}

function erRule(b, put) {
  if (b.endsWith('ier') && b.length >= 5) put(b.slice(0, -3) + 'y', 'cmp', 72);
  else if (b.endsWith('er') && b.length >= 5 && !b.endsWith('eer')) {
    const s = b.slice(0, -2);
    if (doubled(s) && !'lsfz'.includes(s[s.length - 1])) put(s.slice(0, -1), 'er', 72);
    if (wantsE(s)) { put(s + 'e', 'er', 71); put(s, 'er', 70); } else { put(s, 'er', 71); put(s + 'e', 'er', 70); }
  }
  if (b.endsWith('iest') && b.length >= 6) put(b.slice(0, -4) + 'y', 'sup', 72);
  else if (b.endsWith('est') && b.length >= 6) {
    const s = b.slice(0, -3);
    if (doubled(s) && !'lsfz'.includes(s[s.length - 1])) put(s.slice(0, -1), 'sup', 72);
    if (wantsE(s)) { put(s + 'e', 'sup', 71); put(s, 'sup', 70); } else { put(s, 'sup', 71); put(s + 'e', 'sup', 70); }
  }
}

function lyRule(b, put) {
  if (b.length < 5 || !b.endsWith('ly')) return;
  if (b.endsWith('ily')) put(b.slice(0, -3) + 'y', 'adv', 62); // heavily -> heavy
  if (b.endsWith('ically')) { put(b.slice(0, -4), 'adv', 62); put(b.slice(0, -2), 'adv', 61); } // dramatically
  else if (b.endsWith('ally')) put(b.slice(0, -2), 'adv', 62); // annually -> annual
  if (b.endsWith('uly')) put(b.slice(0, -2) + 'e', 'adv', 62); // truly -> true
  if (/[bcdfgkptz]ly$/.test(b) && !b.endsWith('lly')) put(b.slice(0, -1) + 'e', 'adv', 61); // probably, simply, gently
  if (b.endsWith('lly')) put(b.slice(0, -1), 'adv', 61); // fully -> full
  put(b.slice(0, -2), 'adv', 60); // sharply -> sharp, largely -> large
}

function spellVariants(w) {
  const out = [];
  if (SPELL_WORDS[w]) out.push(SPELL_WORDS[w]);
  let m;
  if ((m = /^(.{2,})our(s|ed|ing|able|ably|ite|ites|ful|less|er|ers)?$/.exec(w)) && !/^(?:h|f|y|p|t|s|fl|sc|det|dev|cont)$/.test(m[1])) out.push(m[1] + 'or' + (m[2] || ''));
  if ((m = /^(.{2,}[^aeiou])is(e|es|ed|ing|er|ers|ation|ations)$/.exec(w))) out.push(m[1] + 'iz' + m[2]);
  if ((m = /^(.+)ys(e|es|ed|ing|er|ers)$/.exec(w))) out.push(m[1] + 'yz' + m[2]);
  if ((m = /^(.+?)([tb])re(s)?$/.exec(w))) out.push(m[1] + m[2] + 'er' + (m[3] || ''));
  if ((m = /^(.+)ogue(s)?$/.exec(w))) out.push(m[1] + 'og' + (m[2] || ''));
  return out.filter((x) => x !== w);
}

function candidates(word) {
  return analyze(word).cands.map((c) => c.w);
}

// strong (inflection) lemmas only — no -er/-ly/spelling guesses
function lemmas(word, n = 3) {
  return analyze(word).cands.filter((c) => c.score < 99 && c.score >= 80).slice(0, n).map((c) => c.w);
}

function phraseCandidates(phrase) {
  const p = cleanWord(phrase).replace(/\s+/g, ' ');
  const out = [p, p.toLowerCase()];
  const words = p.toLowerCase().split(' ').filter(Boolean);
  if (words.length > 1 && words.length <= 6) {
    const first = words[0];
    const last = words[words.length - 1];
    const mid = words.slice(1, -1);
    const fs = [first, ...lemmas(first)];
    const ls = [last, ...lemmas(last)];
    for (const f of fs) for (const l of ls) out.push([f, ...mid, l].join(' '));
    out.push(p.toLowerCase().replace(/-/g, ' '));
  }
  return [...new Set(out.filter(Boolean))];
}

function inflections(word) {
  const w = cleanWord(word).toLowerCase();
  if (!w) return [];
  if (/\s/.test(w)) {
    const parts = w.split(/\s+/);
    const out = new Set([w]);
    for (const f of inflections(parts[0])) out.add([f, ...parts.slice(1)].join(' '));
    for (const l of inflections(parts[parts.length - 1])) out.add([...parts.slice(0, -1), l].join(' '));
    return [...out];
  }
  const out = new Set([w]);
  for (const f of FORMS.get(w) || []) out.add(f);
  for (const [form, list] of IRR) if (list.some(([b]) => b === w)) out.add(form);
  const cvc = /[^aeiou][aeiou][^aeiouwxy]$/.test(w);
  const last = w[w.length - 1];
  // -s
  if (/[^aeiou]y$/.test(w)) out.add(w.slice(0, -1) + 'ies');
  else if (/(?:s|x|z|ch|sh|o)$/.test(w)) out.add(w + 'es');
  out.add(w + 's');
  if (/fe?$/.test(w)) out.add(w.replace(/fe?$/, 'ves'));
  // -ed / -ing
  if (w.endsWith('e')) {
    out.add(w + 'd');
    if (w.endsWith('ie')) out.add(w.slice(0, -2) + 'ying');
    if (/(?:ee|ye|oe)$/.test(w)) out.add(w + 'ing'); else out.add(w.slice(0, -1) + 'ing');
  } else if (/[^aeiou]y$/.test(w)) {
    out.add(w.slice(0, -1) + 'ied');
    out.add(w + 'ing');
  } else {
    out.add(w + 'ed');
    out.add(w + 'ing');
    if (cvc) { out.add(w + last + 'ed'); out.add(w + last + 'ing'); }
    if (/[aeiou]c$/.test(w)) { out.add(w + 'ked'); out.add(w + 'king'); }
  }
  // -er / -est / -ly
  if (/[^aeiou]y$/.test(w)) { out.add(w.slice(0, -1) + 'ier'); out.add(w.slice(0, -1) + 'iest'); out.add(w.slice(0, -1) + 'ily'); }
  else if (w.endsWith('e')) { out.add(w + 'r'); out.add(w + 'st'); out.add(w + 'ly'); if (/[bcdfgkptz]le$/.test(w)) out.add(w.slice(0, -1) + 'y'); }
  else {
    out.add(w + 'er'); out.add(w + 'est'); out.add(w + 'ly');
    if (cvc && w.length <= 4) { out.add(w + last + 'er'); out.add(w + last + 'est'); }
    if (w.endsWith('ic')) out.add(w + 'ally');
    if (w.endsWith('ll')) out.add(w + 'y');
  }
  return [...out];
}

module.exports = { analyze, candidates, phraseCandidates, inflections, lemmas, cleanWord, LABEL };
