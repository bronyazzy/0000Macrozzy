'use strict';
// LZO1X decompressor (port of the reference lzo1x_decompress_safe logic).
// Used by older MDict (.mdx/.mdd) files whose blocks are LZO compressed.

function lzo1xDecompress(src, outLen) {
  let cap = outLen && outLen > 0 ? outLen : Math.max(256, src.length * 4);
  let out = new Uint8Array(cap);
  let ip = 0;
  let op = 0;
  let t = 0;
  let mPos = 0;
  const inLen = src.length;

  const ensure = (n) => {
    if (op + n <= cap) return;
    while (op + n > cap) cap *= 2;
    const bigger = new Uint8Array(cap);
    bigger.set(out.subarray(0, op));
    out = bigger;
  };
  const need = (n) => { if (ip + n > inLen) throw new Error('LZO 数据不完整'); };
  const copyLit = (n) => {
    need(n); ensure(n);
    for (let k = 0; k < n; k++) out[op++] = src[ip++];
  };
  const copyMatch = (from, n) => {
    if (from < 0) throw new Error('LZO 数据损坏（回溯越界）');
    ensure(n);
    for (let k = 0; k < n; k++) out[op++] = out[from++];
  };
  const readLen = (base) => {
    let v = 0;
    while (src[ip] === 0) { v += 255; ip++; need(1); }
    return v + base + src[ip++];
  };

  let state = 0; // 0 = loop top, 1 = first_literal_run, 2 = match (t holds opcode)
  need(1);
  if (src[ip] > 17) {
    t = src[ip++] - 17;
    if (t < 4) {
      copyLit(t);
      need(1);
      t = src[ip++];
      state = 2;
    } else {
      copyLit(t);
      state = 1;
    }
  }

  outer: for (;;) {
    if (state === 0) {
      need(1);
      t = src[ip++];
      if (t >= 16) {
        state = 2;
      } else {
        if (t === 0) t = readLen(15);
        copyLit(t + 3);
        state = 1;
      }
    }
    if (state === 1) {
      need(1);
      t = src[ip++];
      if (t < 16) {
        mPos = op - (1 + 0x0800);
        mPos -= t >> 2;
        need(1);
        mPos -= src[ip++] << 2;
        copyMatch(mPos, 3);
        t = src[ip - 2] & 3;
        if (t === 0) { state = 0; continue outer; }
        copyLit(t);
        need(1);
        t = src[ip++];
      }
      state = 2;
    }
    // state === 2
    for (;;) {
      if (t >= 64) {
        mPos = op - 1;
        mPos -= (t >> 2) & 7;
        need(1);
        mPos -= src[ip++] << 3;
        t = (t >> 5) - 1;
        copyMatch(mPos, t + 2);
      } else if (t >= 32) {
        t &= 31;
        if (t === 0) t = readLen(31);
        need(2);
        mPos = op - 1;
        mPos -= (src[ip] >> 2) + (src[ip + 1] << 6);
        ip += 2;
        copyMatch(mPos, t + 2);
      } else if (t >= 16) {
        mPos = op;
        mPos -= (t & 8) << 11;
        t &= 7;
        if (t === 0) t = readLen(7);
        need(2);
        mPos -= (src[ip] >> 2) + (src[ip + 1] << 6);
        ip += 2;
        if (mPos === op) break outer; // end of stream
        mPos -= 0x4000;
        copyMatch(mPos, t + 2);
      } else {
        mPos = op - 1;
        mPos -= t >> 2;
        need(1);
        mPos -= src[ip++] << 2;
        copyMatch(mPos, 2);
      }
      t = src[ip - 2] & 3;
      if (t === 0) { state = 0; continue outer; }
      copyLit(t);
      need(1);
      t = src[ip++];
    }
  }
  return op === out.length ? out : out.slice(0, op);
}

module.exports = { lzo1xDecompress };
