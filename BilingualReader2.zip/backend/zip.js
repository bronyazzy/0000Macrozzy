'use strict';
// Minimal, dependency-free ZIP reader (enough for EPUB): central directory,
// ZIP64, stored/deflate entries, UTF-8 or GBK file names.
const fs = require('fs');
const zlib = require('zlib');

function makeDecoder(enc) {
  try { return new TextDecoder(enc); } catch { return null; }
}
const GBK = makeDecoder('gb18030');

class ZipReader {
  constructor(filePath) {
    this.path = filePath;
    this.fd = fs.openSync(filePath, 'r');
    this.size = fs.fstatSync(this.fd).size;
    this.entries = new Map();
    this.lower = new Map();
    try {
      this._readCentralDirectory();
    } catch (e) {
      this.close();
      throw e;
    }
  }

  _read(pos, len) {
    const buf = Buffer.alloc(len);
    let off = 0;
    while (off < len) {
      const n = fs.readSync(this.fd, buf, off, len - off, pos + off);
      if (n <= 0) break;
      off += n;
    }
    return off === len ? buf : buf.subarray(0, off);
  }

  _readCentralDirectory() {
    const back = Math.min(this.size, 65557);
    if (back < 22) throw new Error('文件太小，不是有效的 EPUB/ZIP 文件');
    const tail = this._read(this.size - back, back);
    let eocd = -1;
    for (let i = tail.length - 22; i >= 0; i--) {
      if (tail.readUInt32LE(i) === 0x06054b50) { eocd = i; break; }
    }
    if (eocd < 0) throw new Error('不是有效的 EPUB/ZIP 文件（找不到目录结构）');
    let count = tail.readUInt16LE(eocd + 10);
    let cdSize = tail.readUInt32LE(eocd + 12);
    let cdOffset = tail.readUInt32LE(eocd + 16);
    if (cdOffset === 0xffffffff || count === 0xffff || cdSize === 0xffffffff) {
      const loc = eocd - 20;
      if (loc >= 0 && tail.readUInt32LE(loc) === 0x07064b50) {
        const z64 = this._read(Number(tail.readBigUInt64LE(loc + 8)), 56);
        if (z64.length >= 56 && z64.readUInt32LE(0) === 0x06064b50) {
          count = Number(z64.readBigUInt64LE(32));
          cdSize = Number(z64.readBigUInt64LE(40));
          cdOffset = Number(z64.readBigUInt64LE(48));
        }
      }
    }
    const cd = this._read(cdOffset, cdSize);
    let p = 0;
    for (let i = 0; i < count && p + 46 <= cd.length; i++) {
      if (cd.readUInt32LE(p) !== 0x02014b50) break;
      const flags = cd.readUInt16LE(p + 8);
      const method = cd.readUInt16LE(p + 10);
      let compSize = cd.readUInt32LE(p + 20);
      let size = cd.readUInt32LE(p + 24);
      const nameLen = cd.readUInt16LE(p + 28);
      const extraLen = cd.readUInt16LE(p + 30);
      const commentLen = cd.readUInt16LE(p + 32);
      let localOffset = cd.readUInt32LE(p + 42);
      const nameBuf = cd.subarray(p + 46, p + 46 + nameLen);
      let name = nameBuf.toString('utf8');
      if (!(flags & 0x800) && name.includes('�') && GBK) name = GBK.decode(nameBuf);
      if (compSize === 0xffffffff || size === 0xffffffff || localOffset === 0xffffffff) {
        let e = p + 46 + nameLen;
        const end = e + extraLen;
        while (e + 4 <= end) {
          const id = cd.readUInt16LE(e);
          const len = cd.readUInt16LE(e + 2);
          if (id === 0x0001) {
            let q = e + 4;
            if (size === 0xffffffff) { size = Number(cd.readBigUInt64LE(q)); q += 8; }
            if (compSize === 0xffffffff) { compSize = Number(cd.readBigUInt64LE(q)); q += 8; }
            if (localOffset === 0xffffffff) { localOffset = Number(cd.readBigUInt64LE(q)); q += 8; }
          }
          e += 4 + len;
        }
      }
      p += 46 + nameLen + extraLen + commentLen;
      name = name.replace(/\\/g, '/');
      if (name.endsWith('/')) continue;
      const entry = { name, method, compSize, size, localOffset, flags };
      this.entries.set(name, entry);
      if (!this.lower.has(name.toLowerCase())) this.lower.set(name.toLowerCase(), entry);
    }
    if (!this.entries.size) throw new Error('压缩包为空或已损坏');
  }

  find(name) {
    if (!name) return null;
    name = String(name).replace(/\\/g, '/').replace(/^\/+/, '');
    return this.entries.get(name) || this.lower.get(name.toLowerCase()) || null;
  }

  has(name) { return !!this.find(name); }

  list() { return [...this.entries.keys()]; }

  read(nameOrEntry) {
    const e = typeof nameOrEntry === 'string' ? this.find(nameOrEntry) : nameOrEntry;
    if (!e) return null;
    if (e.flags & 1) throw new Error('文件已加密，无法读取: ' + e.name);
    const lh = this._read(e.localOffset, 30);
    if (lh.length < 30 || lh.readUInt32LE(0) !== 0x04034b50) throw new Error('ZIP 文件头损坏: ' + e.name);
    const start = e.localOffset + 30 + lh.readUInt16LE(26) + lh.readUInt16LE(28);
    const data = this._read(start, e.compSize);
    if (e.method === 0) return data;
    if (e.method === 8) return zlib.inflateRawSync(data);
    throw new Error('不支持的压缩方式 ' + e.method + ': ' + e.name);
  }

  readText(name) {
    const b = this.read(name);
    return b ? b.toString('utf8') : null;
  }

  close() {
    if (this.fd != null) {
      try { fs.closeSync(this.fd); } catch { /* ignore */ }
      this.fd = null;
    }
  }
}

module.exports = { ZipReader };
