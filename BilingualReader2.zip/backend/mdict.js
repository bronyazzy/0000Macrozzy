'use strict';
// MDict (.mdx / .mdd) reader. Supports engine versions 1.x and 2.x,
// zlib / LZO / uncompressed blocks, and encrypted key-block info (Encrypted="2").
// Format reference: readmdict.py (Xiaoqiang Wang), which this mirrors.
const fs = require('fs');
const zlib = require('zlib');
const { lzo1xDecompress } = require('./lzo');
const { ripemd128 } = require('./ripemd128');

function readNum(buf, pos, width) {
  return width === 8 ? Number(buf.readBigUInt64BE(pos)) : buf.readUInt32BE(pos);
}

function unescapeXml(s) {
  return s.replace(/&lt;/g, '<').replace(/&gt;/g, '>').replace(/&quot;/g, '"')
    .replace(/&apos;/g, "'").replace(/&#(\d+);/g, (_, n) => String.fromCharCode(+n)).replace(/&amp;/g, '&');
}

function mdxDecrypt(block) {
  const keySrc = Buffer.alloc(8);
  block.copy(keySrc, 0, 4, 8);
  keySrc.writeUInt32LE(0x3695, 4);
  const key = ripemd128(keySrc);
  const out = Buffer.from(block);
  let previous = 0x36;
  for (let i = 8; i < out.length; i++) {
    const b = block[i];
    let t = ((b >> 4) | (b << 4)) & 0xff;
    t = t ^ previous ^ ((i - 8) & 0xff) ^ key[(i - 8) % key.length];
    previous = b;
    out[i] = t;
  }
  return out;
}

function decoderFor(encoding) {
  const map = { 'UTF-8': 'utf-8', 'UTF-16LE': 'utf-16le', GB18030: 'gb18030', BIG5: 'big5', 'BIG-5': 'big5' };
  const label = map[encoding] || encoding.toLowerCase();
  try { return new TextDecoder(label); } catch { return new TextDecoder('utf-8'); }
}

class MDict {
  constructor(file, opts = {}) {
    this.file = file;
    this.isMdd = !!opts.isMdd;
    this.fd = fs.openSync(file, 'r');
    this.fileSize = fs.fstatSync(this.fd).size;
    this._blockCache = new Map();
    this._keysLoaded = false;
    try {
      this._readHeader();
    } catch (e) {
      this.close();
      throw e;
    }
  }

  _read(pos, len) {
    const buf = Buffer.alloc(len);
    let off = 0;
    while (off < len) {
      const n = fs.readSync(this.fd, buf, off, len - off, pos + off);
      if (n <= 0) break;
      off += n;
    }
    if (off !== len) throw new Error('词典文件不完整或已损坏');
    return buf;
  }

  _readHeader() {
    if (this.fileSize < 16) throw new Error('不是有效的 MDict 词典文件');
    const headerLen = this._read(0, 4).readUInt32BE(0);
    if (headerLen <= 0 || headerLen > Math.min(this.fileSize, 16 * 1024 * 1024)) throw new Error('不是有效的 MDict 词典文件');
    const hb = this._read(4, headerLen);
    let text = hb.toString('utf16le').replace(/\0+$/, '');
    if (!/<\w/.test(text)) text = hb.toString('utf8').replace(/\0+$/, '');
    const attrs = {};
    const re = /([\w.:-]+)\s*=\s*"([^"]*)"/g;
    let m;
    while ((m = re.exec(text))) attrs[m[1]] = unescapeXml(m[2]);
    this.header = attrs;
    this.version = parseFloat(attrs.GeneratedByEngineVersion || attrs.RequiredEngineVersion || '2.0') || 2.0;
    if (this.version >= 3) throw new Error('暂不支持 MDict 3.0 格式的词典');
    this.numberWidth = this.version >= 2 ? 8 : 4;
    const enc = String(attrs.Encrypted || '0').trim();
    this.encrypt = /^yes$/i.test(enc) ? 1 : /^no$/i.test(enc) ? 0 : (parseInt(enc, 10) || 0);
    let encoding = String(attrs.Encoding || '').trim().toUpperCase();
    if (this.isMdd) encoding = 'UTF-16LE';
    else if (!encoding) encoding = 'UTF-8';
    else if (encoding === 'GBK' || encoding === 'GB2312') encoding = 'GB18030';
    else if (encoding === 'UTF-16' || encoding === 'UNICODE') encoding = 'UTF-16LE';
    this.encoding = encoding;
    this.unitWidth = encoding === 'UTF-16LE' ? 2 : 1;
    this.decoder = decoderFor(encoding);
    let title = String(attrs.Title || '').trim();
    if (/no html code allowed/i.test(title)) title = '';
    this.title = title;
    this.description = attrs.Description || '';
    this.stylesheet = {};
    const ss = attrs.StyleSheet || attrs.Stylesheet || '';
    if (ss.trim()) {
      const lines = ss.split(/\r?\n/);
      for (let i = 0; i + 2 < lines.length + 2; i += 3) {
        const id = (lines[i] || '').trim();
        if (id) this.stylesheet[id] = [lines[i + 1] || '', lines[i + 2] || ''];
      }
    }
    this.keyBlockOffset = 4 + headerLen + 4;
  }

  _decompress(buf, decompSize) {
    const type = buf.readUInt32LE(0);
    const data = buf.subarray(8);
    if (type === 0) return data;
    if (type === 2) return zlib.inflateSync(data);
    if (type === 1) return Buffer.from(lzo1xDecompress(data, decompSize));
    throw new Error('未知的词典压缩类型 ' + type);
  }

  _loadKeys() {
    if (this._keysLoaded) return;
    if (this.encrypt & 1) throw new Error('该词典已加密（需要注册码），暂不支持');
    const nw = this.numberWidth;
    let pos = this.keyBlockOffset;
    const v2 = this.version >= 2;
    const hdr = this._read(pos, v2 ? 40 : 16);
    pos += v2 ? 44 : 16; // v2 has a 4-byte adler32 after the 5 numbers
    let p = 0;
    /* numKeyBlocks */ p += nw;
    const numEntries = readNum(hdr, p, nw); p += nw;
    if (v2) p += nw; // key block info decompressed size
    const infoSize = readNum(hdr, p, nw); p += nw;
    const keyBlockSize = readNum(hdr, p, nw); p += nw;
    const infoBuf = this._read(pos, infoSize);
    pos += infoSize;
    const blocks = this._decodeKeyBlockInfo(infoBuf);
    const kb = this._read(pos, keyBlockSize);
    pos += keyBlockSize;
    this.recordSectionOffset = pos;

    const keys = [];
    const offsets = [];
    let bp = 0;
    const uw = this.unitWidth;
    for (const [compSize, decompSize] of blocks) {
      const block = this._decompress(kb.subarray(bp, bp + compSize), decompSize);
      bp += compSize;
      let i = 0;
      while (i + nw <= block.length) {
        const off = readNum(block, i, nw);
        i += nw;
        let end = i;
        if (uw === 2) {
          while (end + 1 < block.length && (block[end] | block[end + 1]) !== 0) end += 2;
        } else {
          while (end < block.length && block[end] !== 0) end++;
        }
        keys.push(this.decoder.decode(block.subarray(i, end)).trim());
        offsets.push(off);
        i = end + uw;
      }
    }
    this.keys = keys;
    this.offsets = Float64Array.from(offsets);
    this.numEntries = numEntries;
    this._readRecordInfo();
    this.index = new Map();
    for (let i = 0; i < keys.length; i++) {
      const lk = keys[i].toLowerCase();
      const arr = this.index.get(lk);
      if (arr) arr.push(i); else this.index.set(lk, [i]);
    }
    const uniq = Float64Array.from(new Set(offsets));
    uniq.sort();
    this.sortedOffsets = uniq;
    this._keysLoaded = true;
  }

  _decodeKeyBlockInfo(buf) {
    let info = buf;
    const v2 = this.version >= 2;
    if (v2) {
      let data = buf;
      if (this.encrypt & 2) data = mdxDecrypt(buf);
      info = zlib.inflateSync(data.subarray(8));
    }
    const list = [];
    const nw = this.numberWidth;
    const uw = this.unitWidth;
    const term = v2 ? 1 : 0;
    let i = 0;
    while (i < info.length) {
      i += nw; // number of entries in this block
      const headSize = v2 ? info.readUInt16BE(i) : info[i];
      i += v2 ? 2 : 1;
      i += (headSize + term) * uw;
      const tailSize = v2 ? info.readUInt16BE(i) : info[i];
      i += v2 ? 2 : 1;
      i += (tailSize + term) * uw;
      const comp = readNum(info, i, nw); i += nw;
      const decomp = readNum(info, i, nw); i += nw;
      list.push([comp, decomp]);
    }
    return list;
  }

  _readRecordInfo() {
    const nw = this.numberWidth;
    let pos = this.recordSectionOffset;
    const hdr = this._read(pos, nw * 4);
    pos += nw * 4;
    const numBlocks = readNum(hdr, 0, nw);
    const infoSize = readNum(hdr, nw * 2, nw);
    const info = this._read(pos, infoSize);
    pos += infoSize;
    const blocks = [];
    let comp = pos;
    let decomp = 0;
    for (let b = 0, i = 0; b < numBlocks; b++) {
      const c = readNum(info, i, nw); i += nw;
      const d = readNum(info, i, nw); i += nw;
      blocks.push({ compPos: comp, compSize: c, decompPos: decomp, decompSize: d });
      comp += c;
      decomp += d;
    }
    this.recordBlocks = blocks;
    this.totalDecomp = decomp;
  }

  _block(bi) {
    let data = this._blockCache.get(bi);
    if (data) {
      this._blockCache.delete(bi);
      this._blockCache.set(bi, data);
      return data;
    }
    const b = this.recordBlocks[bi];
    data = this._decompress(this._read(b.compPos, b.compSize), b.decompSize);
    this._blockCache.set(bi, data);
    if (this._blockCache.size > 12) this._blockCache.delete(this._blockCache.keys().next().value);
    return data;
  }

  load() { this._loadKeys(); return this; }

  get count() { this._loadKeys(); return this.keys.length; }

  // Indices of entries whose key equals `word` (case-insensitive).
  find(word) {
    this._loadKeys();
    return this.index.get(String(word).toLowerCase().trim()) || [];
  }

  has(word) { return this.find(word).length > 0; }

  findStripped(word) {
    this._loadKeys();
    if (!this._stripIndex) {
      this._stripIndex = new Map();
      for (let i = 0; i < this.keys.length; i++) {
        const sk = strip(this.keys[i]);
        if (!sk) continue;
        const arr = this._stripIndex.get(sk);
        if (arr) arr.push(i); else this._stripIndex.set(sk, [i]);
      }
    }
    return this._stripIndex.get(strip(word)) || [];
  }

  recordBytes(i) {
    this._loadKeys();
    const start = this.offsets[i];
    const so = this.sortedOffsets;
    let lo = 0, hi = so.length;
    while (lo < hi) { const mid = (lo + hi) >> 1; if (so[mid] <= start) lo = mid + 1; else hi = mid; }
    const end = lo < so.length ? so[lo] : this.totalDecomp;
    const rb = this.recordBlocks;
    let a = 0, b = rb.length - 1, bi = -1;
    while (a <= b) {
      const mid = (a + b) >> 1;
      if (rb[mid].decompPos <= start) { bi = mid; a = mid + 1; } else b = mid - 1;
    }
    if (bi < 0) return Buffer.alloc(0);
    const block = this._block(bi);
    const s = start - rb[bi].decompPos;
    const e = Math.min(end - rb[bi].decompPos, block.length);
    return block.subarray(s, Math.max(s, e));
  }

  recordText(i) {
    let txt = this.decoder.decode(this.recordBytes(i));
    txt = txt.replace(/[\0\s]+$/, '');
    if (Object.keys(this.stylesheet).length && /`\d+`/.test(txt)) txt = this._applyStylesheet(txt);
    return txt;
  }

  _applyStylesheet(txt) {
    const parts = txt.split(/`\d+`/);
    const tags = txt.match(/`\d+`/g) || [];
    let out = parts[0];
    for (let j = 1; j < parts.length; j++) {
      const st = this.stylesheet[tags[j - 1].slice(1, -1)] || ['', ''];
      const p = parts[j];
      if (p && p.endsWith('\n')) out += st[0] + p.trimEnd() + st[1] + '\r\n';
      else out += st[0] + p + st[1];
    }
    return out;
  }

  // Look up a word, following @@@LINK= redirects. Returns [{key, text}].
  lookup(word, depth = 0) {
    let idx = this.find(word);
    if (!idx.length) idx = this.findStripped(word);
    const out = [];
    for (const i of idx.slice(0, 6)) {
      const text = this.recordText(i);
      const link = /^@@@LINK=(.+)$/m.exec(text.trim());
      if (link && depth < 5) {
        const target = link[1].trim();
        for (const r of this.lookup(target, depth + 1)) out.push(r);
      } else {
        out.push({ key: this.keys[i], text });
      }
    }
    const seen = new Set();
    return out.filter((r) => { const k = r.text; if (seen.has(k)) return false; seen.add(k); return true; });
  }

  // MDD resource lookup: path like "image/a.png" or "\image\a.png".
  resource(resPath) {
    let p = String(resPath).replace(/\//g, '\\');
    if (!p.startsWith('\\')) p = '\\' + p;
    let idx = this.find(p);
    if (!idx.length) idx = this.find(p.slice(1));
    if (!idx.length) return null;
    return this.recordBytes(idx[0]);
  }

  close() {
    if (this.fd != null) {
      try { fs.closeSync(this.fd); } catch { /* ignore */ }
      this.fd = null;
    }
    this._blockCache.clear();
  }
}

function strip(s) {
  return String(s).toLowerCase().replace(/[\s\-_'’.·,;:!?()[\]{}"“”/\\]+/g, '');
}

module.exports = { MDict, mdxDecrypt };
