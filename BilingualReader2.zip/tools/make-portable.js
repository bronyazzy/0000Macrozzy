'use strict';
// 生成便携版 dist/BilingualReader/BilingualReader.exe（不需要联网）。
// 一般由「3-生成独立程序.bat」运行：它用 runtime\electron.exe 以 Node 模式（ELECTRON_RUN_AS_NODE=1）
// 执行本脚本，所以电脑上不需要安装 Node.js。开发者也可以直接运行 `node tools/make-portable.js`。
const fs = require('fs');
const path = require('path');
const { execFileSync } = require('child_process');

// Under Electron's Node mode fs treats *.asar files as folders, which breaks copying / deleting
// resources\default_app.asar. Turn that off: here they are ordinary files.
process.noAsar = true;

const root = path.resolve(__dirname, '..');
const isWin = process.platform === 'win32';
const exeName = isWin ? 'electron.exe' : 'electron';
const APP_FILES = ['main.js', 'preload.js', 'backend', 'renderer', 'data', 'assets', 'README.md'];

function findRuntime() {
  const cands = [];
  // 以 Node 模式运行时，process.execPath 就是 runtime\electron.exe
  if (process.versions.electron) cands.push(path.dirname(process.execPath));
  cands.push(path.join(root, 'runtime'), path.join(root, 'node_modules', 'electron', 'dist'));
  return cands.find((d) => fs.existsSync(path.join(d, exeName)));
}

function findRcedit() {
  return [
    path.join(__dirname, 'rcedit-x64.exe'),
    path.join(root, 'node_modules', 'rcedit', 'bin', 'rcedit-x64.exe'),
  ].find((f) => fs.existsSync(f));
}

function setExeInfo(exe, version) {
  const rcedit = findRcedit();
  if (!rcedit) {
    console.log('（没有找到 tools\\rcedit-x64.exe，跳过设置程序图标，不影响使用）');
    return;
  }
  const v = String(version || '1.0.0');
  const args = [
    exe,
    '--set-icon', path.join(root, 'assets', 'icon.ico'),
    '--set-file-version', v,
    '--set-product-version', v,
    '--set-version-string', 'FileDescription', '双语阅读器',
    '--set-version-string', 'ProductName', '双语阅读器',
    '--set-version-string', 'CompanyName', 'BilingualReader',
    '--set-version-string', 'InternalName', 'BilingualReader',
    '--set-version-string', 'OriginalFilename', 'BilingualReader.exe',
  ];
  try {
    execFileSync(rcedit, args, { stdio: 'inherit', windowsHide: true });
    console.log('已设置程序图标和名称。');
  } catch (e) {
    console.warn('（未能设置程序图标，不影响使用）' + (e && e.message ? e.message : e));
  }
}

function main() {
  const runtime = findRuntime();
  if (!runtime) {
    console.error('找不到 Electron 运行环境，请先双击运行「1-安装依赖.bat」。');
    return 1;
  }
  const out = path.join(root, 'dist', 'BilingualReader');
  console.log('');
  console.log('复制运行环境 ……');
  try {
    fs.rmSync(out, { recursive: true, force: true, maxRetries: 3, retryDelay: 300 });
  } catch (e) {
    console.error('无法覆盖旧的 dist\\BilingualReader，请先关闭正在运行的 BilingualReader.exe 再试。');
    console.error(e.message);
    return 1;
  }
  fs.mkdirSync(path.dirname(out), { recursive: true });
  fs.cpSync(runtime, out, { recursive: true });
  const exe = path.join(out, isWin ? 'BilingualReader.exe' : 'BilingualReader');
  fs.renameSync(path.join(out, exeName), exe);
  for (const junk of [path.join(out, 'resources', 'default_app.asar'), path.join(out, 'install-ok.txt')]) {
    try { fs.rmSync(junk, { force: true, recursive: true }); } catch (e) { console.warn('（未能删除 ' + path.basename(junk) + '，不影响使用）' + e.message); }
  }

  console.log('复制程序文件 ……');
  const appDir = path.join(out, 'resources', 'app');
  for (const f of APP_FILES) {
    const src = path.join(root, f);
    if (fs.existsSync(src)) fs.cpSync(src, path.join(appDir, f), { recursive: true });
  }
  const pkg = JSON.parse(fs.readFileSync(path.join(root, 'package.json'), 'utf8'));
  delete pkg.devDependencies;
  delete pkg.scripts;
  fs.writeFileSync(path.join(appDir, 'package.json'), JSON.stringify(pkg, null, 2));

  if (isWin) setExeInfo(exe, pkg.version);

  console.log('');
  console.log('完成：' + exe);
  console.log('整个 BilingualReader 文件夹可以复制到任何位置使用，不需要 runtime 文件夹；');
  console.log('可以右键 BilingualReader.exe →「发送到」→「桌面快捷方式」，');
  console.log('或在 EPUB / PDF 文件上右键「打开方式」选择它。');
  return 0;
}

try {
  process.exitCode = main();
} catch (e) {
  console.error('生成失败：' + (e && e.stack ? e.stack : e));
  process.exitCode = 1;
}
