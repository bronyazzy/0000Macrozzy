# -*- coding: utf-8 -*-
"""Generate sample bilingual books for testing the reader.

Creates (in the output dir):
  sample-bilingual.epub   EPUB3: interleaved EN/ZH paragraphs, figures, captions, table, MathML,
                          footnotes, figure links, thumbnail->hi-res, broken image, obfuscated font,
                          inline (immersive-translate style) pairs, one-to-many, duplicated formulas.
  sample-epub2-zhfirst.epub  EPUB2 (NCX only), Chinese-first order, <br>-separated pairs.
  sample-gbk.html (+ sample-gbk_files/)  GBK encoded local HTML page.
  sample.pdf               PDF with outline, internal link, Chinese text (CID font).
All texts are original sample sentences written for testing.
"""
import hashlib
import io
import os
import random
import sys
import zipfile

from PIL import Image, ImageDraw, ImageFont

OUT = sys.argv[1] if len(sys.argv) > 1 else 'samples'
os.makedirs(OUT, exist_ok=True)


def png(w, h, color, text, big=False):
    im = Image.new('RGB', (w, h), color)
    d = ImageDraw.Draw(im)
    for i in range(0, w, max(8, w // 20)):
        d.line([(i, h - 1), (i + w // 6, int(h * (0.3 + 0.6 * ((i * 37) % 100) / 100)))], fill=(40, 80, 160), width=2 if big else 1)
    d.rectangle([2, 2, w - 3, h - 3], outline=(60, 60, 60))
    try:
        f = ImageFont.load_default(size=max(12, h // 10))
    except TypeError:
        f = ImageFont.load_default()
    d.text((10, 10), text, fill=(20, 20, 20), font=f)
    b = io.BytesIO()
    im.save(b, 'PNG')
    return b.getvalue()


def xhtml(title, body, lang='en'):
    return f'''<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml" xmlns:epub="http://www.idpf.org/2007/ops" lang="{lang}" xml:lang="{lang}">
<head><meta charset="utf-8"/><title>{title}</title>
<link rel="stylesheet" type="text/css" href="../Styles/style.css"/></head>
<body>
{body}
</body></html>'''


CSS = '''@font-face { font-family: "SampleSans"; src: url(../Fonts/sample.ttf); }
body { font-family: Georgia, serif; margin: 0 5%; color: #111; }
h1, h2 { font-family: "SampleSans", sans-serif; color: #234; }
p { text-indent: 0; margin: 0.6em 0; }
p.zh { color: #333; }
.figure { text-align: center; margin: 1em 0; }
.caption { font-size: 0.9em; color: #555; }
table { border-collapse: collapse; margin: 1em auto; }
td, th { border: 1px solid #999; padding: 4px 8px; }
.note { font-size: 0.9em; }
blockquote { border-left: 3px solid #aac; margin-left: 1em; padding-left: 1em; color: #334; }
.sidebar { background: #f3f6fb; border: 1px solid #cdd; padding: 0.5em 1em; }
'''

ch1 = '''
<h1 id="ch1">Chapter 1 Market Structure</h1>
<h1 class="zh">第一章 市场结构</h1>
<p>Every trade has two sides: a buyer who believes prices will rise and a seller who believes they will fall or no longer wants the risk.<sup><a epub:type="noteref" href="notes.xhtml#n1" id="r1">1</a></sup></p>
<p class="zh">每一笔交易都有两方：一方是认为价格会上涨的买方，另一方是认为价格会下跌或不再想承担风险的卖方。<sup><a href="notes.xhtml#n1">1</a></sup></p>
<p>The bid-ask spread is the cost of immediacy. A trader who uses a market order pays the spread; a trader who uses a limit order may earn it but risks not being filled.</p>
<p class="zh">买卖价差是“即时成交”的成本。使用市价单的交易者支付价差；使用限价单的交易者可能赚取价差，但要承担无法成交的风险。</p>
<h2 id="s1-1">1.1 Price, Volume and Open Interest</h2>
<h2 class="zh">1.1 价格、成交量与持仓量</h2>
<p>As shown in <a href="#fig1-1">Figure 1.1</a>, volume often expands when price breaks out of a trading range. Duration and convexity matter more for bonds than for stocks.</p>
<p class="zh">如<a href="#fig1-1">图 1.1</a>所示，当价格突破交易区间时，成交量往往会放大。对债券而言，久期和凸性比对股票更重要。</p>
<div class="figure" id="fig1-1">
<a href="../Images/fig1_large.png"><img src="../Images/fig1_thumb.png" alt="Figure 1.1"/></a>
<p class="caption">Figure 1.1 A breakout from a trading range on rising volume (click for the high-resolution image).</p>
<p class="caption zh">图 1.1 放量突破交易区间（点击查看高清原图）。</p>
</div>
<p>The expected return of a position is <math xmlns="http://www.w3.org/1998/Math/MathML"><mi>E</mi><mo>[</mo><mi>R</mi><mo>]</mo><mo>=</mo><mi>p</mi><mo>&#x22C5;</mo><mi>W</mi><mo>&#x2212;</mo><mo>(</mo><mn>1</mn><mo>&#x2212;</mo><mi>p</mi><mo>)</mo><mo>&#x22C5;</mo><mi>L</mi></math>, where W is the average win and L the average loss. Water is H<sub>2</sub>O and the area is 10<sup>3</sup> m<sup>2</sup>.</p>
<p class="zh">一个头寸的期望收益为 <math xmlns="http://www.w3.org/1998/Math/MathML"><mi>E</mi><mo>[</mo><mi>R</mi><mo>]</mo><mo>=</mo><mi>p</mi><mo>&#x22C5;</mo><mi>W</mi><mo>&#x2212;</mo><mo>(</mo><mn>1</mn><mo>&#x2212;</mo><mi>p</mi><mo>)</mo><mo>&#x22C5;</mo><mi>L</mi></math>，其中 W 为平均盈利，L 为平均亏损。水是 H<sub>2</sub>O，面积为 10<sup>3</sup> 平方米。</p>
<math xmlns="http://www.w3.org/1998/Math/MathML" display="block"><mi>&#x3C3;</mi><mo>=</mo><msqrt><mfrac><mn>1</mn><mi>N</mi></mfrac><munderover><mo>&#x2211;</mo><mrow><mi>i</mi><mo>=</mo><mn>1</mn></mrow><mi>N</mi></munderover><msup><mrow><mo>(</mo><msub><mi>r</mi><mi>i</mi></msub><mo>&#x2212;</mo><mover><mi>r</mi><mo>&#xAF;</mo></mover><mo>)</mo></mrow><mn>2</mn></msup></msqrt></math>
<p>Table 1.1 compares three order types.</p>
<p class="zh">表 1.1 比较了三种订单类型。</p>
<table id="t1-1">
<tr><th>Order</th><th>Price</th><th>Fill</th></tr>
<tr><td>Market</td><td>Best available</td><td>Certain</td></tr>
<tr><td>Limit</td><td>Specified or better</td><td>Uncertain</td></tr>
<tr><td>Stop</td><td>Triggered at stop</td><td>Becomes market</td></tr>
</table>
<p>A damaged chart is shown below; the text must remain readable.</p>
<p class="zh">下面是一张损坏的图表；正文必须仍然可以阅读。</p>
<p class="figure"><img src="../Images/broken.png" alt="Broken chart"/></p>
<p class="caption">Figure 1.2 Volume profile (the image file is damaged on purpose).</p>
<p class="caption zh">图 1.2 成交量分布（图片文件被故意损坏）。</p>
<p class="figure"><img src="../Images/chart2.png" alt="Figure 1.3"/></p>
<p class="caption">Figure 1.3 A plain figure without a link. See also <a href="ch03.xhtml#sec3-2">Section 3.2</a>.</p>
<p class="caption zh">图 1.3 普通插图（无链接）。另见<a href="ch03.xhtml#sec3-2">第 3.2 节</a>。</p>
<blockquote><p>“The goal of a successful trader is to make the best trades. Money is secondary.”</p><p class="zh">“成功交易者的目标是做出最好的交易，金钱是次要的。”</p></blockquote>
<p>Figure links can also be images: click <a href="#t1-1"><img src="../Images/icon_table.png" alt="go to table"/></a> to jump back to Table 1.1.</p>
<p class="zh">图号链接也可以是图片：点击<a href="#t1-1"><img src="../Images/icon_table.png" alt="跳到表格"/></a>回到表 1.1。</p>
'''

# immersive-translate style: translation inline inside the same paragraph
def imm(en, zh, tag='p'):
    return (f'<{tag}>{en}<font class="notranslate immersive-translate-target-wrapper" lang="zh-CN">'
            f'<br/><font class="notranslate immersive-translate-target-translation-theme-none immersive-translate-target-translation-block-wrapper-theme-none immersive-translate-target-translation-block-wrapper">'
            f'<font class="notranslate immersive-translate-target-inner immersive-translate-target-translation-theme-none-inner">{zh}</font></font></font></{tag}>')

ch2 = '\n'.join([
    imm('Chapter 2 Risk and Position Sizing', '第二章 风险与头寸规模', 'h1'),
    imm('Risk per trade should be a small, fixed fraction of equity, typically between 0.5% and 2%.', '每笔交易的风险应当是账户权益中一个较小且固定的比例，通常在 0.5% 到 2% 之间。'),
    imm('A stop-loss order defines the maximum loss before the trade is entered, so the position size can be calculated in advance.', '止损单在入场前就确定了最大亏损，因此可以提前计算头寸规模。'),
    imm('For example, with $100,000 of equity, 1% risk and a stop 2.50 points away, the position is 400 shares.', '例如，账户权益为 100,000 美元、风险比例 1%、止损距离 2.50 点时，头寸为 400 股。'),
    '<div class="sidebar">' + imm('Key idea: drawdowns grow nonlinearly. A 50% loss requires a 100% gain to recover.', '要点：回撤的增长是非线性的。亏损 50% 需要盈利 100% 才能回本。') + '</div>',
    imm('The Kelly criterion maximizes long-run growth, but most traders use a fraction of it because estimates of edge are noisy.', '凯利公式能最大化长期增长率，但由于对优势的估计存在噪声，大多数交易者只使用其中的一部分。'),
])
ch2 = '<h1 id="ch2" style="display:none">x</h1>' + ch2 if False else ch2

ch3 = '''
<h1 id="ch3">Chapter 3 Trend Following</h1>
<h1>第三章 趋势跟踪</h1>
<p>Trend following does not try to predict tops or bottoms. It buys strength, sells weakness and lets profits run while cutting losses short.</p>
<p>趋势跟踪并不试图预测顶部或底部。</p>
<p>它买入强势、卖出弱势，让利润奔跑，同时截断亏损。</p>
<p>A moving average smooths price. The crossover of a fast and a slow moving average is one of the oldest trend signals.</p>
<p>The simple moving average is defined as follows:</p>
<p>移动平均线可以平滑价格。快慢两条移动平均线的交叉是最古老的趋势信号之一。简单移动平均线的定义如下：</p>
<p class="formula"><img src="../Images/formula_sma.png" alt="SMA formula"/></p>
<p class="formula"><img src="../Images/formula_sma.png" alt="SMA formula"/></p>
<h2 id="sec3-2">3.2 Breakouts</h2>
<h2>3.2 突破</h2>
<p>A breakout occurs when price closes beyond the highest high of the last N days.</p>
<p class="formula"><img src="../Images/formula_break.png" alt="breakout formula"/></p>
<p>当价格收盘高于过去 N 天的最高价时，就发生了突破。</p>
<p class="formula"><img src="../Images/formula_break.png" alt="breakout formula"/></p>
<ul>
<li>Enter on a 20-day breakout.</li>
<li>在 20 日突破时入场。</li>
<li>Exit on a 10-day breakout in the opposite direction.</li>
<li>在反方向 10 日突破时离场。</li>
</ul>
<ol>
<li>Define the universe of markets.</li>
<li>确定交易的市场范围。</li>
<li>Size every position by volatility.</li>
<li>按波动率确定每个头寸的规模。</li>
</ol>
<p>Whipsaws are the price of admission: most breakouts fail, but the few that succeed pay for all the small losses.</p>
<p>来回震荡（双边打脸）是入场的代价：大多数突破都会失败，但少数成功的突破足以弥补所有小额亏损。</p>
''' + ''.join(f'<p>Paragraph {i} of the long section keeps the reader busy with trend statistics, volatility estimates and portfolio heat calculations.</p>\n<p>长段落第 {i} 段讨论趋势统计、波动率估计以及组合风险热度的计算。</p>\n' for i in range(1, 25))

notes = '''
<h1>Notes</h1>
<h1>注释</h1>
<aside epub:type="footnote" id="n1"><p class="note"><a href="ch01.xhtml#r1">1</a> In futures markets the number of long contracts always equals the number of short contracts.</p>
<p class="note zh">在期货市场中，多头合约的数量总是等于空头合约的数量。</p></aside>
'''

nav = '''<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml" xmlns:epub="http://www.idpf.org/2007/ops"><head><title>目录</title></head><body>
<nav epub:type="toc" id="toc"><h1>目录 Contents</h1><ol>
<li><a href="Text/ch01.xhtml">Chapter 1 Market Structure 第一章 市场结构</a><ol>
  <li><a href="Text/ch01.xhtml#s1-1">1.1 Price, Volume and Open Interest 价格、成交量与持仓量</a></li></ol></li>
<li><a href="Text/ch02.xhtml">Chapter 2 Risk and Position Sizing 第二章 风险与头寸规模</a></li>
<li><a href="Text/ch03.xhtml">Chapter 3 Trend Following 第三章 趋势跟踪</a><ol>
  <li><a href="Text/ch03.xhtml#sec3-2">3.2 Breakouts 突破</a></li></ol></li>
<li><a href="Text/notes.xhtml">Notes 注释</a></li>
</ol></nav></body></html>'''

uid = 'urn:uuid:12345678-1234-5678-1234-567812345678'
opf = f'''<?xml version="1.0" encoding="utf-8"?>
<package xmlns="http://www.idpf.org/2007/opf" version="3.0" unique-identifier="bookid">
<metadata xmlns:dc="http://purl.org/dc/elements/1.1/">
<dc:identifier id="bookid">{uid}</dc:identifier>
<dc:title>交易的结构（中英对照示例）</dc:title>
<dc:creator>Sample Author</dc:creator>
<dc:language>en</dc:language>
<meta property="dcterms:modified">2026-01-01T00:00:00Z</meta>
<meta name="cover" content="cover-img"/>
</metadata>
<manifest>
<item id="nav" href="nav.xhtml" media-type="application/xhtml+xml" properties="nav"/>
<item id="ncx" href="toc.ncx" media-type="application/x-dtbncx+xml"/>
<item id="css" href="Styles/style.css" media-type="text/css"/>
<item id="font" href="Fonts/sample.ttf" media-type="font/ttf"/>
<item id="cover-img" href="Images/cover.png" media-type="image/png" properties="cover-image"/>
<item id="ch01" href="Text/ch01.xhtml" media-type="application/xhtml+xml" properties="mathml"/>
<item id="ch02" href="Text/ch02.xhtml" media-type="application/xhtml+xml"/>
<item id="ch03" href="Text/ch03.xhtml" media-type="application/xhtml+xml"/>
<item id="notes" href="Text/notes.xhtml" media-type="application/xhtml+xml"/>
<item id="i1" href="Images/fig1_thumb.png" media-type="image/png"/>
<item id="i2" href="Images/fig1_large.png" media-type="image/png"/>
<item id="i3" href="Images/broken.png" media-type="image/png"/>
<item id="i4" href="Images/chart2.png" media-type="image/png"/>
<item id="i5" href="Images/formula_sma.png" media-type="image/png"/>
<item id="i6" href="Images/formula_break.png" media-type="image/png"/>
<item id="i7" href="Images/icon_table.png" media-type="image/png"/>
</manifest>
<spine toc="ncx">
<itemref idref="ch01"/><itemref idref="ch02"/><itemref idref="ch03"/><itemref idref="notes"/>
</spine>
</package>'''

ncx = '''<?xml version="1.0" encoding="utf-8"?>
<ncx xmlns="http://www.daisy.org/z3986/2005/ncx/" version="2005-1"><head></head><docTitle><text>Sample</text></docTitle>
<navMap>
<navPoint id="p1" playOrder="1"><navLabel><text>Chapter 1</text></navLabel><content src="Text/ch01.xhtml"/></navPoint>
<navPoint id="p2" playOrder="2"><navLabel><text>Chapter 2</text></navLabel><content src="Text/ch02.xhtml"/></navPoint>
</navMap></ncx>'''


def obfuscate_idpf(data, identifier):
    key = hashlib.sha1(''.join(identifier.split()).encode('utf-8')).digest()
    out = bytearray(data)
    for i in range(min(1040, len(out))):
        out[i] ^= key[i % 20]
    return bytes(out)


font_src = '/opt/npm-tools/node_modules/pdfjs-dist/standard_fonts/LiberationSans-Bold.ttf'
font_data = open(font_src, 'rb').read() if os.path.exists(font_src) else b''

enc_xml = '''<?xml version="1.0" encoding="UTF-8"?>
<encryption xmlns="urn:oasis:names:tc:opendocument:xmlns:container" xmlns:enc="http://www.w3.org/2001/04/xmlenc#">
<enc:EncryptedData><enc:EncryptionMethod Algorithm="http://www.idpf.org/2008/embedding"/>
<enc:CipherData><enc:CipherReference URI="OEBPS/Fonts/sample.ttf"/></enc:CipherData></enc:EncryptedData>
</encryption>'''

container = '''<?xml version="1.0"?>
<container version="1.0" xmlns="urn:oasis:names:tc:opendocument:xmlns:container">
<rootfiles><rootfile full-path="OEBPS/content.opf" media-type="application/oebps-package+xml"/></rootfiles></container>'''

with zipfile.ZipFile(os.path.join(OUT, 'sample-bilingual.epub'), 'w') as z:
    z.writestr(zipfile.ZipInfo('mimetype'), 'application/epub+zip', compress_type=zipfile.ZIP_STORED)
    def w(name, data):
        z.writestr(name, data, compress_type=zipfile.ZIP_DEFLATED)
    w('META-INF/container.xml', container)
    if font_data:
        w('META-INF/encryption.xml', enc_xml)
        w('OEBPS/Fonts/sample.ttf', obfuscate_idpf(font_data, uid))
    w('OEBPS/content.opf', opf)
    w('OEBPS/nav.xhtml', nav)
    w('OEBPS/toc.ncx', ncx)
    w('OEBPS/Styles/style.css', CSS)
    w('OEBPS/Text/ch01.xhtml', xhtml('Chapter 1', ch1))
    w('OEBPS/Text/ch02.xhtml', xhtml('Chapter 2', ch2))
    w('OEBPS/Text/ch03.xhtml', xhtml('Chapter 3', ch3))
    w('OEBPS/Text/notes.xhtml', xhtml('Notes', notes))
    w('OEBPS/Images/cover.png', png(400, 560, (230, 236, 245), 'Sample Cover'))
    w('OEBPS/Images/fig1_thumb.png', png(320, 180, (245, 245, 235), 'Fig 1.1 (thumbnail)'))
    w('OEBPS/Images/fig1_large.png', png(2400, 1350, (245, 245, 235), 'Fig 1.1 HIGH-RES ORIGINAL 2400x1350', big=True))
    w('OEBPS/Images/chart2.png', png(600, 300, (235, 245, 240), 'Fig 1.3 plain figure'))
    w('OEBPS/Images/formula_sma.png', png(360, 60, (255, 255, 255), 'SMA = (P1 + ... + Pn) / n'))
    w('OEBPS/Images/formula_break.png', png(360, 60, (255, 255, 255), 'Close > max(High, N)'))
    w('OEBPS/Images/icon_table.png', png(40, 24, (200, 220, 255), 'T'))
    rnd = random.Random(7)
    w('OEBPS/Images/broken.png', b'\x89PNG\r\n\x1a\n' + bytes(rnd.getrandbits(8) for _ in range(300)))

# ---------------- EPUB2, Chinese first, <br> pairs ----------------
ch_a = '''
<h1>第一章 波动率</h1>
<h1>Chapter 1 Volatility</h1>
<p>波动率衡量价格变化的幅度，而不是方向。</p>
<p>Volatility measures the size of price changes, not their direction.</p>
<p>平均真实波幅（ATR）常用于设置止损距离。<br/>The average true range (ATR) is often used to set stop distances.</p>
<p>隐含波动率来自期权价格。<br/>Implied volatility is derived from option prices.</p>
<p>历史波动率来自过去的收益率。</p>
<p>Historical volatility is computed from past returns.</p>
'''
opf2 = '''<?xml version="1.0" encoding="utf-8"?>
<package xmlns="http://www.idpf.org/2007/opf" version="2.0" unique-identifier="id">
<metadata xmlns:dc="http://purl.org/dc/elements/1.1/" xmlns:opf="http://www.idpf.org/2007/opf">
<dc:identifier id="id">sample-2</dc:identifier><dc:title>波动率手册（中文在前）</dc:title><dc:creator>测试作者</dc:creator><dc:language>zh</dc:language>
</metadata>
<manifest><item id="ncx" href="toc.ncx" media-type="application/x-dtbncx+xml"/>
<item id="c1" href="c1.html" media-type="application/xhtml+xml"/></manifest>
<spine toc="ncx"><itemref idref="c1"/></spine></package>'''
ncx2 = '''<?xml version="1.0" encoding="utf-8"?>
<ncx xmlns="http://www.daisy.org/z3986/2005/ncx/" version="2005-1"><head/><docTitle><text>Vol</text></docTitle>
<navMap><navPoint id="a" playOrder="1"><navLabel><text>第一章 波动率 Volatility</text></navLabel><content src="c1.html"/></navPoint></navMap></ncx>'''
with zipfile.ZipFile(os.path.join(OUT, 'sample-epub2-zhfirst.epub'), 'w') as z:
    z.writestr(zipfile.ZipInfo('mimetype'), 'application/epub+zip', compress_type=zipfile.ZIP_STORED)
    z.writestr('META-INF/container.xml', container.replace('OEBPS/content.opf', 'content.opf'), compress_type=zipfile.ZIP_DEFLATED)
    z.writestr('content.opf', opf2, compress_type=zipfile.ZIP_DEFLATED)
    z.writestr('toc.ncx', ncx2, compress_type=zipfile.ZIP_DEFLATED)
    # deliberately sloppy XHTML (self-closing anchors + unclosed tag) to test the HTML fallback parser
    sloppy = '<html xmlns="http://www.w3.org/1999/xhtml"><head><title>c1</title></head><body><a id="top"/>' + ch_a + '<p>未闭合的段落 &nbsp; unclosed paragraph</body></html>'
    z.writestr('c1.html', sloppy, compress_type=zipfile.ZIP_DEFLATED)

# ---------------- GBK HTML ----------------
os.makedirs(os.path.join(OUT, 'sample-gbk_files'), exist_ok=True)
with open(os.path.join(OUT, 'sample-gbk_files', 'chart.png'), 'wb') as f:
    f.write(png(500, 220, (250, 240, 230), 'HTML page figure'))
html = '''<!DOCTYPE html>
<html><head><meta http-equiv="Content-Type" content="text/html; charset=gbk"><title>期权入门（双语网页）</title>
<style>body{font-family:serif} .en{color:#000} .cn{color:#444}</style>
<script>document.write("SCRIPT SHOULD NOT RUN")</script></head>
<body onload="alert(1)">
<h1>Options Basics</h1><h1>期权基础</h1>
<h2 id="calls">Calls and Puts</h2><h2>看涨期权与看跌期权</h2>
<p class="en">A call option gives the holder the right, but not the obligation, to buy the underlying at the strike price.</p>
<p class="cn">看涨期权赋予持有人在行权价买入标的资产的权利，而非义务。</p>
<p class="en">A put option gives the right to sell. The premium is the price paid for that right.</p>
<p class="cn">看跌期权赋予卖出的权利。期权费是为这项权利支付的价格。</p>
<p><img src="sample-gbk_files/chart.png" alt="payoff"></p>
<p class="en">Delta measures how much the option price changes when the underlying moves by one unit; gamma measures how fast delta changes.</p>
<p class="cn">Delta 衡量标的变动一个单位时期权价格的变化；gamma 衡量 delta 变化的速度。</p>
<h2 id="greeks">The Greeks</h2><h2>希腊字母</h2>
<p class="en">Theta is time decay and vega is sensitivity to implied volatility.</p>
<p class="cn">Theta 是时间衰减，vega 是对隐含波动率的敏感度。</p>
<p><a href="#calls">Back to calls</a> · <a href="https://example.com/">external link</a></p>
</body></html>'''
with open(os.path.join(OUT, 'sample-gbk.html'), 'wb') as f:
    f.write(html.encode('gbk'))

# ---------------- PDF ----------------
try:
    from reportlab.lib.pagesizes import A4
    from reportlab.pdfgen import canvas
    from reportlab.pdfbase import pdfmetrics
    from reportlab.pdfbase.cidfonts import UnicodeCIDFont
    pdfmetrics.registerFont(UnicodeCIDFont('STSong-Light'))
    c = canvas.Canvas(os.path.join(OUT, 'sample.pdf'), pagesize=A4)
    c.setTitle('Sample PDF 交易手册')
    W, H = A4
    for page in range(1, 6):
        c.bookmarkPage('p%d' % page)
        c.addOutlineEntry('Chapter %d 第%d章' % (page, page), 'p%d' % page, level=0)
        c.setFont('Helvetica-Bold', 20)
        c.drawString(72, H - 90, 'Chapter %d  Liquidity and Spreads' % page)
        c.setFont('STSong-Light', 16)
        c.drawString(72, H - 120, '第%d章 流动性与价差' % page)
        c.setFont('Helvetica', 12)
        y = H - 160
        for i in range(10):
            c.drawString(72, y, 'The bid-ask spread widens when liquidity dries up; duration risk rises with maturity. (%d)' % i)
            y -= 18
            c.setFont('STSong-Light', 12)
            c.drawString(72, y, '流动性枯竭时买卖价差会扩大；久期风险随期限增加而上升。（%d）' % i)
            c.setFont('Helvetica', 12)
            y -= 24
        if page == 1:
            c.setFillColorRGB(0.1, 0.2, 0.8)
            c.drawString(72, 80, 'Go to chapter 4 (internal link)')
            c.linkRect('', 'p4', (70, 75, 300, 95), relative=0, thickness=0)
            c.setFillColorRGB(0, 0, 0)
        c.showPage()
    c.save()
except Exception as e:  # pragma: no cover
    print('PDF generation failed:', e)

print('samples written to', OUT)
