'use strict';
// Test helper: writes MDict v2.0 .mdx/.mdd files (zlib blocks, optional Encrypted="2").
const fs = require('fs');
const zlib = require('zlib');
const { ripemd128 } = require('../backend/ripemd128');

function adler32(buf) {
  let a = 1, b = 0;
  for (let i = 0; i < buf.length; i++) { a = (a + buf[i]) % 65521; b = (b + a) % 65521; }
  return ((b << 16) | a) >>> 0;
}
function u64(n) { const b = Buffer.alloc(8); b.writeBigUInt64BE(BigInt(n)); return b; }
function u32be(n) { const b = Buffer.alloc(4); b.writeUInt32BE(n >>> 0); return b; }
function u16be(n) { const b = Buffer.alloc(2); b.writeUInt16BE(n); return b; }

function compressBlock(data) {
  return Buffer.concat([Buffer.from([2, 0, 0, 0]), u32be(adler32(data)), zlib.deflateSync(data)]);
}

function fastEncrypt(block) {
  const keySrc = Buffer.alloc(8);
  block.copy(keySrc, 0, 4, 8);
  keySrc.writeUInt32LE(0x3695, 4);
  const key = ripemd128(keySrc);
  const out = Buffer.from(block);
  let prev = 0x36;
  for (let i = 8; i < out.length; i++) {
    const p = block[i] ^ prev ^ ((i - 8) & 0xff) ^ key[(i - 8) % 16];
    const c = ((p >> 4) | (p << 4)) & 0xff;
    out[i] = c;
    prev = c;
  }
  return out;
}

function writeMdict(file, entries, { isMdd = false, title = 'Test', encrypt = 2, keysPerBlock = 3, recordBlockSize = 64, extraHeader = '', v1 = false } = {}) {
  const num = v1 ? u32be : u64;
  const ver = v1 ? '1.2' : '2.0';
  const enc = isMdd ? 'utf16le' : 'utf8';
  const unit = isMdd ? 2 : 1;
  const sorted = [...entries].sort((a, b) => a[0].toLowerCase().localeCompare(b[0].toLowerCase()));
  // records
  const recBufs = sorted.map(([, v]) => (Buffer.isBuffer(v) ? v : Buffer.from(v + (isMdd ? '' : '\r\n\0'), 'utf8')));
  const offsets = [];
  let off = 0;
  for (const r of recBufs) { offsets.push(off); off += r.length; }
  // header
  const headerXml = isMdd
    ? `<Library_Data GeneratedByEngineVersion="${ver}" RequiredEngineVersion="${ver}" Encrypted="${encrypt}" Encoding="" Format="" CreationDate="2026-1-1" KeyCaseSensitive="No" Stripkey="No" Description="" Title="${title}" ${extraHeader}/>\r\n\0`
    : `<Dictionary GeneratedByEngineVersion="${ver}" RequiredEngineVersion="${ver}" Encrypted="${encrypt}" Encoding="UTF-8" Format="Html" Stripkey="Yes" CreationDate="2026-1-1" Compact="No" Compat="No" KeyCaseSensitive="No" Description="test" Title="${title}" DataSourceFormat="106" StyleSheet="" ${extraHeader}/>\r\n\0`;
  const headerBuf = Buffer.from(headerXml, 'utf16le');
  const parts = [u32be(headerBuf.length), headerBuf, Buffer.from([0, 0, 0, 0])];
  parts[2].writeUInt32LE(adler32(headerBuf));
  // key blocks
  const keyBlocks = [];
  const infoParts = [];
  for (let i = 0; i < sorted.length; i += keysPerBlock) {
    const slice = sorted.slice(i, i + keysPerBlock);
    const raw = Buffer.concat(slice.map(([k], j) => Buffer.concat([num(offsets[i + j]), Buffer.from(k, enc), Buffer.alloc(unit)])));
    const comp = compressBlock(raw);
    keyBlocks.push(comp);
    const first = Buffer.from(slice[0][0], enc);
    const last = Buffer.from(slice[slice.length - 1][0], enc);
    if (v1) infoParts.push(u32be(slice.length), Buffer.from([first.length / unit]), first, Buffer.from([last.length / unit]), last, u32be(comp.length), u32be(raw.length));
    else infoParts.push(u64(slice.length), u16be(first.length / unit), first, Buffer.alloc(unit), u16be(last.length / unit), last, Buffer.alloc(unit), u64(comp.length), u64(raw.length));
  }
  const info = Buffer.concat(infoParts);
  const keyBlockData = Buffer.concat(keyBlocks);
  if (v1) {
    parts.push(u32be(keyBlocks.length), u32be(sorted.length), u32be(info.length), u32be(keyBlockData.length), info, keyBlockData);
  } else {
    let infoComp = compressBlock(info);
    if (encrypt & 2) infoComp = fastEncrypt(infoComp);
    const keyHdr = Buffer.concat([u64(keyBlocks.length), u64(sorted.length), u64(info.length), u64(infoComp.length), u64(keyBlockData.length)]);
    parts.push(keyHdr, u32be(adler32(keyHdr)), infoComp, keyBlockData);
  }
  // record blocks
  const allRec = Buffer.concat(recBufs);
  const recBlocks = [];
  const recInfo = [];
  let cur = [];
  let curLen = 0;
  const flush = () => {
    if (!cur.length) return;
    const raw = Buffer.concat(cur);
    const comp = compressBlock(raw);
    recBlocks.push(comp);
    recInfo.push(num(comp.length), num(raw.length));
    cur = []; curLen = 0;
  };
  for (const r of recBufs) {
    cur.push(r); curLen += r.length;
    if (curLen >= recordBlockSize) flush();
  }
  flush();
  const recData = Buffer.concat(recBlocks);
  parts.push(num(recBlocks.length), num(sorted.length), num(recBlocks.length * (v1 ? 8 : 16)), num(recData.length), Buffer.concat(recInfo), recData);
  fs.writeFileSync(file, Buffer.concat(parts));
}

module.exports = { writeMdict };
