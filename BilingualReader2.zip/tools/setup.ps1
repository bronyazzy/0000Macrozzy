﻿<#
  双语阅读器 - 运行环境安装脚本（Windows 10/11 自带的 Windows PowerShell 5.1 即可运行）

  从 Electron 官方 GitHub 发布页下载 Electron 运行时，校验 SHA-256 后解压到本程序的 runtime 文件夹。
  不需要 Node.js / npm。一般直接双击「1-安装依赖.bat」即可。

  可选参数（在本文件夹地址栏输入 cmd 回车后运行，例如：1-安装依赖.bat -Mirror）：
    -Mirror      先用备用镜像（npmmirror），再用 GitHub
    -Zip <路径>  使用已经下载好的 electron-v45.4.1-win32-x64.zip
    -Force       已安装也重新安装
    -NoPrompt    结束时不询问是否打开阅读器
#>
[CmdletBinding()]
param(
  [switch]$Mirror,
  [string]$Zip = '',
  [switch]$Force,
  [switch]$NoPrompt
)

$ErrorActionPreference = 'Stop'
$ProgressPreference = 'SilentlyContinue'

$ElectronVersion = '45.4.1'
# 官方 SHA-256：取自 electron@45.4.1 npm 包内的 checksums.json（即 GitHub 发布页的 SHASUMS256.txt）
$KnownSha256 = @{
  'x64'   = '2ba6223afa9121f42831fefe92c434334907540165294fc56697449d12e7cfe9'
  'arm64' = '5ad2f09093cba71ad7dc8ddb2ef7261978c9130aa07e492556efe802f6ca74e9'
}

$AppDir  = Split-Path -Parent $PSScriptRoot
$Runtime = Join-Path $AppDir 'runtime'
$DlDir   = Join-Path $AppDir 'runtime-download'
$Marker  = Join-Path $Runtime 'install-ok.txt'

# ---------------------------------------------------------------- 工具函数

function Say([string]$Text = '', [string]$Color = 'Gray') {
  Write-Host $Text -ForegroundColor $Color
}

function Get-ErrText($Err) {
  $e = $Err.Exception
  while ($e.InnerException) { $e = $e.InnerException }
  return $e.Message
}

function Get-HttpStatus($Err) {
  $e = $Err.Exception
  while ($e) {
    if (($e -is [System.Net.WebException]) -and $e.Response) {
      try { return [int]$e.Response.StatusCode } catch { return 0 }
    }
    $e = $e.InnerException
  }
  return 0
}

function Get-WinArch {
  try {
    $a = [string][System.Runtime.InteropServices.RuntimeInformation]::OSArchitecture
    if ($a -eq 'Arm64') { return 'arm64' }
    if ($a -eq 'X64') { return 'x64' }
  } catch { }
  $p = $env:PROCESSOR_ARCHITEW6432
  if (-not $p) { $p = $env:PROCESSOR_ARCHITECTURE }
  if ($p -eq 'ARM64') { return 'arm64' }
  return 'x64'
}

function Get-DownloadsDir {
  try {
    $p = (New-Object -ComObject Shell.Application).NameSpace('shell:Downloads').Self.Path
    if ($p -and (Test-Path -LiteralPath $p -PathType Container)) { return $p }
  } catch { }
  return (Join-Path $env:USERPROFILE 'Downloads')
}

function Get-Size([string]$Path) {
  if (Test-Path -LiteralPath $Path -PathType Leaf) { return (Get-Item -LiteralPath $Path).Length }
  return 0L
}

function Remove-File([string]$Path) {
  if (Test-Path -LiteralPath $Path -PathType Leaf) { Remove-Item -LiteralPath $Path -Force -ErrorAction SilentlyContinue }
}

function Remove-Dir([string]$Path) {
  for ($i = 1; $i -le 4; $i++) {
    if (-not (Test-Path -LiteralPath $Path)) { return }
    try { Remove-Item -LiteralPath $Path -Recurse -Force; return } catch { Start-Sleep -Milliseconds 800 }
  }
  if (Test-Path -LiteralPath $Path) { throw ('无法删除文件夹：' + $Path + '（可能正在使用，请先关闭阅读器）') }
}

function Test-GoodZip([string]$Path) {
  if (-not $Path -or -not (Test-Path -LiteralPath $Path -PathType Leaf)) { return $false }
  try {
    $h = (Get-FileHash -LiteralPath $Path -Algorithm SHA256).Hash.ToLowerInvariant()
    return ($h -eq $ExpectedSha)
  } catch { return $false }
}

function Format-MB([double]$Bytes) {
  return ('{0:N1} MB' -f ($Bytes / 1MB))
}

function Show-Progress([long]$Done, [long]$Total, [long]$ThisRun, [double]$Secs) {
  $speed = 0.0
  if ($Secs -gt 0.2) { $speed = $ThisRun / 1MB / $Secs }
  if ($Total -gt 0) {
    $pct = [math]::Floor(100.0 * $Done / $Total)
    $line = '    {0,7:N1} / {1:N1} MB  {2,3}%   {3:N1} MB/s' -f ($Done / 1MB), ($Total / 1MB), $pct, $speed
  } else {
    $line = '    {0,7:N1} MB   {1:N1} MB/s' -f ($Done / 1MB), $speed
  }
  Write-Host -NoNewline ("`r" + $line + '    ')
}

# 用 .NET 下载：自动使用 Windows 的系统代理设置，支持断点续传
function Invoke-NetDownload([string]$Url, [string]$OutFile) {
  $start = Get-Size $OutFile
  $req = [System.Net.WebRequest]::Create($Url)
  $req.UserAgent = 'BilingualReader-Setup'
  $req.AllowAutoRedirect = $true
  $req.Timeout = 30000
  $req.ReadWriteTimeout = 60000
  try {
    $proxy = [System.Net.WebRequest]::GetSystemWebProxy()
    $proxy.Credentials = [System.Net.CredentialCache]::DefaultNetworkCredentials
    $req.Proxy = $proxy
  } catch { }
  if ($start -gt 0) { $req.AddRange([long]$start) }
  $resp = $req.GetResponse()
  $netStream = $null
  $fileStream = $null
  try {
    $append = ($start -gt 0) -and ([int]$resp.StatusCode -eq 206)
    if (-not $append) { $start = 0L }
    $total = -1L
    if ($resp.ContentLength -ge 0) { $total = $start + $resp.ContentLength }
    $mode = [System.IO.FileMode]::Create
    if ($append) { $mode = [System.IO.FileMode]::Append }
    $fileStream = New-Object System.IO.FileStream -ArgumentList $OutFile, $mode, ([System.IO.FileAccess]::Write), ([System.IO.FileShare]::Read)
    $netStream = $resp.GetResponseStream()
    $buf = New-Object byte[] 262144
    $done = [long]$start
    $sw = [System.Diagnostics.Stopwatch]::StartNew()
    $nextShow = 0L
    while ($true) {
      $n = $netStream.Read($buf, 0, $buf.Length)
      if ($n -le 0) { break }
      $fileStream.Write($buf, 0, $n)
      $done += $n
      if ($sw.ElapsedMilliseconds -ge $nextShow) {
        $nextShow = $sw.ElapsedMilliseconds + 500
        Show-Progress $done $total ($done - $start) $sw.Elapsed.TotalSeconds
      }
    }
    Show-Progress $done $total ($done - $start) $sw.Elapsed.TotalSeconds
    Write-Host ''
    if (($total -gt 0) -and ($done -lt $total)) {
      throw ('连接中断（已下载 {0} / {1}）' -f (Format-MB $done), (Format-MB $total))
    }
  } finally {
    if ($fileStream) { $fileStream.Close() }
    if ($netStream) { $netStream.Close() }
    $resp.Close()
  }
}

# 备用：Windows 自带的 curl.exe（在同一个窗口里显示进度）
function Invoke-CurlDownload([string]$Url, [string]$OutFile) {
  $curl = Join-Path $env:SystemRoot 'System32\curl.exe'
  if (-not (Test-Path -LiteralPath $curl -PathType Leaf)) { throw '系统里没有 curl.exe' }
  $cargs = '-L --fail --retry 2 --retry-delay 3 --connect-timeout 20 --speed-limit 1024 --speed-time 60 -A BilingualReader-Setup'
  if ((Get-Size $OutFile) -gt 0) { $cargs += ' -C -' }
  $cargs += ' -o "' + $OutFile + '" "' + $Url + '"'
  $p = Start-Process -FilePath $curl -ArgumentList $cargs -NoNewWindow -PassThru
  $null = $p.Handle   # 先取得句柄，结束后才能可靠地读到退出码
  $p.WaitForExit()
  $code = $p.ExitCode
  if (($null -ne $code) -and ($code -ne 0)) { throw ('curl 下载失败（错误码 {0}）' -f $code) }
}

# 从一个地址下载到 $Part；成功返回 $true
function Get-FromUrl([string]$Url, [string]$Part) {
  $badUrl = $false
  for ($attempt = 1; $attempt -le 3; $attempt++) {
    $before = Get-Size $Part
    try {
      Invoke-NetDownload $Url $Part
      return $true
    } catch {
      Write-Host ''
      $status = Get-HttpStatus $_
      Say ('    下载出错：' + (Get-ErrText $_)) 'Yellow'
      if ($status -eq 416) { Remove-File $Part; continue }
      if (($status -ge 400) -and ($status -lt 500)) { $badUrl = $true; break }
      if ((Get-Size $Part) -le $before) { break }
      Say '    断点续传……'
    }
  }
  if ($badUrl) { return $false }
  try {
    Say '    改用 Windows 自带的 curl 再试一次……'
    Invoke-CurlDownload $Url $Part
    return $true
  } catch {
    Say ('    ' + (Get-ErrText $_)) 'Yellow'
  }
  return $false
}

function Expand-Runtime([string]$ZipPath) {
  Remove-Dir $Runtime
  Add-Type -AssemblyName System.IO.Compression.FileSystem
  [System.IO.Compression.ZipFile]::ExtractToDirectory($ZipPath, $Runtime)
  if (-not (Test-Path -LiteralPath (Join-Path $Runtime 'electron.exe') -PathType Leaf)) {
    throw '压缩包里没有 electron.exe，文件可能不对。'
  }
  [System.IO.File]::WriteAllText($Marker, ('Electron ' + $ElectronVersion + ' win32-' + $Arch + "`r`n"))
}

function Test-Installed {
  if (-not (Test-Path -LiteralPath (Join-Path $Runtime 'electron.exe') -PathType Leaf)) { return $false }
  if (-not (Test-Path -LiteralPath $Marker -PathType Leaf)) { return $false }
  $verFile = Join-Path $Runtime 'version'
  if (-not (Test-Path -LiteralPath $verFile -PathType Leaf)) { return $false }
  try { $v = (Get-Content -LiteralPath $verFile -Raw).Trim().TrimStart('v') } catch { return $false }
  return ($v -eq $ElectronVersion)
}

function Complete-Setup {
  if ($NoPrompt) { exit 0 }
  Say ''
  Say '  可以开始使用了：' 'Green'
  Say '    - 双击「2-启动阅读器.vbs」打开阅读器（也可以把书拖到它上面直接打开）'
  Say '    - 双击「3-生成独立程序.bat」可生成带图标的便携版 BilingualReader.exe'
  Say ''
  $ans = Read-Host '  按回车键立即打开阅读器（输入 N 再回车则退出）'
  if ($ans -notmatch '^\s*[nN]') {
    Remove-Item Env:ELECTRON_RUN_AS_NODE -ErrorAction SilentlyContinue
    # 不挂到本命令行窗口上，关掉这个窗口不会影响阅读器
    $env:ELECTRON_NO_ATTACH_CONSOLE = '1'
    Start-Process -FilePath (Join-Path $Runtime 'electron.exe') -ArgumentList ('"' + $AppDir + '"') -WorkingDirectory $AppDir
  }
  exit 0
}

function Show-ManualHelp {
  Say ''
  Say '  自动下载没有成功。可以用浏览器手动下载，再运行本脚本安装：' 'Red'
  Say '    1. 下载这个文件（约 110 MB）：'
  Say ('       ' + $GithubUrl) 'White'
  Say '    2. 下载完成后不用解压：留在「下载」文件夹里，或放进本程序文件夹；'
  Say '    3. 重新双击「1-安装依赖.bat」，会自动找到、校验并安装。'
  Say ''
  Say '  提示：使用代理 / VPN 时请打开「系统代理」后再试；' 'DarkGray'
  Say '        也可以在本文件夹地址栏输入 cmd 回车，运行  1-安装依赖.bat -Mirror  优先使用备用镜像。' 'DarkGray'
  if (-not $NoPrompt) {
    Say ''
    $ans = Read-Host '  按回车键用浏览器打开上面的下载地址（输入 N 再回车则退出）'
    if ($ans -notmatch '^\s*[nN]') {
      try { Start-Process $GithubUrl } catch { Say ('  无法打开浏览器：' + (Get-ErrText $_)) 'Yellow' }
    }
  }
}

# ---------------------------------------------------------------- 主流程

$Arch = Get-WinArch
$ExpectedSha = $KnownSha256[$Arch]
$FileName = 'electron-v' + $ElectronVersion + '-win32-' + $Arch + '.zip'
$GithubUrl = 'https://github.com/electron/electron/releases/download/v' + $ElectronVersion + '/' + $FileName
$MirrorUrls = @(
  ('https://npmmirror.com/mirrors/electron/' + $ElectronVersion + '/' + $FileName),
  ('https://npmmirror.com/mirrors/electron/v' + $ElectronVersion + '/' + $FileName)
)
if ($Mirror) { $Urls = $MirrorUrls + @($GithubUrl) } else { $Urls = @($GithubUrl) + $MirrorUrls }

try {
  try { $Host.UI.RawUI.WindowTitle = '双语阅读器 - 安装运行环境' } catch { }

  # 旧版 PowerShell 可能没有启用 TLS 1.2
  try {
    $cur = [int][System.Net.ServicePointManager]::SecurityProtocol
    $t12 = [int][System.Net.SecurityProtocolType]::Tls12
    if (($cur -ne 0) -and (($cur -band $t12) -eq 0)) {
      [System.Net.ServicePointManager]::SecurityProtocol = [System.Net.SecurityProtocolType]($cur -bor $t12)
    }
  } catch { }

  Say ''
  Say '  双语阅读器 - 安装运行环境' 'Cyan'
  Say ('  Electron ' + $ElectronVersion + '（Windows ' + $Arch + '），约 110 MB，只需安装一次，不需要 Node.js。')
  Say ''

  if ((-not $Force) -and (Test-Installed)) {
    Say '  运行环境已经安装好了，不需要重复下载。' 'Green'
    Complete-Setup
  }

  # 1) 先找已经下载好的 zip（-Zip 指定的、本文件夹、「下载」文件夹）
  $zipPath = $null
  $cands = @()
  if ($Zip) {
    if (Test-Path -LiteralPath $Zip -PathType Leaf) { $cands += (Resolve-Path -LiteralPath $Zip).ProviderPath }
    else { Say ('  找不到指定的文件：' + $Zip) 'Yellow' }
  }
  foreach ($dir in @($AppDir, $DlDir, (Get-DownloadsDir))) {
    if ($dir -and (Test-Path -LiteralPath $dir -PathType Container)) {
      $found = Get-ChildItem -LiteralPath $dir -Filter ('electron-v' + $ElectronVersion + '-win32-' + $Arch + '*.zip') -File -ErrorAction SilentlyContinue |
        Sort-Object LastWriteTime -Descending
      foreach ($f in $found) { $cands += $f.FullName }
    }
  }
  foreach ($c in ($cands | Select-Object -Unique)) {
    if (Test-GoodZip $c) { $zipPath = $c; Say ('  使用已下载的文件：' + $c) 'Green'; break }
    Say ('  跳过校验不通过的文件：' + $c) 'Yellow'
  }

  # 2) 下载：GitHub 官方地址优先，失败再用备用镜像
  $ownDownload = $false
  if (-not $zipPath) {
    [System.IO.Directory]::CreateDirectory($DlDir) | Out-Null
    $part = Join-Path $DlDir ($FileName + '.part')
    if (Test-GoodZip $part) { $zipPath = $part; $ownDownload = $true }
    foreach ($u in $Urls) {
      if ($zipPath) { break }
      Say ''
      Say ('  下载：' + $u) 'White'
      if (Get-FromUrl $u $part) {
        Say '  校验 SHA-256 ……'
        if (Test-GoodZip $part) {
          $zipPath = $part
          $ownDownload = $true
          Say '  校验通过。' 'Green'
        } else {
          Say '  校验不通过（文件不完整或内容不对），换下一个地址。' 'Yellow'
          Remove-File $part
        }
      }
    }
  }

  if (-not $zipPath) {
    Show-ManualHelp
    exit 1
  }

  # 3) 解压到 runtime\
  Say ''
  Say '  正在解压到 runtime 文件夹 ……'
  Expand-Runtime $zipPath
  if ($ownDownload) {
    try { Remove-Dir $DlDir } catch { }
  }
  if (-not (Test-Installed)) { throw '安装后检查未通过，请运行「1-安装依赖.bat -Force」重新安装。' }
  Say ('  安装完成：' + $Runtime) 'Green'
  if (-not $ownDownload) {
    Say ('  （已下载的 ' + $FileName + ' 不再需要，可以删除）') 'DarkGray'
  }
  Complete-Setup
} catch {
  Say ''
  Say ('  出错了：' + (Get-ErrText $_)) 'Red'
  exit 1
}
