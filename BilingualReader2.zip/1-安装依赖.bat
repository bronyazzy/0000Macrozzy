@echo off
rem BilingualReader setup: downloads the Electron runtime from the official GitHub release
rem (falls back to a mirror only if GitHub fails). Node.js / npm are NOT needed.
rem All messages are printed by tools\setup.ps1.
rem Options:  -Mirror   -Force   -Zip "D:\path\electron-v45.4.1-win32-x64.zip"
setlocal
cd /d "%~dp0"
title BilingualReader - Setup
set "PSEXE=%SystemRoot%\System32\WindowsPowerShell\v1.0\powershell.exe"
if not exist "%PSEXE%" set "PSEXE=powershell.exe"
"%PSEXE%" -NoProfile -ExecutionPolicy Bypass -File "%~dp0tools\setup.ps1" %*
if errorlevel 1 goto failed
exit /b 0

:failed
echo.
pause
exit /b 1
