// Bilingual engine: detects English / Chinese blocks in a chapter, pairs them into groups
// (automatically, with length-based alignment for one-to-many cases, or from saved manual
// overrides) and restructures the DOM for the two-column / stacked / single-language modes.
import { stats, addStats, langOf, looksMixed, charClass } from './textlang.js';
import { hashString } from './util.js';

const BLOCK = new Set(['address', 'article', 'aside', 'blockquote', 'center', 'dd', 'details', 'dialog', 'dir', 'div', 'dl', 'dt',
  'fieldset', 'figcaption', 'figure', 'footer', 'form', 'h1', 'h2', 'h3', 'h4', 'h5', 'h6', 'header', 'hgroup', 'hr', 'li', 'main',
  'menu', 'nav', 'ol', 'p', 'pre', 'section', 'summary', 'table', 'ul', 'caption', 'legend', 'video', 'audio', 'canvas', 'iframe',
  'object', 'embed', 'listing', 'xmp', 'plaintext', 'search', 'picture']);
const ATOMIC = new Set(['table', 'pre', 'hr', 'math', 'video', 'audio', 'canvas', 'iframe', 'object', 'embed', 'listing', 'xmp', 'plaintext', 'picture']);
const SKIP_TEXT = new Set(['math', 'code', 'kbd', 'samp', 'script', 'style', 'noscript', 'svg', 'rt', 'rp', 'template', 'textarea', 'select']);
const IGNORE = new Set(['script', 'style', 'link', 'meta', 'template', 'title', 'head', 'base']);
const MEDIA_SEL = 'img,svg,math,video,audio,iframe,object,embed,canvas,picture,image';

export function isBlockEl(n) {
  if (!n || n.nodeType !== 1) return false;
  const t = n.localName;
  if (t === 'math') return n.getAttribute('display') === 'block';
  return BLOCK.has(t) || (n.classList && n.classList.contains('br-anon'));
}

function hasBlockChild(el) {
  for (const c of el.children) if (isBlockEl(c)) return true;
  return false;
}

function isUi(n) { return n.nodeType === 1 && n.classList && n.classList.contains('br-ui'); }

// Text nodes of `root`, skipping math/code/etc. subtrees.
export function textNodes(root, includeSkipped = false) {
  const out = [];
  const walk = (n) => {
    for (let c = n.firstChild; c; c = c.nextSibling) {
      if (c.nodeType === 3) out.push(c);
      else if (c.nodeType === 1) {
        if (isUi(c)) continue;
        if (!includeSkipped && SKIP_TEXT.has(c.localName)) continue;
        if (IGNORE.has(c.localName)) continue;
        walk(c);
      }
    }
  };
  walk(root);
  return out;
}

export function elStats(el) {
  let st = { han: 0, words: 0 };
  for (const t of textNodes(el)) st = addStats(st, stats(t.data));
  return st;
}

function meaningful(n) {
  if (n.nodeType === 3) return /\S/.test(n.data);
  if (n.nodeType === 1) return !IGNORE.has(n.localName);
  return false;
}

// Wrap runs of inline content that sit next to block siblings into <div class="br-anon">.
function normalizeContainer(el) {
  const doc = el.ownerDocument;
  const kids = [...el.childNodes];
  let run = [];
  const flush = () => {
    if (run.some(meaningful) && run.some((n) => n.nodeType === 3 ? /\S/.test(n.data) : (n.nodeType === 1 && n.localName !== 'br'))) {
      const w = doc.createElement('div');
      w.className = 'br-anon';
      run[0].before(w);
      for (const n of run) w.append(n);
    }
    run = [];
  };
  for (const k of kids) {
    if (isBlockEl(k)) flush();
    else if (k.nodeType === 1 && IGNORE.has(k.localName)) flush();
    else run.push(k);
  }
  flush();
}

// ---------------------------------------------------------------------------------------------
// Mixed paragraph segmentation (e.g. immersive-translate output, or "English<br>中文").

function segmentLeaf(leaf) {
  const texts = textNodes(leaf);
  const runs = [];
  let cur = null;
  for (let ti = 0; ti < texts.length; ti++) {
    const s = texts[ti].data;
    for (let i = 0; i < s.length; i++) {
      const c = charClass(s[i]);
      if (c === 'n') continue;
      if (cur && cur.cls === c) {
        cur.eT = ti; cur.eO = i + 1; cur.n++;
      } else {
        cur = { cls: c, sT: ti, sO: i, eT: ti, eO: i + 1, n: 1 };
        runs.push(cur);
      }
    }
  }
  const weight = (r) => (r.cls === 'e' ? r.n / 4.5 : r.n);
  const small = (r) => (r.cls === 'e' ? weight(r) < 4 : r.n < 5);
  // Absorb small runs sitting between two runs of the other script ("使用 MACD 指标").
  let changed = true;
  while (changed && runs.length >= 3) {
    changed = false;
    let best = -1;
    for (let k = 1; k < runs.length - 1; k++) {
      if (small(runs[k]) && runs[k - 1].cls === runs[k + 1].cls && (best < 0 || weight(runs[k]) < weight(runs[best]))) best = k;
    }
    if (best > 0) {
      const a = runs[best - 1];
      const b = runs[best + 1];
      a.eT = b.eT; a.eO = b.eO; a.n += b.n;
      runs.splice(best, 2);
      changed = true;
    }
  }
  // merge leading / trailing small runs into their neighbour
  while (runs.length >= 2 && small(runs[0])) { runs[1].sT = runs[0].sT; runs[1].sO = runs[0].sO; runs.shift(); }
  while (runs.length >= 2 && small(runs[runs.length - 1])) { const l = runs.pop(); const p = runs[runs.length - 1]; p.eT = l.eT; p.eO = l.eO; }
  if (runs.length < 2 || runs.some(small)) return null;
  for (let k = 1; k < runs.length; k++) if (runs[k].cls === runs[k - 1].cls) return null;

  const doc = leaf.ownerDocument;
  // Boundary before run k+1, backed off over whitespace and opening quotes/brackets that belong
  // to the next run — so trailing numbers/punctuation ("… 2%.") stay with the previous language.
  const OPENERS = /[\s“‘「『（《【(["' ]/;
  const boundaries = [];
  for (let k = 0; k < runs.length - 1; k++) {
    let ti = runs[k + 1].sT;
    let off = runs[k + 1].sO;
    const minT = runs[k].eT;
    const minO = runs[k].eO;
    for (;;) {
      if (ti === minT && off <= minO) break;
      if (off === 0) {
        if (ti <= minT) break;
        ti--;
        off = texts[ti].data.length;
        continue;
      }
      if (!OPENERS.test(texts[ti].data[off - 1])) break;
      off--;
    }
    boundaries.push({ node: texts[ti], offset: off });
  }
  const frags = [];
  for (let k = 0; k < runs.length; k++) {
    const r = doc.createRange();
    if (k === 0) r.setStart(leaf, 0); else r.setStart(boundaries[k - 1].node, boundaries[k - 1].offset);
    if (k === runs.length - 1) r.setEnd(leaf, leaf.childNodes.length); else r.setEnd(boundaries[k].node, boundaries[k].offset);
    frags.push({ lang: runs[k].cls === 'e' ? 'en' : 'zh', frag: r.cloneContents() });
  }
  const seenIds = new Set();
  const spans = frags.map(({ lang, frag }, i) => {
    const sp = doc.createElement('span');
    sp.className = 'br-seg';
    sp.dataset.lang = lang;
    sp.dataset.seg = String(i);
    sp.append(frag);
    for (const e of sp.querySelectorAll('[id]')) {
      if (seenIds.has(e.id)) e.removeAttribute('id'); else seenIds.add(e.id);
    }
    return sp;
  });
  leaf.replaceChildren(...spans);
  leaf.dataset.mixed = '1';
  return spans;
}

// ---------------------------------------------------------------------------------------------
// Preparation: annotate blocks with data-bidx / data-lang, segment mixed paragraphs.

export function prepare(body) {
  let bidx = 0;
  const walk = (el, path) => {
    normalizeContainer(el);
    const items = [];
    let ci = 0;
    for (const child of [...el.children]) {
      if (IGNORE.has(child.localName) || isUi(child)) continue;
      if (!isBlockEl(child)) continue;
      const item = { el: child };
      if (ATOMIC.has(child.localName)) {
        item.kind = 'atomic';
        item.st = elStats(child);
        item.lang = child.localName === 'math' || child.localName === 'pre' ? 'neutral' : langOf(item.st);
        child.dataset.bidx = String(bidx++);
        if (item.lang === 'en' || item.lang === 'zh') child.dataset.lang = item.lang;
      } else if (hasBlockChild(child)) {
        item.kind = 'container';
        item.node = walk(child, path + '/' + ci);
        let st = { han: 0, words: 0 };
        let en = false;
        let zh = false;
        let media = false;
        for (const it of item.node.items) {
          st = addStats(st, it.st);
          if (it.lang === 'en') en = true;
          else if (it.lang === 'zh') zh = true;
          else if (it.lang === 'mixed') { en = true; zh = true; }
          else if (it.el.matches(MEDIA_SEL) || it.el.querySelector(MEDIA_SEL) || it.el.localName === 'table') media = true;
          if (it.kind === 'atomic' && (it.el.localName === 'table' || it.el.localName === 'pre')) media = true;
        }
        item.st = st;
        // A container holding a shared figure/table plus text is opened up so the figure spans both columns.
        item.lang = (en && zh) || ((en || zh) && media) ? 'mixed' : en ? 'en' : zh ? 'zh' : 'neutral';
      } else {
        item.kind = 'leaf';
        item.st = elStats(child);
        child.dataset.bidx = String(bidx++);
        if (looksMixed(item.st)) {
          const segs = segmentLeaf(child);
          if (segs) { item.lang = 'mixed'; item.segs = segs; }
        }
        if (!item.segs) {
          item.lang = langOf(item.st);
          if (item.lang === 'en' || item.lang === 'zh') child.dataset.lang = item.lang;
        }
      }
      items.push(item);
      ci++;
    }
    return { el, path, items };
  };
  const root = walk(body, '');
  return { root, count: bidx };
}

// ---------------------------------------------------------------------------------------------
// Pairing

function unitLen(st, lang) {
  return lang === 'en' ? Math.max(1, st.words) : Math.max(1, st.han);
}

function sharedSig(el) {
  const imgs = [...el.querySelectorAll('img,image')].map((i) => i.getAttribute('src') || i.getAttribute('href') || i.getAttribute('xlink:href') || '').join('|');
  const txt = (el.textContent || '').replace(/\s+/g, ' ').trim().slice(0, 200);
  if (!imgs && !txt) return null;
  return el.localName + ':' + imgs + ':' + txt;
}

// Atomic blocks (tables, code, video…) are shared full-width unless a translated twin of the
// other language sits right next to them (e.g. an English table followed by its Chinese version).
function atomicIsShared(items, i) {
  const it = items[i];
  if (it.kind !== 'atomic' || (it.lang !== 'en' && it.lang !== 'zh')) return false;
  if (looksMixed(it.st)) return true;
  const twin = (j) => {
    const o = items[j];
    return o && o.kind === 'atomic' && o.el.localName === it.el.localName && (o.lang === 'en' || o.lang === 'zh') && o.lang !== it.lang;
  };
  return !(twin(i - 1) || twin(i + 1));
}

function collectUnits(node) {
  const out = [];
  node.items.forEach((it, i) => { it.sharedAtomic = atomicIsShared(node.items, i); });
  for (const it of node.items) {
    if (it.sharedAtomic) { out.push({ type: 'shared', el: it.el, sig: sharedSig(it.el) }); continue; }
    if (it.kind === 'leaf' && it.lang === 'mixed') {
      it.segs.forEach((sp, i) => {
        const lang = sp.dataset.lang;
        out.push({ type: 'lang', lang, seg: sp, segIndex: i, leaf: it.el, len: unitLen(elStats(sp), lang) });
      });
    } else if (it.lang === 'en' || it.lang === 'zh') {
      out.push({ type: 'lang', lang: it.lang, el: it.el, len: unitLen(it.st, it.lang), item: it });
    } else if (it.kind === 'container' && it.lang === 'mixed') {
      out.push({ type: 'shared', el: it.el, node: it.node, sig: null });
    } else {
      out.push({ type: 'shared', el: it.el, sig: sharedSig(it.el) });
    }
  }
  return out;
}

// Collapse duplicated figures / formulas that a translation tool copied for each language.
function dedupeShared(units) {
  for (let i = 0; i < units.length; i++) {
    const X = units[i];
    if (X.type !== 'shared' || !X.sig || X.dropped) continue;
    for (let j = i + 1; j < units.length && j <= i + 10; j++) {
      const Y = units[j];
      if (Y.type !== 'shared') continue;
      if (Y.sig === X.sig && !Y.dropped) {
        const between = units.slice(i + 1, j);
        if (!between.length) { Y.dropped = true; break; }
        const langs = new Set(between.map((u) => u.lang));
        if (langs.size === 1) {
          let before = null;
          for (let k = i - 1; k >= 0; k--) { if (units[k].type === 'lang') { before = units[k]; break; } if (units[k].type === 'shared') break; }
          if (before && before.lang !== [...langs][0]) X.dropped = true; else Y.dropped = true;
        }
      }
      break;
    }
  }
  return units.filter((u) => !u.dropped);
}

function dpAlign(A, B, R, firstIsEn) {
  const m = A.length;
  const n = B.length;
  if (m * n > 160000) {
    // Very long runs: proportional alignment instead of the full DP.
    const groups = [];
    let j = 0;
    for (let i = 0; i < m; i++) {
      const end = i === m - 1 ? n : Math.round(((i + 1) * n) / m);
      groups.push({ p: [A[i]], s: B.slice(j, Math.max(j, end)) });
      j = Math.max(j, end);
    }
    return groups;
  }
  const INF = 1e15;
  const cost = Array.from({ length: m + 1 }, () => new Float64Array(n + 1).fill(INF));
  const back = Array.from({ length: m + 1 }, () => new Array(n + 1));
  cost[0][0] = 0;
  const pats = [[1, 1, 0], [1, 2, 0.6], [2, 1, 0.6], [1, 3, 1.4], [3, 1, 1.4], [2, 2, 1.2], [1, 4, 2.2], [4, 1, 2.2], [2, 3, 1.8], [3, 2, 1.8], [1, 0, 2.6], [0, 1, 2.6]];
  const preA = [0];
  for (const u of A) preA.push(preA[preA.length - 1] + u.len);
  const preB = [0];
  for (const u of B) preB.push(preB[preB.length - 1] + u.len);
  const leafTotal = new Map();
  for (const u of A) if (u.leaf) leafTotal.set(u.leaf, (leafTotal.get(u.leaf) || 0) + 1);
  for (const u of B) if (u.leaf) leafTotal.set(u.leaf, (leafTotal.get(u.leaf) || 0) + 1);
  const hasLeaves = leafTotal.size > 0;
  for (let i = 0; i <= m; i++) {
    for (let j = 0; j <= n; j++) {
      if (cost[i][j] >= INF) continue;
      for (const [di, dj, pen] of pats) {
        const ni = i + di;
        const nj = j + dj;
        if (ni > m || nj > n) continue;
        let c = pen;
        if (di && dj) {
          const la = preA[ni] - preA[i];
          const lb = preB[nj] - preB[j];
          const enLen = firstIsEn ? la : lb;
          const zhLen = firstIsEn ? lb : la;
          c += Math.abs(Math.log((zhLen + 3) / (enLen * R + 3))) * 2.2;
        }
        if (hasLeaves) {
          // keep the segments of one mixed paragraph together
          const inside = new Map();
          for (let k = i; k < ni; k++) if (A[k].leaf) inside.set(A[k].leaf, (inside.get(A[k].leaf) || 0) + 1);
          for (let k = j; k < nj; k++) if (B[k].leaf) inside.set(B[k].leaf, (inside.get(B[k].leaf) || 0) + 1);
          for (const [lf, cnt] of inside) c += cnt === leafTotal.get(lf) ? -0.4 : 2;
        }
        if (cost[i][j] + c < cost[ni][nj]) {
          cost[ni][nj] = cost[i][j] + c;
          back[ni][nj] = [i, j];
        }
      }
    }
  }
  const groups = [];
  let i = m;
  let j = n;
  while (i > 0 || j > 0) {
    const b = back[i][j];
    if (!b) break;
    groups.unshift({ p: A.slice(b[0], i), s: B.slice(b[1], j) });
    [i, j] = b;
  }
  return groups;
}

function autoAlign(units, first, R) {
  const runs = [];
  let cur = null;
  for (const u of units) {
    if (u.lang === first) {
      if (!cur || cur.s.length) { cur = { p: [], s: [] }; runs.push(cur); }
      cur.p.push(u);
    } else {
      if (!cur) { cur = { p: [], s: [] }; runs.push(cur); }
      cur.s.push(u);
    }
  }
  const groups = [];
  for (const r of runs) {
    if (r.p.length <= 1 && r.s.length <= 1) groups.push(r);
    else if (!r.p.length || !r.s.length) {
      for (const u of r.p) groups.push({ p: [u], s: [] });
      for (const u of r.s) groups.push({ p: [], s: [u] });
    } else groups.push(...dpAlign(r.p, r.s, R, first === 'en'));
  }
  return groups.map((g) => (first === 'en' ? { en: g.p, zh: g.s } : { en: g.s, zh: g.p }));
}

function groupsFromCounts(units, counts) {
  const en = units.filter((u) => u.lang === 'en');
  const zh = units.filter((u) => u.lang === 'zh');
  let se = 0;
  let sz = 0;
  for (const [e, z] of counts) { se += e; sz += z; if (e < 0 || z < 0) return null; }
  if (se !== en.length || sz !== zh.length) return null;
  const out = [];
  let a = 0;
  let b = 0;
  for (const [e, z] of counts) {
    if (e + z === 0) continue;
    out.push({ en: en.slice(a, a + e), zh: zh.slice(b, b + z) });
    a += e;
    b += z;
  }
  return out;
}

export function segmentSig(units) {
  return hashString(units.map((u) => u.lang[0] + u.len).join('.'));
}

// Build the pairing plan for a prepared chapter.
// overrides: { "<containerPath>#<segIndex>": { sig, groups: [[en, zh], ...] } }
export function buildPlan(model, overrides = {}) {
  const containers = [];
  const visit = (node) => {
    const units = dedupeShared(collectUnits(node));
    const c = { node, units, segs: [] };
    containers.push(c);
    for (const u of units) if (u.type === 'shared' && u.node) visit(u.node);
  };
  visit(model.root);

  // Global order (English first or Chinese first): choose the order that leaves fewer blocks
  // unpaired; inline pairs inside one paragraph ("中文<br>English") are a strong hint.
  const ratios = [];
  const segsOf = (c) => {
    const out = [];
    let cur = [];
    for (const u of c.units) {
      if (u.type === 'lang') cur.push(u);
      else { if (cur.length) out.push(cur); cur = []; }
    }
    if (cur.length) out.push(cur);
    return out;
  };
  const orphanScore = (first) => {
    let orphans = 0;
    for (const c of containers) {
      for (const seg of segsOf(c)) {
        let cur = null;
        const groups = [];
        for (const u of seg) {
          if (u.lang === first) { if (!cur || cur.s) { cur = { p: 0, s: 0 }; groups.push(cur); } cur.p++; } else { if (!cur) { cur = { p: 0, s: 0 }; groups.push(cur); } cur.s++; }
        }
        for (const g of groups) if (!g.p || !g.s) orphans++;
      }
    }
    return orphans;
  };
  let inlineEn = 0;
  let inlineZh = 0;
  for (const c of containers) {
    for (const u of c.units) if (u.type === 'lang' && u.seg && u.segIndex === 0) { if (u.lang === 'en') inlineEn++; else inlineZh++; }
  }
  const scoreEn = orphanScore('en') * 2 - inlineEn;
  const scoreZh = orphanScore('zh') * 2 - inlineZh;
  const first = scoreZh < scoreEn ? 'zh' : 'en';
  // estimate Chinese characters per English word from clean 1:1 neighbours
  for (const c of containers) {
    for (let i = 1; i < c.units.length; i++) {
      const a = c.units[i - 1];
      const b = c.units[i];
      if (a.type === 'lang' && b.type === 'lang' && a.lang === first && b.lang !== first) {
        const nx = c.units[i + 1];
        const pv = c.units[i - 2];
        if ((!nx || nx.type !== 'lang' || nx.lang === first) && (!pv || pv.type !== 'lang' || pv.lang !== first)) {
          const en = a.lang === 'en' ? a : b;
          const zh = a.lang === 'en' ? b : a;
          if (en.len >= 4 && zh.len >= 4) ratios.push(zh.len / en.len);
        }
      }
    }
  }
  ratios.sort((x, y) => x - y);
  const R = ratios.length >= 3 ? Math.min(4, Math.max(0.8, ratios[ratios.length >> 1])) : 1.7;

  const plan = { first, R, segments: new Map(), groups: [], unitGroup: new Map(), containers: new Map(), stats: { en: 0, zh: 0, groups: 0, paired: 0 } };
  for (const c of containers) {
    const items = [];
    let seg = [];
    let segIndex = 0;
    const flushSeg = () => {
      if (!seg.length) return;
      const key = (c.node.path || '/') + '#' + segIndex++;
      const sig = segmentSig(seg);
      const auto = autoAlign(seg, first, R);
      let groups = auto;
      const ov = overrides && overrides[key];
      let overridden = false;
      if (ov && ov.sig === sig && Array.isArray(ov.groups)) {
        const g = groupsFromCounts(seg, ov.groups);
        if (g) { groups = g; overridden = true; }
      }
      const segRec = { key, sig, units: seg, groups, overridden, auto: auto.map((g) => [g.en.length, g.zh.length]) };
      plan.segments.set(key, segRec);
      groups.forEach((g, gi) => {
        const item = { type: 'group', key, gi, en: g.en, zh: g.zh, seg: segRec };
        items.push(item);
        plan.groups.push(item);
        for (const u of [...g.en, ...g.zh]) plan.unitGroup.set(u.seg || u.el, item);
        plan.stats.groups++;
        if (g.en.length && g.zh.length) plan.stats.paired++;
      });
      for (const u of seg) plan.stats[u.lang]++;
      seg = [];
    };
    for (const u of c.units) {
      if (u.type === 'lang') seg.push(u);
      else { flushSeg(); items.push({ type: 'shared', unit: u }); }
    }
    flushSeg();
    plan.containers.set(c.node, items);
  }
  plan.root = model.root;
  plan.bilingual = plan.stats.en > 0 && plan.stats.zh > 0 && plan.stats.paired >= Math.min(3, plan.stats.groups);
  return plan;
}

// ---------------------------------------------------------------------------------------------
// Rendering into rows / cells

function trimEdges(el) {
  const isBlank = (n) => {
    if (n.nodeType === 3) return !/\S/.test(n.data);
    if (n.nodeType === 8) return true;
    if (n.nodeType !== 1) return false;
    if (n.localName === 'br') return true;
    if (n.matches && n.matches(MEDIA_SEL)) return false;
    if (n.querySelector && n.querySelector(MEDIA_SEL)) return false;
    return !/\S/.test(n.textContent || '');
  };
  const trimSide = (node, fromStart) => {
    for (;;) {
      const c = fromStart ? node.firstChild : node.lastChild;
      if (!c) return;
      if (isBlank(c)) { c.remove(); continue; }
      if (c.nodeType === 3) {
        c.data = fromStart ? c.data.replace(/^\s+/, '') : c.data.replace(/\s+$/, '');
        return;
      }
      if (c.nodeType === 1) trimSide(c, fromStart);
      return;
    }
  };
  trimSide(el, true);
  trimSide(el, false);
}

function materialize(u) {
  if (!u.seg) return u.el;
  const leaf = u.leaf;
  const c = leaf.cloneNode(false);
  c.removeAttribute('data-mixed');
  if (u.segIndex > 0) c.removeAttribute('id');
  c.dataset.lang = u.lang;
  c.dataset.seg = String(u.segIndex);
  c.append(...u.seg.childNodes);
  trimEdges(c);
  u.mat = c;
  return c;
}

const HEAD_RE = /^h[1-6]$/;

// Restructure the DOM (non-original modes). Returns nothing; mutates plan items (row/cell refs).
export function renderPlan(plan, doc) {
  const renderNode = (node) => {
    const items = plan.containers.get(node);
    if (!items) return;
    const container = node.el;
    // ordered lists: keep per-language numbering
    if (container.localName === 'ol') {
      const start = parseInt(container.getAttribute('start') || '1', 10) || 1;
      const ctr = { en: start, zh: start };
      for (const it of items) {
        if (it.type !== 'group') continue;
        for (const u of [...it.en, ...it.zh]) if (u.el && u.el.localName === 'li') u.el.value = ctr[u.lang]++;
      }
    }
    const frag = doc.createDocumentFragment();
    for (const keep of [...container.children]) {
      if (keep.localName === 'style' || keep.localName === 'link' || isUi(keep)) frag.append(keep);
    }
    for (const it of items) {
      if (it.type === 'shared') {
        if (it.unit.node) renderNode(it.unit.node);
        const row = doc.createElement('div');
        row.className = 'br-row br-shared';
        row.append(it.unit.el);
        frag.append(row);
        it.row = row;
        continue;
      }
      const row = doc.createElement('div');
      row.className = 'br-row br-group';
      row.dataset.seg = it.key;
      row.dataset.gi = String(it.gi);
      const en = doc.createElement('div');
      en.className = 'br-cell br-en';
      en.lang = 'en';
      const zh = doc.createElement('div');
      zh.className = 'br-cell br-zh';
      zh.lang = 'zh-CN';
      for (const u of it.en) en.append(materialize(u));
      for (const u of it.zh) zh.append(materialize(u));
      if (!it.en.length) row.classList.add('br-no-en');
      if (!it.zh.length) row.classList.add('br-no-zh');
      if ([...it.en, ...it.zh].some((u) => HEAD_RE.test((u.leaf || u.el).localName))) row.classList.add('br-head');
      if (it.seg.overridden) row.classList.add('br-manual');
      row.append(en, zh);
      frag.append(row);
      it.row = row;
      it.enCell = en;
      it.zhCell = zh;
    }
    container.replaceChildren(frag);
    container.classList.add('br-container');
  };
  renderNode(plan.root);
  plan.rendered = true;
}

// Elements that hold a group's content for one language in the current DOM.
export function groupEls(item, lang, rendered) {
  if (rendered) {
    const cell = lang === 'en' ? item.enCell : item.zhCell;
    return cell ? [cell] : [];
  }
  return item[lang].map((u) => u.seg || u.el);
}

// ---------------------------------------------------------------------------------------------
// Manual alignment operations. counts: [[en, zh], ...] for one segment.

export function applyAlignOp(counts, gi, op, arg) {
  const c = counts.map((x) => x.slice());
  const g = c[gi];
  if (!g) return null;
  const next = c[gi + 1];
  const prev = c[gi - 1];
  switch (op) {
    case 'merge-next':
      if (!next) return null;
      c.splice(gi, 2, [g[0] + next[0], g[1] + next[1]]);
      break;
    case 'merge-prev':
      if (!prev) return null;
      c.splice(gi - 1, 2, [prev[0] + g[0], prev[1] + g[1]]);
      break;
    case 'en-down':
    case 'zh-down': {
      const k = op === 'en-down' ? 0 : 1;
      if (g[k] < 1) return null;
      g[k]--;
      if (next) next[k]++; else c.splice(gi + 1, 0, k === 0 ? [1, 0] : [0, 1]);
      break;
    }
    case 'en-up':
    case 'zh-up': {
      const k = op === 'en-up' ? 0 : 1;
      if (!next || next[k] < 1) return null;
      next[k]--;
      g[k]++;
      break;
    }
    case 'split': {
      if (g[0] + g[1] < 2 || (g[0] <= 1 && g[1] <= 1)) return null;
      const n = Math.max(g[0], g[1]);
      const parts = [];
      for (let i = 0; i < n; i++) parts.push([i < g[0] ? 1 : 0, i < g[1] ? 1 : 0]);
      c.splice(gi, 1, ...parts);
      break;
    }
    case 'split-at': {
      const e = g[0];
      const z = g[1];
      let e1;
      let z1;
      if (arg.lang === 'en') { e1 = arg.index; z1 = e ? Math.round((z * arg.index) / e) : 0; } else { z1 = arg.index; e1 = z ? Math.round((e * arg.index) / z) : 0; }
      e1 = Math.max(0, Math.min(e, e1));
      z1 = Math.max(0, Math.min(z, z1));
      if (e1 + z1 === 0 || e - e1 + (z - z1) === 0) return null;
      c.splice(gi, 1, [e1, z1], [e - e1, z - z1]);
      break;
    }
    default:
      return null;
  }
  return c.filter((x) => x[0] + x[1] > 0);
}

export function countsOf(seg) {
  return seg.groups.map((g) => [g.en.length, g.zh.length]);
}
