// Small, safe Markdown renderer for AI answers. All text is HTML-escaped first; only a fixed set of tags
// is produced (p, h3-h6, strong, em, del, code, pre, ul/ol/li, blockquote, table, hr, a[data-ext], span.math).
import { escapeHtml } from './util.js';

const GREEK = {
  alpha: 'α', beta: 'β', gamma: 'γ', delta: 'δ', epsilon: 'ε', varepsilon: 'ε', zeta: 'ζ', eta: 'η', theta: 'θ', kappa: 'κ',
  lambda: 'λ', mu: 'μ', nu: 'ν', xi: 'ξ', pi: 'π', rho: 'ρ', sigma: 'σ', tau: 'τ', phi: 'φ', varphi: 'φ', chi: 'χ', psi: 'ψ',
  omega: 'ω', Gamma: 'Γ', Delta: 'Δ', Theta: 'Θ', Lambda: 'Λ', Pi: 'Π', Sigma: 'Σ', Phi: 'Φ', Psi: 'Ψ', Omega: 'Ω',
};
const SYMBOLS = {
  times: '×', cdot: '·', div: '÷', pm: '±', mp: '∓', le: '≤', leq: '≤', ge: '≥', geq: '≥', ne: '≠', neq: '≠', approx: '≈',
  sim: '∼', equiv: '≡', infty: '∞', sum: '∑', prod: '∏', int: '∫', partial: '∂', nabla: '∇', sqrt: '√', to: '→',
  rightarrow: '→', leftarrow: '←', Rightarrow: '⇒', Leftrightarrow: '⇔', in: '∈', ldots: '…', cdots: '⋯', dots: '…',
  percent: '%', quad: ' ', qquad: '  ', left: '', right: '', bar: '', hat: '', tilde: '', mathrm: '', text: '', mathbf: '',
  operatorname: '', displaystyle: '', ln: 'ln', log: 'log', exp: 'exp', max: 'max', min: 'min', lim: 'lim', E: 'E',
};

// Very small TeX prettifier for formulas such as D_{mod} = \frac{D}{1+y} (input is already escaped).
function texLite(s) {
  let t = s;
  for (let i = 0; i < 4; i++) t = t.replace(/\\[dt]?frac\s*\{([^{}]*)\}\s*\{([^{}]*)\}/g, '($1)/($2)');
  t = t.replace(/\\sqrt\s*\{([^{}]*)\}/g, '√($1)');
  t = t.replace(/\\([A-Za-z]+)/g, (m, name) => (GREEK[name] || (SYMBOLS[name] !== undefined ? SYMBOLS[name] : m)));
  t = t.replace(/\\%/g, '%').replace(/\\,|\\;|\\!|\\ /g, ' ');
  t = t.replace(/\^\{([^{}]*)\}/g, '<sup>$1</sup>').replace(/\^([A-Za-z0-9])/g, '<sup>$1</sup>');
  t = t.replace(/_\{([^{}]*)\}/g, '<sub>$1</sub>').replace(/_([A-Za-z0-9])/g, '<sub>$1</sub>');
  t = t.replace(/[{}]/g, '');
  return t;
}

function inline(src) {
  const keep = [];
  const stash = (html) => { keep.push(html); return '\u0001' + (keep.length - 1) + '\u0002'; };
  let s = src;
  s = s.replace(/`([^`\n]+)`/g, (_, c) => stash('<code>' + c + '</code>'));
  s = s.replace(/\\\((.+?)\\\)/g, (_, m) => stash('<span class="math">' + texLite(m) + '</span>'));
  // $...$ only when it looks like a formula (not "$100 and $200")
  s = s.replace(/(^|[^\\$\w])\$(?![\s\d])([^$\n]*?[^\s\\$])\$(?![\w$])/g, (_, pre, m) => pre + stash('<span class="math">' + texLite(m) + '</span>'));
  s = s.replace(/\[([^\]\n]+)\]\((https?:\/\/[^\s)]+)\)/g, (_, t, u) => stash(`<a href="${u}" data-ext="1" title="${u}">${t}</a>`));
  s = s.replace(/(^|[\s(（：:])(https?:\/\/[A-Za-z0-9\-._~:/?#@!$%+,;=*]+(?:&amp;[A-Za-z0-9\-._~:/?#@!$%+,;=*]+)*)/g, (_, pre, url) => {
    const m = /[.,;:!?]+$/.exec(url);
    const u = m ? url.slice(0, m.index) : url;
    return pre + stash(`<a href="${u}" data-ext="1">${u}</a>`) + (m ? m[0] : '');
  });
  s = s.replace(/\*\*(?=\S)([^\n]*?\S)\*\*/g, '<strong>$1</strong>').replace(/__(?=\S)([^\n]*?\S)__/g, '<strong>$1</strong>');
  s = s.replace(/(^|[^*\w])\*(?=\S)([^*\n]*?\S)\*(?![*\w])/g, '$1<em>$2</em>');
  s = s.replace(/(^|[^_\w])_(?=\S)([^_\n]*?\S)_(?![_\w])/g, '$1<em>$2</em>');
  s = s.replace(/~~(?=\S)([^\n]*?\S)~~/g, '<del>$1</del>');
  return s.replace(/\u0001(\d+)\u0002/g, (_, i) => keep[+i]);
}

const esc = (s) => escapeHtml(String(s));
const inl = (s) => inline(esc(s));

function splitRow(line) {
  let s = line.trim();
  if (s.startsWith('|')) s = s.slice(1);
  if (s.endsWith('|')) s = s.slice(0, -1);
  return s.split(/(?<!\\)\|/).map((c) => c.trim().replace(/\\\|/g, '|'));
}

const LIST_RE = /^(\s*)([-*+•]|\d+[.)、])\s+(.*)$/;

function parseList(lines, start) {
  const items = [];
  let i = start;
  while (i < lines.length) {
    const m = LIST_RE.exec(lines[i]);
    if (m) {
      items.push({ indent: m[1].replace(/\t/g, '    ').length, ordered: /\d/.test(m[2]), start: parseInt(m[2], 10) || 1, text: m[3] });
      i++;
      continue;
    }
    if (lines[i].trim() && /^\s{2,}\S/.test(lines[i]) && items.length) {
      items[items.length - 1].text += '\n' + lines[i].trim();
      i++;
      continue;
    }
    break;
  }
  let html = '';
  const stack = [];
  for (const it of items) {
    while (stack.length && it.indent < stack[stack.length - 1].indent) html += `</li></${stack.pop().tag}>`;
    const top = stack[stack.length - 1];
    if (!top || it.indent > top.indent) {
      const tag = it.ordered ? 'ol' : 'ul';
      html += `<${tag}${it.ordered && it.start > 1 ? ` start="${it.start}"` : ''}>`;
      stack.push({ indent: it.indent, tag });
    } else {
      html += '</li>';
    }
    html += '<li>' + it.text.split('\n').map(inl).join('<br>');
  }
  while (stack.length) html += `</li></${stack.pop().tag}>`;
  return { html, next: i };
}

export function renderMarkdown(src) {
  const lines = String(src || '').replace(/\r\n?/g, '\n').split('\n');
  const out = [];
  let para = [];
  const flush = () => {
    if (para.length) out.push('<p>' + para.map(inl).join('<br>') + '</p>');
    para = [];
  };
  let i = 0;
  while (i < lines.length) {
    const line = lines[i];
    let m = /^\s*(`{3,}|~{3,})\s*([\w+#.-]*)\s*$/.exec(line);
    if (m) {
      flush();
      const fence = m[1];
      const buf = [];
      i++;
      while (i < lines.length && !lines[i].trim().startsWith(fence)) buf.push(lines[i++]);
      i++;
      out.push('<pre><code>' + esc(buf.join('\n')) + '</code></pre>');
      continue;
    }
    if (/^\s*\$\$\s*$/.test(line)) {
      flush();
      const buf = [];
      i++;
      while (i < lines.length && !/^\s*\$\$\s*$/.test(lines[i])) buf.push(lines[i++]);
      i++;
      out.push('<div class="math block">' + texLite(esc(buf.join(' '))) + '</div>');
      continue;
    }
    if (!line.trim()) { flush(); i++; continue; }
    m = /^\s*\$\$(.+)\$\$\s*$/.exec(line) || /^\s*\\\[(.+)\\\]\s*$/.exec(line);
    if (m) { flush(); out.push('<div class="math block">' + texLite(esc(m[1])) + '</div>'); i++; continue; }
    m = /^\s{0,3}(#{1,6})\s+(.*?)\s*#*\s*$/.exec(line);
    if (m) { flush(); const lv = Math.min(6, m[1].length + 2); out.push(`<h${lv}>${inl(m[2])}</h${lv}>`); i++; continue; }
    if (/^\s{0,3}([-*_])(\s*\1){2,}\s*$/.test(line)) { flush(); out.push('<hr>'); i++; continue; }
    if (/^\s*\|.*\|\s*$/.test(line) && i + 1 < lines.length && /^\s*\|?\s*:?-{2,}:?\s*(\|\s*:?-{2,}:?\s*)*\|?\s*$/.test(lines[i + 1])) {
      flush();
      const head = splitRow(line);
      i += 2;
      const rows = [];
      while (i < lines.length && /^\s*\|.*\|\s*$/.test(lines[i])) rows.push(splitRow(lines[i++]));
      out.push('<div class="tbl"><table><thead><tr>' + head.map((c) => '<th>' + inl(c) + '</th>').join('') + '</tr></thead><tbody>' +
        rows.map((r) => '<tr>' + r.map((c) => '<td>' + inl(c) + '</td>').join('') + '</tr>').join('') + '</tbody></table></div>');
      continue;
    }
    if (/^\s*>/.test(line)) {
      flush();
      const buf = [];
      while (i < lines.length && /^\s*>/.test(lines[i])) buf.push(lines[i++].replace(/^\s*>\s?/, ''));
      out.push('<blockquote>' + renderMarkdown(buf.join('\n')) + '</blockquote>');
      continue;
    }
    if (LIST_RE.test(line)) {
      flush();
      const r = parseList(lines, i);
      out.push(r.html);
      i = r.next;
      continue;
    }
    para.push(line.trim());
    i++;
  }
  flush();
  return out.join('\n');
}
