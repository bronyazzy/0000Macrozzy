// Fetching, decoding, parsing and sanitizing book documents (EPUB XHTML or local HTML).
import { decodeBytes } from './util.js';

const VOID = 'area|base|br|col|embed|hr|img|input|link|meta|param|source|track|wbr|keygen|command|basefont|frame|isindex';
const SELF_CLOSING_RE = new RegExp('<((?!(?:' + VOID + ')\\b)[a-zA-Z][\\w:.-]*)((?:\\s+[^\\s"\'>/=]+(?:\\s*=\\s*(?:"[^"]*"|\'[^\']*\'|[^\\s"\'>]+))?)*)\\s*/>', 'g');

const XLINK = 'http://www.w3.org/1999/xlink';

export async function fetchBytes(url) {
  const res = await fetch(url);
  if (!res.ok) throw new Error(`无法读取 ${decodeURIComponent(url.split('/').pop() || url)}（${res.status}）`);
  return res.arrayBuffer();
}

export async function fetchText(url) {
  return decodeBytes(await fetchBytes(url));
}

export async function fetchXml(url) {
  const text = await fetchText(url);
  let doc = new DOMParser().parseFromString(text.replace(/^\uFEFF/, ''), 'application/xml');
  if (doc.getElementsByTagName('parsererror').length) doc = new DOMParser().parseFromString(text, 'text/html');
  return doc;
}

export function parseDocument(text, { xmlFirst = false } = {}) {
  let doc = null;
  if (xmlFirst || /^\s*(<\?xml|<html[^>]+xmlns\s*=\s*["']http:\/\/www\.w3\.org\/1999\/xhtml)/i.test(text)) {
    try {
      doc = new DOMParser().parseFromString(text.replace(/^\uFEFF/, ''), 'application/xhtml+xml');
      if (doc.getElementsByTagName('parsererror').length || !doc.body) doc = null;
    } catch { doc = null; }
  }
  if (!doc) doc = new DOMParser().parseFromString(text.replace(SELF_CLOSING_RE, '<$1$2></$1>'), 'text/html');
  return doc;
}

const DROP = 'script,iframe,frame,frameset,object,embed,applet,base,portal,meta[http-equiv]';

export function sanitize(doc) {
  for (const e of doc.querySelectorAll(DROP)) e.remove();
  for (const e of [...doc.getElementsByTagName('script')]) e.remove(); // XML docs: namespaced svg:script
  for (const e of doc.querySelectorAll('noscript')) e.replaceWith(...e.childNodes);
  for (const e of doc.querySelectorAll('link')) {
    if (!/\bstylesheet\b/i.test(e.getAttribute('rel') || '') || /\balternate\b/i.test(e.getAttribute('rel') || '')) e.remove();
  }
  for (const e of doc.querySelectorAll('animate,set,animateMotion,animateTransform')) {
    if (/href/i.test(e.getAttribute('attributeName') || '')) e.remove();
  }
  const all = doc.getElementsByTagName('*');
  for (let i = 0; i < all.length; i++) {
    const e = all[i];
    for (const a of [...e.attributes]) {
      const n = a.name.toLowerCase();
      if (n.startsWith('on')) { e.removeAttributeNode(a); continue; }
      if ((n === 'href' || n === 'src' || n === 'xlink:href' || n === 'action' || n === 'formaction' || n === 'data' || n === 'poster') &&
        /^\s*(javascript|vbscript|data:text\/html)/i.test(a.value)) e.removeAttributeNode(a);
    }
    // lazy-loaded images in saved web pages
    if (e.localName === 'img') {
      const lazy = e.getAttribute('data-src') || e.getAttribute('data-original') || e.getAttribute('data-lazy-src');
      const src = e.getAttribute('src') || '';
      if (lazy && (!src || /^data:/.test(src))) e.setAttribute('src', lazy);
      e.removeAttribute('loading');
    }
  }
  return doc;
}

export function headStyles(doc) {
  const out = [];
  const head = doc.head || doc.getElementsByTagName('head')[0];
  const scan = (root) => {
    if (!root) return;
    for (const e of root.querySelectorAll('link, style')) {
      if (e.localName === 'link') out.push({ type: 'link', href: e.getAttribute('href') });
      else out.push({ type: 'style', text: e.textContent || '' });
      e.remove();
    }
  };
  scan(head);
  return out;
}

export function epubType(el) {
  return el.getAttributeNS('http://www.idpf.org/2007/ops', 'type') || el.getAttribute('epub:type') || '';
}

export function linkHref(a) {
  return a.getAttribute('href') || a.getAttributeNS(XLINK, 'href') || a.getAttribute('xlink:href') || '';
}

// Load a chapter: returns { doc, styles, lang, htmlClass }.
export async function loadChapterDoc(url, { xmlFirst = false } = {}) {
  return parseChapter(await fetchText(url), { xmlFirst });
}

export function parseChapter(text, { xmlFirst = false } = {}) {
  const doc = parseDocument(text, { xmlFirst });
  sanitize(doc);
  const styles = headStyles(doc);
  const html = doc.documentElement;
  if (!doc.body) {
    const b = doc.createElementNS('http://www.w3.org/1999/xhtml', 'body');
    html.append(b);
  }
  return {
    doc,
    styles,
    lang: html.getAttribute('lang') || html.getAttribute('xml:lang') || '',
    htmlClass: html.getAttribute('class') || '',
    title: (doc.querySelector('title') || {}).textContent || '',
  };
}

// Give headings stable ids (used to build a table of contents for plain HTML files).
export function assignHeadingIds(doc) {
  let n = 0;
  for (const h of doc.body.querySelectorAll('h1,h2,h3,h4')) {
    n++;
    if (!h.id) h.id = 'br-h-' + n;
  }
}
