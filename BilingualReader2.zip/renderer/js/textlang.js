// Script statistics and English/Chinese language classification.

const HAN_RE = /[㐀-䶿一-鿿豈-﫿]|[\ud840-\ud87e][\udc00-\udfff]/;
export const HAN_G = /[㐀-䶿一-鿿豈-﫿]|[\ud840-\ud87e][\udc00-\udfff]/g;
const CJK_PUNCT_RE = /[　-〿！-｠‘’“”—…]/;
const WORD_G = /[A-Za-zÀ-ɏ]+(?:['’-][A-Za-zÀ-ɏ]+)*/g;

export function isHan(ch) { return HAN_RE.test(ch); }

export function stats(text) {
  const han = (text.match(HAN_G) || []).length;
  const words = (text.match(WORD_G) || []).length;
  return { han, words };
}

export function addStats(a, b) { return { han: a.han + b.han, words: a.words + b.words }; }

// Language of a piece of text given its stats: 'en' | 'zh' | 'neutral'.
export function langOf(st) {
  const { han, words } = st;
  if (han === 0 && words === 0) return 'neutral';
  if (han === 0) return 'en';
  if (words === 0) return 'zh';
  if (han <= 1 && words >= 2) return 'en';
  return han >= words * 1.7 * 0.35 ? 'zh' : 'en';
}

// Both languages substantially present (candidate for splitting a mixed paragraph).
export function looksMixed(st) {
  const { han, words } = st;
  if (han < 4 || words < 3) return false;
  const r = han / (words * 1.7);
  return r > 0.18 && r < 6;
}

// Classify each character: 'e' latin letter, 'z' Han / CJK punctuation, 'n' neutral.
export function charClass(ch) {
  const c = ch.charCodeAt(0);
  if ((c >= 65 && c <= 90) || (c >= 97 && c <= 122) || (c >= 0xc0 && c <= 0x24f)) return 'e';
  if (HAN_RE.test(ch) || CJK_PUNCT_RE.test(ch)) return 'z';
  return 'n';
}

// Split text into sentences, returns [{text, start, end}].
const ABBR_END = /(?:\b(?:e\.g|i\.e|etc|vs|Mr|Mrs|Ms|Dr|Prof|Inc|Ltd|Co|Corp|Fig|Figs|No|Nos|Vol|pp|cf|al|approx|est|Jan|Feb|Mar|Apr|Jun|Jul|Aug|Sep|Sept|Oct|Nov|Dec|St|Jr|Sr)\.|\b[A-Z]\.)$/;

export function sentences(text, lang) {
  const out = [];
  if (!text) return out;
  const isZh = lang === 'zh';
  const n = text.length;
  let start = 0;
  const push = (a, b) => {
    const raw = text.slice(a, b);
    const lead = raw.length - raw.trimStart().length;
    const t = raw.trim();
    if (t) out.push({ text: t, start: a + lead, end: a + lead + t.length });
  };
  for (let i = 0; i < n; i++) {
    const ch = text[i];
    const term = isZh ? /[。！？!?…]/.test(ch) : /[.!?。！？]/.test(ch);
    if (!term) continue;
    let j = i + 1;
    while (j < n && /[.!?。！？…”’"'」』）)\]]/.test(text[j])) j++;
    if (!isZh && !/[。！？]/.test(ch)) {
      if (j < n && !/\s/.test(text[j])) { i = j - 1; continue; }
      if (ch === '.' && ABBR_END.test(text.slice(Math.max(start, i - 12), i + 1))) { i = j - 1; continue; }
      let k = j;
      while (k < n && /\s/.test(text[k])) k++;
      if (k < n && /[a-z]/.test(text[k])) { i = j - 1; continue; }
    }
    push(start, j);
    start = j;
    i = j - 1;
  }
  if (start < n) push(start, n);
  return out;
}

export function sentenceAt(text, offset, lang) {
  const ss = sentences(text, lang);
  for (let i = 0; i < ss.length; i++) {
    if (offset >= ss[i].start && offset <= ss[i].end) return { ...ss[i], index: i, count: ss.length };
  }
  return ss.length ? { ...ss[ss.length - 1], index: ss.length - 1, count: ss.length } : { text, start: 0, end: text.length, index: 0, count: 1 };
}

export function isEnglishQuery(s) {
  return /^[A-Za-z][A-Za-z'’\- .&/]{0,60}$/.test(s.trim());
}

export function hasHan(s) { return HAN_RE.test(s); }
