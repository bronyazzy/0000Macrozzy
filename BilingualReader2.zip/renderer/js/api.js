// Bridge to the backend: Electron IPC (window.bridge from preload.js) or the HTTP test harness.
const bridge = window.bridge || null;
export const isElectron = !!bridge;

export async function call(method, ...args) {
  if (bridge) return bridge.call(method, ...args);
  const r = await fetch('/api/' + method, { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify(args) });
  const j = await r.json();
  if (j.error) throw new Error(j.error);
  return j.result;
}

const handlers = {};
let events = null;
export function on(channel, cb) {
  if (bridge) { bridge.on(channel, cb); return; }
  (handlers[channel] = handlers[channel] || []).push(cb);
  // test harness: backend events arrive as server-sent events
  if (!events && typeof EventSource !== 'undefined') {
    events = new EventSource('/__events');
    events.onmessage = (e) => {
      let m;
      try { m = JSON.parse(e.data); } catch { return; }
      (handlers[m.channel] || []).forEach((h) => h(...(m.args || [])));
    };
  }
}

// Test harness hook: window.__emit('open-file', path)
window.__emit = (channel, ...args) => (handlers[channel] || []).forEach((cb) => cb(...args));

export function pathForFile(file) {
  if (bridge && bridge.pathForFile) {
    try { return bridge.pathForFile(file); } catch { return null; }
  }
  return file && file.path ? file.path : null;
}
