// Dictionary side panel and vocabulary book.
import { el, escapeHtml, formatDate, toast } from './util.js';
import { hasHan } from './textlang.js';
import * as api from './api.js';

const FIN_LABEL = /[【〔[〈<（(]\s*(?:金融|经济学?|经|财经?|财务|商业?|证券|股票|股市|银行|会计|投资|期货|期权|债券|外汇|贸易|保险|税务?|财政|市场)\s*[】〕\]〉>）)]/;
const FIN_WORD = /(金融|证券|股票|债券|期货|期权|外汇|利率|收益率|保证金|头寸|仓位|对冲|套利|做空|做多|多头|空头|行权|久期|凸性|价差|利差|波动率|流动性|杠杆|股息|红利|市盈率|资产|负债|基金|指数|交易所|结算|交割|合约)/;
const BLOCK_TAGS = new Set(['p', 'div', 'li', 'ul', 'ol', 'dd', 'dt', 'dl', 'h1', 'h2', 'h3', 'h4', 'h5', 'h6', 'tr', 'table', 'section', 'blockquote', 'hr', 'pre']);

function htmlLines(html) {
  const doc = new DOMParser().parseFromString(html, 'text/html');
  for (const e of doc.querySelectorAll('script,style,link,audio,video')) e.remove();
  let out = '';
  const walk = (n) => {
    for (let c = n.firstChild; c; c = c.nextSibling) {
      if (c.nodeType === 3) out += c.data.replace(/\s+/g, ' ');
      else if (c.nodeType === 1) {
        const t = c.localName;
        if (t === 'br') { out += '\n'; continue; }
        const blk = BLOCK_TAGS.has(t);
        if (blk) out += '\n';
        walk(c);
        if (blk) out += '\n';
      }
    }
  };
  walk(doc.body);
  const lines = out.split('\n').map((l) => l.trim()).filter(Boolean);
  // phonetic
  let ph = '';
  const phEl = doc.querySelector('[class*="phon" i],[class*="pron" i],[class*="ipa" i],[class*="yinbiao" i],[class*="symbol" i],phon,pron,ipa');
  if (phEl) ph = (phEl.textContent || '').trim();
  if (!ph || ph.length > 60) {
    const m = /([/[][^/[\]\n]{0,40}[ˈˌəɪʊæɑɔʌθðŋʃʒːɜɒ][^/[\]\n]{0,40}[/\]])/.exec(lines.join('\n'));
    ph = m ? m[1] : '';
  }
  return { lines, ph };
}

function hanRatio(s) {
  const h = (s.match(/[一-鿿]/g) || []).length;
  const l = (s.match(/[A-Za-z]/g) || []).length;
  return h / Math.max(1, h + l / 3);
}

export function analyzeMdx(html) {
  const { lines, ph } = htmlLines(html);
  const isExample = (l) => /^[A-Z"“'‘(]?[A-Za-z][^一-鿿]{18,}[.!?]["”’)]?\s*[一-鿿]/.test(l);
  const finLines = lines.filter((l) => FIN_LABEL.test(l) && l.length <= 200).slice(0, 6);
  const defLines = lines.filter((l) => hanRatio(l) >= 0.3 && l.length <= 140 && !isExample(l) && !/^[/[].*[/\]]$/.test(l)).slice(0, 10);
  return { ph, finLines, defLines, lines };
}

function finSenses(text) {
  return String(text || '').split(/[\n;；]|(?=\d+[.、)])/).map((s) => s.trim()).filter((s) => s && (FIN_LABEL.test(s) || FIN_WORD.test(s)));
}

const reEsc = (s) => String(s).replace(/[.*+?^${}()|[\]\\]/g, '\\$&');

// Regex matching any inflected form of the word (hedge -> hedges / hedged / hedging, sell -> sold).
export function formsRegex(word, forms, flags = 'gi') {
  const list = [...new Set([word, ...(forms || [])].filter(Boolean).map((f) => String(f).toLowerCase()))]
    .sort((a, b) => b.length - a.length);
  if (!list.length) return null;
  if (list.some((f) => hasHan(f))) return new RegExp(list.map(reEsc).join('|'), flags.replace('i', ''));
  return new RegExp("(?<![A-Za-z'’-])(?:" + list.map((f) => reEsc(f).replace(/ +/g, '\\s+')).join('|') + ")(?![A-Za-z])", flags);
}

function highlightWord(sentence, word, forms) {
  const s = escapeHtml(sentence);
  if (!word) return s;
  const re = formsRegex(escapeHtml(word), (forms || []).map(escapeHtml));
  return re ? s.replace(re, (m) => `<mark>${m}</mark>`) : s;
}

export class DictPanel {
  constructor(app) {
    this.app = app;
    this.body = document.getElementById('dict-body');
    this.input = document.getElementById('dict-input');
    this.history = [];
    this.hpos = -1;
    this.result = null;
    this.ctx = null;
    this.frames = new Map();
    this.fid = 0;
    this.input.addEventListener('keydown', (e) => {
      if (e.key === 'Enter') {
        const q = this.input.value.trim();
        if (q) this.app.lookup(q, null);
      }
      e.stopPropagation();
      if (e.key === 'Escape') this.input.blur();
    });
    document.getElementById('dict-back').addEventListener('click', () => this.step(-1));
    document.getElementById('dict-fwd').addEventListener('click', () => this.step(1));
    document.getElementById('dict-compact').addEventListener('click', () => this.app.toggleCompact());
    window.addEventListener('message', (e) => this._onFrameMessage(e));
    this.renderEmpty();
  }

  renderEmpty() {
    this.body.replaceChildren(el('div', { class: 'dict-empty' },
      el('div', { class: 'dict-empty-title' }, '双击单词或选中短语即可查词'),
      el('ul', {},
        el('li', {}, '优先显示金融 / 交易释义，例如 duration → 久期'),
        el('li', {}, '可在“设置 → 词典”中导入 MDX/MDD、CSV 词库'),
        el('li', {}, 'F8：只看释义　F9：简洁模式'))));
  }

  step(d) {
    const n = this.hpos + d;
    if (n < 0 || n >= this.history.length) return;
    this.hpos = n;
    const h = this.history[n];
    this.show(h.result, h.ctx, false);
  }

  async show(result, ctx, push = true) {
    this.result = result;
    this.ctx = ctx;
    if (push) {
      this.history = this.history.slice(0, this.hpos + 1);
      this.history.push({ result, ctx });
      if (this.history.length > 60) this.history.shift();
      this.hpos = this.history.length - 1;
    }
    this.input.value = result.query;
    this.render();
  }

  render() {
    const r = this.result;
    if (!r) { this.renderEmpty(); return; }
    const compact = this.app.settings.dictCompact;
    this.frames.clear();
    const box = el('div', { class: 'dict-result' + (compact ? ' compact' : '') });
    if (r.reverse && r.reverse.length) {
      box.append(el('div', { class: 'dict-head' }, el('span', { class: 'dict-word' }, r.query), el('span', { class: 'dict-sub' }, '中文 → 英文')));
      const list = el('div', { class: 'dict-reverse' });
      for (const it of r.reverse) {
        list.append(el('div', { class: 'rev-item', onclick: () => this.app.lookup(it.w, null) },
          el('span', { class: 'rev-w' }, it.w), it.ph ? el('span', { class: 'rev-ph' }, it.ph) : null,
          el('div', { class: 'rev-s', html: highlightWord(it.sense, r.query) }), el('span', { class: 'rev-src' }, it.dictName)));
      }
      box.append(list);
      this.body.replaceChildren(box);
      return;
    }
    const head = r.headword || r.query;
    const builtin = r.sections.find((s) => s.type === 'builtin');
    let ph = builtin && builtin.ph;
    const analyses = new Map();
    for (const s of r.sections) {
      if (s.type === 'mdx') {
        const a = analyzeMdx(s.html);
        analyses.set(s, a);
        if (!ph && a.ph) ph = a.ph;
      } else if (s.type === 'csv' && !ph) {
        ph = (s.items.find((i) => i.ph) || {}).ph;
      }
    }
    this.phonetic = ph || '';
    const headEl = el('div', { class: 'dict-head' },
      el('span', { class: 'dict-word' }, head),
      ph ? el('span', { class: 'dict-ph' }, ph) : null,
      el('button', { class: 'icon-btn', title: '朗读（系统语音）', onclick: () => this.app.speak(head) }, '🔊'),
      el('span', { class: 'grow' }),
      el('button', { class: 'small-btn', title: '让 Gemini 结合原句解释这个词（Ctrl+J 打开 AI 对话）', onclick: () => this.app.ai.askWord(r.query, this.ctx) }, '问 AI'),
      el('button', { class: 'small-btn', title: '把词条连同原句加入生词本', onclick: () => this.addVocab() }, '＋生词本'));
    box.append(headEl);
    if (r.morph) {
      box.append(el('div', { class: 'dict-note morph' }, el('b', {}, r.morph.form), ' 是 ', el('b', {}, r.morph.lemma), ' 的' + (r.morph.label || '变形')));
    } else if (r.alt) {
      box.append(el('div', { class: 'dict-note morph' }, el('b', {}, r.alt.form), ' 也是 ',
        el('a', { href: '#', title: '查看原形', onclick: (e) => { e.preventDefault(); this.app.lookup(r.alt.lemma, this.ctx); } }, r.alt.lemma), ' 的' + (r.alt.label || '变形')));
    } else if (r.query.toLowerCase() !== String(head).toLowerCase() && !/\s/.test(r.query)) {
      box.append(el('div', { class: 'dict-note' }, `查询“${r.query}”，显示 ${head}`));
    }

    // finance senses found in other dictionaries (only when the built-in glossary has no entry)
    if (!builtin) {
      const fin = [];
      for (const s of r.sections) {
        if (s.type === 'mdx') for (const l of analyses.get(s).finLines) fin.push({ l, src: s.dictName });
        if (s.type === 'csv') for (const it of s.items) for (const l of finSenses(it.def)) fin.push({ l, src: s.dictName });
      }
      if (fin.length) {
        box.append(el('div', { class: 'dict-sec fin' }, el('div', { class: 'sec-title' }, '金融释义'),
          el('ul', { class: 'senses' }, fin.slice(0, 6).map((f) => el('li', {}, f.l, el('span', { class: 'src' }, f.src))))));
      }
    }
    if (r.phrases && r.phrases.length) {
      box.append(el('div', { class: 'dict-phrases' }, el('span', { class: 'lbl' }, '原句中的词组：'),
        r.phrases.map((p) => el('button', { class: 'chip', title: p.brief || p.dictName, onclick: () => this.app.lookup(p.phrase, this.ctx) },
          p.phrase, p.brief ? el('small', {}, ' ' + p.brief.slice(0, 14)) : null))));
    }
    if (!r.sections.length) {
      box.append(el('div', { class: 'dict-none' }, `没有找到“${r.query}”。`,
        el('div', { class: 'muted' }, this.app.state.dicts.filter((d) => d.type !== 'builtin').length ? '已查询全部启用的词典。' : '内置词典只收录金融交易词汇；可在 设置 → 词典 中导入 MDX/CSV 通用词典。')));
    }
    for (const s of r.sections) box.append(this.renderSection(s, analyses.get(s), compact));
    if (!compact && this.ctx && this.ctx.sentence) {
      const c = el('div', { class: 'dict-sec ctx' }, el('div', { class: 'sec-title' }, '原句'),
        el('div', { class: 'ctx-en', html: highlightWord(this.ctx.sentence, r.query, r.forms) }),
        this.ctx.sentenceZh ? el('div', { class: 'ctx-zh' }, this.ctx.sentenceZh) : null,
        this.ctx.chapter ? el('div', { class: 'ctx-src' }, this.ctx.chapter) : null);
      box.append(c);
    }
    if (!compact && !hasHan(r.query)) {
      const more = this.app.bookExamples(head, this.ctx && this.ctx.sentence, r.forms);
      if (more.length) {
        box.append(el('div', { class: 'dict-sec' }, el('div', { class: 'sec-title' }, '本章其他例句'),
          el('ul', { class: 'examples' }, more.map((s) => el('li', { html: highlightWord(s, head, r.forms) })))));
      }
    }
    if (r.errors && r.errors.length) box.append(el('div', { class: 'dict-err' }, r.errors.join('；')));
    this.body.replaceChildren(box);
    this.body.scrollTop = 0;
  }

  renderSection(s, analysis, compact) {
    const sec = el('div', { class: 'dict-sec src-' + s.type });
    sec.append(el('div', { class: 'sec-title' }, el('span', {}, s.dictName), s.headword && s.headword.toLowerCase() !== (this.result.headword || '').toLowerCase() ? el('span', { class: 'hw' }, s.headword) : null));
    if (s.type === 'builtin') {
      if (s.fin.length) sec.append(el('div', { class: 'tag fin' }, '金融' + (s.pos ? ' · ' + s.pos : '')), el('ol', { class: 'senses fin' }, s.fin.map((x) => el('li', {}, x))));
      if (s.gen.length) sec.append(el('div', { class: 'tag' }, '通用' + (s.pos && !s.fin.length ? ' · ' + s.pos : '')), el('ol', { class: 'senses' }, s.gen.map((x) => el('li', {}, x))));
      if (!compact && s.ex.length) {
        sec.append(el('ul', { class: 'examples' }, s.ex.map(([en, zh]) => el('li', {}, el('div', { html: highlightWord(en, s.headword, this.result.forms) }), zh ? el('div', { class: 'zh' }, zh) : null))));
      }
      if (!compact && s.rel.length) {
        sec.append(el('div', { class: 'rel' }, '相关：', s.rel.map((w) => el('button', { class: 'chip', onclick: () => this.app.lookup(w, null) }, w))));
      }
    } else if (s.type === 'csv') {
      for (const it of s.items) {
        const b = el('div', { class: 'csv-item' });
        if (it.pos || it.def) b.append(el('div', { class: 'def' }, (it.pos ? it.pos + ' ' : '') + (it.def || '')));
        if (!compact && it.ex) b.append(el('div', { class: 'ex', html: highlightWord(it.ex, s.headword, this.result.forms) }));
        if (!compact && it.note) b.append(el('div', { class: 'note' }, it.note));
        sec.append(b);
      }
    } else if (s.type === 'mdx') {
      if (compact) {
        const defs = analysis.defLines.length ? analysis.defLines : analysis.lines.slice(0, 4);
        sec.append(el('ol', { class: 'senses' }, defs.slice(0, 8).map((x) => el('li', {}, x))));
      } else {
        const fid = 'f' + (++this.fid);
        const frame = el('iframe', {
          class: 'mdx-frame',
          sandbox: 'allow-scripts',
          src: `dictentry/${encodeURIComponent(s.dictId)}/${encodeURIComponent(s.key)}?fid=${fid}`,
          title: s.dictName,
        });
        frame.style.height = '120px';
        this.frames.set(fid, frame);
        sec.append(frame);
      }
    }
    return sec;
  }

  _onFrameMessage(e) {
    const d = e.data;
    if (!d || !d.__brDict) return;
    const frame = this.frames.get(d.fid);
    if (!frame || e.source !== frame.contentWindow) return;
    if (d.type === 'height') frame.style.height = Math.min(4000, Math.max(40, d.h + 4)) + 'px';
    else if (d.type === 'entry' && d.word) this.app.lookup(d.word, null);
    else if (d.type === 'lookup' && d.word) this.app.lookup(d.word, null);
    else if (d.type === 'sound' && d.path) {
      const sec = this.result && this.result.sections.find((s) => s.type === 'mdx' && frame.src.includes(encodeURIComponent(s.dictId)));
      if (sec) {
        const a = new Audio(`dictres/${encodeURIComponent(sec.dictId)}/${d.path.split('/').map(encodeURIComponent).join('/')}`);
        a.play().catch(() => this.app.speak(this.result.headword || this.result.query));
      }
    } else if (d.type === 'external' && d.url) this.app.openExternal(d.url);
    else if (d.type === 'key') this.app.handleShortcut(d.key);
  }

  shortDef() {
    const r = this.result;
    if (!r) return '';
    const parts = [];
    for (const s of r.sections) {
      if (s.type === 'builtin') parts.push(...s.fin.slice(0, 2), ...s.gen.slice(0, 1));
      else if (s.type === 'csv') parts.push(...s.items.slice(0, 2).map((i) => i.def).filter(Boolean));
      else if (s.type === 'mdx') parts.push(...analyzeMdx(s.html).defLines.slice(0, 2));
      if (parts.length >= 3) break;
    }
    return parts.slice(0, 3).join('；').slice(0, 200);
  }

  async addVocab() {
    const r = this.result;
    if (!r) return;
    const word = r.headword || r.query;
    const ctx = this.ctx || {};
    try {
      const res = await api.call('vocabAdd', {
        word,
        phonetic: this.phonetic || '',
        def: this.shortDef(),
        sentence: ctx.sentence || '',
        sentenceZh: ctx.sentenceZh || '',
        bookId: this.app.info ? this.app.info.bookId : '',
        bookTitle: this.app.book ? this.app.book.title : '',
        chapter: ctx.chapter || '',
        pos: ctx.pos || null,
      });
      toast(res.duplicate ? '生词本里已有这条（同一原句）' : `已加入生词本：${word}`);
      this.app.refreshVocab();
    } catch (e) {
      toast('加入失败：' + e.message, { type: 'error' });
    }
  }
}

export class VocabPanel {
  constructor(app) {
    this.app = app;
    this.list = document.getElementById('vocab-list');
    this.filter = document.getElementById('vocab-filter');
    this.items = [];
    this.filter.addEventListener('input', () => this.render());
    this.filter.addEventListener('keydown', (e) => e.stopPropagation());
    document.getElementById('vocab-export-csv').addEventListener('click', () => this.exportAs('csv'));
    document.getElementById('vocab-export-anki').addEventListener('click', () => this.exportAs('anki'));
  }

  async refresh() {
    this.items = await api.call('vocabList');
    document.getElementById('vocab-count').textContent = this.items.length ? String(this.items.length) : '';
    this.render();
  }

  render() {
    const q = this.filter.value.trim().toLowerCase();
    const items = q ? this.items.filter((x) => (x.word + ' ' + x.def + ' ' + x.sentence + ' ' + (x.note || '')).toLowerCase().includes(q)) : this.items;
    if (!items.length) {
      this.list.replaceChildren(el('div', { class: 'empty-tip' }, this.items.length ? '没有匹配的生词' : '生词本是空的。查词后点击“＋生词本”，会连同原句一起保存。'));
      return;
    }
    this.list.replaceChildren(...items.map((x) => {
      const sameBook = this.app.info && x.bookId === this.app.info.bookId && x.pos;
      return el('div', { class: 'vocab-item' },
        el('div', { class: 'v-head' },
          el('a', { class: 'v-word', href: '#', onclick: (e) => { e.preventDefault(); this.app.lookup(x.word, null); } }, x.word),
          x.phonetic ? el('span', { class: 'v-ph' }, x.phonetic) : null,
          el('span', { class: 'grow' }),
          sameBook ? el('button', { class: 'icon-btn', title: '跳到原文位置', onclick: () => this.app.jumpTo(x.pos) }, '↪') : null,
          el('button', { class: 'icon-btn', title: '笔记', onclick: () => this.editNote(x) }, '✎'),
          el('button', { class: 'icon-btn', title: '删除', onclick: () => this.remove(x) }, '🗑')),
        x.def ? el('div', { class: 'v-def' }, x.def) : null,
        x.sentence ? el('div', { class: 'v-sent', html: highlightWord(x.sentence, x.word) }) : null,
        x.sentenceZh ? el('div', { class: 'v-sent-zh' }, x.sentenceZh) : null,
        x.note ? el('div', { class: 'v-note' }, x.note) : null,
        el('div', { class: 'v-meta' }, [x.bookTitle, x.chapter, formatDate(x.added)].filter(Boolean).join(' · ')));
    }));
  }

  async editNote(x) {
    const note = await this.app.prompt('笔记', x.note || '', { multiline: true });
    if (note == null) return;
    await api.call('vocabUpdate', x.id, { note });
    await this.refresh();
  }

  async remove(x) {
    await api.call('vocabRemove', x.id);
    await this.refresh();
    toast(`已删除 ${x.word}`);
  }

  async exportAs(format) {
    if (!this.items.length) { toast('生词本是空的'); return; }
    const name = format === 'anki' ? '生词本-Anki.txt' : '生词本.csv';
    if (api.isElectron) {
      const p = await api.call('pickSave', name, format === 'anki' ? [{ name: 'Anki 文本', extensions: ['txt'] }] : [{ name: 'CSV', extensions: ['csv'] }]);
      if (!p) return;
      await api.call('vocabExport', p, format);
      toast('已导出到 ' + p);
    } else {
      const text = await api.call('vocabExportText', format);
      const a = document.createElement('a');
      a.href = URL.createObjectURL(new Blob([text], { type: 'text/plain;charset=utf-8' }));
      a.download = name;
      a.click();
    }
  }
}
