// Table of contents, bookmarks, search panel and the library (start screen).
import { el, escapeHtml, formatDate, formatSize, debounce, toast } from './util.js';
import { BookSearch } from './search.js';
import { searchRegex } from './flowview.js';
import { openMenu } from './menu.js';
import * as api from './api.js';

export class TocPanel {
  constructor(app) {
    this.app = app;
    this.root = document.getElementById('tab-toc');
    this.collapsed = new Set();
  }

  render() {
    const book = this.app.book;
    this.root.replaceChildren();
    if (!book) return;
    const toc = book.toc && book.toc.length ? book.toc : this._fallback(book);
    if (!toc.length) {
      this.root.append(el('div', { class: 'empty-tip' }, '这本书没有目录'));
      return;
    }
    const mk = (nodes, depth, pathKey) => {
      const ul = el('ul', { class: 'toc-list' + (depth ? ' sub' : '') });
      nodes.forEach((n, i) => {
        const key = pathKey + '.' + i;
        const hasKids = n.children && n.children.length;
        const li = el('li', { class: 'toc-item', dataset: { key } });
        const row = el('div', { class: 'toc-row', style: { paddingLeft: 8 + depth * 14 + 'px' } },
          hasKids ? el('span', { class: 'toc-tw' + (this.collapsed.has(key) ? ' closed' : ''), onclick: (e) => { e.stopPropagation(); this.toggle(key, li); } }, '▾') : el('span', { class: 'toc-tw empty' }),
          el('span', { class: 'toc-label', title: n.label }, n.label),
          n.page ? el('span', { class: 'toc-page' }, String(n.page)) : null);
        row.addEventListener('click', () => this.app.gotoToc(n));
        n._row = row;
        li.append(row);
        if (hasKids) {
          const sub = mk(n.children, depth + 1, key);
          if (this.collapsed.has(key)) sub.hidden = true;
          li.append(sub);
        }
        ul.append(li);
      });
      return ul;
    };
    this.nodes = toc;
    this.root.append(mk(toc, 0, 'r'));
    this.highlight();
  }

  _fallback(book) {
    if (book.kind === 'flow' && book.spine.length > 1) {
      return book.spine.map((s, i) => ({ label: book.chapterTitles[i] || `第 ${i + 1} 部分`, url: s.url, spine: i, fragment: null, children: [] }));
    }
    return [];
  }

  toggle(key, li) {
    const sub = li.querySelector(':scope > ul');
    const tw = li.querySelector(':scope > .toc-row > .toc-tw');
    if (!sub) return;
    if (this.collapsed.has(key)) { this.collapsed.delete(key); sub.hidden = false; tw.classList.remove('closed'); } else { this.collapsed.add(key); sub.hidden = true; tw.classList.add('closed'); }
  }

  highlight() {
    if (!this.nodes) return;
    const pos = this.app.lastPos;
    if (!pos) return;
    let best = null;
    const walk = (nodes) => {
      for (const n of nodes) {
        if (pos.kind === 'pdf') { if (n.page && n.page <= pos.page && (!best || n.page >= best.page)) best = n; }
        else if (n.spine === pos.index && (!best || best.spine !== pos.index || !n.fragment)) { if (!best || best.spine !== pos.index) best = n; }
        walk(n.children || []);
      }
    };
    walk(this.nodes);
    for (const r of this.root.querySelectorAll('.toc-row.current')) r.classList.remove('current');
    if (best && best._row) {
      best._row.classList.add('current');
      if (this.app.state.leftTab === 'toc' && !this._userScrolled) {
        const r = best._row.getBoundingClientRect();
        const pr = this.root.getBoundingClientRect();
        if (r.top < pr.top || r.bottom > pr.bottom) best._row.scrollIntoView({ block: 'center' });
      }
    }
  }
}

export class BookmarksPanel {
  constructor(app) {
    this.app = app;
    this.root = document.getElementById('bookmark-list');
    document.getElementById('bookmark-add').addEventListener('click', () => this.app.addBookmark());
  }

  render() {
    const bms = (this.app.bookData && this.app.bookData.bookmarks) || [];
    if (!this.app.book) { this.root.replaceChildren(); return; }
    if (!bms.length) {
      this.root.replaceChildren(el('div', { class: 'empty-tip' }, '还没有书签。按 Ctrl+D 或点击上方按钮，在当前位置添加书签。'));
      return;
    }
    const sorted = [...bms].sort((a, b) => (a.pos.percent || 0) - (b.pos.percent || 0));
    this.root.replaceChildren(...sorted.map((b) => el('div', { class: 'bm-item', onclick: () => this.app.jumpTo(b.pos) },
      el('div', { class: 'bm-top' }, el('span', { class: 'bm-label' }, b.label), el('span', { class: 'bm-pct' }, Math.round((b.pos.percent || 0) * 100) + '%')),
      b.note ? el('div', { class: 'bm-note' }, b.note) : null,
      b.excerpt ? el('div', { class: 'bm-ex' }, b.excerpt) : null,
      el('div', { class: 'bm-meta' }, formatDate(b.created),
        el('span', { class: 'grow' }),
        el('button', { class: 'icon-btn', title: '备注', onclick: async (e) => { e.stopPropagation(); const n = await this.app.prompt('书签备注', b.note || ''); if (n != null) { b.note = n; this.app.saveBookData({ bookmarks: bms }); this.render(); } } }, '✎'),
        el('button', { class: 'icon-btn', title: '删除', onclick: (e) => { e.stopPropagation(); this.app.removeBookmark(b.id); } }, '🗑')))));
  }
}

export class SearchPanel {
  constructor(app) {
    this.app = app;
    this.input = document.getElementById('search-input');
    this.results = document.getElementById('search-results');
    this.status = document.getElementById('search-status');
    this.caseBox = document.getElementById('search-case');
    this.wordBox = document.getElementById('search-word');
    this.searcher = null;
    this.query = '';
    this.input.addEventListener('keydown', (e) => {
      e.stopPropagation();
      if (e.key === 'Enter') { e.preventDefault(); this.run(); }
      if (e.key === 'Escape') { this.input.blur(); this.app.refocusReader(); }
      if (e.key === 'F3') { e.preventDefault(); this.app.searchStep(e.shiftKey ? -1 : 1); }
    });
    this.caseBox.addEventListener('change', () => this.query && this.run());
    this.wordBox.addEventListener('change', () => this.query && this.run());
  }

  get opts() { return { caseSensitive: this.caseBox.checked, wholeWord: this.wordBox.checked }; }

  reset() {
    if (this.searcher) this.searcher.cancel();
    this.searcher = null;
    this.query = '';
    this.results.replaceChildren();
    this.status.textContent = '';
  }

  focus(prefill) {
    if (prefill) this.input.value = prefill;
    this.input.focus();
    this.input.select();
  }

  async run() {
    const q = this.input.value.trim();
    const app = this.app;
    this.query = q;
    this.results.replaceChildren();
    if (!q || !app.book) { this.status.textContent = ''; return; }
    if (app.book.kind === 'pdf') return this.runPdf(q);
    if (!this.searcher || this.searcher.book !== app.book) this.searcher = new BookSearch(app.book);
    this.status.textContent = '正在搜索…';
    const opts = this.opts;
    app.flow.clearHighlights();
    app.flow.highlightAll(q, opts);
    let lastChapter = -1;
    let shown = 0;
    const total = await this.searcher.run(q, opts, (hits, i) => {
      if (this.query !== q) return;
      if (i !== lastChapter) {
        this.results.append(el('div', { class: 'sr-chapter' }, app.book.chapterTitles[i] || `第 ${i + 1} 部分`));
        lastChapter = i;
      }
      for (const h of hits) {
        if (shown++ > 600) break;
        this.results.append(el('div', { class: 'sr-item', onclick: () => app.gotoSearchHit({ ...h, query: q, opts }) },
          el('span', {}, h.before), el('mark', {}, h.match), el('span', {}, h.after)));
      }
    }, (i, n) => { if (this.query === q && i < n) this.status.textContent = `正在搜索… ${i}/${n}`; });
    if (this.query !== q) return;
    this.status.textContent = total ? `找到 ${total >= 1000 ? '1000+' : total} 处` + (total > 600 ? '（列出前 600 处）' : '') : '没有找到';
  }

  async runPdf(q) {
    const pdf = this.app.pdf;
    const opts = this.opts;
    this.status.textContent = '正在搜索…';
    pdf.find(q, opts);
    let total = 0;
    const re = searchRegex(q, opts);
    for (let p = 1; p <= pdf.pages; p++) {
      if (this.query !== q) return;
      let text = '';
      try { text = await pdf.pageText(p); } catch { continue; }
      re.lastIndex = 0;
      let m;
      let first = true;
      while ((m = re.exec(text))) {
        if (!m[0].length) { re.lastIndex++; continue; }
        if (first) { this.results.append(el('div', { class: 'sr-chapter' }, `第 ${p} 页`)); first = false; }
        const s = Math.max(0, m.index - 36);
        const e = Math.min(text.length, m.index + m[0].length + 60);
        const page = p;
        this.results.append(el('div', { class: 'sr-item', onclick: () => this.app.gotoPdfHit(page, q, opts) },
          el('span', {}, (s ? '…' : '') + text.slice(s, m.index).replace(/\s+/g, ' ')), el('mark', {}, m[0]), el('span', {}, text.slice(m.index + m[0].length, e).replace(/\s+/g, ' ') + '…')));
        if (++total >= 600) break;
      }
      if (total >= 600) break;
      if (p % 5 === 0) {
        this.status.textContent = `正在搜索… ${p}/${pdf.pages}`;
        await new Promise((r) => setTimeout(r, 0));
      }
    }
    this.status.textContent = total ? `找到 ${total}${total >= 600 ? '+' : ''} 处` : '没有找到';
  }
}

export class Library {
  constructor(app) {
    this.app = app;
    this.root = document.getElementById('library');
    this.filter = document.getElementById('lib-filter');
    this.filter.addEventListener('input', () => this.render());
    this.filter.addEventListener('keydown', (e) => e.stopPropagation());
  }

  render() {
    const q = this.filter.value.trim().toLowerCase();
    const books = (this.app.state.library || []).filter((b) => !q || ((b.title || '') + ' ' + (b.author || '') + ' ' + (b.name || '')).toLowerCase().includes(q));
    if (!books.length) {
      this.root.replaceChildren(el('div', { class: 'lib-empty' }, (this.app.state.library || []).length ? '没有匹配的书' : '还没有阅读记录。打开或拖入一本书开始阅读。'));
      return;
    }
    this.root.replaceChildren(...books.map((b) => {
      const cover = b.cover ? el('img', { class: 'cover-img', src: b.cover, alt: '' }) : el('div', { class: 'cover-ph fmt-' + b.type }, el('span', {}, [...(b.title || b.name || '?').replace(/^[\s\p{P}\p{S}]+/u, '')][0] || '?'));
      const pct = Math.round((b.progress || 0) * 100);
      const card = el('div', { class: 'book-card' + (b.missing ? ' missing' : ''), title: b.path || '' },
        el('div', { class: 'cover' }, cover, el('span', { class: 'fmt' }, (b.type || '').toUpperCase())),
        el('div', { class: 'book-info' },
          el('div', { class: 'book-title' }, b.title || b.name),
          b.author ? el('div', { class: 'book-author' }, b.author) : null,
          el('div', { class: 'book-progress' }, el('div', { class: 'bar' }, el('i', { style: { width: pct + '%' } })), el('span', {}, pct + '%')),
          el('div', { class: 'book-meta' }, b.missing ? '⚠ 文件已移动或删除' : [b.posLabel, formatDate(b.lastOpened), formatSize(b.size)].filter(Boolean).join(' · '))));
      card.addEventListener('click', () => {
        if (b.missing) { toast('找不到文件：' + b.path, { type: 'error', ms: 4000 }); return; }
        this.app.openPath(b.path);
      });
      card.addEventListener('contextmenu', (e) => {
        e.preventDefault();
        openMenu(e.clientX, e.clientY, [
          { label: '打开', disabled: b.missing, action: () => this.app.openPath(b.path) },
          { label: '在文件夹中显示', disabled: b.missing || !api.isElectron, action: () => api.call('showInFolder', b.path) },
          '-',
          { label: '从列表中移除', danger: true, action: async () => { await api.call('removeFromLibrary', b.id); await this.app.reloadState(); this.render(); } },
        ]);
      });
      return card;
    }));
  }
}

export { escapeHtml, debounce };
