// Runs inside a sandboxed MDX dictionary entry frame: reports height, forwards entry:// and sound:// links.
(function () {
  var script = document.currentScript;
  var fid = (script && script.getAttribute('data-fid')) || new URLSearchParams(location.search).get('fid') || '';
  function post(msg) {
    msg.__brDict = true;
    msg.fid = fid;
    try { parent.postMessage(msg, '*'); } catch (e) { /* ignore */ }
  }
  function report() {
    var h = Math.max(document.documentElement.scrollHeight, document.body ? document.body.scrollHeight : 0);
    post({ type: 'height', h: h });
  }
  document.addEventListener('DOMContentLoaded', function () {
    report();
    if (window.ResizeObserver) new ResizeObserver(report).observe(document.documentElement);
    var imgs = document.images;
    for (var i = 0; i < imgs.length; i++) imgs[i].addEventListener('load', report);
  });
  window.addEventListener('load', report);
  document.addEventListener('click', function (e) {
    var a = e.target.closest ? e.target.closest('a') : null;
    if (!a) return;
    var href = a.getAttribute('href') || '';
    if (/^entry:\/\//i.test(href)) {
      e.preventDefault();
      var w = href.replace(/^entry:\/\//i, '').replace(/^\/+/, '');
      try { w = decodeURIComponent(w); } catch (x) { /* ignore */ }
      if (w.charAt(0) === '#') return;
      post({ type: 'entry', word: w });
    } else if (/^bword:\/\//i.test(href)) {
      e.preventDefault();
      post({ type: 'entry', word: decodeURIComponent(href.replace(/^bword:\/\//i, '')) });
    } else if (/^sound:\/\//i.test(href)) {
      e.preventDefault();
      post({ type: 'sound', path: href.replace(/^sound:\/\//i, '').replace(/\\/g, '/').replace(/^\/+/, '') });
    } else if (/^https?:/i.test(href)) {
      e.preventDefault();
      post({ type: 'external', url: href });
    } else if (href.charAt(0) === '#') {
      // in-page anchors are fine
    } else {
      e.preventDefault();
    }
  }, true);
  document.addEventListener('dblclick', function () {
    var s = String(window.getSelection() || '').trim();
    if (s && s.length < 60) post({ type: 'lookup', word: s });
  });
  document.addEventListener('keydown', function (e) {
    if (e.key === 'Escape' || e.key === 'F6' || e.key === 'F8' || e.key === 'F9') { e.preventDefault(); post({ type: 'key', key: e.key }); }
  });
})();
