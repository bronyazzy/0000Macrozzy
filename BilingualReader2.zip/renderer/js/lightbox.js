// Full-window image viewer: fit-to-window, original size, wheel zoom, drag to pan.
import { clamp } from './util.js';

export class Lightbox {
  constructor(app) {
    this.app = app;
    this.root = document.getElementById('lightbox');
    this.stage = this.root.querySelector('.lb-stage');
    this.img = this.root.querySelector('img');
    this.msg = this.root.querySelector('.lb-msg');
    this.zoomLabel = this.root.querySelector('.lb-zoom');
    this.caption = this.root.querySelector('.lb-caption');
    this.scale = 1;
    this.tx = 0;
    this.ty = 0;
    this.fit = true;
    this.isOpen = false;
    this.root.addEventListener('click', (e) => {
      const b = e.target.closest('[data-lb]');
      if (b) {
        e.stopPropagation();
        const a = b.dataset.lb;
        if (a === 'close') this.close();
        else if (a === 'fit') this.setFit();
        else if (a === 'orig') this.setScale(1, null, true);
        else if (a === 'in') this.zoomBy(1.25);
        else if (a === 'out') this.zoomBy(0.8);
        return;
      }
      if (e.target === this.stage || e.target === this.root) this.close();
    });
    this.stage.addEventListener('wheel', (e) => {
      e.preventDefault();
      this.zoomBy(e.deltaY < 0 ? 1.15 : 1 / 1.15, { x: e.clientX, y: e.clientY });
    }, { passive: false });
    this.img.addEventListener('dblclick', (e) => {
      if (this.fit || Math.abs(this.scale - this.fitScale()) < 0.01) this.setScale(1, { x: e.clientX, y: e.clientY }, true);
      else this.setFit();
    });
    let drag = null;
    this.img.addEventListener('mousedown', (e) => {
      if (e.button !== 0) return;
      e.preventDefault();
      drag = { x: e.clientX, y: e.clientY, tx: this.tx, ty: this.ty };
      this.img.classList.add('dragging');
    });
    window.addEventListener('mousemove', (e) => {
      if (!drag) return;
      this.tx = drag.tx + (e.clientX - drag.x);
      this.ty = drag.ty + (e.clientY - drag.y);
      this.fit = false;
      this.apply();
    });
    window.addEventListener('mouseup', () => {
      if (drag) { drag = null; this.img.classList.remove('dragging'); }
    });
    window.addEventListener('resize', () => { if (this.isOpen && this.fit) this.setFit(); });
    this.img.addEventListener('load', () => {
      this.msg.hidden = true;
      this.img.hidden = false;
      this.setFit();
    });
    this.img.addEventListener('error', () => {
      if (this.fallback && this.img.src !== this.fallback) {
        const f = this.fallback;
        this.fallback = null;
        this.img.src = f;
        return;
      }
      this.img.hidden = true;
      this.msg.hidden = false;
      this.msg.textContent = '⚠ 图片无法打开（文件可能已损坏或缺失）。按 Esc 返回继续阅读。';
      this.zoomLabel.textContent = '';
    });
  }

  open(src, { alt = '', fallback = null } = {}) {
    this.isOpen = true;
    this.fallback = fallback;
    this.root.hidden = false;
    this.root.classList.add('open');
    this.msg.hidden = false;
    this.msg.textContent = '正在加载图片…';
    this.img.hidden = true;
    this.caption.textContent = alt || decodeURIComponent((src.split('/').pop() || '').split('?')[0]).slice(0, 80);
    this.img.removeAttribute('src');
    this.img.src = src;
    this.root.focus();
  }

  close() {
    if (!this.isOpen) return;
    this.isOpen = false;
    this.root.classList.remove('open');
    this.root.hidden = true;
    this.img.removeAttribute('src');
    this.app.refocusReader();
  }

  fitScale() {
    const W = this.stage.clientWidth - 40;
    const H = this.stage.clientHeight - 40;
    const w = this.img.naturalWidth || 1;
    const h = this.img.naturalHeight || 1;
    return Math.min(1, W / w, H / h);
  }

  setFit() {
    this.fit = true;
    this.scale = this.fitScale();
    this.tx = 0;
    this.ty = 0;
    this.apply();
  }

  setScale(s, at, resetPan) {
    const old = this.scale;
    this.scale = clamp(s, 0.05, 16);
    this.fit = false;
    if (resetPan) { this.tx = 0; this.ty = 0; }
    if (at && !resetPan) {
      const r = this.stage.getBoundingClientRect();
      const cx = at.x - (r.left + r.width / 2);
      const cy = at.y - (r.top + r.height / 2);
      const k = this.scale / old;
      this.tx = cx - (cx - this.tx) * k;
      this.ty = cy - (cy - this.ty) * k;
    }
    this.apply();
  }

  zoomBy(f, at) { this.setScale(this.scale * f, at); }

  apply() {
    this.img.style.width = this.img.naturalWidth * this.scale + 'px';
    this.img.style.height = this.img.naturalHeight * this.scale + 'px';
    this.img.style.transform = `translate(calc(-50% + ${this.tx}px), calc(-50% + ${this.ty}px))`;
    const dims = this.img.naturalWidth ? `${this.img.naturalWidth}×${this.img.naturalHeight}` : '';
    this.zoomLabel.textContent = `${Math.round(this.scale * 100)}%  ${dims}`;
  }

  onKey(e) {
    if (!this.isOpen) return false;
    if (e.key === 'Escape') this.close();
    else if (e.key === '+' || e.key === '=') this.zoomBy(1.25);
    else if (e.key === '-') this.zoomBy(0.8);
    else if (e.key === '0') this.setFit();
    else if (e.key === '1') this.setScale(1, null, true);
    else return true;
    e.preventDefault();
    return true;
  }
}
