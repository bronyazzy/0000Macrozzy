// EPUB 2/3 package parsing (container.xml, OPF, nav document / NCX) and plain-HTML "books".
import { fetchXml, loadChapterDoc, epubType, linkHref, assignHeadingIds } from './chapter.js';
import { stripHash } from './util.js';

const DC = 'http://purl.org/dc/elements/1.1/';

function dc(opf, name) {
  let list = opf.getElementsByTagNameNS(DC, name);
  if (!list.length) list = opf.getElementsByTagName('dc:' + name);
  return [...list].map((e) => (e.textContent || '').trim()).filter(Boolean);
}

function normUrl(u) {
  try {
    const x = new URL(u);
    x.hash = '';
    return decodeURIComponent(x.pathname).toLowerCase();
  } catch {
    return String(u).toLowerCase();
  }
}

export async function loadEpub(info) {
  const base = new URL(info.baseUrl, location.href).href;
  let opfPath = null;
  try {
    const c = await fetchXml(base + 'META-INF/container.xml');
    const rf = c.getElementsByTagName('rootfile')[0];
    opfPath = rf && rf.getAttribute('full-path');
  } catch { /* ignore */ }
  if (!opfPath) throw new Error('EPUB 缺少 container.xml 或 OPF 路径');
  const opfUrl = new URL(opfPath.split('/').map(encodeURIComponent).join('/'), base).href;
  const opf = await fetchXml(opfUrl);

  const title = dc(opf, 'title')[0] || info.name.replace(/\.[^.]+$/, '');
  const author = dc(opf, 'creator').join('、');
  const language = dc(opf, 'language')[0] || '';

  const manifest = new Map();
  const byUrl = new Map();
  for (const it of opf.getElementsByTagName('item')) {
    const href = it.getAttribute('href');
    if (!href) continue;
    const url = new URL(href, opfUrl).href;
    const rec = { id: it.getAttribute('id'), url, type: (it.getAttribute('media-type') || '').toLowerCase(), props: it.getAttribute('properties') || '' };
    manifest.set(rec.id, rec);
    byUrl.set(normUrl(url), rec);
  }
  const spineEl = opf.getElementsByTagName('spine')[0];
  const spine = [];
  if (spineEl) {
    for (const ref of spineEl.getElementsByTagName('itemref')) {
      const item = manifest.get(ref.getAttribute('idref'));
      if (!item) continue;
      if (item.type && !/html|xml/.test(item.type)) continue;
      spine.push({ url: item.url, id: item.id, linear: ref.getAttribute('linear') !== 'no', key: decodeURIComponent(new URL(item.url).pathname.split('/book/')[1] || item.id).replace(/^[^/]+\//, '') });
    }
  }
  if (!spine.length) throw new Error('EPUB 中没有可阅读的章节');

  let toc = [];
  const navItem = [...manifest.values()].find((m) => /\bnav\b/.test(m.props));
  if (navItem) {
    try { toc = await parseNav(navItem.url); } catch (e) { console.warn('nav 解析失败', e); }
  }
  if (!toc.length) {
    const ncxId = spineEl && spineEl.getAttribute('toc');
    const ncx = (ncxId && manifest.get(ncxId)) || [...manifest.values()].find((m) => m.type === 'application/x-dtbncx+xml');
    if (ncx) {
      try { toc = await parseNcx(ncx.url); } catch (e) { console.warn('ncx 解析失败', e); }
    }
  }
  let coverUrl = null;
  const coverItem = [...manifest.values()].find((m) => /\bcover-image\b/.test(m.props));
  if (coverItem) coverUrl = coverItem.url;
  else {
    const meta = [...opf.getElementsByTagName('meta')].find((m) => m.getAttribute('name') === 'cover');
    const ci = meta && manifest.get(meta.getAttribute('content'));
    if (ci && /^image\//.test(ci.type)) coverUrl = ci.url;
  }

  const book = { kind: 'flow', format: 'epub', title, author, language, spine, toc, manifest: byUrl, coverUrl, opfUrl, xmlFirst: true };
  finishToc(book);
  return book;
}

async function parseNav(url) {
  const doc = await fetchXml(url);
  const navs = [...doc.getElementsByTagName('nav')];
  const nav = navs.find((n) => /\btoc\b/.test(epubType(n))) || navs[0];
  if (!nav) return [];
  const ol = [...nav.children].find((c) => c.localName === 'ol') || nav.getElementsByTagName('ol')[0];
  const walk = (list) => {
    const out = [];
    for (const li of [...list.children].filter((c) => c.localName === 'li')) {
      const a = [...li.children].find((c) => c.localName === 'a' || c.localName === 'span');
      const sub = [...li.children].find((c) => c.localName === 'ol');
      const label = (a ? a.textContent : li.textContent || '').replace(/\s+/g, ' ').trim();
      const href = a && a.localName === 'a' ? linkHref(a) : '';
      const node = { label: label || '（无标题）', url: href ? new URL(href, url).href : null, children: sub ? walk(sub) : [] };
      out.push(node);
    }
    return out;
  };
  return ol ? walk(ol) : [];
}

async function parseNcx(url) {
  const doc = await fetchXml(url);
  const map = doc.getElementsByTagName('navMap')[0];
  if (!map) return [];
  const walk = (parent) => {
    const out = [];
    for (const np of [...parent.children].filter((c) => c.localName === 'navPoint')) {
      const label = np.getElementsByTagName('text')[0];
      const content = [...np.children].find((c) => c.localName === 'content');
      const src = content && content.getAttribute('src');
      out.push({ label: (label ? label.textContent : '').replace(/\s+/g, ' ').trim() || '（无标题）', url: src ? new URL(src, url).href : null, children: walk(np) });
    }
    return out;
  };
  return walk(map);
}

// Map toc entries to spine indexes and derive chapter titles.
export function finishToc(book) {
  const spineIndex = new Map(book.spine.map((s, i) => [normUrl(s.url), i]));
  const titles = new Array(book.spine.length).fill(null);
  const walk = (nodes, depth) => {
    for (const n of nodes) {
      n.depth = depth;
      n.spine = n.url ? spineIndex.get(normUrl(n.url)) : undefined;
      if (n.spine === undefined) n.spine = null;
      n.fragment = n.url && n.url.includes('#') ? decodeURIComponent(n.url.split('#')[1]) : null;
      if (n.spine != null && (!titles[n.spine] || (!n.fragment && depth === 0))) {
        if (!titles[n.spine] || !n.fragment) titles[n.spine] = n.label;
      }
      walk(n.children || [], depth + 1);
    }
  };
  walk(book.toc, 0);
  let last = null;
  book.chapterTitles = titles.map((t, i) => {
    if (t) last = t;
    return t || (last ? last : `第 ${i + 1} 部分`);
  });
  book.spineIndexOf = (url) => {
    const k = normUrl(stripHash(url));
    return spineIndex.has(k) ? spineIndex.get(k) : -1;
  };
  book.isImageUrl = (url) => {
    const rec = book.manifest && book.manifest.get(normUrl(url));
    if (rec && rec.type) return /^image\//.test(rec.type);
    return /\.(png|jpe?g|gif|webp|bmp|svg|avif|tiff?)(\?|#|$)/i.test(url);
  };
}

export async function loadHtmlBook(info) {
  const url = new URL(info.entryUrl, location.href).href;
  const ch = await loadChapterDoc(url, { xmlFirst: /\.xhtml?$/i.test(info.name) });
  assignHeadingIds(ch.doc);
  const toc = [];
  const stack = [{ level: 0, children: toc }];
  for (const h of ch.doc.body.querySelectorAll('h1,h2,h3,h4')) {
    const level = +h.localName[1];
    const label = (h.textContent || '').replace(/\s+/g, ' ').trim();
    if (!label) continue;
    while (stack.length > 1 && stack[stack.length - 1].level >= level) stack.pop();
    const node = { label: label.slice(0, 120), url: url + '#' + h.id, children: [] };
    stack[stack.length - 1].children.push(node);
    stack.push({ level, children: node.children });
  }
  const title = ch.title.trim() || info.name.replace(/\.[^.]+$/, '');
  const book = { kind: 'flow', format: 'html', title, author: '', language: ch.lang, spine: [{ url, id: 'main', linear: true, key: 'main' }], toc, manifest: null, coverUrl: null, xmlFirst: /\.xhtml?$/i.test(info.name), isHtmlBook: true };
  finishToc(book);
  book.chapterTitles = [title];
  return book;
}
