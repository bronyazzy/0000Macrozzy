// Full-text search across all chapters of a reflowable book.
import { fetchText, parseChapter, assignHeadingIds } from './chapter.js';
import { prepare, textNodes } from './bilingual.js';
import { searchRegex } from './flowview.js';

export class BookSearch {
  constructor(book) {
    this.book = book;
    this.cache = new Map(); // spine index -> [{bidx, text}]
    this.token = 0;
  }

  async blocks(i) {
    if (this.cache.has(i)) return this.cache.get(i);
    const sp = this.book.spine[i];
    const ch = parseChapter(await fetchText(sp.url), { xmlFirst: this.book.xmlFirst });
    if (this.book.isHtmlBook) assignHeadingIds(ch.doc);
    prepare(ch.doc.body);
    const out = [];
    for (const e of ch.doc.body.querySelectorAll('[data-bidx]')) {
      if (e.querySelector('[data-bidx]')) continue;
      const text = textNodes(e, true).map((n) => n.data).join('');
      if (text.trim()) out.push({ bidx: +e.dataset.bidx, text });
    }
    this.cache.set(i, out);
    return out;
  }

  cancel() { this.token++; }

  // onResult(list) is called with each chapter's hits; returns total count.
  async run(query, opts, onResult, onProgress) {
    const token = ++this.token;
    const q = query.trim();
    if (!q) return 0;
    let total = 0;
    const n = this.book.spine.length;
    for (let i = 0; i < n; i++) {
      if (token !== this.token) return total;
      if (onProgress) onProgress(i, n);
      let blocks;
      try { blocks = await this.blocks(i); } catch { continue; }
      const hits = [];
      for (const b of blocks) {
        const re = searchRegex(q, opts);
        let m;
        let occ = 0;
        while ((m = re.exec(b.text))) {
          if (!m[0].length) { re.lastIndex++; continue; }
          const s = Math.max(0, m.index - 36);
          const e = Math.min(b.text.length, m.index + m[0].length + 60);
          hits.push({
            index: i,
            bidx: b.bidx,
            occ,
            before: (s > 0 ? '…' : '') + b.text.slice(s, m.index).replace(/\s+/g, ' '),
            match: m[0],
            after: b.text.slice(m.index + m[0].length, e).replace(/\s+/g, ' ') + (e < b.text.length ? '…' : ''),
          });
          occ++;
          total++;
          if (total >= 1000) break;
        }
        if (total >= 1000) break;
      }
      if (hits.length && token === this.token) onResult(hits, i);
      if (total >= 1000) break;
      if (i % 4 === 3) await new Promise((r) => setTimeout(r, 0));
    }
    if (onProgress && token === this.token) onProgress(n, n);
    return total;
  }
}
