// Custom context menu / dropdown with one level of submenus.
import { el } from './util.js';

let current = null;

export function closeMenu() {
  if (current) {
    current.remove();
    current = null;
  }
}

// items: [{label, hint, action, disabled, checked, danger, submenu: [...]}, '-' ]
export function openMenu(x, y, items, { minWidth = 190 } = {}) {
  closeMenu();
  const root = el('div', { class: 'ctx-menu', role: 'menu' });
  const build = (list, container) => {
    for (const it of list) {
      if (!it) continue;
      if (it === '-') { container.append(el('div', { class: 'ctx-sep' })); continue; }
      if (it.header) { container.append(el('div', { class: 'ctx-header' }, it.header)); continue; }
      const row = el('div', { class: 'ctx-item' + (it.disabled ? ' disabled' : '') + (it.danger ? ' danger' : ''), role: 'menuitem' },
        el('span', { class: 'ctx-check' }, it.checked ? '✓' : ''),
        el('span', { class: 'ctx-label' }, it.label),
        el('span', { class: 'ctx-hint' }, it.submenu ? '›' : (it.hint || '')));
      if (it.title) row.title = it.title;
      if (it.submenu) {
        row.classList.add('has-sub');
        const sub = el('div', { class: 'ctx-menu ctx-sub' });
        build(it.submenu, sub);
        row.append(sub);
        row.addEventListener('mouseenter', () => {
          sub.style.display = 'block';
          const r = row.getBoundingClientRect();
          const sr = sub.getBoundingClientRect();
          let left = r.width - 4;
          if (r.right + sr.width > window.innerWidth - 4) left = -sr.width + 4;
          sub.style.left = left + 'px';
          let top = -6;
          if (r.top + sr.height > window.innerHeight - 4) top = window.innerHeight - 4 - r.top - sr.height;
          sub.style.top = top + 'px';
        });
        row.addEventListener('mouseleave', () => { sub.style.display = 'none'; });
      } else if (!it.disabled) {
        row.addEventListener('click', (e) => {
          e.stopPropagation();
          closeMenu();
          if (it.action) it.action();
        });
      }
      container.append(row);
    }
  };
  build(items, root);
  root.style.minWidth = minWidth + 'px';
  root.style.left = '0px';
  root.style.top = '0px';
  document.body.append(root);
  const r = root.getBoundingClientRect();
  const left = Math.min(x, window.innerWidth - r.width - 6);
  const top = Math.min(y, window.innerHeight - r.height - 6);
  root.style.left = Math.max(4, left) + 'px';
  root.style.top = Math.max(4, top) + 'px';
  root.addEventListener('contextmenu', (e) => e.preventDefault());
  root.addEventListener('mousedown', (e) => e.stopPropagation());
  current = root;
  return root;
}

export function isMenuOpen() { return !!current; }

window.addEventListener('blur', closeMenu);
document.addEventListener('mousedown', closeMenu);
