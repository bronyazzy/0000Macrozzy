// AI chat panel (Gemini): model picker, streaming answers rendered as Markdown, reading context
// (selection / paragraph / chapter), per-book history. Network calls happen in the backend.
import { el, toast } from './util.js';
import * as api from './api.js';
import { renderMarkdown } from './markdown.js';

const THINK = [['', '思考：默认'], ['low', '思考：低'], ['medium', '思考：中'], ['high', '思考：高']];
const MAX_QUOTE = 24000;
const MAX_CHAPTER = 90000;

export class AiPanel {
  constructor(app) {
    this.app = app;
    this.root = document.getElementById('tab-ai');
    this.cfg = null;
    this.messages = [];
    this.bookId = '';
    this.job = null; // { id, msg }
    this.attach = null; // { text }
    this.seq = 0;
    this._raf = 0;
    api.on('ai-event', (e) => this._onEvent(e));
    this._build();
  }

  // ------------------------------------------------------------------ layout
  _build() {
    this.modelSel = el('select', { class: 'ai-model', title: '选择模型（列表来自你的 Gemini 账号）' });
    this.modelSel.addEventListener('change', () => this.saveConfig({ model: this.modelSel.value }));
    this.thinkSel = el('select', { class: 'ai-think', title: '思考程度：新模型支持低 / 中 / 高；“默认”由模型决定' }, THINK.map(([v, l]) => el('option', { value: v }, l)));
    this.thinkSel.addEventListener('change', () => this.saveConfig({ thinking: this.thinkSel.value }));
    this.refreshBtn = el('button', { class: 'icon-btn', title: '刷新模型列表', onclick: () => this.refreshModels(true) }, '⟳');
    this.bar = el('div', { class: 'ai-bar' }, this.modelSel, this.refreshBtn, this.thinkSel, el('span', { class: 'grow' }),
      el('button', { class: 'small-btn', title: '清空当前对话', onclick: () => this.newChat() }, '新对话'));
    this.setup = el('div', { class: 'ai-setup', hidden: true });
    this.list = el('div', { class: 'ai-msgs' });
    this.list.addEventListener('click', (e) => this._onListClick(e));
    this.attachEl = el('div', { class: 'ai-attach', hidden: true });
    this.sumBtn = el('button', { class: 'chip', title: '把本章正文发给模型做总结', onclick: () => this.summarize() }, '总结本章');
    this.quick = el('div', { class: 'ai-quick' },
      el('button', { class: 'chip', title: '解释书中选中的文字', onclick: () => this.quickAction('explain') }, '解释所选'),
      el('button', { class: 'chip', title: '翻译书中选中的文字', onclick: () => this.quickAction('translate') }, '翻译所选'),
      el('button', { class: 'chip', title: '把选中的文字附在下一个问题里', onclick: () => this.attachSelection() }, '引用所选'),
      this.sumBtn);
    this.input = el('textarea', { class: 'ai-input', rows: 3, placeholder: '输入问题，Enter 发送，Shift+Enter 换行', spellcheck: 'false' });
    this.input.addEventListener('keydown', (e) => this._onKey(e));
    this.sendBtn = el('button', { class: 'primary ai-send', onclick: () => (this.job ? this.stop() : this.send()) }, '发送');
    this.compose = el('div', { class: 'ai-compose' }, this.attachEl, this.quick, el('div', { class: 'ai-inrow' }, this.input, this.sendBtn));
    this.root.replaceChildren(this.bar, this.setup, this.list, this.compose);
  }

  async init() {
    await this.reloadConfig();
    await this.setBook(this.app.info ? this.app.info.bookId : '');
    if (this.cfg && this.cfg.hasKey && !(this.cfg.models || []).length) this.refreshModels(false, true);
  }

  async reloadConfig() {
    try { this.cfg = await api.call('aiConfig'); } catch (e) { this.cfg = null; console.error(e); }
    this._renderBar();
    this._renderSetup();
  }

  onShow() {
    this._renderBar();
    this._scrollBottom(true);
  }

  focus() { setTimeout(() => this.input.focus(), 30); }

  _renderBar() {
    const c = this.cfg || {};
    const models = c.models || [];
    const opts = models.map((m) => el('option', { value: m.id, title: [m.name, m.desc].filter(Boolean).join('\n') }, m.id));
    if (c.model && !models.some((m) => m.id === c.model)) opts.unshift(el('option', { value: c.model }, c.model));
    if (!opts.length) opts.push(el('option', { value: '' }, '（无模型）'));
    this.modelSel.replaceChildren(...opts);
    this.modelSel.value = c.model || '';
    this.thinkSel.value = c.thinking || '';
    this.bar.classList.toggle('off', !c.hasKey);
    this.sumBtn.textContent = this.app.view === this.app.pdf ? '总结本页' : '总结本章';
  }

  _renderSetup() {
    const c = this.cfg || {};
    const need = !c.hasKey;
    this.setup.hidden = !need;
    this.compose.classList.toggle('off', need);
    if (!need) { this.setup.replaceChildren(); return; }
    const input = el('input', { type: 'password', placeholder: '粘贴 Gemini API Key（AQ.… 或 AIza…）', autocomplete: 'off', spellcheck: 'false' });
    const msg = el('div', { class: 'ai-setup-msg' });
    const btn = el('button', { class: 'primary' }, '保存');
    const save = async () => {
      const k = input.value.trim();
      if (!k) { input.focus(); return; }
      btn.disabled = true;
      msg.className = 'ai-setup-msg';
      msg.textContent = '正在验证…';
      try {
        const r = await this.saveKey(k);
        if (r.warning) { msg.className = 'ai-setup-msg warn'; msg.textContent = r.warning; } else toast('已保存 API Key');
      } catch (e) {
        msg.className = 'ai-setup-msg err';
        msg.textContent = e.message;
      } finally {
        btn.disabled = false;
      }
    };
    btn.addEventListener('click', save);
    input.addEventListener('keydown', (e) => { e.stopPropagation(); if (e.key === 'Enter') save(); });
    this.setup.replaceChildren(
      el('div', { class: 'ai-setup-title' }, '使用 AI 对话需要 Gemini API Key'),
      el('div', { class: 'muted' }, c.keyBroken ? '之前保存的 Key 无法解密（可能换了 Windows 账户），请重新填写。' : 'Key 只保存在本机，并用 Windows 加密保存。'),
      el('div', { class: 'ai-setup-row' }, input, btn),
      msg,
      el('a', { href: '#', onclick: (e) => { e.preventDefault(); this.app.openExternal('https://aistudio.google.com/apikey'); } }, '在 Google AI Studio 获取 API Key →'));
  }

  // verify (when possible) and store a key; used by the panel and the settings dialog
  async saveKey(k) {
    let warning = '';
    try {
      await api.call('aiTest', k);
    } catch (e) {
      if (/无效|过期|格式|权限/.test(e.message)) throw e;
      warning = '已保存，但暂时无法验证：' + e.message;
    }
    this.cfg = await api.call('aiSetKey', k);
    if (!warning) await this.refreshModels(true, true);
    this._renderSetup();
    this._renderBar();
    this.render();
    return { warning };
  }

  async saveConfig(patch) {
    try {
      this.cfg = await api.call('aiSaveConfig', patch);
    } catch (e) {
      toast(e.message, { type: 'error' });
    }
    this._renderBar();
    return this.cfg;
  }

  async refreshModels(force, quiet) {
    if (!this.cfg || !this.cfg.hasKey) return;
    this.refreshBtn.disabled = true;
    this.refreshBtn.classList.add('spin');
    try {
      await api.call('aiModels', !!force);
      this.cfg = await api.call('aiConfig');
      this._renderBar();
      if (!quiet) toast(`已获取 ${this.cfg.models.length} 个可用模型`);
    } catch (e) {
      if (!quiet) toast('获取模型列表失败：' + e.message, { type: 'error', ms: 7000 });
    } finally {
      this.refreshBtn.disabled = false;
      this.refreshBtn.classList.remove('spin');
    }
  }

  // ------------------------------------------------------------------ conversations
  async setBook(bookId) {
    if (this.job) this.stop();
    this.bookId = bookId || '';
    this.attach = null;
    const seq = (this._bookSeq = (this._bookSeq || 0) + 1);
    let list = [];
    try { list = await api.call('aiHistory', this.bookId || '_global'); } catch { list = []; }
    if (seq !== this._bookSeq) return; // another book was opened meanwhile
    this.messages = list;
    this.render();
    this._renderBar();
  }

  newChat() {
    if (this.job) this.stop();
    this.messages = [];
    this.attach = null;
    this._persist();
    this.render();
    this.input.focus();
  }

  _persist() {
    const list = this.messages.filter((m) => !m.pending);
    api.call('aiSaveHistory', this.bookId || '_global', list).catch(() => {});
  }

  _system() {
    const c = this.cfg || {};
    let s = c.system || c.defaultSystem || '';
    if (c.includeBook !== false && this.app.book) {
      const title = this.app.book.title || '';
      const pos = this.app.view && this.app.view.getPosition ? this.app.view.getPosition() : null;
      const where = pos ? this.app.posLabel(pos) : '';
      s += `\n\n用户正在阅读：《${title}》${where ? '，' + where : ''}。`;
    }
    return s;
  }

  _contents(upTo) {
    const out = [];
    for (const m of this.messages) {
      if (m === upTo) break;
      if (m.role === 'user') out.push({ role: 'user', parts: m.parts && m.parts.length ? m.parts : [{ text: m.text || '' }] });
      else if (!m.error && ((m.parts && m.parts.length) || m.text)) out.push({ role: 'model', parts: m.parts && m.parts.length ? m.parts : [{ text: m.text }] });
    }
    return out;
  }

  // send(typed?, { title, quote, prompt })
  async send(typed, extra = {}) {
    if (this.job) return;
    if (!this.cfg || !this.cfg.hasKey) {
      this.app.openAi();
      toast('请先填写 Gemini API Key');
      return;
    }
    const fromBox = typed == null;
    const text = fromBox ? this.input.value.trim() : String(typed || '');
    const attach = extra.prompt ? null : this.attach;
    if (!text && !attach && !extra.prompt) return;
    let prompt = extra.prompt || text;
    if (attach) prompt = (text || '请解释下面这段内容。') + '\n\n"""\n' + attach.text + '\n"""';
    const user = {
      role: 'user',
      text: extra.prompt ? text : text,
      title: extra.title || '',
      quote: extra.quote != null ? extra.quote : attach ? attach.text.slice(0, 600) : '',
      parts: [{ text: prompt }],
      at: Date.now(),
    };
    if (fromBox) this.input.value = '';
    this.attach = null;
    this.messages.push(user);
    const answer = { role: 'model', text: '', parts: [], model: this.cfg.model, at: Date.now(), pending: true };
    this.messages.push(answer);
    this.render();
    await this._start(answer);
  }

  async _start(answer) {
    const id = 'c' + Date.now().toString(36) + '-' + (++this.seq);
    const contents = this._contents(answer);
    this.job = { id, msg: answer };
    this._busy(true);
    try {
      await api.call('aiChat', id, { model: this.cfg.model, thinking: this.cfg.thinking || '', system: this._system(), contents });
    } catch (e) {
      this._finish(id, { type: 'error', message: e.message });
    }
  }

  stop() {
    if (!this.job) return;
    const id = this.job.id;
    api.call('aiCancel', id).catch(() => {});
    // the backend answers with an 'aborted' event; make sure the UI never stays busy
    setTimeout(() => { if (this.job && this.job.id === id) this._finish(id, { type: 'aborted' }); }, 4000);
  }

  regenerate(i) {
    if (this.job) return;
    const m = this.messages[i];
    if (!m || m.role !== 'model' || i !== this.messages.length - 1) return;
    const answer = { role: 'model', text: '', parts: [], model: this.cfg.model, at: Date.now(), pending: true };
    this.messages[i] = answer;
    this.render();
    this._start(answer);
  }

  _onEvent(e) {
    if (!e || !this.job || e.id !== this.job.id) return;
    if (e.type === 'delta') {
      this.job.msg.text += e.text || '';
      this._scheduleStream();
      return;
    }
    this._finish(e.id, e);
  }

  _finish(id, e) {
    if (!this.job || this.job.id !== id) return;
    const m = this.job.msg;
    this.job = null;
    delete m.pending;
    if (e.type === 'done') {
      m.text = e.text || m.text;
      m.parts = e.parts || [];
      if (e.model) m.model = e.model;
      if (e.note) m.note = e.note;
      if (e.usage) m.usage = e.usage;
    } else if (e.type === 'aborted') {
      if (e.text) m.text = e.text;
      m.parts = e.parts || (m.text ? [{ text: m.text }] : []);
      m.note = '已停止';
    } else {
      if (e.text) m.text = e.text;
      m.parts = e.parts || [];
      m.error = e.message || '出错了';
    }
    this._busy(false);
    this.render();
    this._persist();
  }

  _busy(on) {
    this.sendBtn.textContent = on ? '停止' : '发送';
    this.sendBtn.classList.toggle('stop', on);
    this.root.classList.toggle('busy', on);
  }

  // ------------------------------------------------------------------ reading context
  selectionOrToast() {
    const sel = this.app.aiSelection();
    if (!sel || !sel.text.trim()) {
      toast('请先在书中选中一段文字（或在段落上点右键选择“AI 解释本段”）');
      return null;
    }
    return sel;
  }

  quickAction(kind, src) {
    const sel = src || this.selectionOrToast();
    if (!sel) return;
    const text = sel.text.trim().slice(0, MAX_QUOTE);
    const what = sel.kind === 'paragraph' ? '这一段' : '所选内容';
    const prompt = kind === 'translate'
      ? `请把下面${what}翻译成准确、通顺的简体中文，术语后用括号保留英文原文；如果原文是中文，请译成英文。只输出译文和必要的术语说明。`
      : `请结合金融 / 交易语境解释下面${what}：说明它的意思、其中的关键术语和前后逻辑。`;
    this.app.openAi(false);
    this.send('', { title: (kind === 'translate' ? '翻译' : '解释') + what, quote: text.slice(0, 600), prompt: prompt + '\n\n"""\n' + text + '\n"""' });
  }

  attachSelection(src) {
    const sel = src || this.selectionOrToast();
    if (!sel) return;
    this.attach = { text: sel.text.trim().slice(0, MAX_QUOTE) };
    this._renderAttach();
    this.app.openAi();
  }

  askWord(word, ctx) {
    const w = String(word || '').trim();
    if (!w) return;
    const s = ctx && ctx.sentence ? ctx.sentence : '';
    let p;
    if (s) {
      p = `“${w}”在下面这句话里是什么意思？请结合金融 / 交易语境给出准确的中文释义，并说明它在句中的含义和用法。\n\n原句：${s}`;
      if (ctx.sentenceZh) p += `\n参考译文：${ctx.sentenceZh}`;
    } else {
      p = `请解释英文单词或短语“${w}”在金融 / 交易领域的含义、常见搭配，并给两个例句（附中文翻译）。`;
    }
    this.app.openAi(false);
    this.send('', { title: `解释“${w}”`, quote: s, prompt: p });
  }

  async summarize() {
    let r;
    try { r = await this.app.aiChapterText(); } catch (e) { toast('读取正文失败：' + e.message, { type: 'error' }); return; }
    if (!r || !r.text || r.text.trim().length < 30) { toast('没有可总结的正文'); return; }
    const long = r.text.length > MAX_CHAPTER;
    const body = r.text.slice(0, MAX_CHAPTER);
    this.app.openAi(false);
    this.send('', {
      title: '总结' + r.label,
      quote: '',
      prompt: `请用简体中文总结下面${r.label}的内容：先用两三句话概括主旨，再分点列出核心概念、结论和关键术语（术语保留英文）。${long ? '（正文较长，这里只附上了前面一部分。）' : ''}\n\n"""\n${body}\n"""`,
    });
  }

  // ------------------------------------------------------------------ rendering
  _renderAttach() {
    if (!this.attach) { this.attachEl.hidden = true; this.attachEl.replaceChildren(); return; }
    this.attachEl.hidden = false;
    const t = this.attach.text.replace(/\s+/g, ' ');
    this.attachEl.replaceChildren(
      el('span', { class: 'lbl' }, '附带：'),
      el('span', { class: 'txt', title: this.attach.text.slice(0, 1200) }, t.length > 60 ? t.slice(0, 60) + '…' : t),
      el('button', { class: 'icon-btn', title: '不附带', onclick: () => { this.attach = null; this._renderAttach(); } }, '✕'));
  }

  render() {
    this._renderAttach();
    if (!this.messages.length) {
      this.list.replaceChildren(el('div', { class: 'ai-empty' },
        el('div', { class: 'ai-empty-title' }, '和 Gemini 讨论正在读的内容'),
        el('ul', {},
          el('li', {}, '在书中选中文字，点下方“解释所选”“翻译所选”'),
          el('li', {}, '段落右键：AI 解释本段 / AI 翻译本段；词典栏“问 AI”'),
          el('li', {}, '“总结本章”会把本章正文发给模型'),
          el('li', {}, 'Ctrl+J 打开 AI 对话；回答可复制、重新生成'))));
      return;
    }
    this.list.replaceChildren(...this.messages.map((m, i) => (m.role === 'user' ? this._userEl(m, i) : this._modelEl(m, i))));
    this._scrollBottom(true);
  }

  _userEl(m, i) {
    return el('div', { class: 'ai-msg user', dataset: { i: String(i) } },
      el('div', { class: 'ai-bubble' },
        m.title ? el('div', { class: 'ai-title' }, m.title) : null,
        m.quote ? el('div', { class: 'ai-quote', title: '点击展开 / 收起' }, m.quote) : null,
        m.text ? el('div', { class: 'ai-text' }, m.text) : null));
  }

  _modelEl(m, i) {
    const last = i === this.messages.length - 1;
    const body = el('div', { class: 'ai-md', html: m.text ? renderMarkdown(m.text) : '' });
    if (m.pending && !m.text) body.append(el('span', { class: 'ai-typing' }, '正在思考'));
    const node = el('div', { class: 'ai-msg model' + (m.pending ? ' streaming' : '') + (m.error ? ' failed' : ''), dataset: { i: String(i) } }, body);
    if (m.note) node.append(el('div', { class: 'ai-note' }, m.note));
    if (m.error) node.append(el('div', { class: 'ai-err' }, m.error));
    if (!m.pending) {
      node.append(el('div', { class: 'ai-meta' },
        el('span', { class: 'ai-model-tag', title: m.usage ? `输入 ${m.usage.prompt} · 输出 ${m.usage.output}${m.usage.thoughts ? ' · 思考 ' + m.usage.thoughts : ''} tokens` : '' }, m.model || ''),
        el('span', { class: 'grow' }),
        m.text ? el('button', { class: 'icon-btn', title: '复制回答', dataset: { act: 'copy' } }, '⧉') : null,
        last ? el('button', { class: 'icon-btn', title: m.error ? '重试' : '重新生成', dataset: { act: 'regen' } }, '↻') : null));
    }
    return node;
  }

  _scheduleStream() {
    if (this._raf) return;
    this._raf = requestAnimationFrame(() => {
      this._raf = 0;
      if (!this.job) return;
      const i = this.messages.indexOf(this.job.msg);
      const node = this.list.querySelector(`.ai-msg[data-i="${i}"] .ai-md`);
      if (!node) { this.render(); return; }
      const stick = this._nearBottom();
      node.innerHTML = renderMarkdown(this.job.msg.text);
      if (stick) this._scrollBottom();
    });
  }

  _nearBottom() {
    const l = this.list;
    return l.scrollHeight - l.scrollTop - l.clientHeight < 80;
  }

  _scrollBottom(force) {
    if (force || this._nearBottom()) this.list.scrollTop = this.list.scrollHeight;
  }

  _onListClick(e) {
    const a = e.target.closest('a[data-ext]');
    if (a) { e.preventDefault(); this.app.openExternal(a.getAttribute('href')); return; }
    const q = e.target.closest('.ai-quote');
    if (q) { q.classList.toggle('open'); return; }
    const btn = e.target.closest('[data-act]');
    if (!btn) return;
    const i = +btn.closest('.ai-msg').dataset.i;
    const m = this.messages[i];
    if (!m) return;
    if (btn.dataset.act === 'copy') this.app.copyOut(m.text);
    else if (btn.dataset.act === 'regen') this.regenerate(i);
  }

  _onKey(e) {
    e.stopPropagation();
    if (e.key === 'Enter' && !e.shiftKey && !e.isComposing && e.keyCode !== 229) {
      e.preventDefault();
      if (!this.job) this.send();
    } else if (e.key === 'Escape') {
      this.input.blur();
      this.app.refocusReader();
    } else if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'j') {
      e.preventDefault();
    }
  }
}
