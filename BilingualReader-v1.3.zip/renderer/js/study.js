// Learning hub: today's summary and streak (vocabulary tab + start screen), the statistics dialog,
// reading-time tracking and the spaced-repetition review session (flashcards).
import { el, toast, escapeHtml } from './util.js';
import * as api from './api.js';
import { formsRegex } from './dictpanel.js';
import { STATE_LABEL } from './vocabstate.js';

export { STATE_LABEL };

function fmtMin(sec) {
  const m = Math.round((sec || 0) / 60);
  if (m < 60) return `${m} 分钟`;
  return `${Math.floor(m / 60)} 小时${m % 60 ? ' ' + (m % 60) + ' 分' : ''}`;
}

export class StudyHub {
  constructor(app) {
    this.app = app;
    this.box = document.getElementById('vocab-study');
    this.startBox = document.getElementById('start-study');
    this.stats = null;
    this.pending = 0;
    this.lastAct = 0;
    this.review = new ReviewSession(app, this);
    for (const ev of ['mousemove', 'keydown', 'wheel', 'mousedown']) {
      window.addEventListener(ev, () => this.activity(), { passive: true, capture: true });
    }
    this._t1 = setInterval(() => this.tick(), 15000);
    this._t2 = setInterval(() => this.flush(), 60000);
  }

  activity() { this.lastAct = Date.now(); }

  // 15 s of reading time when a book is open, the window has focus and the reader was active recently
  tick(force) {
    if (!this.app.view || !this.app.info || this.review.open) return;
    if (!force && (document.hidden || !document.hasFocus() || Date.now() - this.lastAct > 120000)) return;
    this.pending += 15;
  }

  async flush() {
    if (this.pending <= 0) return;
    const s = this.pending;
    this.pending = 0;
    try { await api.call('statsRead', s); } catch { this.pending += s; return; }
    this.refresh();
  }

  async init() { await this.refresh(); }

  async refresh() {
    try { this.stats = await api.call('studyStats'); } catch { return; }
    this.render();
  }

  todo() {
    const s = this.stats;
    if (!s) return 0;
    const limit = +this.app.settings.srsNewPerDay || 20;
    return s.totals.due + Math.min(s.totals.new, Math.max(0, limit - (s.today.newLearned || 0)));
  }

  _card(where) {
    const s = this.stats;
    const t = s.today || {};
    const todo = this.todo();
    return el('div', { class: 'study-card ' + where },
      el('div', { class: 'sc-top' },
        el('span', { class: 'sc-streak', title: '连续学习天数：当天阅读满 1 分钟或复习过生词就算一天' }, `🔥 连续 ${s.streak} 天`),
        el('span', { class: 'grow' }),
        el('a', { href: '#', onclick: (e) => { e.preventDefault(); this.openStats(); } }, '学习统计')),
      el('div', { class: 'sc-today' }, `今天：阅读 ${fmtMin(t.read)} · 查词 ${t.lookups || 0} · 新词 ${t.added || 0} · 复习 ${t.reviewed || 0}`),
      el('div', { class: 'sc-actions' },
        el('button', { class: todo ? 'primary review-btn' : 'review-btn', disabled: !s.totals.words, title: '快捷键 Ctrl+R', onclick: () => this.startReview() },
          !s.totals.words ? '生词本还是空的' : todo ? `开始复习（${todo}）` : '今天的复习已完成 ✓'),
        el('span', { class: 'sc-words' }, s.totals.words ? `生词 ${s.totals.words} · 已掌握 ${s.totals.mastered}` : '')));
  }

  render() {
    if (!this.stats) return;
    if (this.box) this.box.replaceChildren(this._card('in-vocab'));
    if (this.startBox) this.startBox.replaceChildren(this._card('on-start'));
    const badge = document.getElementById('vocab-count');
    const todo = this.todo();
    if (badge) {
      badge.textContent = todo ? String(todo) : this.stats.totals.words ? String(this.stats.totals.words) : '';
      badge.classList.toggle('due', !!todo);
      badge.title = todo ? `今天待复习 ${todo} 个` : '';
    }
  }

  startReview() { this.review.start(); }

  async openStats() {
    await this.refresh();
    const s = this.stats;
    if (!s) return;
    const modal = document.getElementById('modal');
    const close = () => { modal.hidden = true; modal.replaceChildren(); this.app.modalOpen = false; this.app.refocusReader(); };
    const mins = s.days.map((d) => Math.round((d.read || 0) / 60));
    const maxM = Math.max(10, ...mins);
    const maxR = Math.max(10, ...s.days.map((d) => d.reviewed || 0));
    const chart = (vals, max, cls, tip) => el('div', { class: 'chart' }, s.days.map((d, i) => el('div', { class: 'bar-wrap', title: tip(d, vals[i]) },
      el('div', { class: 'bar ' + cls + (vals[i] ? '' : ' zero'), style: { height: Math.round((vals[i] / max) * 100) + '%' } }),
      el('span', { class: 'bar-day' }, i % 5 === 4 || i === 29 ? d.day.slice(5).replace('-', '/') : ''))));
    const tile = (v, l) => el('div', { class: 'tile' }, el('b', {}, String(v)), el('span', {}, l));
    const tot = s.totals;
    modal.replaceChildren(el('div', { class: 'modal-box stats-box' },
      el('div', { class: 'modal-head' }, el('span', {}, '学习统计'), el('button', { class: 'icon-btn', onclick: close }, '✕')),
      el('div', { class: 'modal-pad' },
        el('div', { class: 'tiles' },
          tile(s.streak + ' 天', '连续学习'), tile(s.activeDays + ' 天', '累计学习'), tile(fmtMin(s.readAll), '累计阅读'),
          tile(tot.words, '生词'), tile(tot.mastered, '已掌握'), tile(tot.due + ' / ' + tot.dueTomorrow, '待复习 / 明天')),
        el('div', { class: 'chart-title' }, '近 30 天阅读时长（分钟）'),
        chart(mins, maxM, 'read', (d, v) => `${d.day}：阅读 ${v} 分钟 · 查词 ${d.lookups || 0} · 新词 ${d.added || 0}`),
        el('div', { class: 'chart-title' }, '近 30 天复习（个）'),
        chart(s.days.map((d) => d.reviewed || 0), maxR, 'rev', (d, v) => `${d.day}：复习 ${v} 个，记得 ${d.correct || 0} 个${d.ai ? ' · AI 提问 ' + d.ai + ' 次' : ''}${d.notes ? ' · 笔记 ' + d.notes + ' 条' : ''}`),
        el('div', { class: 'muted small' }, '阅读时长只统计打开书、窗口在前台且两分钟内有操作的时间。')),
      el('div', { class: 'modal-foot' },
        el('button', { onclick: close }, '关闭'),
        el('button', { class: 'primary', disabled: !tot.words, onclick: () => { close(); this.startReview(); } }, '开始复习'))));
    modal.hidden = false;
    modal.onclick = (e) => { if (e.target === modal) close(); };
    this.app.modalOpen = true;
  }
}

// ---------------------------------------------------------------- review session

export class ReviewSession {
  constructor(app, hub) {
    this.app = app;
    this.hub = hub;
    this.root = document.getElementById('review');
    this.open = false;
    this.onKey = (e) => this._key(e);
  }

  async start() {
    let q;
    try { q = await api.call('vocabQueue', +this.app.settings.srsNewPerDay || 20); } catch (e) { toast('无法开始复习：' + e.message, { type: 'error' }); return; }
    if (!q.items.length) {
      toast(q.newWaiting ? `今天的新词已学完（每天 ${this.app.settings.srsNewPerDay || 20} 个，可在设置 → 学习中调整）` : '今天没有需要复习的单词');
      return;
    }
    this.queue = q.items;
    this.total = q.items.length;
    this.done = 0;
    this.right = 0;
    this.again = new Set();
    this.card = null;
    this.open = true;
    this.app.modalOpen = true;
    this.root.hidden = false;
    document.addEventListener('keydown', this.onKey, true);
    for (const f of document.querySelectorAll('iframe')) try { f.contentDocument.addEventListener('keydown', this.onKey, true); } catch { /* ignore */ }
    this._next();
  }

  close() {
    if (!this.open) return;
    this.open = false;
    this.root.hidden = true;
    this.root.replaceChildren();
    this.app.modalOpen = false;
    document.removeEventListener('keydown', this.onKey, true);
    for (const f of document.querySelectorAll('iframe')) try { f.contentDocument.removeEventListener('keydown', this.onKey, true); } catch { /* ignore */ }
    try { window.speechSynthesis && window.speechSynthesis.cancel(); } catch { /* ignore */ }
    this.hub.refresh();
    this.app.refreshVocab();
    this.app.refocusReader();
  }

  _key(e) {
    if (!this.open) return;
    const k = e.key;
    if (k === 'Escape') { e.preventDefault(); e.stopPropagation(); this.close(); return; }
    if (!this.card) { if (k === 'Enter' || k === ' ') { e.preventDefault(); e.stopPropagation(); this.close(); } return; }
    if (!this.card.shown && (k === ' ' || k === 'Enter')) { e.preventDefault(); e.stopPropagation(); this._reveal(); return; }
    if (this.card.shown && /^[1-4]$/.test(k)) { e.preventDefault(); e.stopPropagation(); this._grade(+k - 1); return; }
    if (k.toLowerCase() === 'r' && !e.ctrlKey) { e.preventDefault(); e.stopPropagation(); this.app.speak(this.card.item.word); }
  }

  _frame(...body) {
    const pct = this.total ? Math.round((this.done / this.total) * 100) : 0;
    this.root.replaceChildren(el('div', { class: 'rv-box' },
      el('div', { class: 'rv-head' },
        el('span', { class: 'rv-title' }, '生词复习'),
        el('span', { class: 'rv-prog' }, `${Math.min(this.done + (this.card ? 1 : 0), this.total)} / ${this.total}`),
        el('div', { class: 'rv-bar' }, el('i', { style: { width: pct + '%' } })),
        el('button', { class: 'icon-btn', title: '结束复习（Esc）', onclick: () => this.close() }, '✕')),
      ...body));
  }

  _next() {
    const item = this.queue.shift();
    if (!item) { this._finish(); return; }
    this.card = { item, shown: false };
    const x = item;
    const re = x.sentence ? formsRegex(x.word, [x.word], 'gi') : null;
    const sent = x.sentence ? escapeHtml(x.sentence).replace(re || /$^/, (m) => `<mark>${m}</mark>`) : '';
    this.sentEl = sent ? el('div', { class: 'rv-sent', html: sent }) : null;
    this.backEl = el('div', { class: 'rv-back', hidden: true });
    this.btnEl = el('div', { class: 'rv-btns' }, el('button', { class: 'primary rv-show', onclick: () => this._reveal() }, '显示答案（空格）'));
    this._frame(
      el('div', { class: 'rv-card' },
        el('div', { class: 'rv-state ' + (x.state || 'new') }, STATE_LABEL[x.state] || '新词'),
        el('div', { class: 'rv-word' }, x.word,
          el('button', { class: 'icon-btn rv-say', title: '朗读（R）', onclick: () => this.app.speak(x.word) }, '🔊')),
        x.phonetic ? el('div', { class: 'rv-ph' }, x.phonetic) : null,
        this.sentEl,
        x.bookTitle || x.chapter ? el('div', { class: 'rv-src' }, [x.bookTitle ? '《' + x.bookTitle + '》' : '', x.chapter].filter(Boolean).join(' · ')) : null,
        this.backEl),
      this.btnEl);
    if (this.app.settings.reviewSpeak !== false) this.app.speak(x.word);
  }

  async _reveal() {
    const c = this.card;
    if (!c || c.shown) return;
    c.shown = true;
    const x = c.item;
    let def = x.def;
    if (!def) {
      try {
        const r = await api.call('lookup', x.word, { noStats: true });
        def = shortDefOf(r);
        if (def) api.call('vocabUpdate', x.id, { def }).catch(() => {});
      } catch { /* ignore */ }
    }
    if (this.card !== c) return;
    this.backEl.replaceChildren(...[
      el('div', { class: 'rv-def' }, def || '（没有保存释义，可在词典中查看）'),
      x.sentenceZh ? el('div', { class: 'rv-zh' }, x.sentenceZh) : null,
      x.note ? el('div', { class: 'rv-note' }, '笔记：' + x.note) : null,
      el('div', { class: 'rv-links' },
        el('a', { href: '#', onclick: (e) => { e.preventDefault(); this.app.lookup(x.word, x.sentence ? { sentence: x.sentence, sentenceZh: x.sentenceZh } : null); toast('已在词典栏查询，结束复习后可查看'); } }, '在词典中查看'),
        x.pos && this.app.info && this.app.info.bookId === x.bookId ? el('a', { href: '#', onclick: (e) => { e.preventDefault(); const p = x.pos; this.close(); this.app.jumpTo(p); } }, '跳到原文') : null),
    ].filter(Boolean));
    this.backEl.hidden = false;
    const p = x.preview || ['10 分钟', '1 天', '1 天', '4 天'];
    const names = ['忘了', '模糊', '记得', '简单'];
    this.btnEl.replaceChildren(...names.map((n, i) => el('button', { class: 'rv-grade g' + i, onclick: () => this._grade(i) },
      el('b', {}, n), el('small', {}, `${i + 1} · ${p[i]}`))));
  }

  async _grade(g) {
    const c = this.card;
    if (!c || !c.shown || c.busy) return;
    c.busy = true;
    let r;
    try { r = await api.call('vocabGrade', c.item.id, g); } catch (e) { toast('保存失败：' + e.message, { type: 'error' }); c.busy = false; return; }
    if (g === 0) {
      // show it again later in this session
      this.again.add(c.item.id);
      this.queue.splice(Math.min(3, this.queue.length), 0, { ...c.item, srs: r.srs, state: r.state, preview: r.preview });
      this.total++;
    } else if (!this.again.has(c.item.id) && g >= 2) {
      this.right++;
    }
    this.done++;
    this.card = null;
    this._next();
  }

  _finish() {
    this.card = null;
    const uniq = this.done - this.again.size;
    const rate = uniq > 0 ? Math.round((this.right / Math.max(1, uniq)) * 100) : 0;
    this._frame(el('div', { class: 'rv-card rv-done' },
      el('div', { class: 'rv-word' }, '🎉 今天的复习完成了'),
      el('div', { class: 'rv-sum' }, `一共复习 ${this.done} 次，第一次就记得 ${this.right} 个（${rate}%）。`),
      el('div', { class: 'rv-sum muted' }, '记得的词会隔得越来越久再出现；忘了的词已经安排在近期重复。')),
      el('div', { class: 'rv-btns' }, el('button', { class: 'primary', onclick: () => this.close() }, '完成（Enter）')));
    this.hub.refresh();
  }
}

// a one-line definition from a lookup result (built-in finance meaning first)
export function shortDefOf(r) {
  for (const s of (r && r.sections) || []) {
    if (s.type === 'builtin') return [...(s.fin || []), ...(s.gen || [])].slice(0, 2).join('；');
    if (s.type === 'csv' && s.items && s.items[0]) return String(s.items[0].def || s.items[0].zh || s.items[0].meaning || '').slice(0, 120);
    if (s.type === 'mdx' && s.html) {
      const d = document.createElement('div');
      d.innerHTML = s.html;
      return d.textContent.replace(/\s+/g, ' ').trim().slice(0, 120);
    }
  }
  return '';
}
