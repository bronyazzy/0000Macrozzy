// Reflowable view for EPUB chapters and HTML files, rendered in a same-origin iframe.
import { prepare, buildPlan, renderPlan, groupEls, applyAlignOp, countsOf, textNodes } from './bilingual.js';
import { fetchText, parseChapter, linkHref, assignHeadingIds, epubType } from './chapter.js';
import { attachCopy, serializeRange, serializeEls, langAt } from './copy.js';
import { sentenceAt, hasHan, sentences } from './textlang.js';
import { throttle, debounce, clamp, stripHash, sleep } from './util.js';
import { formsRegex } from './dictpanel.js';

const BILINGUAL_MODES = new Set(['two', 'stack', 'en', 'zh']);

function waitLoad(link, ms = 2500) {
  return new Promise((resolve) => {
    let done = false;
    const fin = () => { if (!done) { done = true; resolve(); } };
    link.addEventListener('load', fin, { once: true });
    link.addEventListener('error', fin, { once: true });
    setTimeout(fin, ms);
  });
}

const BLOCK_SEL = 'p,li,td,th,dt,dd,h1,h2,h3,h4,h5,h6,blockquote,pre,figcaption,caption,div,section,article,aside,table,tr,.br-cell';

function isVisible(e) {
  return !!(e && e.getClientRects().length);
}

export class FlowView {
  constructor(app) {
    this.app = app;
    this.host = document.getElementById('flow-host');
    this.book = null;
    this.index = -1;
    this.frame = null;
    this.doc = null;
    this.win = null;
    this.plan = null;
    this.mode = 'original';
    this.effMode = 'original';
    this.textCache = new Map();
    this.token = 0;
    this.overscroll = 0;
    this.userMoved = false;
    this.onScroll = throttle(() => this._scrolled(), 120);
    this.saveSoon = debounce(() => this.app.savePosition(), 900);
  }

  async open(book, target) {
    this.book = book;
    this.textCache.clear();
    const t = target || {};
    await this.show(clamp(t.index || 0, 0, book.spine.length - 1), t);
  }

  close() {
    this.token++;
    for (const f of this.host.querySelectorAll('iframe')) f.remove();
    this.frame = this.doc = this.win = this.plan = null;
    this.book = null;
    this.index = -1;
  }

  get chapterKey() {
    const sp = this.book && this.book.spine[this.index];
    return sp ? sp.key : 'main';
  }

  async _text(url) {
    if (this.textCache.has(url)) return this.textCache.get(url);
    const t = await fetchText(url);
    this.textCache.set(url, t);
    if (this.textCache.size > 8) this.textCache.delete(this.textCache.keys().next().value);
    return t;
  }

  // target: {bidx, frac} | {fragment} | {end} | {chapterFrac} | {search:{bidx, occ, query}}
  async show(index, target = {}) {
    const book = this.book;
    if (!book) return;
    index = clamp(index, 0, book.spine.length - 1);
    const token = ++this.token;
    const sp = book.spine[index];
    let text;
    try {
      text = await this._text(sp.url);
    } catch (e) {
      this.app.toast('章节读取失败：' + e.message, 'error');
      return;
    }
    if (token !== this.token) return;
    const ch = parseChapter(text, { xmlFirst: book.xmlFirst });
    if (book.isHtmlBook) assignHeadingIds(ch.doc);

    const frame = document.createElement('iframe');
    frame.className = 'book-frame pending';
    frame.setAttribute('title', '正文');
    this.host.append(frame);
    const doc = frame.contentDocument;
    doc.open();
    doc.write('<!DOCTYPE html><html><head><meta charset="utf-8"></head><body></body></html>');
    doc.close();
    const win = frame.contentWindow;
    const base = doc.createElement('base');
    base.href = sp.url;
    doc.head.append(base);
    const html = doc.documentElement;
    if (ch.lang) html.lang = ch.lang;
    if (ch.htmlClass) html.className = ch.htmlClass;
    const loads = [];
    for (const s of ch.styles) {
      if (s.type === 'link' && s.href) {
        let href;
        try { href = new URL(s.href, sp.url).href; } catch { continue; }
        const l = doc.createElement('link');
        l.rel = 'stylesheet';
        l.href = href;
        loads.push(waitLoad(l));
        doc.head.append(l);
      } else if (s.type === 'style') {
        const st = doc.createElement('style');
        st.textContent = s.text;
        doc.head.append(st);
      }
    }
    const appCss = doc.createElement('link');
    appCss.rel = 'stylesheet';
    appCss.href = new URL('css/book.css', location.href).href;
    loads.push(waitLoad(appCss));
    doc.head.append(appCss);
    const vars = doc.createElement('style');
    vars.id = 'br-vars';
    doc.head.append(vars);
    this._attach(doc, win);

    const body = doc.importNode(ch.doc.body, true);
    html.replaceChild(body, doc.body);
    const model = prepare(body);
    const overrides = ((this.app.bookData && this.app.bookData.align) || {})[sp.key] || {};
    const plan = buildPlan(model, overrides);
    const eff = BILINGUAL_MODES.has(this.mode) && plan.bilingual ? this.mode : 'original';
    if (eff !== 'original') renderPlan(plan, doc);
    this._chapterNav(doc, index);
    await Promise.all(loads);
    if (token !== this.token) { frame.remove(); return; }

    const old = [...this.host.querySelectorAll('iframe')].filter((f) => f !== frame);
    this.frame = frame;
    this.doc = doc;
    this.win = win;
    this.plan = plan;
    this.index = index;
    this.effMode = eff;
    this.applySettings(this.app.settings);
    this.userMoved = false;
    this.restore(target);
    frame.classList.remove('pending');
    for (const f of old) f.remove();
    this.app.onChapterShown(this, plan);
    try { win.focus(); } catch { /* ignore */ }
    // re-apply the position while late images change the layout
    const t0 = Date.now();
    const reapply = () => {
      if (this.doc !== doc || this.userMoved || Date.now() - t0 > 2500) return;
      this.restore(target, true);
    };
    doc.addEventListener('load', reapply, true);
    setTimeout(reapply, 400);
    setTimeout(reapply, 1200);
    this._scrolled(true);
    this.saveSoon();
  }

  _chapterNav(doc, index) {
    const n = this.book.spine.length;
    if (n <= 1) return;
    const nav = doc.createElement('div');
    nav.className = 'br-ui br-chapter-nav';
    const mk = (label, action, disabled) => {
      const b = doc.createElement('button');
      b.className = 'br-ui';
      b.textContent = label;
      b.dataset.brAction = action;
      if (disabled) b.disabled = true;
      return b;
    };
    nav.append(mk('‹ 上一章', 'prev', index === 0), mk(`${index + 1} / ${n}`, 'toc', false), mk('下一章 ›', 'next', index >= n - 1));
    doc.body.append(nav);
  }

  _attach(doc, win) {
    attachCopy(doc, {
      getMode: () => this.effMode,
      onCopied: (lang) => this.app.flashStatus(lang === 'en' ? '已复制英文' : lang === 'zh' ? '已复制中文' : '已复制'),
    });
    doc.addEventListener('click', (e) => this._onClick(e), true);
    doc.addEventListener('dblclick', (e) => this._onDblClick(e));
    doc.addEventListener('mouseup', (e) => this._onMouseUp(e));
    doc.addEventListener('mousedown', (e) => {
      this.userMoved = true;
      this.downAt = { x: e.clientX, y: e.clientY };
      this.app.closeMenus();
      this.app.dismissOverlay();
      if (e.button === 3) { e.preventDefault(); this.app.goBack(); return; }
      // A new drag always starts a new selection (instead of dragging the old selected text).
      if (e.button === 0 && !e.shiftKey && e.detail === 1) {
        const sel = doc.getSelection();
        if (sel && !sel.isCollapsed && !(e.target.closest && e.target.closest('a,img,image,button'))) sel.removeAllRanges();
      }
    }, true);
    doc.addEventListener('dragstart', (e) => {
      if (!(e.target && e.target.nodeType === 1 && e.target.closest('img,a'))) e.preventDefault();
    });
    doc.addEventListener('contextmenu', (e) => this._onContextMenu(e));
    doc.addEventListener('keydown', (e) => {
      if (['ArrowUp', 'ArrowDown', 'PageUp', 'PageDown', ' ', 'Home', 'End'].includes(e.key)) this.userMoved = true;
      this.app.onKeyDown(e, 'book');
    });
    doc.addEventListener('wheel', (e) => this._onWheel(e), { passive: true });
    win.addEventListener('scroll', this.onScroll, { passive: true });
    doc.addEventListener('mousemove', throttle((e) => this._onMouseMove(e), 40));
    doc.addEventListener('mouseleave', () => { this.app.hidePairHandle(true); this.app.hideVocabTip(); });
    doc.addEventListener('error', (e) => this._onResError(e), true);
    doc.addEventListener('dragover', (e) => { e.preventDefault(); this.app.onDragOver(e); });
    doc.addEventListener('drop', (e) => this.app.onDrop(e));
  }

  // ------------------------------------------------------------------ settings / modes
  applySettings(s) {
    if (!this.doc) return;
    const html = this.doc.documentElement;
    const v = this.doc.getElementById('br-vars');
    const ratio = clamp(+s.colRatio || 50, 25, 75);
    const theme = this.app.themeColors();
    v.textContent = `:root{--br-fs:${s.fontSize}px;--br-lh:${s.lineHeight};--br-width:${s.pageWidth}px;` +
      `--br-cols:minmax(0,${ratio}fr) minmax(0,${100 - ratio}fr);--br-gap:${s.gutter}px;--br-para:${s.paraSpacing}em;` +
      `--br-bg:${theme.bg};--br-fg:${theme.fg};--br-zh-fg:${s.zhColor || 'inherit'};--br-link:${theme.link};` +
      `--br-font-en:${s.fontEn || 'inherit'};--br-font-zh:${s.fontZh || 'inherit'};}`;
    const cls = [...html.classList].filter((c) => !c.startsWith('br-'));
    cls.push('br-root', 'br-mode-' + this.effMode, 'br-theme-' + theme.name);
    if (s.overrideTypography) cls.push('br-ov');
    if (s.showPairSep) cls.push('br-sep');
    if (s.zhLeft) cls.push('br-zh-left');
    if (s.fontEn) cls.push('br-font-en');
    if (s.fontZh) cls.push('br-font-zh');
    if (this.plan && this.plan.bilingual) cls.push('br-bilingual');
    if ((s.blurMode === 'zh' || s.blurMode === 'en') && (this.effMode === 'two' || this.effMode === 'stack')) cls.push('br-hide-' + s.blurMode);
    html.className = cls.join(' ');
  }

  async setMode(mode) {
    const prev = this.mode;
    this.mode = mode;
    if (!this.doc) return;
    const pos = this.getPosition();
    const wantEff = BILINGUAL_MODES.has(mode) && this.plan && this.plan.bilingual ? mode : 'original';
    if (wantEff === this.effMode && prev !== mode && wantEff === 'original') return;
    const needRerender = (wantEff === 'original') !== (this.effMode === 'original');
    if (needRerender) {
      await this.show(this.index, pos);
    } else {
      this.effMode = wantEff;
      this.applySettings(this.app.settings);
      this.restore(pos);
      this.app.onChapterShown(this, this.plan);
    }
  }

  // ------------------------------------------------------------------ positions
  findBidx(n) {
    if (!this.doc) return null;
    const all = this.doc.querySelectorAll(`[data-bidx="${n}"]`);
    for (const e of all) if (isVisible(e)) return e;
    const row = all[0] && all[0].closest('.br-row');
    if (row && isVisible(row)) return row;
    // nearest visible block before it
    const list = [...this.doc.querySelectorAll('[data-bidx]')];
    let best = null;
    for (const e of list) {
      if (+e.dataset.bidx > n) break;
      if (isVisible(e)) best = e;
    }
    return best;
  }

  _blockAtTop() {
    const doc = this.doc;
    const w = this.win.innerWidth;
    const xs = [];
    const cell = doc.querySelector('.br-row.br-group:not(.br-no-en) .br-cell.br-en');
    if (cell && isVisible(cell)) { const r = cell.getBoundingClientRect(); xs.push(r.left + Math.min(40, r.width / 2)); }
    xs.push(w / 2, w / 3, w * 0.66);
    for (let y = 6; y < Math.min(200, this.win.innerHeight); y += 14) {
      for (const x of xs) {
        const e = doc.elementFromPoint(x, y);
        const b = e && e.closest && e.closest('[data-bidx]');
        if (b) return b;
      }
    }
    // fallback: first block whose bottom is below the top edge
    for (const e of doc.querySelectorAll('[data-bidx]')) {
      const r = e.getBoundingClientRect();
      if (r.bottom > 4 && r.height > 0) return e;
    }
    return null;
  }

  getPosition() {
    if (!this.doc) return null;
    const se = this.doc.scrollingElement;
    const max = Math.max(1, se.scrollHeight - this.win.innerHeight);
    const chapterFrac = clamp(se.scrollTop / max, 0, 1);
    const b = this._blockAtTop();
    const pos = { kind: 'flow', index: this.index, chapterFrac };
    if (b) {
      const r = b.getBoundingClientRect();
      pos.bidx = +b.dataset.bidx;
      pos.frac = r.height > 0 ? clamp((6 - r.top) / r.height, 0, 1) : 0;
    }
    const n = this.book.spine.length;
    pos.percent = clamp((this.index + chapterFrac) / n, 0, 1);
    return pos;
  }

  restore(target = {}, silent = false) {
    const doc = this.doc;
    if (!doc) return;
    const se = doc.scrollingElement;
    const top = (e) => e.getBoundingClientRect().top + se.scrollTop;
    if (target.fragment) {
      const t = this._fragmentEl(target.fragment);
      if (t) {
        se.scrollTop = Math.max(0, top(t) - 12);
        if (!silent) this.flash(t);
        return;
      }
    }
    if (target.search) {
      if (!silent) this.gotoSearchHit(target.search);
      else if (this._lastHitRange) this._scrollRange(this._lastHitRange);
      return;
    }
    if (target.bidx != null) {
      const e = this.findBidx(target.bidx);
      if (e) {
        se.scrollTop = Math.max(0, top(e) + (target.frac || 0) * e.getBoundingClientRect().height - 6);
        return;
      }
    }
    if (target.end) { se.scrollTop = se.scrollHeight; return; }
    if (target.chapterFrac != null) { se.scrollTop = target.chapterFrac * Math.max(0, se.scrollHeight - this.win.innerHeight); return; }
    if (!silent) se.scrollTop = 0;
  }

  _fragmentEl(frag) {
    const doc = this.doc;
    let t = doc.getElementById(frag);
    if (!t) { try { t = doc.getElementsByName(frag)[0]; } catch { t = null; } }
    if (!t) return null;
    if (!isVisible(t)) {
      const row = t.closest('.br-row');
      if (row && isVisible(row)) return row;
      let p = t;
      while (p && !isVisible(p)) p = p.nextElementSibling || p.parentElement;
      return p || t;
    }
    return t;
  }

  flash(e) {
    const target = e.closest('[data-bidx]') || e;
    target.classList.remove('br-flash');
    void target.offsetWidth;
    target.classList.add('br-flash');
    setTimeout(() => target.classList.remove('br-flash'), 1900);
  }

  _scrolled(initial) {
    if (!this.doc) return;
    const pos = this.getPosition();
    this.app.onPositionChange(pos);
    if (!initial) this.saveSoon();
    this.app.hidePairHandle();
  }

  // ------------------------------------------------------------------ navigation
  async next() {
    if (this.index < this.book.spine.length - 1) await this.show(this.index + 1, {});
    else this.app.toast('已经是最后一章');
  }

  async prev(toEnd = true) {
    if (this.index > 0) await this.show(this.index - 1, toEnd ? { end: true } : {});
    else this.app.toast('已经是第一章');
  }

  async navigateUrl(url, push = true) {
    const idx = this.book.spineIndexOf(url);
    const frag = url.includes('#') ? decodeURIComponent(url.split('#')[1]) : null;
    if (idx < 0) { this.app.toast('链接目标不在本书中'); return; }
    if (push) this.app.pushHistory(this.getPosition());
    if (idx === this.index && this.doc) {
      if (frag) this.restore({ fragment: frag }); else this.restore({});
      this._scrolled(true);
    } else {
      await this.show(idx, frag ? { fragment: frag } : {});
    }
    if (push) this.app.showBackPill();
  }

  async goTo(pos) {
    if (!pos) return;
    if (pos.index === this.index && this.doc) {
      this.restore(pos);
      this._scrolled(true);
    } else await this.show(pos.index, pos);
  }

  scrollBy(dy) {
    if (this.doc) this.doc.scrollingElement.scrollBy({ top: dy, behavior: 'smooth' });
  }

  page(dir) {
    if (!this.doc) return;
    const se = this.doc.scrollingElement;
    const h = this.win.innerHeight;
    if (dir > 0 && se.scrollTop + h >= se.scrollHeight - 2) return this.next();
    if (dir < 0 && se.scrollTop <= 0) return this.prev(true);
    se.scrollBy({ top: dir * (h - 48), behavior: 'auto' });
    return null;
  }

  _onWheel(e) {
    this.userMoved = true;
    const se = this.doc.scrollingElement;
    const h = this.win.innerHeight;
    const atBottom = se.scrollTop + h >= se.scrollHeight - 2;
    const atTop = se.scrollTop <= 0;
    clearTimeout(this._osTimer);
    this._osTimer = setTimeout(() => { this.overscroll = 0; this.app.overscrollHint(0); }, 700);
    if (e.ctrlKey) return;
    if (e.deltaY > 0 && atBottom && this.index < this.book.spine.length - 1) {
      this.overscroll = Math.max(0, this.overscroll) + Math.min(120, e.deltaY);
      this.app.overscrollHint(this.overscroll / 360, 'next');
      if (this.overscroll > 360) { this.overscroll = 0; this.app.overscrollHint(0); this.next(); }
    } else if (e.deltaY < 0 && atTop && this.index > 0) {
      this.overscroll = Math.min(0, this.overscroll) + Math.max(-120, e.deltaY);
      this.app.overscrollHint(-this.overscroll / 360, 'prev');
      if (this.overscroll < -360) { this.overscroll = 0; this.app.overscrollHint(0); this.prev(true); }
    } else {
      this.overscroll = 0;
      this.app.overscrollHint(0);
    }
  }

  // ------------------------------------------------------------------ clicks, links, images
  _imageSrc(img) {
    if (img.localName === 'img') return img.currentSrc || img.src;
    if (img.localName === 'image') {
      const h = img.getAttribute('href') || img.getAttributeNS('http://www.w3.org/1999/xlink', 'href');
      try { return new URL(h, img.baseURI).href; } catch { return null; }
    }
    if (img.localName === 'svg') {
      const s = new XMLSerializer().serializeToString(img);
      return 'data:image/svg+xml;charset=utf-8,' + encodeURIComponent(s);
    }
    return null;
  }

  _onClick(e) {
    if (e.button !== 0) return;
    const t = e.target;
    const action = t.closest && t.closest('[data-br-action]');
    if (action) {
      e.preventDefault();
      const a = action.dataset.brAction;
      if (a === 'next') this.next();
      else if (a === 'prev') this.prev(false);
      else if (a === 'toc') this.app.showPanel('toc');
      return;
    }
    const moved = this.downAt && (Math.abs(e.clientX - this.downAt.x) > 4 || Math.abs(e.clientY - this.downAt.y) > 4);
    const hidden = t.closest && t.closest('html.br-hide-zh .br-cell.br-zh:not(.br-reveal), html.br-hide-en .br-cell.br-en:not(.br-reveal)');
    if (hidden && !moved) {
      e.preventDefault();
      e.stopPropagation();
      hidden.classList.add('br-reveal');
      return;
    }
    if (!moved && this._noteRanges && this._noteRanges.length) {
      const sel = this.doc.getSelection();
      if (!sel || sel.isCollapsed) {
        const hit = this._noteAt(e.clientX, e.clientY);
        if (hit) {
          const fr = this.frame.getBoundingClientRect();
          const r = hit.rect;
          this.app.notes.showPopover(hit.note, { left: fr.left + r.left, top: fr.top + r.top, bottom: fr.top + r.bottom, right: fr.left + r.right });
          return;
        }
      }
    }
    const a = t.closest && t.closest('a');
    if (a && linkHref(a)) {
      e.preventDefault();
      if (moved) return;
      this._followLink(a);
      return;
    }
    const img = t.closest && t.closest('img, image');
    if (img && !img.dataset.brBroken && !moved) {
      e.preventDefault();
      const src = this._imageSrc(img);
      if (src) this.app.lightbox.open(src, { alt: img.getAttribute('alt') || '' });
    }
  }

  _followLink(a) {
    const href = linkHref(a);
    let url;
    let parsed;
    try { parsed = new URL(href, a.baseURI || this.doc.baseURI); url = parsed.href; } catch { return; }
    if (parsed.origin !== location.origin && /^(https?|mailto|ftp|tel):/i.test(url)) { this.app.openExternal(url); return; }
    if (parsed.origin !== location.origin) { this.app.toast('无法打开此链接：' + url); return; }
    if (this.book.isImageUrl(url) && !url.includes('#')) {
      this.app.lightbox.open(url, { alt: (a.querySelector('img') || {}).alt || '' });
      return;
    }
    if (href.startsWith('#') || stripHash(url) === stripHash(this.book.spine[this.index].url)) {
      const frag = url.includes('#') ? decodeURIComponent(url.split('#')[1]) : '';
      this.app.pushHistory(this.getPosition());
      this.restore(frag ? { fragment: frag } : {});
      this._scrolled(true);
      this.app.showBackPill();
      return;
    }
    this.navigateUrl(url, true);
  }

  _onResError(e) {
    const t = e.target;
    if (!t || !t.localName) return;
    if (t.localName === 'img' || t.localName === 'image') this.markBroken(t);
  }

  markBroken(img) {
    if (img.dataset.brBroken) return;
    img.dataset.brBroken = '1';
    const doc = img.ownerDocument;
    let name = '';
    try { name = decodeURIComponent((this._imageSrc(img) || '').split('/').pop().split('?')[0]); } catch { name = ''; }
    const ph = doc.createElement('span');
    ph.className = 'br-ui br-img-broken';
    ph.textContent = '⚠ 图片无法显示' + (name ? '：' + name : '') + (img.getAttribute('alt') ? '（' + img.getAttribute('alt') + '）' : '');
    ph.title = '图片文件损坏或缺失，正文不受影响';
    if (img.localName === 'image') {
      const svg = img.closest('svg');
      if (svg && svg.parentNode) { svg.style.display = 'none'; svg.before(ph); }
    } else {
      img.style.display = 'none';
      img.before(ph);
    }
  }

  // ------------------------------------------------------------------ selection / lookup
  _context(range) {
    const node = range.startContainer;
    const elx = node.nodeType === 1 ? node : node.parentElement;
    const holder = elx && elx.closest('.br-seg, [data-bidx]');
    if (!holder) return { sentence: '', offset: 0 };
    const r = this.doc.createRange();
    r.setStart(holder, 0);
    r.setEnd(range.startContainer, range.startOffset);
    const raw = holder.textContent || '';
    const offset = r.toString().length;
    const lang = langAt(holder) || (hasHan(raw) ? 'zh' : 'en');
    const s = sentenceAt(raw, offset, lang);
    const sentence = s.text.replace(/\s+/g, ' ').trim();
    const before = raw.slice(s.start, offset).replace(/\s+/g, ' ');
    const ctx = { sentence, offset: Math.max(0, before.length - (before.length - before.trimStart().length)), lang, sentIndex: s.index, sentCount: s.count };
    // translation of the sentence from the paired group
    const item = this.groupFor(holder);
    if (item && lang === 'en' && item.zh.length) {
      const zhText = this._groupText(item, 'zh');
      const zs = sentences(zhText, 'zh');
      if (zs.length && zs.length === s.count) ctx.sentenceZh = zs[s.index].text;
      else ctx.sentenceZh = zhText.length > 400 ? zhText.slice(0, 400) + '…' : zhText;
    }
    ctx.chapter = this.book.chapterTitles[this.index] || '';
    ctx.pos = this.getPosition();
    return ctx;
  }

  _onDblClick(e) {
    if (!this.app.settings.lookupDblClick) return;
    const sel = this.doc.getSelection();
    if (!sel || !sel.rangeCount) return;
    const text = sel.toString().trim();
    if (!text || text.length > 60) return;
    if (e.target.closest && e.target.closest('img,image,.br-ui')) return;
    this.app.lookup(text, this._context(sel.getRangeAt(0)));
  }

  _onMouseUp(e) {
    if (e.button === 0) setTimeout(() => { const s = this.doc && this.doc.getSelection(); if (s && !s.isCollapsed) this.app.noteSelection(this, s.toString()); }, 0);
    if (e.button !== 0 || e.detail >= 2 || !this.app.settings.lookupSelection) return;
    setTimeout(() => {
      const sel = this.doc && this.doc.getSelection();
      if (!sel || sel.isCollapsed || !sel.rangeCount) return;
      const text = sel.toString().replace(/\s+/g, ' ').trim();
      if (!text) return;
      const words = text.split(' ').length;
      const ok = hasHan(text) ? text.length <= 8 && !/[，。；：！？]/.test(text) : /[A-Za-z]/.test(text) && words <= 6 && text.length <= 60 && !/[.;!?]\s/.test(text);
      if (ok) this.app.lookup(text, this._context(sel.getRangeAt(0)));
    }, 10);
  }

  // ------------------------------------------------------------------ groups
  groupFor(node) {
    if (!this.plan || !node) return null;
    const e = node.nodeType === 1 ? node : node.parentElement;
    if (!e) return null;
    if (this.effMode !== 'original') {
      const row = e.closest('.br-row.br-group');
      if (!row) return null;
      return this.plan.groups.find((g) => g.row === row) || null;
    }
    let p = e;
    while (p && p !== this.doc.body) {
      if (this.plan.unitGroup.has(p)) return this.plan.unitGroup.get(p);
      p = p.parentElement;
    }
    return null;
  }

  groupsInRange(range) {
    if (!this.plan) return [];
    const rendered = this.effMode !== 'original';
    return this.plan.groups.filter((g) => {
      const els = [...groupEls(g, 'en', rendered), ...groupEls(g, 'zh', rendered)];
      return els.some((x) => range.intersectsNode(x));
    });
  }

  _groupText(item, lang) {
    return serializeEls(groupEls(item, lang, this.effMode !== 'original'), lang).text;
  }

  groupsText(groups, lang) {
    const rendered = this.effMode !== 'original';
    if (lang === 'both') {
      return groups.map((g) => [serializeEls(groupEls(g, 'en', rendered), 'en').text, serializeEls(groupEls(g, 'zh', rendered), 'zh').text]
        .filter(Boolean).join('\n')).filter(Boolean).join('\n\n');
    }
    return groups.map((g) => serializeEls(groupEls(g, lang, rendered), lang).text).filter(Boolean).join('\n\n');
  }

  // Copy for the context menu: lang = 'en' | 'zh' | 'both'
  copyText(lang, node) {
    const sel = this.doc.getSelection();
    const hasSel = sel && !sel.isCollapsed && sel.rangeCount;
    if (hasSel) {
      const range = sel.getRangeAt(0);
      const selLang = this.doc.documentElement.dataset.brSel || langAt(sel.anchorNode);
      if (lang !== 'both' && (selLang === lang || !this.plan || !this.plan.bilingual)) return serializeRange(range, lang);
      const groups = this.groupsInRange(range);
      if (groups.length) return { text: this.groupsText(groups, lang) };
      return serializeRange(range, lang === 'both' ? 'all' : lang);
    }
    const g = this.groupFor(node);
    if (g) return { text: this.groupsText([g], lang) };
    const blk = node && (node.nodeType === 1 ? node : node.parentElement);
    const b = blk && blk.closest('[data-bidx]');
    return b ? serializeEls([b], lang === 'both' ? 'all' : lang) : { text: '' };
  }

  // ------------------------------------------------------------------ manual pairing
  async alignOp(item, op, arg) {
    const key = item.key;
    const seg = item.seg;
    const counts = applyAlignOp(countsOf(seg), item.gi, op, arg);
    if (!counts) { this.app.toast('无法执行该配对调整'); return; }
    this._saveAlign(key, { sig: seg.sig, groups: counts });
    const pos = this.getPosition();
    await this.show(this.index, pos);
    this.app.toast('已保存配对调整');
  }

  async resetAlign(scope, item) {
    const all = { ...(this.app.bookData.align || {}) };
    const ch = { ...(all[this.chapterKey] || {}) };
    if (scope === 'seg' && item) delete ch[item.key];
    else for (const k of Object.keys(ch)) delete ch[k];
    all[this.chapterKey] = ch;
    this.app.saveBookData({ align: all });
    const pos = this.getPosition();
    await this.show(this.index, pos);
    this.app.toast(scope === 'seg' ? '已恢复本段自动配对' : '已恢复本章自动配对');
  }

  _saveAlign(segKey, rec) {
    const all = { ...(this.app.bookData.align || {}) };
    const ch = { ...(all[this.chapterKey] || {}) };
    ch[segKey] = rec;
    all[this.chapterKey] = ch;
    this.app.saveBookData({ align: all });
  }

  unitIndexInGroup(item, node) {
    const e = node && (node.nodeType === 1 ? node : node.parentElement);
    if (!e) return null;
    for (const lang of ['en', 'zh']) {
      const list = item[lang];
      for (let i = 0; i < list.length; i++) {
        const u = list[i];
        const elx = u.mat || u.seg || u.el;
        if (elx && (elx === e || elx.contains(e))) return { lang, index: i };
      }
    }
    return null;
  }

  // ------------------------------------------------------------------ hover helpers
  _noteAt(x, y) {
    if (!this.doc.caretRangeFromPoint) return null;
    const c = this.doc.caretRangeFromPoint(x, y);
    if (!c) return null;
    for (const it of this._noteRanges) {
      try {
        if (!it.range.isPointInRange(c.startContainer, c.startOffset)) continue;
        for (const rect of it.range.getClientRects()) {
          if (x >= rect.left - 1 && x <= rect.right + 1 && y >= rect.top - 1 && y <= rect.bottom + 1) return { note: it.note, rect };
        }
      } catch { /* detached */ }
    }
    return null;
  }

  _onMouseMove(e) {
    if (!e.buttons && this._vocabRanges && this._vocabRanges.length) {
      const hit = this._vocabAt(e.clientX, e.clientY);
      if (hit) {
        const fr = this.frame.getBoundingClientRect();
        this.app.showVocabTip(hit.v, { left: fr.left + hit.rect.left, top: fr.top + hit.rect.top, bottom: fr.top + hit.rect.bottom });
      } else this.app.hideVocabTip();
    }
    this.app.study && this.app.study.activity();
    if (!this.plan || this.effMode === 'original' || e.buttons) { this.app.hidePairHandle(); return; }
    const row = e.target.closest && e.target.closest('.br-row.br-group');
    if (!row) { this.app.hidePairHandle(); return; }
    const item = this.plan.groups.find((g) => g.row === row);
    if (!item) return;
    this.app.showPairHandle(this, item, row);
  }

  _onContextMenu(e) {
    e.preventDefault();
    const fr = this.frame.getBoundingClientRect();
    const sel = this.doc.getSelection();
    const selText = sel && !sel.isCollapsed ? sel.toString() : '';
    const t = e.target;
    const a = t.closest && t.closest('a');
    const img = t.closest && t.closest('img:not([data-br-broken]), image');
    const item = this.groupFor(t);
    this.app.openBookMenu({
      x: fr.left + e.clientX,
      y: fr.top + e.clientY,
      view: this,
      target: t,
      selText,
      range: selText ? sel.getRangeAt(0) : null,
      link: a && linkHref(a) ? a : null,
      image: img ? this._imageSrc(img) : null,
      item,
      word: selText ? '' : this._wordAt(e.clientX, e.clientY),
    });
  }

  _wordAt(x, y) {
    const doc = this.doc;
    let range = null;
    if (doc.caretRangeFromPoint) range = doc.caretRangeFromPoint(x, y);
    if (!range || range.startContainer.nodeType !== 3) return null;
    const text = range.startContainer.data;
    let s = range.startOffset;
    let t = s;
    while (s > 0 && /[A-Za-z'’-]/.test(text[s - 1])) s--;
    while (t < text.length && /[A-Za-z'’-]/.test(text[t])) t++;
    const w = text.slice(s, t).replace(/^['’-]+|['’-]+$/g, '');
    if (!w) return null;
    const r = doc.createRange();
    r.setStart(range.startContainer, s);
    r.setEnd(range.startContainer, t);
    return { word: w, range: r };
  }

  contextFor(range) { return this._context(range); }

  // ------------------------------------------------------------------ learning overlays
  // Named CSS highlights in the book frame (search, vocabulary, notes): no DOM changes, copy stays intact.
  setHighlight(name, ranges) {
    const hl = this.win && this.win.CSS && this.win.CSS.highlights;
    if (!hl) return;
    if (ranges && ranges.length) hl.set(name, new this.win.Highlight(...ranges));
    else hl.delete(name);
  }

  // Underline every occurrence (any inflected form) of the vocabulary-book words.
  applyVocab(list) {
    this._vocabRanges = [];
    if (!this.doc) return 0;
    if (!list || !list.length) { this.setHighlight('br-vocab', null); return 0; }
    const single = new Map();
    const phrases = [];
    for (const v of list) {
      for (const f of v.forms || [v.word]) {
        const k = String(f).toLowerCase();
        if (/\s/.test(k)) phrases.push([k, v]);
        else if (!single.has(k)) single.set(k, v);
      }
    }
    const idx = this._textIndex(true);
    const found = [];
    const re = /[A-Za-z][A-Za-z'’-]*[A-Za-z]|[A-Za-z]/g;
    let m;
    while ((m = re.exec(idx.text)) && found.length < 5000) {
      const w = m[0].toLowerCase().replace(/’/g, "'");
      const v = single.get(w) || single.get(w.replace(/'s$/, ''));
      if (v) found.push([m.index, m[0].length, v]);
    }
    for (const [f, v] of phrases) {
      const pr = new RegExp('(?<![A-Za-z])' + f.replace(/[.*+?^${}()|[\]\\]/g, '\\$&').replace(/ +/g, '\\s+') + '(?![A-Za-z])', 'gi');
      while ((m = pr.exec(idx.text)) && found.length < 5000) found.push([m.index, m[0].length, v]);
    }
    this._vocabRanges = found.map(([s, n, v]) => ({ r: this._rangeAt(idx, s, n), v }));
    this.setHighlight('br-vocab', this._vocabRanges.map((x) => x.r));
    return found.length;
  }

  _vocabAt(x, y) {
    if (!this._vocabRanges || !this._vocabRanges.length || !this.doc.caretRangeFromPoint) return null;
    const c = this.doc.caretRangeFromPoint(x, y);
    if (!c || c.startContainer.nodeType !== 3) return null;
    for (const it of this._vocabRanges) {
      try {
        if (it.r.isPointInRange(c.startContainer, c.startOffset)) {
          const rect = it.r.getBoundingClientRect();
          if (x >= rect.left - 1 && x <= rect.right + 1 && y >= rect.top - 1 && y <= rect.bottom + 1) return { ...it, rect };
        }
      } catch { /* detached */ }
    }
    return null;
  }

  // Self-test: blur the Chinese (or English) side of each pair until it is clicked.
  setBlur(mode) {
    if (!this.doc) return;
    for (const c of this.doc.querySelectorAll('.br-reveal')) c.classList.remove('br-reveal');
    this.applySettings(this.app.settings);
    void mode;
  }

  // Scroll to the first occurrence of a word (any form) and flash it; returns the range or null.
  revealForms(word, forms) {
    if (!this.doc) return null;
    const idx = this._textIndex(true);
    const re = formsRegex(word, forms, 'i');
    const m = re && re.exec(idx.text);
    if (!m) return null;
    const r = this._rangeAt(idx, m.index, m[0].length);
    this.flashRange(r);
    return r;
  }

  flashRange(r) {
    const rect = r.getBoundingClientRect();
    const h = this.win.innerHeight;
    if (rect.top < 60 || rect.bottom > h - 60) this.doc.scrollingElement.scrollBy({ top: rect.top - h / 3 });
    this.userMoved = true;
    this.setHighlight('br-search-cur', [r]);
    clearTimeout(this._flashT);
    this._flashT = setTimeout(() => this.setHighlight('br-search-cur', null), 2600);
  }

  // Text-quote anchor of the current selection, for notes.
  selectionAnchor() {
    const sel = this.doc && this.doc.getSelection();
    if (!sel || sel.isCollapsed || !sel.rangeCount) return null;
    const range = sel.getRangeAt(0);
    const idx = this._textIndex(true);
    const a = this._offsetOf(idx, range.startContainer, range.startOffset);
    const b = this._offsetOf(idx, range.endContainer, range.endOffset);
    if (a < 0 || b <= a) return null;
    const quote = idx.text.slice(a, b);
    if (!quote.trim()) return null;
    const sp = this.book.spine[this.index] || {};
    return {
      quote,
      prefix: idx.text.slice(Math.max(0, a - 40), a),
      suffix: idx.text.slice(b, b + 40),
      chapter: this.index,
      chapterKey: sp.key || '',
      chapterTitle: (this.book.chapterTitles && this.book.chapterTitles[this.index]) || '',
      pos: this.getPosition(),
    };
  }

  // Find the stored quotes in the current chapter (whitespace-insensitive; prefix / suffix pick the right
  // occurrence). Returns [{ note, range }] for the notes that could be placed.
  anchorNotes(notes) {
    if (!this.doc || !notes.length) return [];
    const idx = this._textIndex(true);
    let norm = '';
    const back = [];
    let ws = false;
    for (let i = 0; i < idx.text.length; i++) {
      const ch = idx.text[i];
      if (/\s/.test(ch)) {
        if (!ws) { norm += ' '; back.push(i); }
        ws = true;
      } else {
        norm += ch;
        back.push(i);
        ws = false;
      }
    }
    const squash = (s) => String(s || '').replace(/\s+/g, ' ');
    const out = [];
    for (const n of notes) {
      let q = squash(n.quote).trim();
      if (!q) continue;
      let hits = [];
      let p = norm.indexOf(q);
      while (p >= 0 && hits.length < 50) { hits.push(p); p = norm.indexOf(q, p + 1); }
      if (!hits.length && q.length > 60) { // layout changed: place at least the beginning
        q = q.slice(0, 60);
        p = norm.indexOf(q);
        while (p >= 0 && hits.length < 50) { hits.push(p); p = norm.indexOf(q, p + 1); }
      }
      if (!hits.length) continue;
      const pre = squash(n.prefix);
      const suf = squash(n.suffix);
      const score = (h) => {
        let s = 0;
        const before = norm.slice(Math.max(0, h - pre.length), h);
        const after = norm.slice(h + q.length, h + q.length + suf.length);
        for (let i = 1; i <= Math.min(before.length, pre.length); i++) { if (before[before.length - i] === pre[pre.length - i]) s++; else break; }
        for (let i = 0; i < Math.min(after.length, suf.length); i++) { if (after[i] === suf[i]) s++; else break; }
        return s;
      };
      const best = hits.reduce((x, y) => (score(y) > score(x) ? y : x));
      const rs = back[best];
      const re = back[best + q.length - 1] + 1;
      if (rs === undefined || re === undefined || re <= rs) continue;
      out.push({ note: n, range: this._rangeAt(idx, rs, re - rs) });
    }
    return out;
  }

  // Plain text of the current chapter for AI summaries (English side only when the book is bilingual).
  chapterText() {
    if (!this.doc) return '';
    if (this.plan && this.plan.bilingual && this.plan.groups.length) {
      const en = this.groupsText(this.plan.groups, 'en');
      if (en.trim().length > 200) return en;
    }
    return (this.doc.body.innerText || '').replace(/\n{3,}/g, '\n\n').trim();
  }

  // ------------------------------------------------------------------ search highlighting
  // Visible text of the chapter with a map back to the text nodes. With sep, a newline is inserted
  // between text of different blocks so words of neighbouring paragraphs / table cells never merge.
  _textIndex(sep = false) {
    const nodes = textNodes(this.doc.body, true).filter((n) => {
      const p = n.parentElement;
      return p && !p.closest('.br-ui') && isVisible(p);
    });
    let text = '';
    const map = [];
    let lastBlock = null;
    for (const n of nodes) {
      if (sep) {
        const b = n.parentElement.closest(BLOCK_SEL);
        if (lastBlock && b !== lastBlock) text += '\n';
        lastBlock = b;
      }
      map.push({ n, start: text.length });
      text += n.data;
    }
    return { text, map };
  }

  // position of a DOM point inside a text index
  _offsetOf(idx, node, offset) {
    if (node.nodeType === 3) {
      const e = idx.map.find((x) => x.n === node);
      if (e) return e.start + Math.min(offset, node.data.length);
    }
    const r = this.doc.createRange();
    try { r.setStart(node, offset); } catch { return -1; }
    // an element boundary: the first text node at or after the point
    for (const e of idx.map) {
      try { if (r.comparePoint(e.n, 0) >= 0) return e.start; } catch { /* other tree */ }
    }
    return idx.text.length;
  }

  _rangeAt(idx, start, len) {
    const find = (pos) => {
      let lo = 0;
      let hi = idx.map.length - 1;
      while (lo < hi) {
        const mid = (lo + hi + 1) >> 1;
        if (idx.map[mid].start <= pos) lo = mid; else hi = mid - 1;
      }
      return idx.map[lo];
    };
    const a = find(start);
    const b = find(start + len - 1);
    const r = this.doc.createRange();
    r.setStart(a.n, start - a.start);
    r.setEnd(b.n, start + len - b.start);
    return r;
  }

  highlightAll(query, opts = {}) {
    const doc = this.doc;
    if (!doc || !this.win.CSS || !this.win.CSS.highlights) return 0;
    this.win.CSS.highlights.delete('br-search');
    if (!query) return 0;
    const idx = this._textIndex();
    const ranges = [];
    const re = searchRegex(query, opts);
    let m;
    while ((m = re.exec(idx.text)) && ranges.length < 2000) {
      if (!m[0].length) { re.lastIndex++; continue; }
      ranges.push(this._rangeAt(idx, m.index, m[0].length));
    }
    if (ranges.length) this.win.CSS.highlights.set('br-search', new this.win.Highlight(...ranges));
    this._searchRanges = ranges;
    return ranges.length;
  }

  clearHighlights() {
    if (this.win && this.win.CSS && this.win.CSS.highlights) {
      this.win.CSS.highlights.delete('br-search');
      this.win.CSS.highlights.delete('br-search-cur');
    }
    this._searchRanges = [];
  }

  gotoSearchHit(hit) {
    const doc = this.doc;
    if (!doc) return;
    if (hit.query) this.highlightAll(hit.query, hit.opts || {});
    let els = [...doc.querySelectorAll(`[data-bidx="${hit.bidx}"]`)].filter(isVisible);
    if (!els.length) {
      const e = this.findBidx(hit.bidx);
      if (e) els = [e];
    }
    let range = null;
    if (els.length && hit.query) {
      const re = searchRegex(hit.query, hit.opts || {});
      let count = 0;
      outer: for (const e of els) {
        const nodes = textNodes(e, true).filter((n) => !n.parentElement.closest('.br-ui'));
        let text = '';
        const map = [];
        for (const n of nodes) { map.push({ n, start: text.length }); text += n.data; }
        let m;
        re.lastIndex = 0;
        while ((m = re.exec(text))) {
          if (!m[0].length) { re.lastIndex++; continue; }
          if (count === (hit.occ || 0)) {
            range = this._rangeAt({ map }, m.index, m[0].length);
            break outer;
          }
          count++;
        }
      }
      if (!range) {
        for (const e of els) {
          const nodes = textNodes(e, true);
          let text = '';
          const map = [];
          for (const n of nodes) { map.push({ n, start: text.length }); text += n.data; }
          re.lastIndex = 0;
          const m = re.exec(text);
          if (m) { range = this._rangeAt({ map }, m.index, m[0].length); break; }
        }
      }
    }
    if (range) {
      this._lastHitRange = range;
      if (this.win.CSS && this.win.CSS.highlights) this.win.CSS.highlights.set('br-search-cur', new this.win.Highlight(range));
      this._scrollRange(range);
    } else if (els.length) {
      const se = doc.scrollingElement;
      se.scrollTop = Math.max(0, els[0].getBoundingClientRect().top + se.scrollTop - this.win.innerHeight / 3);
      this.flash(els[0]);
    }
  }

  stepSearch(dir) {
    const ranges = this._searchRanges || [];
    if (!ranges.length) return false;
    const se = this.doc.scrollingElement;
    const y = this.win.innerHeight / 3;
    let i;
    if (dir > 0) {
      i = ranges.findIndex((r) => r.getBoundingClientRect().top > y + 4);
      if (i < 0) return false;
    } else {
      i = -1;
      for (let k = ranges.length - 1; k >= 0; k--) if (ranges[k].getBoundingClientRect().top < y - 4) { i = k; break; }
      if (i < 0) return false;
    }
    this.win.CSS.highlights.set('br-search-cur', new this.win.Highlight(ranges[i]));
    this._scrollRange(ranges[i]);
    void se;
    return true;
  }

  _scrollRange(range) {
    const se = this.doc.scrollingElement;
    const r = range.getBoundingClientRect();
    se.scrollTop = Math.max(0, r.top + se.scrollTop - this.win.innerHeight / 3);
  }

  currentSelectionText() {
    const sel = this.doc && this.doc.getSelection();
    return sel && !sel.isCollapsed ? sel.toString() : '';
  }

  waitIdle() { return sleep(0); }
}

export function searchRegex(query, opts = {}) {
  const esc = query.trim().replace(/[.*+?^${}()|[\]\\]/g, '\\$&').replace(/\s+/g, '\\s+');
  let src = esc;
  if (opts.wholeWord && /^[A-Za-z0-9]/.test(query) && /[A-Za-z0-9]$/.test(query)) src = '\\b' + esc + '\\b';
  return new RegExp(src, opts.caseSensitive ? 'g' : 'gi');
}

export { epubType };
