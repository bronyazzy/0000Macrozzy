'use strict';
// AI chat for the reader. Several services can be configured side by side — Google Gemini, DeepSeek,
// OpenAI, Anthropic Claude and any OpenAI- or Anthropic-compatible service (Kimi, Qwen, GLM, OpenRouter,
// a local Ollama / LM Studio …) — each with its own API key (encrypted with Windows DPAPI in the app),
// model list and last used model. Answers are streamed as 'ai-event' events; the model's reasoning is
// streamed separately when the service sends it. Quizzes are requested as JSON. Chats are stored per book.
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const P = require('./ai-providers');

const { AiError, GeminiClient, OpenAIClient, AnthropicClient, BUILTIN, PRESETS, maskKey, validKey, normBase, isLocalUrl, isReasoningParamError, shapeModels, pickDefault, describeHttpError, describeStreamError } = P;

const DEFAULT_BASE = P.GEMINI_BASE;
const DEFAULT_MODEL = 'gemini-3.8-flash';
const KEY_FILE = 'gemini-api-key.txt';
const DEFAULT_SYSTEM = [
  '你是一位金融与交易教材的阅读助手，帮助中文读者读懂英文或中英对照的交易、投资、金融教材。',
  '- 用简体中文回答；专业术语在中文后给出英文原文，例如：久期（duration）。',
  '- 先给结论，再分点解释；涉及公式时说明每个变量的含义。',
  '- 解释词句时结合原文上下文和金融含义；翻译要准确、通顺，保留数字、单位和专有名词。',
  '- 不确定的内容直接说明，不要编造。',
].join('\n');
// '' = the service's default, 'off' = no reasoning, low / medium / high = reasoning effort
const THINKING = new Set(['', 'off', 'low', 'medium', 'high']);

const FINISH_NOTE = {
  MAX_TOKENS: '回答达到长度上限，被截断了。',
  SAFETY: '回答被安全策略拦截。',
  PROHIBITED_CONTENT: '回答被安全策略拦截。',
  BLOCKLIST: '回答被安全策略拦截。',
  SPII: '回答因涉及敏感个人信息被拦截。',
  RECITATION: '回答可能大段引用受版权保护的内容，已被中止。',
  CONTINUATION: '回答较长，已在中途结束。',
  LANGUAGE: '模型不支持这种语言的请求。',
  // OpenAI-compatible
  length: '回答达到长度上限，被截断了。',
  content_filter: '回答被内容安全策略拦截。',
  insufficient_system_resource: '服务器资源不足，回答被中断，请重试。',
  // Anthropic
  max_tokens: '回答达到长度上限，被截断了。',
  refusal: '模型拒绝回答这个问题。',
  pause_turn: '回答较长，已在中途结束。',
};
const FINISH_OK = new Set(['STOP', 'stop', 'end_turn', 'stop_sequence', 'tool_calls', 'FINISH_REASON_UNSPECIFIED']);
const QUIZ_FORMAT = '{"title": "...", "questions": [{"q": "...", "options": ["...", "...", "...", "..."], "answer": 0, "explain": "..."}]}';

const plainSecrets = {
  kind: 'plain',
  encrypt: (s) => 'plain:' + Buffer.from(String(s), 'utf8').toString('base64'),
  decrypt: (v) => (String(v).startsWith('plain:') ? Buffer.from(String(v).slice(6), 'base64').toString('utf8') : ''),
};

class AiManager {
  constructor({ store, appDir, emit }) {
    this.store = store;
    this.appDir = appDir;
    this.emit = emit || (() => {});
    this.secrets = plainSecrets;
    this.fetch = globalThis.fetch;
    this.jobs = new Map();
  }

  setSecrets(s) { if (s && s.encrypt && s.decrypt) { this.secrets = s; this._dec = null; } }
  setFetch(f) { if (typeof f === 'function') this.fetch = f; }

  // ------------------------------------------------------------------ settings

  // stored settings, upgraded from the single-service (Gemini only) format of earlier versions
  _cfg() {
    const c = this.store.get('ai', {});
    if (!c.providers || typeof c.providers !== 'object' || Array.isArray(c.providers)) c.providers = {};
    if (!Array.isArray(c.custom)) c.custom = [];
    if (c.keyEnc || c.baseUrl || c.modelCache || (c.model && !c.provider)) {
      const g = c.providers.gemini || (c.providers.gemini = {});
      if (c.keyEnc && !g.keyEnc) g.keyEnc = c.keyEnc;
      if (c.baseUrl && !g.baseUrl) g.baseUrl = c.baseUrl;
      if (c.modelCache && !g.modelCache) g.modelCache = c.modelCache;
      if (c.model && !g.model) g.model = c.model;
      delete c.keyEnc; delete c.baseUrl; delete c.modelCache; delete c.model;
      if (!c.provider) c.provider = 'gemini';
    }
    return c;
  }

  _save(cfg) { this.store.set('ai', cfg, true); }

  _state(c, id) { return c.providers[id] || (c.providers[id] = {}); }

  // service definitions: the built-in ones plus the services added by the user
  _defs(c = this._cfg()) {
    const out = BUILTIN.map((b) => {
      const relay = b.id === 'gemini' ? ((c.providers.gemini || {}).baseUrl || '') : '';
      return { ...b, builtin: true, base0: b.base, base: relay || process.env[b.env] || b.base };
    });
    for (const x of c.custom) {
      if (!x || !x.id) continue;
      out.push({
        id: x.id, type: x.type === 'anthropic' ? 'anthropic' : 'openai', name: x.name || '自定义服务', short: x.name || '自定义',
        base: x.baseUrl, custom: true, noKey: !!x.noKey, preset: x.preset || '', local: isLocalUrl(x.baseUrl),
      });
    }
    return out;
  }

  _def(id, c) { return this._defs(c).find((d) => d.id === id) || null; }

  _client(d) {
    if (d.type === 'gemini') return new GeminiClient({ fetch: this.fetch, baseUrl: d.base, label: d.short });
    if (d.type === 'anthropic') return new AnthropicClient({ fetch: this.fetch, baseUrl: d.base, label: d.short, compat: !!d.custom, local: d.local });
    return new OpenAIClient({ fetch: this.fetch, baseUrl: d.base, label: d.short, flavor: d.flavor, local: d.local });
  }

  _decrypt(enc) {
    if (!enc) return '';
    if (!this._dec || this._dec.size > 50) this._dec = new Map();
    if (this._dec.has(enc)) return this._dec.get(enc);
    let v = '';
    try { v = this.secrets.decrypt(enc) || ''; } catch { v = ''; }
    this._dec.set(enc, v);
    return v;
  }

  // API key of a service (the current one when no id is given)
  getKey(id) {
    const c = this._cfg();
    const pid = id || this._currentId(c);
    return this._decrypt((c.providers[pid] || {}).keyEnc);
  }

  _keyId(key, base) { return crypto.createHash('sha256').update(String(key || '') + '|' + String(base || '')).digest('hex').slice(0, 12); }

  _ready(d, c) { return !!(d && (d.noKey || this._decrypt((c.providers[d.id] || {}).keyEnc))); }

  // the service in use: the chosen one when usable, else the first usable one
  _currentId(c) {
    const defs = this._defs(c);
    const chosen = defs.find((d) => d.id === c.provider);
    if (chosen && this._ready(chosen, c)) return chosen.id;
    const ready = defs.find((d) => this._ready(d, c));
    return (ready || chosen || defs[0]).id;
  }

  _models(d, c) {
    const s = c.providers[d.id] || {};
    const key = this._decrypt(s.keyEnc);
    const cache = s.modelCache && s.modelCache.keyId === this._keyId(key, d.base) ? s.modelCache : null;
    const list = cache ? cache.models.slice() : [];
    for (const m of Array.isArray(s.manualModels) ? s.manualModels : []) if (m && !list.some((x) => x.id === m)) list.push({ id: m, name: m, manual: true });
    return { list, at: cache ? cache.at : 0 };
  }

  _info(d, c) {
    const s = c.providers[d.id] || {};
    const key = this._decrypt(s.keyEnc);
    const { list, at } = this._models(d, c);
    return {
      id: d.id, type: d.type, name: d.name, short: d.short, builtin: !!d.builtin, custom: !!d.custom, preset: d.preset || '',
      baseUrl: d.custom ? d.base : d.id === 'gemini' ? (s.baseUrl || '') : '', defaultBaseUrl: d.base0 || '',
      noKey: !!d.noKey, local: !!d.local,
      hasKey: !!key, keyHint: maskKey(key), keyProtected: !!(s.keyEnc && !String(s.keyEnc).startsWith('plain:')), keyBroken: !!(s.keyEnc && !key),
      ready: !!(key || d.noKey),
      model: s.model || pickDefault(d, list),
      models: list, modelsAt: at,
      keyUrl: d.keyUrl || '', keyPlaceholder: d.keyPlaceholder || (d.noKey ? '本机服务可以不填' : 'API Key'),
    };
  }

  config() {
    const c = this._cfg();
    const providers = this._defs(c).map((d) => this._info(d, c));
    const cur = providers.find((p) => p.id === this._currentId(c)) || providers[0];
    return {
      provider: cur.id,
      providerName: cur.name,
      model: cur.model,
      hasKey: cur.ready,
      anyReady: providers.some((p) => p.ready),
      keyHint: cur.keyHint,
      keyProtected: cur.keyProtected,
      keyBroken: cur.keyBroken,
      models: cur.models,
      modelsAt: cur.modelsAt,
      thinking: THINKING.has(c.thinking) ? c.thinking : '',
      system: typeof c.system === 'string' && c.system.trim() ? c.system : DEFAULT_SYSTEM,
      defaultSystem: DEFAULT_SYSTEM,
      baseUrl: (c.providers.gemini || {}).baseUrl || '',
      defaultBaseUrl: DEFAULT_BASE,
      includeBook: c.includeBook !== false,
      saveHistory: c.saveHistory !== false,
      providers,
      presets: PRESETS.map((p) => ({ ...p })),
    };
  }

  saveConfig(patch) {
    const c = this._cfg();
    const p = patch || {};
    if (typeof p.provider === 'string' && this._def(p.provider, c)) c.provider = p.provider;
    if (typeof p.model === 'string') {
      const pid = (typeof p.provider === 'string' && this._def(p.provider, c)) ? p.provider : this._currentId(c);
      const m = p.model.trim().replace(/^models\//, '').slice(0, 160);
      const s = this._state(c, pid);
      if (m) {
        s.model = m;
        if (p.addModel) s.manualModels = [...new Set([...(s.manualModels || []), m])].slice(-20);
      }
    }
    if (typeof p.thinking === 'string' && THINKING.has(p.thinking)) c.thinking = p.thinking;
    if (typeof p.system === 'string') c.system = p.system.trim() === DEFAULT_SYSTEM.trim() ? '' : p.system.slice(0, 8000);
    if (typeof p.baseUrl === 'string') {
      // relay address for Gemini (advanced)
      const u = p.baseUrl.trim().replace(/\/+$/, '');
      if (u && !/^https?:\/\/[^\s]+$/i.test(u)) throw new Error('接口地址必须以 http:// 或 https:// 开头');
      const g = this._state(c, 'gemini');
      g.baseUrl = u === DEFAULT_BASE ? '' : u;
      delete g.modelCache;
    }
    if (typeof p.includeBook === 'boolean') c.includeBook = p.includeBook;
    if (typeof p.saveHistory === 'boolean') c.saveHistory = p.saveHistory;
    this._save(c);
    return this.config();
  }

  // set or remove (empty key) the API key of a service; a service that gets its first key becomes the current one
  setKey(key, id = 'gemini') {
    const k = String(key || '').trim();
    const c = this._cfg();
    const d = this._def(id, c);
    if (!d) throw new Error('未知的 AI 服务');
    const s = this._state(c, id);
    if (!k) {
      delete s.keyEnc;
      delete s.modelCache;
      this._save(c);
      return this.config();
    }
    if (!validKey(k)) throw new Error('API Key 格式不对（应为一串连续的字母、数字和符号，中间没有空格）');
    const curId = this._currentId(c);
    const curReady = this._ready(this._def(curId, c), c);
    const first = !this._decrypt(s.keyEnc);
    s.keyEnc = this.secrets.encrypt(k);
    delete s.modelCache;
    if (!curReady || first || !c.provider) c.provider = id;
    this._save(c);
    return this.config();
  }

  // add / update an OpenAI- or Anthropic-compatible service: { id?, name, type, baseUrl, key?, model?, noKey? }
  saveProvider(p) {
    const x = p || {};
    const c = this._cfg();
    const name = String(x.name || '').trim().slice(0, 40);
    const baseUrl = normBase(x.baseUrl);
    if (!name) throw new Error('请填写服务名称');
    if (!/^https?:\/\/[^\s]+$/i.test(baseUrl)) throw new Error('接口地址必须以 http:// 或 https:// 开头');
    const type = x.type === 'anthropic' ? 'anthropic' : 'openai';
    let entry = x.id ? c.custom.find((e) => e.id === x.id) : null;
    if (x.id && !entry) throw new Error('找不到要修改的服务');
    if (!entry) {
      if (c.custom.length >= 20) throw new Error('最多添加 20 个服务');
      entry = { id: 'c-' + crypto.randomBytes(4).toString('hex') };
      c.custom.push(entry);
    }
    const s = this._state(c, entry.id);
    if (entry.baseUrl !== baseUrl || entry.type !== type) delete s.modelCache;
    Object.assign(entry, { name, type, baseUrl, noKey: !!x.noKey, preset: String(x.preset || entry.preset || '').slice(0, 30) });
    const k = String(x.key || '').trim();
    if (k) {
      if (!validKey(k)) throw new Error('API Key 格式不对（应为一串连续的字母、数字和符号，中间没有空格）');
      s.keyEnc = this.secrets.encrypt(k);
      delete s.modelCache;
    } else if (x.clearKey) {
      delete s.keyEnc;
    }
    const model = String(x.model || '').trim().slice(0, 160);
    if (model) {
      s.model = model;
      s.manualModels = [...new Set([...(s.manualModels || []), model])].slice(-20);
    }
    c.provider = entry.id;
    this._save(c);
    return { ...this.config(), id: entry.id };
  }

  // remove an added service, or the key of a built-in one
  removeProvider(id) {
    const c = this._cfg();
    const d = this._def(id, c);
    if (!d) return this.config();
    if (d.custom) {
      c.custom = c.custom.filter((e) => e.id !== id);
      delete c.providers[id];
    } else {
      const s = this._state(c, id);
      delete s.keyEnc;
      delete s.modelCache;
    }
    if (c.provider === id) c.provider = '';
    this._save(c);
    return this.config();
  }

  // One-time import of <appDir>/<service>-api-key.txt (gemini-api-key.txt, deepseek-api-key.txt, …):
  // the key is stored encrypted, then the file is deleted.
  importKeyFile() {
    let imported = false;
    for (const b of BUILTIN) {
      const file = path.join(this.appDir, b.keyFile);
      if (!fs.existsSync(file)) continue;
      try {
        const k = fs.readFileSync(file, 'utf8').replace(/^﻿/, '').split(/\r?\n/).map((s) => s.trim()).find((s) => s && !s.startsWith('#')) || '';
        if (k && validKey(k) && !this.getKey(b.id)) {
          this.setKey(k, b.id);
          imported = true;
        }
      } catch (e) {
        console.error('导入 API Key 文件失败：', e.message);
      }
      try { fs.unlinkSync(file); } catch { /* read-only folder: leave it */ }
    }
    return imported;
  }

  // ------------------------------------------------------------------ models

  _need(pid) {
    const c = this._cfg();
    const d = this._def(pid || this._currentId(c), c);
    if (!d) throw new Error('未知的 AI 服务');
    const key = this._decrypt((c.providers[d.id] || {}).keyEnc);
    if (!key && !d.noKey) throw new Error(`还没有设置 ${d.name} 的 API Key（设置 → AI 对话）`);
    return { c, d, key };
  }

  async models(refresh, id) {
    const { c, d, key } = this._need(id);
    const s = c.providers[d.id] || {};
    const keyId = this._keyId(key, d.base);
    if (!refresh && s.modelCache && s.modelCache.keyId === keyId && s.modelCache.models.length && Date.now() - s.modelCache.at < 7 * 86400e3) {
      return s.modelCache.models;
    }
    const models = await this._client(d).listModels(key);
    const c2 = this._cfg();
    const s2 = this._state(c2, d.id);
    s2.modelCache = { keyId, at: Date.now(), models };
    const all = this._models(d, c2).list;
    if (!s2.model || !all.some((m) => m.id === s2.model)) s2.model = pickDefault(d, all) || s2.model;
    this._save(c2);
    return models;
  }

  // Checks a key (or the stored one) by listing the models. opts = { baseUrl, type, name, model, noKey } tests a
  // service that is not saved yet. Services without a model list are checked with a tiny chat request.
  async test(key, id = 'gemini', opts = {}) {
    const c = this._cfg();
    let d = id ? this._def(id, c) : null;
    if (opts && opts.baseUrl) {
      const base = normBase(opts.baseUrl);
      if (!/^https?:\/\/[^\s]+$/i.test(base)) throw new Error('接口地址必须以 http:// 或 https:// 开头');
      d = { ...(d || {}), id: (d && d.id) || '', type: opts.type === 'anthropic' ? 'anthropic' : 'openai', name: opts.name || (d && d.name) || '自定义服务', short: opts.name || (d && d.short) || '自定义服务', base, custom: true, noKey: !!opts.noKey, local: isLocalUrl(base) };
    }
    if (!d) throw new Error('未知的 AI 服务');
    const k = String(key || '').trim() || (d.id ? this._decrypt((c.providers[d.id] || {}).keyEnc) : '');
    if (!k && !d.noKey) throw new Error('请先填写 API Key');
    if (k && !validKey(k)) throw new Error('API Key 格式不对');
    const client = this._client(d);
    try {
      const models = await client.listModels(k);
      return { ok: true, count: models.length, models: models.slice(0, 6).map((m) => m.id) };
    } catch (e) {
      const model = String((opts && opts.model) || (d.id && (c.providers[d.id] || {}).model) || d.defaultModel || '').trim();
      if (d.type !== 'gemini' && e.status && [404, 405, 501].includes(e.status) && model) {
        await this._ping(client, d, k, model);
        return { ok: true, count: 0, models: [], noList: true };
      }
      throw e;
    }
  }

  async _ping(client, d, key, model) {
    if (d.type === 'anthropic') return client.create({ key, model, body: { max_tokens: 16, messages: [{ role: 'user', content: 'hi' }] } });
    return client.complete({ key, model, body: { messages: [{ role: 'user', content: 'hi' }] } });
  }

  // ------------------------------------------------------------------ chat

  // Starts a streaming chat; progress arrives as 'ai-event' events
  // {id, type: delta | thought | done | error | aborted, ...}.
  chat(id, req) {
    id = String(id || '');
    if (!id) throw new Error('缺少请求编号');
    const r = req || {};
    const { c, d, key } = this._need(r.provider);
    const model = String(r.model || this._info(d, c).model || '').replace(/^models\//, '');
    if (!model) throw new Error(`请先为 ${d.name} 选择或填写模型名称（设置 → AI 对话）`);
    const contents = normalizeContents(r.contents);
    if (!contents.length || contents[contents.length - 1].role !== 'user') throw new Error('没有要发送的问题');
    const job = { d, key, model, contents, system: String(r.system || '').trim(), thinking: THINKING.has(r.thinking) ? r.thinking : '' };
    const ac = new AbortController();
    this.jobs.set(id, ac);
    this._run(id, job, ac).finally(() => this.jobs.delete(id));
    return { started: true, model, provider: d.id };
  }

  async _run(id, job, ac) {
    const out = { parts: [], text: '', thought: '', finish: '', note: '', usage: null, model: '' };
    const sink = {
      text: (t) => { if (!t) return; out.text += t; this.emit('ai-event', { id, type: 'delta', text: t }); },
      thought: (t) => { if (!t) return; out.thought += t; this.emit('ai-event', { id, type: 'thought', text: t }); },
    };
    const base = () => ({ id, text: out.text, thought: out.thought, model: out.model || job.model, provider: job.d.id, parts: out.parts.length ? out.parts : out.text ? [{ text: out.text }] : [] });
    let retried = false;
    try {
      for (;;) {
        try {
          if (job.d.type === 'gemini') await this._runGemini(job, ac, out, sink);
          else if (job.d.type === 'anthropic') await this._runAnthropic(job, ac, out, sink);
          else await this._runOpenAI(job, ac, out, sink);
          break;
        } catch (e) {
          // the model does not accept the reasoning settings: ask once more without them
          if (!retried && job.thinking && !out.text && !out.thought && isReasoningParamError(e)) {
            retried = true;
            job.noThinking = true;
            continue;
          }
          throw e;
        }
      }
      if (!out.text && !out.parts.some((p) => p.text)) {
        throw new AiError('模型没有返回内容' + (out.finish && !FINISH_OK.has(out.finish) ? '（' + out.finish + '）' : '') + '，请重试或换一个模型。');
      }
      const note = [
        out.finish && !FINISH_OK.has(out.finish) ? FINISH_NOTE[out.finish] || '回答提前结束（' + out.finish + '）。' : '',
        retried ? '这个模型不支持“思考程度”设置，已按默认方式回答。' : '',
      ].filter(Boolean).join(' ');
      this.emit('ai-event', { ...base(), type: 'done', finish: out.finish, note, usage: out.usage });
    } catch (e) {
      if (e && e.aborted) this.emit('ai-event', { ...base(), type: 'aborted' });
      else this.emit('ai-event', { ...base(), type: 'error', message: String((e && e.message) || e) });
    }
  }

  async _runGemini(job, ac, out, sink) {
    const body = { contents: job.contents };
    if (job.system) body.systemInstruction = { parts: [{ text: job.system }] };
    const tc = job.noThinking ? null : geminiThinking(job.thinking);
    if (tc) body.generationConfig = { thinkingConfig: tc };
    let blocked = '';
    const addPart = (p) => {
      if (!p) return;
      if (p.thought) { if (typeof p.text === 'string') sink.thought(p.text); return; } // thought summary
      if (typeof p.text === 'string') {
        const last = out.parts[out.parts.length - 1];
        // never merge a part that carries a thought signature with another part
        if (p.thoughtSignature) out.parts.push({ text: p.text, thoughtSignature: p.thoughtSignature });
        else if (last && typeof last.text === 'string' && !last.thoughtSignature) last.text += p.text;
        else out.parts.push({ text: p.text });
        sink.text(p.text);
      } else if (p.thoughtSignature) {
        out.parts.push(p);
      }
    };
    for await (const chunk of this._client(job.d).stream({ key: job.key, model: job.model, body, signal: ac.signal })) {
      if (chunk.promptFeedback && chunk.promptFeedback.blockReason) blocked = chunk.promptFeedback.blockReason;
      const cand = (chunk.candidates || [])[0];
      if (cand) {
        for (const p of (cand.content && cand.content.parts) || []) addPart(p);
        if (cand.finishReason) out.finish = cand.finishReason;
      }
      if (chunk.usageMetadata) out.usage = shapeUsage(chunk.usageMetadata);
      if (chunk.modelVersion) out.model = chunk.modelVersion;
    }
    if (blocked && !out.text) throw new AiError('问题被安全策略拦截（' + blocked + '），请换一种问法。');
  }

  async _runOpenAI(job, ac, out, sink) {
    const messages = [];
    if (job.system) messages.push({ role: 'system', content: job.system });
    for (const t of textTurns(job.contents)) messages.push({ role: t.role === 'model' ? 'assistant' : 'user', content: t.text });
    const body = { messages, ...(job.noThinking ? {} : openaiThinking(job.d, job.thinking)) };
    const split = thinkSplitter(sink);
    const ctx = { label: job.d.short, model: job.model };
    for await (const j of this._client(job.d).stream({ key: job.key, model: job.model, body, signal: ac.signal })) {
      if (!j) continue;
      if (j.error) {
        const st = +(j.error.code || j.error.status) || 500;
        throw new AiError(describeHttpError(st >= 400 && st < 600 ? st : 500, JSON.stringify(j), ctx), { status: st });
      }
      if (j.model) out.model = j.model;
      if (j.usage) out.usage = shapeUsageOpenAI(j.usage);
      const ch = (j.choices || [])[0];
      if (!ch) continue;
      const dl = ch.delta || ch.message || {};
      const rc = typeof dl.reasoning_content === 'string' ? dl.reasoning_content : typeof dl.reasoning === 'string' ? dl.reasoning : '';
      if (rc) sink.thought(rc);
      if (typeof dl.content === 'string' && dl.content) split.feed(dl.content);
      if (ch.finish_reason) out.finish = ch.finish_reason;
    }
    split.end();
  }

  async _runAnthropic(job, ac, out, sink) {
    const messages = textTurns(job.contents).map((t) => ({ role: t.role === 'model' ? 'assistant' : 'user', content: t.text }));
    const th = job.noThinking ? null : anthropicThinking(job.thinking);
    const body = { max_tokens: th ? 16000 : 8192, messages, ...(th || {}) };
    if (job.system) body.system = job.system;
    let input = 0;
    for await (const j of this._client(job.d).stream({ key: job.key, model: job.model, body, signal: ac.signal })) {
      if (!j || !j.type) continue;
      if (j.type === 'message_start' && j.message) {
        if (j.message.model) out.model = j.message.model;
        input = (j.message.usage && j.message.usage.input_tokens) || 0;
      } else if (j.type === 'content_block_delta' && j.delta) {
        if (j.delta.type === 'text_delta') sink.text(j.delta.text || '');
        else if (j.delta.type === 'thinking_delta') sink.thought(j.delta.thinking || '');
      } else if (j.type === 'message_delta') {
        if (j.delta && j.delta.stop_reason) out.finish = j.delta.stop_reason;
        if (j.usage) {
          const o = j.usage.output_tokens || 0;
          const i = j.usage.input_tokens || input;
          out.usage = { prompt: i, output: o, thoughts: 0, total: i + o };
        }
      } else if (j.type === 'error') {
        throw new AiError(describeStreamError(j.error, { label: job.d.short }), { status: /overloaded/.test((j.error && j.error.type) || '') ? 529 : 500 });
      }
    }
  }

  // ------------------------------------------------------------------ quiz

  // Multiple-choice quiz about a passage, returned as JSON. req = { id?, provider?, model?, thinking?, text, count?, focus? }
  async quiz(req) {
    const r = req || {};
    const { c, d, key } = this._need(r.provider);
    const model = String(r.model || this._info(d, c).model || '').replace(/^models\//, '');
    if (!model) throw new Error(`请先为 ${d.name} 选择或填写模型名称（设置 → AI 对话）`);
    const count = Math.max(3, Math.min(10, Math.round(+r.count || 5)));
    const text = String(r.text || '').slice(0, 90000);
    if (text.trim().length < 30) throw new Error('没有足够的正文用来出题');
    const prompt = [
      `请根据下面的教材内容出 ${count} 道单项选择题，检查读者是否真正理解了内容（概念、因果关系、计算或应用），不要考无关紧要的细节。`,
      '要求：题干、选项和解析用简体中文，关键术语保留英文原文；每题 4 个选项且只有一个正确；answer 是正确选项的序号（从 0 开始）；explain 简要说明为什么正确、其他选项错在哪里。',
      r.focus ? '侧重：' + String(r.focus).slice(0, 200) : null,
      '', '教材内容：', '"""', text, '"""',
    ].filter((x) => x !== null).join('\n');
    const plainPrompt = prompt + '\n\n只输出 json（一个 JSON 对象），不要输出其他文字，格式：' + QUIZ_FORMAT;
    const thinking = THINKING.has(r.thinking) ? r.thinking : '';
    const ac = new AbortController();
    const jid = r.id ? String(r.id) : '';
    if (jid) this.jobs.set(jid, ac);
    const client = this._client(d);
    try {
      let out = '';
      let used = model;
      // answers once more without the optional settings when the model rejects them
      const attempt = async (fn, opts) => {
        try { return await fn(opts); } catch (e) {
          if (opts.thinking && isReasoningParamError(e)) return fn({ ...opts, thinking: '' });
          throw e;
        }
      };
      if (d.type === 'gemini') {
        const schema = {
          type: 'OBJECT',
          properties: {
            title: { type: 'STRING' },
            questions: {
              type: 'ARRAY',
              items: {
                type: 'OBJECT',
                properties: { q: { type: 'STRING' }, options: { type: 'ARRAY', items: { type: 'STRING' } }, answer: { type: 'INTEGER' }, explain: { type: 'STRING' } },
                required: ['q', 'options', 'answer', 'explain'],
              },
            },
          },
          required: ['questions'],
        };
        const call = async ({ thinking: t, json }) => {
          const gen = json ? { responseMimeType: 'application/json', responseSchema: schema } : {};
          const tc = geminiThinking(t);
          if (tc) gen.thinkingConfig = tc;
          const body = { contents: [{ role: 'user', parts: [{ text: json ? prompt : plainPrompt }] }] };
          if (Object.keys(gen).length) body.generationConfig = gen;
          return client.generate({ key, model, body, signal: ac.signal });
        };
        let j;
        try {
          j = await attempt(call, { thinking, json: true });
        } catch (e) {
          // some models do not support JSON mode: ask for plain JSON text instead
          if (e.status !== 400 || !/schema|mime|json/i.test(e.message)) throw e;
          j = await attempt(call, { thinking, json: false });
        }
        const cand = (j.candidates || [])[0];
        out = ((cand && cand.content && cand.content.parts) || []).filter((p) => !p.thought).map((p) => p.text || '').join('');
        used = j.modelVersion || model;
      } else if (d.type === 'anthropic') {
        const call = async ({ thinking: t }) => {
          const th = anthropicThinking(t);
          return client.create({ key, model, body: { max_tokens: th ? 16000 : 8192, messages: [{ role: 'user', content: plainPrompt }], ...(th || {}) }, signal: ac.signal });
        };
        const j = await attempt(call, { thinking });
        out = ((j && j.content) || []).filter((b) => b && b.type === 'text').map((b) => b.text || '').join('');
        used = (j && j.model) || model;
      } else {
        const call = async ({ thinking: t, json }) => {
          const body = { messages: [{ role: 'user', content: plainPrompt }], ...openaiThinking(d, t) };
          if (json) body.response_format = { type: 'json_object' };
          return client.complete({ key, model, body, signal: ac.signal });
        };
        let j;
        try {
          j = await attempt(call, { thinking, json: true });
        } catch (e) {
          // JSON mode not supported by this service / model: plain text answer
          if (!(e.status === 400 || e.status === 422) || !/response_format|json/i.test(e.message)) throw e;
          j = await attempt(call, { thinking, json: false });
        }
        if (j && j.error) throw new AiError(describeHttpError(+(j.error.code) || 500, JSON.stringify(j), { label: d.short, model }));
        const msg = (((j && j.choices) || [])[0] || {}).message || {};
        out = String(msg.content || '').replace(/^\s*<think>[\s\S]*?<\/think>\s*/i, '');
        used = (j && j.model) || model;
      }
      const quiz = parseQuiz(out);
      if (!quiz) throw new AiError('模型返回的题目格式不对，请重试或换一个模型。');
      return { ...quiz, model: used, provider: d.id };
    } catch (e) {
      if ((e && e.aborted) || ac.signal.aborted) throw new AiError('已停止', { aborted: true });
      throw e;
    } finally {
      if (jid) this.jobs.delete(jid);
    }
  }

  cancel(id) {
    const ac = this.jobs.get(String(id || ''));
    if (ac) ac.abort();
    return !!ac;
  }

  cancelAll() { for (const ac of this.jobs.values()) ac.abort(); }

  // ------------------------------------------------------------------ history

  history(bookId) {
    return this.store.get('ai-chats/' + safeId(bookId), { messages: [] }).messages || [];
  }

  saveHistory(bookId, messages) {
    if (this._cfg().saveHistory === false) return false;
    const list = (Array.isArray(messages) ? messages : []).slice(-80).map((m) => ({
      role: m.role === 'model' ? 'model' : 'user',
      text: String(m.text || '').slice(0, 60000),
      parts: Array.isArray(m.parts) ? m.parts.filter((p) => p && (typeof p.text === 'string' || p.thoughtSignature)).slice(0, 400) : undefined,
      thought: m.thought ? String(m.thought).slice(0, 30000) : undefined,
      quote: m.quote ? String(m.quote).slice(0, 600) : undefined,
      title: m.title ? String(m.title).slice(0, 80) : undefined,
      provider: m.provider ? String(m.provider).slice(0, 40) : undefined,
      model: m.model ? String(m.model).slice(0, 160) : undefined,
      note: m.note ? String(m.note).slice(0, 200) : undefined,
      error: m.error ? String(m.error).slice(0, 600) : undefined,
      kind: m.kind === 'quiz' ? 'quiz' : undefined,
      quiz: m.quiz && Array.isArray(m.quiz.questions) ? {
        title: String(m.quiz.title || '').slice(0, 100),
        questions: m.quiz.questions.slice(0, 10).map((q) => ({ q: String(q.q || '').slice(0, 600), options: (q.options || []).slice(0, 6).map((o) => String(o).slice(0, 300)), answer: +q.answer || 0, explain: String(q.explain || '').slice(0, 1200) })),
        picks: (m.quiz.picks || []).slice(0, 10).map((p) => (p == null ? null : +p)),
      } : undefined,
      at: +m.at || Date.now(),
    }));
    this.store.set('ai-chats/' + safeId(bookId), { messages: list });
    return true;
  }
}

// ---------------------------------------------------------------- request helpers

function geminiThinking(t) {
  if (!t) return null;
  return { thinkingLevel: t === 'off' ? 'minimal' : t };
}

function openaiThinking(d, t) {
  if (!t) return {};
  if (d && d.flavor === 'deepseek') {
    // DeepSeek: thinking is on by default (effort high); effort levels are low / high / max
    if (t === 'off') return { thinking: { type: 'disabled' } };
    return { thinking: { type: 'enabled' }, reasoning_effort: t === 'low' ? 'low' : 'high' };
  }
  if (t === 'off') return { reasoning_effort: 'none' };
  return { reasoning_effort: t };
}

function anthropicThinking(t) {
  if (!t || t === 'off') return null;
  return { thinking: { type: 'adaptive' }, output_config: { effort: t } };
}

// Splits "<think>…</think>" at the start of an answer (local reasoning models) into reasoning and answer.
function thinkSplitter(sink) {
  let st = 'start';
  let buf = '';
  let strip = false; // drop the blank lines right after </think>
  const OPEN = '<think>';
  const CLOSE = '</think>';
  const tailLen = (s, tag) => {
    for (let n = Math.min(tag.length - 1, s.length); n > 0; n--) if (tag.startsWith(s.slice(-n))) return n;
    return 0;
  };
  return {
    feed(s) {
      if (st === 'out') {
        if (strip) { s = s.replace(/^\s+/, ''); if (!s) return; strip = false; }
        sink.text(s);
        return;
      }
      buf += s;
      if (st === 'start') {
        const t = buf.replace(/^\s+/, '');
        if (!t) return;
        if (OPEN.startsWith(t)) return;
        if (!t.startsWith(OPEN)) { st = 'out'; const b = buf; buf = ''; sink.text(b); return; }
        st = 'in';
        buf = t.slice(OPEN.length);
      }
      const i = buf.indexOf(CLOSE);
      if (i < 0) {
        const keep = tailLen(buf, CLOSE);
        const emit = buf.slice(0, buf.length - keep);
        if (emit) sink.thought(emit);
        buf = buf.slice(buf.length - keep);
        return;
      }
      if (i > 0) sink.thought(buf.slice(0, i));
      const rest = buf.slice(i + CLOSE.length).replace(/^\s+/, '');
      buf = '';
      st = 'out';
      if (rest) sink.text(rest);
      else strip = true;
    },
    end() {
      if (buf) { if (st === 'in') sink.thought(buf); else sink.text(buf); }
      buf = '';
    },
  };
}

function parseQuiz(text) {
  let s = String(text || '').trim();
  const fence = /```(?:json)?\s*([\s\S]*?)```/i.exec(s);
  if (fence) s = fence[1];
  const a = s.indexOf('{');
  const b = s.lastIndexOf('}');
  if (a < 0 || b <= a) return null;
  let j;
  try { j = JSON.parse(s.slice(a, b + 1)); } catch { return null; }
  const qs = (Array.isArray(j.questions) ? j.questions : []).map((q) => {
    const options = (Array.isArray(q.options) ? q.options : []).map((o) => String(o).replace(/^\s*[A-Da-d][.、:：)]\s*/, '').trim()).filter(Boolean).slice(0, 6);
    let answer = Number.isInteger(+q.answer) ? +q.answer : 'ABCDEF'.indexOf(String(q.answer || '').trim().toUpperCase()[0]);
    if (answer >= options.length && answer - 1 >= 0 && answer - 1 < options.length) answer -= 1; // 1-based answers
    return { q: String(q.q || q.question || '').trim(), options, answer, explain: String(q.explain || q.explanation || '').trim() };
  }).filter((q) => q.q && q.options.length >= 2 && q.answer >= 0 && q.answer < q.options.length);
  if (!qs.length) return null;
  return { title: String(j.title || '').slice(0, 100), questions: qs.slice(0, 10) };
}

function safeId(id) {
  return String(id || '_global').replace(/[^A-Za-z0-9_-]/g, '_').slice(0, 64) || '_global';
}

function shapeUsage(u) {
  if (!u) return null;
  return { prompt: u.promptTokenCount || 0, output: u.candidatesTokenCount || 0, thoughts: u.thoughtsTokenCount || 0, total: u.totalTokenCount || 0 };
}

function shapeUsageOpenAI(u) {
  if (!u) return null;
  const thoughts = (u.completion_tokens_details && u.completion_tokens_details.reasoning_tokens) || 0;
  return { prompt: u.prompt_tokens || 0, output: u.completion_tokens || 0, thoughts, total: u.total_tokens || (u.prompt_tokens || 0) + (u.completion_tokens || 0) };
}

// user/model turns with non-empty parts; consecutive turns of the same role are merged
function normalizeContents(list) {
  const out = [];
  for (const c of Array.isArray(list) ? list : []) {
    const role = c && c.role === 'model' ? 'model' : 'user';
    const parts = (Array.isArray(c && c.parts) ? c.parts : [])
      .filter((p) => p && (typeof p.text === 'string' || p.thoughtSignature))
      .map((p) => {
        const q = { text: String(p.text || '') };
        if (p.thoughtSignature) q.thoughtSignature = String(p.thoughtSignature);
        return q;
      })
      .filter((p) => p.text || p.thoughtSignature);
    if (!parts.length) continue;
    const last = out[out.length - 1];
    if (last && last.role === role) last.parts.push(...parts);
    else out.push({ role, parts });
  }
  while (out.length && out[0].role !== 'user') out.shift();
  return out;
}

// plain-text turns for chat-completion style APIs (no empty turns, roles alternate, first turn is the user's)
function textTurns(contents) {
  const out = [];
  for (const c of contents || []) {
    const text = (c.parts || []).map((p) => p.text || '').join('');
    if (!text.trim()) continue;
    const last = out[out.length - 1];
    if (last && last.role === c.role) last.text += '\n\n' + text;
    else out.push({ role: c.role, text });
  }
  while (out.length && out[0].role !== 'user') out.shift();
  return out;
}

module.exports = {
  AiManager, GeminiClient, AiError, shapeModels, pickDefaultModel: (models) => pickDefault(BUILTIN[0], models), describeHttpError,
  normalizeContents, textTurns, thinkSplitter, parseQuiz, openaiThinking, anthropicThinking, geminiThinking,
  DEFAULT_SYSTEM, DEFAULT_MODEL, DEFAULT_BASE, KEY_FILE,
};
