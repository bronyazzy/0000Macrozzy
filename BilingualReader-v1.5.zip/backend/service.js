'use strict';
// Core backend service (no Electron dependency). Electron's main process and the
// browser test harness both expose these methods and the same URL routes:
//   /<ui files>                     renderer
//   /book/<bookId>/<path>           book resources (EPUB entries / files next to an HTML file / the PDF)
//   /dictres/<dictId>/<path>        MDX/MDD resources
//   /dictentry/<dictId>/<key>       an MDX entry rendered as a page
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const { ZipReader } = require('./zip');
const { Store } = require('./store');
const { DictManager } = require('./dict');
const { AiManager } = require('./ai');
const { LearnManager } = require('./learn');

const MIME = {
  html: 'text/html; charset=utf-8', htm: 'text/html; charset=utf-8', xhtml: 'application/xhtml+xml', xht: 'application/xhtml+xml',
  xml: 'application/xml', opf: 'application/xml', ncx: 'application/xml', css: 'text/css; charset=utf-8',
  js: 'text/javascript; charset=utf-8', mjs: 'text/javascript; charset=utf-8', json: 'application/json; charset=utf-8',
  map: 'application/json', txt: 'text/plain; charset=utf-8', png: 'image/png', jpg: 'image/jpeg', jpeg: 'image/jpeg',
  jpe: 'image/jpeg', gif: 'image/gif', webp: 'image/webp', svg: 'image/svg+xml', svgz: 'image/svg+xml', bmp: 'image/bmp',
  ico: 'image/x-icon', tif: 'image/tiff', tiff: 'image/tiff', avif: 'image/avif', ttf: 'font/ttf', otf: 'font/otf',
  woff: 'font/woff', woff2: 'font/woff2', eot: 'application/vnd.ms-fontobject', mp3: 'audio/mpeg', wav: 'audio/wav',
  ogg: 'audio/ogg', oga: 'audio/ogg', spx: 'audio/ogg', m4a: 'audio/mp4', mp4: 'video/mp4', pdf: 'application/pdf',
  wasm: 'application/wasm', bcmap: 'application/octet-stream', pfb: 'application/octet-stream', icc: 'application/octet-stream',
  ftl: 'text/plain; charset=utf-8',
};

function mimeOf(p) {
  const ext = path.extname(String(p)).slice(1).toLowerCase();
  return MIME[ext] || 'application/octet-stream';
}

const BOOK_EXT = { '.epub': 'epub', '.pdf': 'pdf', '.html': 'html', '.htm': 'html', '.xhtml': 'html', '.xht': 'html', '.shtml': 'html' };

function detectType(file) {
  const ext = path.extname(file).toLowerCase();
  if (BOOK_EXT[ext]) return BOOK_EXT[ext];
  const fd = fs.openSync(file, 'r');
  try {
    const b = Buffer.alloc(64);
    fs.readSync(fd, b, 0, 64, 0);
    if (b.subarray(0, 4).toString('latin1') === '%PDF') return 'pdf';
    if (b[0] === 0x50 && b[1] === 0x4b && b.toString('latin1').includes('epub')) return 'epub';
    if (/^\s*</.test(b.toString('utf8'))) return 'html';
  } finally {
    fs.closeSync(fd);
  }
  return null;
}

// a learning-data backup (JSON text or object), reduced to the documents it may contain
function parseBackup(src) {
  let data = src;
  if (typeof src === 'string') {
    try { data = JSON.parse(src.replace(/^\uFEFF/, '')); } catch { throw new Error('这不是有效的备份文件（无法读取）'); }
  }
  if (!data || data.kind !== 'learning-data' || !data.docs || typeof data.docs !== 'object') throw new Error('这不是双语阅读器的学习数据备份文件');
  if ((+data.version || 0) > 1) throw new Error('这个备份来自更新版本的阅读器，请先升级后再恢复');
  const ok = /^(?:vocab|stats|lookups|settings|library|(?:books|notes|ai-chats)\/[A-Za-z0-9_-]{1,80})$/;
  const docs = {};
  for (const [k, v] of Object.entries(data.docs)) if (ok.test(k) && v && typeof v === 'object' && !Array.isArray(v)) docs[k] = v;
  if (!Object.keys(docs).length) throw new Error('备份文件里没有可以恢复的数据');
  return { ...data, docs };
}

function backupSummary(data) {
  const d = data.docs;
  const keys = Object.keys(d);
  const sum = (pre, f) => keys.filter((k) => k.startsWith(pre + '/')).reduce((n, k) => n + f(d[k]), 0);
  return {
    created: +data.created || 0,
    vocab: ((d.vocab && d.vocab.items) || []).length,
    notes: sum('notes', (x) => (Array.isArray(x.items) ? x.items.length : 0)),
    bookmarks: sum('books', (x) => (Array.isArray(x.bookmarks) ? x.bookmarks.length : 0)),
    books: ((d.library && d.library.books) || []).length,
    days: Object.keys((d.stats && d.stats.days) || {}).length,
    lookups: Object.keys((d.lookups && d.lookups.items) || {}).length,
    chats: keys.filter((k) => k.startsWith('ai-chats/')).length,
    settings: !!d.settings,
  };
}

function fileFingerprint(file, size) {
  const h = crypto.createHash('sha1');
  h.update(String(size));
  const fd = fs.openSync(file, 'r');
  try {
    const n = Math.min(size, 65536);
    const head = Buffer.alloc(n);
    fs.readSync(fd, head, 0, n, 0);
    h.update(head);
    if (size > n) {
      const tail = Buffer.alloc(n);
      fs.readSync(fd, tail, 0, n, Math.max(0, size - n));
      h.update(tail);
    }
  } finally {
    fs.closeSync(fd);
  }
  return h.digest('hex').slice(0, 20);
}

function parseEpubObfuscation(zip) {
  const map = new Map();
  const encXml = zip.readText('META-INF/encryption.xml');
  if (!encXml) return map;
  const blocks = encXml.match(/<(?:\w+:)?EncryptedData[\s\S]*?<\/(?:\w+:)?EncryptedData>/g) || [];
  for (const blk of blocks) {
    const alg = /Algorithm\s*=\s*"([^"]+)"/.exec(blk);
    const uri = /<(?:\w+:)?CipherReference[^>]*URI\s*=\s*"([^"]+)"/.exec(blk);
    if (!alg || !uri) continue;
    const a = alg[1];
    if (a !== 'http://www.idpf.org/2008/embedding' && a !== 'http://ns.adobe.com/pdf/enc#RC' && /\.(x?html?|xml|ncx|opf)$/i.test(uri[1])) map.drm = true;
    if (a === 'http://www.idpf.org/2008/embedding' || a === 'http://ns.adobe.com/pdf/enc#RC') {
      let p;
      try { p = decodeURIComponent(uri[1]); } catch { p = uri[1]; }
      map.set(p.replace(/^\/+/, '').toLowerCase(), a);
    }
  }
  if (!map.size) return map;
  const container = zip.readText('META-INF/container.xml') || '';
  const opfPath = (/full-path\s*=\s*"([^"]+)"/.exec(container) || [])[1];
  const opf = opfPath ? (zip.readText(opfPath) || '') : '';
  const uidRef = (/<package[^>]*unique-identifier\s*=\s*"([^"]+)"/.exec(opf) || [])[1];
  let uid = '';
  if (uidRef) {
    const re = new RegExp('<(?:dc:)?identifier[^>]*id\\s*=\\s*"' + uidRef.replace(/[.*+?^${}()|[\]\\]/g, '\\$&') + '"[^>]*>([^<]*)<', 'i');
    uid = ((re.exec(opf) || [])[1] || '').trim();
  }
  if (!uid) uid = ((/<(?:dc:)?identifier[^>]*>([^<]*)</i.exec(opf) || [])[1] || '').trim();
  const allIds = [...opf.matchAll(/<(?:dc:)?identifier[^>]*>([^<]*)</gi)].map((m) => m[1].trim());
  const uuid = allIds.map((s) => s.replace(/^urn:uuid:/i, '').replace(/-/g, '')).find((s) => /^[0-9a-f]{32}$/i.test(s));
  map.idpfKey = crypto.createHash('sha1').update(uid.replace(/[ \u0009\u000d\u000a]/g, ''), 'utf8').digest();
  map.adobeKey = uuid ? Buffer.from(uuid, 'hex') : null;
  return map;
}

function deobfuscate(data, alg, keys) {
  const out = Buffer.from(data);
  if (alg === 'http://www.idpf.org/2008/embedding') {
    const key = keys.idpfKey;
    const n = Math.min(1040, out.length);
    for (let i = 0; i < n; i++) out[i] ^= key[i % key.length];
  } else if (alg === 'http://ns.adobe.com/pdf/enc#RC' && keys.adobeKey) {
    const key = keys.adobeKey;
    const n = Math.min(1024, out.length);
    for (let i = 0; i < n; i++) out[i] ^= key[i % key.length];
  }
  return out;
}

function safeDecode(s) {
  try { return decodeURIComponent(s); } catch { return s; }
}

function csvCell(v) {
  const s = String(v == null ? '' : v);
  return /[",\r\n]/.test(s) ? '"' + s.replace(/"/g, '""') + '"' : s;
}

class Service {
  constructor({ userDataDir, appDir }) {
    this.appDir = appDir;
    this.uiDir = path.join(appDir, 'renderer');
    this.store = new Store(userDataDir);
    this.dicts = new DictManager({ store: this.store, appDir });
    this.books = new Map();
    // events pushed to the renderer (Electron: webContents.send; test harness: server-sent events)
    this.emit = () => {};
    this.ai = new AiManager({ store: this.store, appDir, emit: (channel, payload) => this.emit(channel, payload) });
    this.learn = new LearnManager({ store: this.store, dicts: this.dicts });
  }

  // ---------- state ----------
  getState() {
    const lib = this.store.get('library', { books: [] });
    const books = lib.books
      .map((b) => ({ ...b, missing: !b.path || !fs.existsSync(b.path) }))
      .sort((a, b) => (b.lastOpened || 0) - (a.lastOpened || 0));
    return {
      settings: this.store.get('settings', {}),
      library: books,
      dicts: this.dicts.list(),
      vocabCount: this.store.get('vocab', { items: [] }).items.length,
    };
  }

  saveSettings(settings) {
    this.store.set('settings', settings || {});
    return true;
  }

  // ---------- books ----------
  openBook(filePath) {
    if (!filePath) throw new Error('没有指定文件');
    filePath = path.resolve(String(filePath));
    if (!fs.existsSync(filePath)) throw new Error('文件不存在：' + filePath);
    const st = fs.statSync(filePath);
    if (!st.isFile()) throw new Error('不是文件：' + filePath);
    const type = detectType(filePath);
    if (!type) throw new Error('不支持的文件类型（支持 EPUB、PDF、HTML）');
    const id = fileFingerprint(filePath, st.size);
    const old = this.books.get(id);
    if (old && old.zip) old.zip.close();
    const book = { id, type, path: filePath, dir: path.dirname(filePath), name: path.basename(filePath), size: st.size };
    if (type === 'epub') {
      book.zip = new ZipReader(filePath);
      if (!book.zip.find('META-INF/container.xml') && !book.zip.list().some((n) => /\.opf$/i.test(n))) {
        book.zip.close();
        throw new Error('EPUB 文件结构不完整（缺少 META-INF/container.xml）');
      }
      try { book.obf = parseEpubObfuscation(book.zip); } catch { book.obf = new Map(); }
      if (book.obf.drm || book.zip.find('META-INF/rights.xml')) {
        book.zip.close();
        throw new Error('这本 EPUB 受 DRM 版权保护（加密），无法打开。请使用未加密的版本。');
      }
    }
    this.books.set(id, book);

    const lib = this.store.get('library', { books: [] });
    let entry = lib.books.find((b) => b.id === id);
    const now = Date.now();
    if (!entry) {
      entry = { id, type, path: filePath, name: book.name, title: book.name.replace(/\.[^.]+$/, ''), size: st.size, addedAt: now };
      lib.books.push(entry);
    }
    entry.path = filePath;
    entry.name = book.name;
    entry.lastOpened = now;
    if (lib.books.length > 300) {
      lib.books.sort((a, b) => (b.lastOpened || 0) - (a.lastOpened || 0));
      lib.books.length = 300;
    }
    this.store.set('library', lib);
    const base = `/book/${id}/`;
    let entryUrl = null;
    if (type === 'html') entryUrl = base + encodeURIComponent(book.name);
    if (type === 'pdf') entryUrl = base + '__file.pdf';
    return { bookId: id, type, name: book.name, path: filePath, size: st.size, baseUrl: base, entryUrl, library: entry, data: this.getBookData(id) };
  }

  closeBook(bookId) {
    const b = this.books.get(bookId);
    if (b && b.zip) b.zip.close();
    this.books.delete(bookId);
    return true;
  }

  updateLibrary(bookId, patch) {
    const lib = this.store.get('library', { books: [] });
    const e = lib.books.find((b) => b.id === bookId);
    if (!e) return null;
    for (const k of ['title', 'author', 'cover', 'progress', 'posLabel', 'lastRead', 'lang']) {
      if (patch && patch[k] !== undefined) e[k] = patch[k];
    }
    this.store.set('library', lib);
    return e;
  }

  removeFromLibrary(bookId) {
    const lib = this.store.get('library', { books: [] });
    lib.books = lib.books.filter((b) => b.id !== bookId);
    this.store.set('library', lib);
    return true;
  }

  getBookData(bookId) {
    return this.store.get('books/' + bookId, { position: null, bookmarks: [], align: {} });
  }

  saveBookData(bookId, patch) {
    const d = this.getBookData(bookId);
    Object.assign(d, patch || {});
    this.store.set('books/' + bookId, d);
    return true;
  }

  // ---------- dictionaries ----------
  lookup(query, ctx) {
    const c = ctx || {};
    const r = this.dicts.lookup(query, c);
    if (!c.noStats && r && r.query) {
      this.learn.bump({ lookups: 1 });
      // English words that were found go into the lookup history (base form: hedged -> hedge)
      if (r.sections.length && /[A-Za-z]/.test(r.query)) {
        const word = (r.morph && r.morph.lemma) || r.headword || r.query;
        try { r.seen = this.learn.recordLookup({ word, sentence: c.sentence, book: c.book }); } catch { /* ignore */ }
      }
    }
    return r;
  }
  lookupHistory(limit) { return this.learn.lookupHistory(limit); }

  // ---------- learning data backup ----------
  // vocabulary + review progress, statistics, lookup history, notes, bookmarks / positions, settings,
  // AI chats. Never API keys (ai.json) or dictionaries.
  _backupKeys() {
    const keys = ['vocab', 'stats', 'lookups', 'settings', 'library'];
    for (const pre of ['books', 'notes', 'ai-chats']) for (const k of this.store.list(pre)) keys.push(pre + '/' + k);
    return keys;
  }

  backupData() {
    this.store.flush();
    const docs = {};
    for (const k of this._backupKeys()) {
      const v = this.store.get(k, null);
      if (v && typeof v === 'object') docs[k] = v;
    }
    return { app: 'BilingualReader', kind: 'learning-data', version: 1, created: Date.now(), docs };
  }

  backupExport(file) {
    const f = String(file || '');
    if (!f) throw new Error('没有选择文件');
    const data = this.backupData();
    fs.writeFileSync(f, JSON.stringify(data), 'utf8');
    return { ...backupSummary(data), file: f };
  }

  backupInspect(src) { return backupSummary(parseBackup(src)); }

  backupRestore(src) {
    const data = parseBackup(src);
    // the current data is saved first, so a restore can be undone
    const dir = path.join(this.store.dir, 'backups');
    fs.mkdirSync(dir, { recursive: true });
    const stamp = new Date().toISOString().replace(/[:.]/g, '-').slice(0, 19);
    const safety = path.join(dir, `before-restore-${stamp}.json`);
    fs.writeFileSync(safety, JSON.stringify(this.backupData()), 'utf8');
    try {
      const old = fs.readdirSync(dir).filter((f) => /^before-restore-.*\.json$/.test(f)).sort();
      for (const f of old.slice(0, Math.max(0, old.length - 5))) fs.unlinkSync(path.join(dir, f));
    } catch { /* ignore */ }
    for (const [k, v] of Object.entries(data.docs)) {
      if (k === 'library') {
        // books of this computer stay; books from the backup are added (shown as missing until opened here)
        const lib = this.store.get('library', { books: [] });
        const byId = new Map(lib.books.map((b) => [b.id, b]));
        for (const b of Array.isArray(v.books) ? v.books : []) {
          if (!b || !b.id) continue;
          const cur = byId.get(b.id);
          if (!cur) { lib.books.push(b); continue; }
          const keepPath = cur.path && fs.existsSync(cur.path);
          Object.assign(cur, { ...b, path: keepPath ? cur.path : b.path, lastOpened: Math.max(cur.lastOpened || 0, b.lastOpened || 0) });
        }
        this.store.set('library', lib, true);
      } else this.store.set(k, v, true);
    }
    return { ...backupSummary(data), safety };
  }
  lookupForget(word) { return this.learn.lookupForget(word); }
  dictList() { return this.dicts.list(); }
  dictImport(file) {
    const ext = path.extname(String(file)).toLowerCase();
    if (ext === '.mdx' || ext === '.mdd') return this.dicts.importMdx(file);
    if (ext === '.csv' || ext === '.tsv' || ext === '.txt') return this.dicts.importCsv(file);
    throw new Error('不支持的词库格式：' + ext + '（支持 .mdx/.mdd、.csv/.tsv/.txt）');
  }
  dictRemove(id) { return this.dicts.remove(id); }
  dictSetEnabled(id, enabled) { return this.dicts.setEnabled(id, enabled); }
  dictMove(id, delta) { return this.dicts.move(id, delta); }
  dictRename(id, name) { return this.dicts.rename(id, name); }

  // ---------- vocabulary book ----------
  vocabList() { return this.store.get('vocab', { items: [] }).items; }

  vocabAdd(item) {
    const v = this.store.get('vocab', { items: [] });
    const word = String(item && item.word || '').trim();
    if (!word) throw new Error('单词为空');
    const sentence = String(item.sentence || '').trim();
    const dup = v.items.find((x) => x.word.toLowerCase() === word.toLowerCase() && (x.sentence || '') === sentence);
    if (dup) return { item: dup, duplicate: true };
    const rec = {
      id: crypto.randomBytes(6).toString('hex'),
      word,
      phonetic: item.phonetic || '',
      def: item.def || '',
      sentence,
      sentenceZh: item.sentenceZh || '',
      bookId: item.bookId || '',
      bookTitle: item.bookTitle || '',
      chapter: item.chapter || '',
      pos: item.pos || null,
      note: item.note || '',
      added: Date.now(),
    };
    v.items.unshift(rec);
    this.store.set('vocab', v);
    this.learn.bump({ added: 1 });
    return { item: rec, duplicate: false };
  }

  vocabUpdate(id, patch) {
    const v = this.store.get('vocab', { items: [] });
    const it = v.items.find((x) => x.id === id);
    if (it) for (const k of ['note', 'def', 'phonetic', 'sentence', 'sentenceZh']) if (patch[k] !== undefined) it[k] = String(patch[k]);
    this.store.set('vocab', v);
    return it || null;
  }

  vocabRemove(id) {
    const v = this.store.get('vocab', { items: [] });
    v.items = v.items.filter((x) => x.id !== id);
    this.store.set('vocab', v);
    return true;
  }

  vocabExportText(format) {
    const items = this.vocabList();
    if (format === 'anki') {
      return items.map((x) => [x.word, [x.phonetic, x.def].filter(Boolean).join(' '), x.sentence, x.sentenceZh]
        .map((s) => String(s || '').replace(/[\t\r\n]+/g, ' ')).join('\t')).join('\n');
    }
    const head = ['单词', '音标', '释义', '原句', '原句译文', '书名', '章节', '笔记', '添加时间'];
    const rows = items.map((x) => [x.word, x.phonetic, x.def, x.sentence, x.sentenceZh, x.bookTitle, x.chapter, x.note,
      new Date(x.added).toLocaleString('zh-CN', { hour12: false })]);
    return '﻿' + [head, ...rows].map((r) => r.map(csvCell).join(',')).join('\r\n');
  }

  vocabExport(file, format) {
    fs.writeFileSync(file, this.vocabExportText(format), 'utf8');
    return true;
  }

  exists(p) { try { return fs.existsSync(p); } catch { return false; } }

  // ---------- learning: review, statistics, glossary, notes ----------
  vocabQueue(newLimit) { return this.learn.queue(this.vocabList(), { newLimit: +newLimit || 20 }); }

  vocabGrade(id, grade) {
    const v = this.store.get('vocab', { items: [] });
    const it = v.items.find((x) => x.id === id);
    if (!it) throw new Error('生词不存在');
    const r = this.learn.grade(it, grade);
    it.srs = r.srs;
    this.store.set('vocab', v);
    return { id, ...r };
  }

  vocabResetProgress(id) {
    const v = this.store.get('vocab', { items: [] });
    const it = v.items.find((x) => x.id === id);
    if (it) { delete it.srs; this.store.set('vocab', v); }
    return !!it;
  }

  vocabForms() { return this.learn.vocabForms(this.vocabList()); }
  studyStats() { return this.learn.summary(this.vocabList()); }

  // reading time reported by the window (seconds); capped so a stuck timer cannot inflate it
  statsRead(seconds) {
    const s = Math.max(0, Math.min(180, +seconds || 0));
    if (s) this.learn.bump({ read: s });
    return true;
  }

  glossary(text) { return this.learn.glossary(text, this.vocabList()); }
  notesList(bookId) { return this.learn.notes(bookId); }
  noteAdd(bookId, note) { return this.learn.noteAdd(bookId, note); }
  noteUpdate(bookId, id, patch) { return this.learn.noteUpdate(bookId, id, patch); }
  noteRemove(bookId, id) { return this.learn.noteRemove(bookId, id); }
  notesMarkdown(bookId, title) { return this.learn.notesMarkdown(bookId, title); }
  notesExport(file, bookId, title) {
    fs.writeFileSync(file, '\uFEFF' + this.learn.notesMarkdown(bookId, title), 'utf8');
    return true;
  }

  // ---------- AI chat (Gemini) ----------
  aiConfig() { return this.ai.config(); }
  aiSaveConfig(patch) { return this.ai.saveConfig(patch); }
  aiSetKey(key, provider) { return this.ai.setKey(key, provider || 'gemini'); }
  aiModels(refresh, provider) { return this.ai.models(!!refresh, provider || ''); }
  aiTest(key, provider, opts) { return this.ai.test(key, provider == null ? 'gemini' : provider, opts || {}); }
  aiSaveProvider(p) { return this.ai.saveProvider(p); }
  aiRemoveProvider(id) { return this.ai.removeProvider(id); }
  aiChat(id, req) {
    const r = this.ai.chat(id, req);
    this.learn.bump({ ai: 1 });
    return r;
  }
  aiQuiz(req) { this.learn.bump({ ai: 1 }); return this.ai.quiz(req); }
  aiCancel(id) { return this.ai.cancel(id); }
  aiHistory(bookId) { return this.ai.history(bookId); }
  aiSaveHistory(bookId, messages) { return this.ai.saveHistory(bookId, messages); }

  flush() { this.store.flush(); }

  shutdown() {
    this.ai.cancelAll();
    this.store.flush();
    for (const b of this.books.values()) if (b.zip) b.zip.close();
    this.dicts.closeAll();
  }

  // ---------- URL routing ----------
  handle(pathname, search = '') {
    try {
      const parts = pathname.split('/').filter((x, i) => i > 0);
      if (parts[0] === 'book') return this._book(parts[1], parts.slice(2).map(safeDecode).join('/'));
      if (parts[0] === 'dictres') return this._dictRes(safeDecode(parts[1] || ''), parts.slice(2).map(safeDecode).join('/'));
      if (parts[0] === 'dictentry') {
        const fid = new URLSearchParams(search).get('fid') || '';
        const html = this.dicts.entryPage(safeDecode(parts[1] || ''), safeDecode(parts.slice(2).join('/')), fid);
        if (html == null) return notFound();
        return { status: 200, headers: { 'content-type': 'text/html; charset=utf-8' }, body: Buffer.from(html, 'utf8') };
      }
      return this._ui(parts.map(safeDecode).join('/') || 'index.html');
    } catch (e) {
      return { status: 500, headers: { 'content-type': 'text/plain; charset=utf-8' }, body: Buffer.from(String(e && e.message || e), 'utf8') };
    }
  }

  _ui(rel) {
    const full = path.resolve(this.uiDir, rel);
    if (!full.startsWith(path.resolve(this.uiDir))) return notFound();
    let data;
    try { data = fs.readFileSync(full); } catch { return notFound(); }
    return { status: 200, headers: { 'content-type': mimeOf(full) }, body: data };
  }

  _book(bookId, rel) {
    const b = this.books.get(bookId);
    if (!b) return notFound('书籍未打开');
    const csp = "script-src 'none'; object-src 'none'";
    if (b.type === 'epub') {
      const e = b.zip.find(rel);
      if (!e) return notFound();
      let data = b.zip.read(e);
      const alg = b.obf && b.obf.get(e.name.toLowerCase());
      if (alg) data = deobfuscate(data, alg, b.obf);
      return { status: 200, headers: { 'content-type': mimeOf(e.name), 'content-security-policy': csp }, body: data };
    }
    if (b.type === 'pdf') {
      if (rel !== '__file.pdf') return notFound();
      return { status: 200, headers: { 'content-type': 'application/pdf' }, body: fs.readFileSync(b.path) };
    }
    if (b.type === 'html') {
      const root = path.resolve(b.dir);
      const full = path.resolve(root, rel);
      if (full !== root && !full.startsWith(root + path.sep)) return { status: 403, headers: {}, body: Buffer.from('forbidden') };
      let data;
      try { data = fs.readFileSync(full); } catch { return notFound(); }
      return { status: 200, headers: { 'content-type': mimeOf(full), 'content-security-policy': csp }, body: data };
    }
    return notFound();
  }

  _dictRes(dictId, rel) {
    const data = this.dicts.resource(dictId, rel);
    if (!data) return notFound();
    return { status: 200, headers: { 'content-type': mimeOf(rel), 'access-control-allow-origin': '*' }, body: data };
  }
}

function notFound(msg) {
  return { status: 404, headers: { 'content-type': 'text/plain; charset=utf-8' }, body: Buffer.from(msg || 'not found', 'utf8') };
}

// Methods the renderer may call through IPC / HTTP.
const API_METHODS = [
  'getState', 'saveSettings', 'openBook', 'closeBook', 'updateLibrary', 'removeFromLibrary', 'getBookData', 'saveBookData',
  'lookup', 'dictList', 'dictImport', 'dictRemove', 'dictSetEnabled', 'dictMove', 'dictRename',
  'vocabList', 'vocabAdd', 'vocabUpdate', 'vocabRemove', 'vocabExport', 'vocabExportText', 'exists',
  'aiConfig', 'aiSaveConfig', 'aiSetKey', 'aiModels', 'aiTest', 'aiChat', 'aiCancel', 'aiHistory', 'aiSaveHistory', 'aiQuiz', 'aiSaveProvider', 'aiRemoveProvider',
  'vocabQueue', 'vocabGrade', 'vocabResetProgress', 'vocabForms', 'studyStats', 'statsRead', 'glossary',
  'notesList', 'noteAdd', 'noteUpdate', 'noteRemove', 'notesMarkdown', 'notesExport',
  'lookupHistory', 'lookupForget', 'backupData', 'backupExport', 'backupInspect', 'backupRestore',
];

module.exports = { Service, API_METHODS, mimeOf };
