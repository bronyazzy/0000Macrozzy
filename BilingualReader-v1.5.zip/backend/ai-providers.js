'use strict';
// HTTP clients for the AI services the reader can talk to:
//   gemini     Google Gemini REST API (generateContent / streamGenerateContent?alt=sse, x-goog-api-key)
//   openai     OpenAI Chat Completions and the many compatible services: DeepSeek, Kimi, Qwen, GLM,
//              OpenRouter, a local Ollama / LM Studio, …
//   anthropic  Anthropic Messages API (Claude) and compatible endpoints
// Network calls go through an injected fetch (Electron's net.fetch in the app, so the Windows / system
// proxy settings are honoured).

const GEMINI_BASE = 'https://generativelanguage.googleapis.com/v1beta';
const ANTHROPIC_VERSION = '2023-06-01';

// Services built into the settings page; more OpenAI / Anthropic compatible services can be added (PRESETS).
const BUILTIN = [
  {
    id: 'gemini', type: 'gemini', name: 'Google Gemini', short: 'Gemini', base: GEMINI_BASE, env: 'BR_GEMINI_BASE',
    defaultModel: 'gemini-3.8-flash', keyUrl: 'https://aistudio.google.com/apikey', keyPlaceholder: 'AQ.… 或 AIza…', keyFile: 'gemini-api-key.txt',
  },
  {
    id: 'deepseek', type: 'openai', flavor: 'deepseek', name: 'DeepSeek', short: 'DeepSeek', base: 'https://api.deepseek.com', env: 'BR_DEEPSEEK_BASE',
    defaultModel: 'deepseek-flash', keyUrl: 'https://platform.deepseek.com/api_keys', keyPlaceholder: 'sk-…', keyFile: 'deepseek-api-key.txt',
  },
  {
    id: 'openai', type: 'openai', flavor: 'openai', name: 'OpenAI', short: 'OpenAI', base: 'https://api.openai.com/v1', env: 'BR_OPENAI_BASE',
    prefer: [/^gpt-\d+(?:\.\d+)?-mini$/, /^gpt-\d+(?:\.\d+)?$/], keyUrl: 'https://platform.openai.com/api-keys', keyPlaceholder: 'sk-…', keyFile: 'openai-api-key.txt',
  },
  {
    id: 'anthropic', type: 'anthropic', name: 'Anthropic Claude', short: 'Claude', base: 'https://api.anthropic.com/v1', env: 'BR_ANTHROPIC_BASE',
    prefer: [/sonnet/], keyUrl: 'https://platform.claude.com/settings/keys', keyPlaceholder: 'sk-ant-…', keyFile: 'anthropic-api-key.txt',
  },
];

// Starting points for "添加其他服务"; every field stays editable.
const PRESETS = [
  { id: 'openrouter', name: 'OpenRouter', type: 'openai', base: 'https://openrouter.ai/api/v1', note: '一个 Key 可以使用多家公司的模型。' },
  { id: 'kimi', name: 'Kimi（月之暗面）', type: 'openai', base: 'https://api.moonshot.ai/v1', note: '国际站地址；中国大陆账号请改为 https://api.moonshot.cn/v1' },
  { id: 'qwen', name: '通义千问（阿里云百炼）', type: 'openai', base: 'https://dashscope-intl.aliyuncs.com/compatible-mode/v1', note: '国际站（新加坡）地址；中国大陆账号请改为 https://dashscope.aliyuncs.com/compatible-mode/v1' },
  { id: 'glm', name: '智谱 GLM（Z.ai）', type: 'openai', base: 'https://api.z.ai/api/paas/v4', note: '国际站地址；中国大陆账号请改为 https://open.bigmodel.cn/api/paas/v4。获取不到模型列表时，请在“模型名称”中填写，例如 glm-5.1' },
  { id: 'siliconflow', name: '硅基流动 SiliconFlow', type: 'openai', base: 'https://api.siliconflow.com/v1', note: '国际站地址；中国大陆账号请改为 https://api.siliconflow.cn/v1' },
  { id: 'xai', name: 'xAI Grok', type: 'openai', base: 'https://api.x.ai/v1' },
  { id: 'ollama', name: 'Ollama（本机模型）', type: 'openai', base: 'http://localhost:11434/v1', noKey: true, note: '模型在自己的电脑上运行，不联网、不需要 Key；请先在 Ollama 中下载模型。' },
  { id: 'lmstudio', name: 'LM Studio（本机模型）', type: 'openai', base: 'http://localhost:1234/v1', noKey: true, note: '在 LM Studio 中加载模型并启动本地服务器（Developer → Start Server）。' },
  { id: 'custom', name: '其他服务（OpenAI 兼容）', type: 'openai', base: '', note: '填写服务商文档中的 base_url（通常以 /v1 结尾）。' },
  { id: 'custom-anthropic', name: '其他服务（Anthropic 兼容）', type: 'anthropic', base: '', note: '填写 Anthropic 兼容接口的地址，例如 https://api.deepseek.com/anthropic' },
];

class AiError extends Error {
  constructor(message, info = {}) {
    super(message);
    Object.assign(this, info);
  }
}

function maskKey(k) {
  const s = String(k || '');
  if (!s) return '';
  return s.length <= 12 ? '••••' : s.slice(0, 5) + '…' + s.slice(-4);
}

// one token of printable ASCII without spaces (API keys of every service fit this)
function validKey(k) {
  return /^[\x21-\x7e]{12,800}$/.test(String(k || ''));
}

function normBase(u) {
  return String(u || '').trim().replace(/\/+$/, '').replace(/\/chat\/completions$/i, '').replace(/\/messages$/i, '');
}

function isLocalUrl(u) {
  return /^https?:\/\/(localhost|127\.\d+\.\d+\.\d+|\[::1\]|0\.0\.0\.0)(:|\/|$)/i.test(String(u || ''));
}

// ---------------------------------------------------------------- errors

function errorInfo(body) {
  try {
    const j = JSON.parse(body);
    const e = (j && (j.error || (Array.isArray(j) && j[0] && j[0].error))) || j || {};
    if (typeof e === 'string') return { msg: e, status: '', reason: '', type: '' };
    const reason = ((e.details || []).find((d) => d && d.reason) || {}).reason || '';
    const msg = e.message || (typeof j.message === 'string' ? j.message : '') || (typeof j.detail === 'string' ? j.detail : '');
    return { msg: String(msg || ''), status: String(e.status || e.code || ''), reason, type: String(e.type || '') };
  } catch {
    return { msg: String(body || '').replace(/<[^>]+>/g, ' ').replace(/\s+/g, ' ').trim().slice(0, 300), status: '', reason: '', type: '' };
  }
}

function ctxOf(c) {
  return c && typeof c === 'object' ? c : { model: c || '' };
}

// Chinese message for an HTTP error; c = model name (Gemini) or { label, model, what: 'chat' | 'models' }
function describeHttpError(status, body, c) {
  const ctx = ctxOf(c);
  const label = ctx.label || 'Gemini';
  const { msg, status: st, reason, type } = errorInfo(body);
  const all = `${msg} ${reason} ${st} ${type}`;
  const more = msg ? '\n' + msg : '';
  if (/API_KEY_INVALID|API key not valid|API_KEY_EXPIRED|invalid[ _-]?api[ _-]?key|incorrect api key|invalid x-api-key|authentication_error|invalid_authentication|key.*expired/i.test(all) || status === 401) {
    return `API Key 无效或已过期（${label}），请在「设置 → AI 对话」中重新填写。`;
  }
  if (status === 402 || /insufficient[ _-]?(balance|quota|funds)|余额不足|credit balance is too low|billing/i.test(all)) return `${label} 账户余额不足或没有开通付费，请充值后再试。${more}`;
  if (/location is not supported|User location|unsupported_country|not available in your (country|region)/i.test(all)) return `当前所在地区不能使用 ${label}：${msg}`;
  if (status === 403) return `API Key 没有访问权限（403${reason ? '，' + reason : ''}）：${msg || '请确认 Key 有效并已开通对应的服务'}`;
  if (status === 404) {
    if (ctx.what === 'models') return `获取模型列表失败（404）：接口地址可能不对，或者该服务不提供模型列表（可以手动填写模型名称）。${more}`;
    return `找不到模型“${ctx.model || ''}”。请点模型列表旁的刷新按钮，重新选择一个模型。${more}`;
  }
  if (status === 429) return `请求太频繁或额度已用完（429）。${msg || '请稍后再试。'}`;
  if (status === 529 || /overloaded/i.test(type)) return `${label} 服务繁忙（${status}），请稍后再试。${more}`;
  if (status >= 500) return `${label} 服务暂时不可用（${status}），请稍后再试。${more}`;
  return `请求失败（${status}${st && st !== String(status) ? ' ' + st : ''}）：${msg || '未知错误'}`;
}

function describeNetError(e, c) {
  const ctx = ctxOf(c);
  const m = String((e && e.cause && (e.cause.code || e.cause.message)) || (e && e.message) || e);
  if (ctx.local) return `无法连接本机的模型服务（${m}）。请确认 Ollama / LM Studio 已经启动，接口地址和端口正确。`;
  return `无法连接 ${ctx.label || 'Gemini'} 服务（${m}）。请检查网络和接口地址；使用代理 / VPN 时请打开「系统代理」。`;
}

// 400 caused by the reasoning options (the model does not support them) — retried without them
function isReasoningParamError(e) {
  return !!(e && (e.status === 400 || e.status === 422) && /thinking|reasoning|effort|output_config|budget/i.test(String(e.message || '')));
}

async function request(fetchFn, url, init, ctx) {
  let res;
  try {
    res = await fetchFn(url, init);
  } catch (e) {
    if (init.signal && init.signal.aborted) throw new AiError('已停止', { aborted: true });
    throw new AiError(describeNetError(e, ctx), { network: true });
  }
  if (!res.ok) {
    let body = '';
    try { body = await res.text(); } catch { /* ignore */ }
    throw new AiError(describeHttpError(res.status, body, ctx), { status: res.status });
  }
  return res;
}

// Parsed JSON objects of a server-sent-events body ("data: …" blocks); stops at "data: [DONE]".
async function* sseJson(res, signal, ctx) {
  if (!res.body) throw new AiError(`${ctxOf(ctx).label || 'AI 服务'} 返回了空响应`);
  const reader = res.body.getReader();
  // stop reading as soon as the user presses 停止, even if the fetch implementation ignores the signal
  const onAbort = () => { try { reader.cancel().catch(() => {}); } catch { /* ignore */ } };
  if (signal) signal.addEventListener('abort', onAbort, { once: true });
  const dec = new TextDecoder();
  let buf = '';
  let finished = false;
  const parseBlock = (block) => {
    const data = block.split(/\r?\n/).filter((l) => l.startsWith('data:')).map((l) => l.slice(5).replace(/^ /, '')).join('\n').trim();
    if (!data) return null;
    if (data === '[DONE]') return { done: true };
    try { return { json: JSON.parse(data) }; } catch { return null; }
  };
  try {
    for (;;) {
      const { value, done } = await reader.read();
      if (signal && signal.aborted) throw new AiError('已停止', { aborted: true });
      if (done) break;
      buf += dec.decode(value, { stream: true });
      let m;
      while ((m = /\r?\n\r?\n/.exec(buf))) {
        const block = buf.slice(0, m.index);
        buf = buf.slice(m.index + m[0].length);
        const r = parseBlock(block);
        if (r && r.done) { finished = true; return; }
        if (r) yield r.json;
      }
    }
    buf += dec.decode();
    if (buf.trim()) {
      const r = parseBlock(buf);
      if (r && r.json) yield r.json;
    }
    finished = true;
  } catch (e) {
    if (signal && signal.aborted) throw new AiError('已停止', { aborted: true });
    if (e instanceof AiError) throw e;
    throw new AiError(describeNetError(e, ctx), { network: true });
  } finally {
    if (signal) signal.removeEventListener('abort', onAbort);
    if (!finished) { try { reader.cancel().catch(() => {}); } catch { /* ignore */ } }
    try { reader.releaseLock(); } catch { /* ignore */ }
  }
}

// ---------------------------------------------------------------- model lists

const GEMINI_NON_CHAT = /(?:embed|imagen|veo|tts|aqa|audio|live|image|robotics|computer-use|lyria|omni|transcri|learnlm|bison|gecko)/i;
const OPENAI_NON_CHAT = /(?:embed|rerank|tts|whisper|transcri|audio|realtime|moderation|dall-e|image|davinci|babbage|speech|sora|computer-use|\bbge\b|\bclip\b)/i;
const OPENAI_RESPONSES_ONLY = /(?:^o\d+-pro|^gpt-[\d.]+(?:-\w+)?-pro\b|deep-research|codex|search|instruct)/i;

function geminiRank(id) {
  const v = /^gemini-(\d+(?:\.\d+)?)/.exec(id);
  const fam = /flash-lite|lite/.test(id) ? 2 : /flash/.test(id) ? 1 : /pro/.test(id) ? 0 : 3;
  const pre = /preview|exp|latest|-\d{2,}/.test(id) ? 1 : 0;
  return { gemini: id.startsWith('gemini') ? 0 : 1, ver: v ? parseFloat(v[1]) : 0, fam, pre };
}

function shapeModels(raw) {
  const out = [];
  const seen = new Set();
  for (const m of raw || []) {
    const id = String((m && m.name) || '').replace(/^models\//, '');
    if (!id || seen.has(id)) continue;
    const methods = m.supportedGenerationMethods || m.supportedActions || [];
    if (methods.length && !methods.includes('generateContent')) continue;
    if (GEMINI_NON_CHAT.test(id)) continue;
    seen.add(id);
    out.push({
      id,
      name: String(m.displayName || id),
      desc: String(m.description || '').slice(0, 300),
      input: m.inputTokenLimit || 0,
      output: m.outputTokenLimit || 0,
      thinking: !!m.thinking,
    });
  }
  return out.sort((a, b) => {
    const x = geminiRank(a.id);
    const y = geminiRank(b.id);
    return x.gemini - y.gemini || y.ver - x.ver || x.fam - y.fam || x.pre - y.pre || a.id.localeCompare(b.id);
  });
}

function shapeOpenAIModels(raw, flavor) {
  const out = [];
  const seen = new Set();
  for (const m of raw || []) {
    const id = String((m && (m.id || m.name || m.model)) || (typeof m === 'string' ? m : '')).trim();
    if (!id || seen.has(id)) continue;
    if (OPENAI_NON_CHAT.test(id)) continue;
    if (flavor === 'openai' && OPENAI_RESPONSES_ONLY.test(id)) continue;
    seen.add(id);
    out.push({
      id,
      name: String((m && (m.display_name || (m.name !== id && m.name))) || id),
      desc: String((m && m.description) || '').slice(0, 300),
      input: (m && (m.context_window || m.context_length)) || 0,
      output: (m && m.max_output_tokens) || 0,
      created: (m && +m.created) || 0,
    });
  }
  if (out.some((m) => m.created)) out.sort((a, b) => b.created - a.created || a.id.localeCompare(b.id));
  return out.slice(0, 1500);
}

function shapeAnthropicModels(raw) {
  const out = [];
  const seen = new Set();
  for (const m of raw || []) {
    const id = String((m && m.id) || '');
    if (!id || seen.has(id) || (m.lifecycle && m.lifecycle === 'retired')) continue;
    seen.add(id);
    out.push({ id, name: String(m.display_name || id), desc: m.lifecycle === 'deprecated' ? '即将停用' : '', input: m.max_input_tokens || 0, output: m.max_tokens || 0 });
  }
  return out;
}

// default model of a service for a model list
function pickDefault(def, models) {
  const list = models || [];
  if (!list.length) return (def && def.defaultModel) || '';
  if (def && def.defaultModel && list.some((m) => m.id === def.defaultModel)) return def.defaultModel;
  if (def && def.type === 'gemini') {
    const stable = list.filter((m) => !geminiRank(m.id).pre);
    return ((stable.find((m) => /flash/.test(m.id) && !/lite/.test(m.id))) || stable[0] || list[0]).id;
  }
  for (const re of (def && def.prefer) || []) {
    const hit = list.find((m) => re.test(m.id));
    if (hit) return hit.id;
  }
  return list[0].id;
}

// ---------------------------------------------------------------- Gemini

class GeminiClient {
  constructor({ fetch: f, baseUrl, label } = {}) {
    this.fetch = f || globalThis.fetch;
    this.base = String(baseUrl || GEMINI_BASE).replace(/\/+$/, '');
    this.ctx = { label: label || 'Gemini' };
  }

  async _request(url, init, model, what) {
    return request(this.fetch, url, init, { ...this.ctx, model, what });
  }

  async listModels(key, signal) {
    const all = [];
    let token = '';
    for (let page = 0; page < 6; page++) {
      const url = `${this.base}/models?pageSize=1000${token ? '&pageToken=' + encodeURIComponent(token) : ''}`;
      const res = await this._request(url, { method: 'GET', headers: { 'x-goog-api-key': key }, signal }, '', 'models');
      const j = await res.json();
      all.push(...(j.models || []));
      token = j.nextPageToken || '';
      if (!token) break;
    }
    return shapeModels(all);
  }

  // One-shot generateContent call (used for structured JSON output such as quizzes).
  async generate({ key, model, body, signal }) {
    const url = `${this.base}/models/${encodeURIComponent(model)}:generateContent`;
    const res = await this._request(url, {
      method: 'POST',
      headers: { 'content-type': 'application/json', 'x-goog-api-key': key },
      body: JSON.stringify(body),
      signal,
    }, model);
    return res.json();
  }

  // Yields every GenerateContentResponse chunk of a streamGenerateContent call.
  async *stream({ key, model, body, signal }) {
    const url = `${this.base}/models/${encodeURIComponent(model)}:streamGenerateContent?alt=sse`;
    const res = await this._request(url, {
      method: 'POST',
      headers: { 'content-type': 'application/json', 'x-goog-api-key': key },
      body: JSON.stringify(body),
      signal,
    }, model);
    for await (const j of sseJson(res, signal, this.ctx)) {
      if (j && j.error) throw new AiError(describeHttpError(j.error.code || 500, JSON.stringify(j), { ...this.ctx, model }), { status: j.error.code });
      yield j;
    }
  }
}

// ---------------------------------------------------------------- OpenAI Chat Completions (and compatible)

class OpenAIClient {
  constructor({ fetch: f, baseUrl, label, flavor, local } = {}) {
    this.fetch = f || globalThis.fetch;
    this.base = normBase(baseUrl);
    this.flavor = flavor || '';
    this.ctx = { label: label || 'AI 服务', local: !!local };
  }

  _headers(key) {
    const h = { 'content-type': 'application/json' };
    if (key) h.authorization = 'Bearer ' + key;
    return h;
  }

  async listModels(key, signal) {
    const res = await request(this.fetch, this.base + '/models', { method: 'GET', headers: this._headers(key), signal }, { ...this.ctx, what: 'models' });
    let j;
    try { j = await res.json(); } catch { throw new AiError('模型列表的格式无法识别，请检查接口地址。', { status: 404 }); }
    const raw = Array.isArray(j && j.data) ? j.data : Array.isArray(j && j.models) ? j.models : Array.isArray(j) ? j : null;
    if (!raw) throw new AiError('模型列表的格式无法识别，请检查接口地址。', { status: 404 });
    return shapeOpenAIModels(raw, this.flavor);
  }

  async complete({ key, model, body, signal }) {
    const res = await request(this.fetch, this.base + '/chat/completions', {
      method: 'POST', headers: this._headers(key), body: JSON.stringify({ ...body, model, stream: false }), signal,
    }, { ...this.ctx, model });
    return res.json();
  }

  // Yields chat.completion.chunk objects (a non-streamed answer is turned into one chunk).
  async *stream({ key, model, body, signal }) {
    const res = await request(this.fetch, this.base + '/chat/completions', {
      method: 'POST', headers: { ...this._headers(key), accept: 'text/event-stream' }, body: JSON.stringify({ ...body, model, stream: true }), signal,
    }, { ...this.ctx, model });
    const ct = (res.headers && res.headers.get && res.headers.get('content-type')) || '';
    if (/application\/json/i.test(ct)) {
      const j = await res.json();
      if (j && j.error) { yield j; return; }
      const c = ((j && j.choices) || [])[0] || {};
      const msg = c.message || {};
      yield { model: j.model, usage: j.usage, choices: [{ delta: { content: msg.content || '', reasoning_content: msg.reasoning_content || msg.reasoning || '' }, finish_reason: c.finish_reason || 'stop' }] };
      return;
    }
    yield* sseJson(res, signal, this.ctx);
  }
}

// ---------------------------------------------------------------- Anthropic Messages (Claude)

class AnthropicClient {
  constructor({ fetch: f, baseUrl, label, compat, local } = {}) {
    this.fetch = f || globalThis.fetch;
    this.base = normBase(baseUrl);
    this.compat = !!compat; // third-party Anthropic-compatible endpoint
    this.ctx = { label: label || 'Claude', local: !!local };
  }

  _headers(key) {
    const h = { 'content-type': 'application/json', 'anthropic-version': ANTHROPIC_VERSION };
    if (key) {
      h['x-api-key'] = key;
      if (this.compat) h.authorization = 'Bearer ' + key; // compatible services often read the bearer token
    }
    return h;
  }

  async listModels(key, signal) {
    const all = [];
    let after = '';
    for (let page = 0; page < 5; page++) {
      const url = `${this.base}/models?limit=1000${after ? '&after_id=' + encodeURIComponent(after) : ''}`;
      const res = await request(this.fetch, url, { method: 'GET', headers: this._headers(key), signal }, { ...this.ctx, what: 'models' });
      const j = await res.json();
      if (!Array.isArray(j && j.data)) throw new AiError('模型列表的格式无法识别，请检查接口地址。', { status: 404 });
      all.push(...j.data);
      if (!j.has_more || !j.last_id) break;
      after = j.last_id;
    }
    return shapeAnthropicModels(all);
  }

  async create({ key, model, body, signal }) {
    const res = await request(this.fetch, this.base + '/messages', {
      method: 'POST', headers: this._headers(key), body: JSON.stringify({ ...body, model }), signal,
    }, { ...this.ctx, model });
    return res.json();
  }

  async *stream({ key, model, body, signal }) {
    const res = await request(this.fetch, this.base + '/messages', {
      method: 'POST', headers: { ...this._headers(key), accept: 'text/event-stream' }, body: JSON.stringify({ ...body, model, stream: true }), signal,
    }, { ...this.ctx, model });
    yield* sseJson(res, signal, this.ctx);
  }
}

function describeStreamError(err, ctx) {
  const e = err || {};
  const type = String(e.type || '');
  if (/overloaded/i.test(type)) return `${ctx.label} 服务繁忙，请稍后再试。`;
  if (/rate_limit/i.test(type)) return `请求太频繁或额度已用完（429）。${e.message || ''}`;
  if (/authentication|permission/i.test(type)) return `API Key 无效或没有权限（${ctx.label}）：${e.message || ''}`;
  return `${ctx.label} 返回错误：${e.message || type || '未知错误'}`;
}

module.exports = {
  GEMINI_BASE, ANTHROPIC_VERSION, BUILTIN, PRESETS,
  AiError, maskKey, validKey, normBase, isLocalUrl, isReasoningParamError,
  describeHttpError, describeNetError, describeStreamError, errorInfo,
  shapeModels, shapeOpenAIModels, shapeAnthropicModels, pickDefault,
  GeminiClient, OpenAIClient, AnthropicClient, sseJson,
};
