'use strict';
// Learning features:
//  - spaced-repetition review of the vocabulary book (SM-2 style, four answer buttons)
//  - daily study statistics (reading time, lookups, new words, reviews, AI questions) and streak
//  - chapter glossary: finance terms of the built-in dictionary that occur in a chapter
//  - reading notes (highlights + comments) per book, exported as Markdown
const crypto = require('crypto');
const { analyze, phraseCandidates, inflections } = require('./lemma');

const DAY = 86400000;
const MASTERED_DAYS = 21;

function pad(n) { return String(n).padStart(2, '0'); }
function dayKey(t = Date.now()) {
  const d = new Date(t);
  return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
}
function startOfDay(t) {
  const d = new Date(t);
  d.setHours(0, 0, 0, 0);
  return d.getTime();
}
function addDays(t, n) {
  const d = new Date(t);
  d.setDate(d.getDate() + n);
  return d.getTime();
}

// ---------------------------------------------------------------- spaced repetition

function srsOf(item) {
  const s = item && item.srs;
  if (s && typeof s.due === 'number') return { ivl: 0, ease: 2.5, reps: 0, lapses: 0, last: 0, ...s };
  return { due: (item && item.added) || 0, ivl: 0, ease: 2.5, reps: 0, lapses: 0, last: 0 };
}

// grade: 0 忘了, 1 模糊, 2 记得, 3 简单
function schedule(s, grade, now = Date.now()) {
  const n = { ...s };
  if (grade <= 0) {
    if (s.last && s.reps > 0) n.lapses = (s.lapses || 0) + 1;
    n.reps = 0;
    n.ivl = 0;
    n.ease = Math.max(1.3, s.ease - 0.2);
    n.due = now + 10 * 60e3; // see it again in this session
  } else {
    let ivl;
    if (grade === 1) ivl = s.reps === 0 ? 1 : Math.max(s.ivl + 1, Math.round(s.ivl * 1.2));
    else if (grade === 2) ivl = s.reps === 0 ? 2 : Math.max(s.ivl + 1, Math.round(s.ivl * s.ease));
    else ivl = s.reps === 0 ? 4 : Math.max(s.ivl + 2, Math.round(s.ivl * s.ease * 1.3));
    n.ease = Math.min(3.2, Math.max(1.3, s.ease + (grade === 1 ? -0.15 : grade === 3 ? 0.15 : 0)));
    n.ivl = Math.min(ivl, 3650);
    n.reps = s.reps + 1;
    n.due = startOfDay(addDays(now, n.ivl)); // available from the start of that day
  }
  n.last = now;
  return n;
}

function ivlLabel(s, now) {
  if (!s.ivl) {
    const m = Math.max(1, Math.round((s.due - now) / 60e3));
    return m < 60 ? `${m} 分钟` : `${Math.round(m / 60)} 小时`;
  }
  if (s.ivl < 30) return `${s.ivl} 天`;
  if (s.ivl < 365) return `${(s.ivl / 30).toFixed(s.ivl < 300 ? 1 : 0).replace(/\.0$/, '')} 个月`;
  return `${(s.ivl / 365).toFixed(1).replace(/\.0$/, '')} 年`;
}

function previews(s, now = Date.now()) {
  return [0, 1, 2, 3].map((g) => ivlLabel(schedule(s, g, now), now));
}

function stateOf(s) {
  if (!s.last) return 'new';
  if (s.ivl >= MASTERED_DAYS) return 'mastered';
  return 'learning';
}

// ---------------------------------------------------------------- glossary helpers

function shortFin(e) {
  const f = (e.fin && e.fin[0]) || (e.gen && e.gen[0]) || '';
  const s = String(f).replace(/（[^）]*）|\([^)]*\)/g, '').split(/[；;]/)[0].trim();
  return (s || String(f)).slice(0, 40);
}

function sentenceAround(text, start, end) {
  let a = start;
  while (a > 0 && !/[.!?。！？\n]/.test(text[a - 1]) && start - a < 300) a--;
  let b = end;
  while (b < text.length && !/[.!?。！？\n]/.test(text[b]) && b - end < 300) b++;
  if (b < text.length && /[.!?。！？]/.test(text[b])) b++;
  return text.slice(a, b).replace(/\s+/g, ' ').trim();
}

const TOKEN = /[A-Za-z0-9][A-Za-z0-9'’-]*[A-Za-z0-9]|[A-Za-z]/g;

// ---------------------------------------------------------------- notes

const COLORS = new Set(['yellow', 'green', 'blue', 'pink']);
function cleanNote(n) {
  return {
    quote: String(n.quote || '').slice(0, 4000),
    prefix: String(n.prefix || '').slice(-60),
    suffix: String(n.suffix || '').slice(0, 60),
    color: COLORS.has(n.color) ? n.color : 'yellow',
    note: String(n.note || '').slice(0, 8000),
    chapter: Number.isFinite(+n.chapter) ? +n.chapter : 0,
    chapterKey: String(n.chapterKey || '').slice(0, 300),
    chapterTitle: String(n.chapterTitle || '').slice(0, 200),
    pos: n.pos && typeof n.pos === 'object' ? n.pos : null,
  };
}

class LearnManager {
  constructor({ store, dicts }) {
    this.store = store;
    this.dicts = dicts;
  }

  // ---------- statistics ----------
  _stats() { return this.store.get('stats', { days: {} }); }

  bump(fields, t = Date.now()) {
    const s = this._stats();
    const k = dayKey(t);
    const d = s.days[k] || (s.days[k] = {});
    for (const [f, v] of Object.entries(fields || {})) {
      const n = Number(v);
      if (!Number.isFinite(n) || n <= 0) continue;
      d[f] = Math.round(((d[f] || 0) + n) * 10) / 10;
    }
    this.store.set('stats', s);
    return d;
  }

  _active(d) { return !!d && ((d.read || 0) >= 60 || (d.reviewed || 0) > 0); }

  // ---------- lookup history ----------
  // one entry per word (base form): times looked up, first / last time, the latest sentence and book
  recordLookup({ word, sentence, book } = {}, t = Date.now()) {
    const w = String(word || '').replace(/\s+/g, ' ').trim();
    if (!w || w.length > 60) return null;
    const k = w.toLowerCase();
    const h = this.store.get('lookups', { items: {} });
    const e = h.items[k] || (h.items[k] = { w, n: 0, first: t });
    e.n++;
    e.last = t;
    if (sentence) e.s = String(sentence).replace(/\s+/g, ' ').trim().slice(0, 400);
    if (book) e.b = String(book).slice(0, 120);
    const keys = Object.keys(h.items);
    if (keys.length > 3000) {
      // forget the words looked up once, longest ago
      keys.sort((a, b) => (h.items[a].n - h.items[b].n) || (h.items[a].last - h.items[b].last));
      for (const x of keys.slice(0, keys.length - 2500)) delete h.items[x];
    }
    this.store.set('lookups', h);
    return { n: e.n, first: e.first, last: e.last };
  }

  lookupHistory(limit = 500) {
    const h = this.store.get('lookups', { items: {} });
    return Object.values(h.items).sort((a, b) => b.last - a.last).slice(0, Math.max(1, Math.min(3000, +limit || 500)))
      .map((e) => ({ word: e.w, n: e.n, first: e.first, last: e.last, sentence: e.s || '', book: e.b || '', forms: e.s ? inflections(e.w).slice(0, 40) : [] }));
  }

  lookupForget(word) {
    const h = this.store.get('lookups', { items: {} });
    if (word == null) h.items = {};
    else delete h.items[String(word).toLowerCase()];
    this.store.set('lookups', h);
    return true;
  }

  summary(vocabItems) {
    const s = this._stats();
    const now = Date.now();
    const days = [];
    for (let i = 29; i >= 0; i--) {
      const k = dayKey(addDays(now, -i));
      days.push({ day: k, ...(s.days[k] || {}) });
    }
    const today = s.days[dayKey(now)] || {};
    let streak = 0;
    let i = this._active(today) ? 0 : 1;
    for (; i < 3650; i++) {
      if (this._active(s.days[dayKey(addDays(now, -i))])) streak++;
      else break;
    }
    const totals = { words: 0, new: 0, learning: 0, mastered: 0, due: 0, dueTomorrow: 0 };
    const tomorrow = startOfDay(addDays(now, 1));
    for (const it of vocabItems || []) {
      const sr = srsOf(it);
      totals.words++;
      totals[stateOf(sr)]++;
      if (sr.last && sr.due <= now) totals.due++;
      else if (sr.last && sr.due < addDays(tomorrow, 1)) totals.dueTomorrow++;
    }
    let readAll = 0;
    let activeDays = 0;
    for (const d of Object.values(s.days)) {
      readAll += d.read || 0;
      if (this._active(d)) activeDays++;
    }
    return { today, streak, days, totals, readAll, activeDays };
  }

  // ---------- review ----------
  queue(vocabItems, { newLimit = 20 } = {}) {
    const now = Date.now();
    const today = this._stats().days[dayKey(now)] || {};
    // the vocabulary list is newest first; _i breaks ties between words added in the same millisecond
    const items = (vocabItems || []).map((x, i) => ({ ...x, srs: srsOf(x), _i: i }));
    const due = items.filter((x) => x.srs.last && x.srs.due <= now).sort((a, b) => a.srs.due - b.srs.due);
    const fresh = items.filter((x) => !x.srs.last).sort((a, b) => (a.added || 0) - (b.added || 0) || b._i - a._i);
    const room = Math.max(0, Math.round(newLimit) - (today.newLearned || 0));
    const pick = fresh.slice(0, room);
    return {
      items: [...due, ...pick].map(({ _i, ...x }) => ({ ...x, state: stateOf(x.srs), preview: previews(x.srs, now), forms: inflections(String(x.word || '')).slice(0, 40) })),
      dueCount: due.length,
      newCount: pick.length,
      newWaiting: fresh.length,
      newToday: today.newLearned || 0,
    };
  }

  grade(item, grade) {
    const g = Math.max(0, Math.min(3, Math.round(+grade)));
    const now = Date.now();
    const before = srsOf(item);
    const next = schedule(before, g, now);
    const bump = { reviewed: 1 };
    if (g >= 2) bump.correct = 1;
    if (!before.last) bump.newLearned = 1;
    this.bump(bump, now);
    return { srs: next, state: stateOf(next), preview: previews(next, now), nextLabel: ivlLabel(next, now) };
  }

  // ---------- glossary ----------
  glossary(text, vocabItems) {
    const idx = this.dicts.builtin.index;
    const src = String(text || '').slice(0, 400000);
    const toks = [];
    let m;
    TOKEN.lastIndex = 0;
    while ((m = TOKEN.exec(src))) toks.push({ w: m[0].replace(/’/g, "'"), s: m.index, e: m.index + m[0].length });
    if (!this._maxN) {
      let mx = 1;
      for (const k of idx.keys()) mx = Math.max(mx, k.split(' ').length);
      this._maxN = Math.min(mx, 6);
    }
    const memo = new Map();
    const lookupWord = (w) => {
      const k = w.toLowerCase();
      if (memo.has(k)) return memo.get(k);
      let e = null;
      for (const c of analyze(w.replace(/'s$/i, '')).cands) {
        if (c.score < 80) break;
        e = idx.get(c.w.toLowerCase()) || null;
        if (e) break;
      }
      memo.set(k, e);
      return e;
    };
    const vocab = new Set((vocabItems || []).map((x) => String(x.word || '').toLowerCase()));
    const found = new Map();
    const hit = (e, s, end) => {
      let r = found.get(e.w);
      if (!r) {
        r = { w: e.w, ph: e.ph || '', pos: e.pos || '', fin: shortFin(e), count: 0, first: s, sentence: sentenceAround(src, s, end), inVocab: vocab.has(e.w.toLowerCase()) };
        found.set(e.w, r);
      }
      r.count++;
    };
    for (let i = 0; i < toks.length; i++) {
      let matched = 0;
      for (let n = Math.min(this._maxN, toks.length - i); n >= 2 && !matched; n--) {
        let ok = true;
        for (let j = i; j < i + n - 1; j++) {
          if (!/^[ \t -]{1,3}$/.test(src.slice(toks[j].e, toks[j + 1].s))) { ok = false; break; }
        }
        if (!ok) continue;
        const phrase = toks.slice(i, i + n).map((t) => t.w).join(' ');
        for (const c of phraseCandidates(phrase)) {
          const e = idx.get(c.toLowerCase());
          if (e) { hit(e, toks[i].s, toks[i + n - 1].e); matched = n; break; }
        }
      }
      if (matched) { i += matched - 1; continue; }
      const e = lookupWord(toks[i].w);
      if (e) hit(e, toks[i].s, toks[i].e);
    }
    const list = [...found.values()].sort((a, b) => a.first - b.first);
    for (const r of list) r.forms = inflections(r.w).slice(0, 40);
    return list;
  }

  // ---------- vocabulary index for in-text highlighting ----------
  vocabForms(vocabItems) {
    const out = [];
    const seen = new Set();
    for (const it of vocabItems || []) {
      const w = String(it.word || '').trim();
      const k = w.toLowerCase();
      if (!w || seen.has(k)) continue;
      seen.add(k);
      out.push({ id: it.id, word: w, def: String(it.def || '').slice(0, 120), state: stateOf(srsOf(it)), forms: inflections(w).slice(0, 40) });
    }
    return out;
  }

  // ---------- notes ----------
  _notesKey(bookId) { return 'notes/' + String(bookId || '_none').replace(/[^A-Za-z0-9_-]/g, '_').slice(0, 64); }
  notes(bookId) { return this.store.get(this._notesKey(bookId), { items: [] }).items; }

  noteAdd(bookId, n) {
    const data = this.store.get(this._notesKey(bookId), { items: [] });
    const c = cleanNote(n || {});
    if (!c.quote.trim()) throw new Error('没有选中文字');
    const rec = { id: crypto.randomBytes(6).toString('hex'), ...c, created: Date.now(), updated: Date.now() };
    data.items.push(rec);
    this.store.set(this._notesKey(bookId), data);
    if (c.note) this.bump({ notes: 1 });
    return rec;
  }

  noteUpdate(bookId, id, patch) {
    const data = this.store.get(this._notesKey(bookId), { items: [] });
    const it = data.items.find((x) => x.id === id);
    if (!it) return null;
    const p = patch || {};
    if (typeof p.note === 'string') { if (p.note && !it.note) this.bump({ notes: 1 }); it.note = p.note.slice(0, 8000); }
    if (COLORS.has(p.color)) it.color = p.color;
    it.updated = Date.now();
    this.store.set(this._notesKey(bookId), data);
    return it;
  }

  noteRemove(bookId, id) {
    const data = this.store.get(this._notesKey(bookId), { items: [] });
    data.items = data.items.filter((x) => x.id !== id);
    this.store.set(this._notesKey(bookId), data);
    return true;
  }

  notesMarkdown(bookId, title) {
    const items = this.notes(bookId).slice().sort((a, b) => a.chapter - b.chapter || a.created - b.created);
    const lines = [`# ${title || '读书笔记'}`, '', `> 导出于 ${new Date().toLocaleString('zh-CN', { hour12: false })}，共 ${items.length} 条`, ''];
    let ch = null;
    for (const n of items) {
      if (n.chapter !== ch) {
        ch = n.chapter;
        lines.push(`## ${n.chapterTitle || '第 ' + (n.chapter + 1) + ' 部分'}`, '');
      }
      lines.push(...n.quote.replace(/\s+\n/g, '\n').split('\n').map((l) => '> ' + l.trim()));
      if (n.note) lines.push('', n.note.trim());
      lines.push('');
    }
    return lines.join('\n');
  }
}

module.exports = { LearnManager, schedule, previews, srsOf, stateOf, dayKey, ivlLabel, MASTERED_DAYS };
