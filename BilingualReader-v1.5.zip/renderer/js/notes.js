// Highlights and reading notes: created from a selection in the book, drawn with CSS highlights,
// listed in the left "笔记" tab (jump / edit / colour / delete) and exported as Markdown.
import { el, toast } from './util.js';
import * as api from './api.js';

export const NOTE_COLORS = [['yellow', '黄色'], ['green', '绿色'], ['blue', '蓝色'], ['pink', '粉色']];

function fmt(t) {
  const d = new Date(t);
  return `${d.getMonth() + 1}-${d.getDate()} ${String(d.getHours()).padStart(2, '0')}:${String(d.getMinutes()).padStart(2, '0')}`;
}

export class NotesPanel {
  constructor(app) {
    this.app = app;
    this.root = document.getElementById('tab-notes');
    this.list = [];
    this.bookId = '';
    this.placed = new Set();
    this.root.addEventListener('click', (e) => this._onClick(e));
  }

  async setBook(bookId) {
    this.bookId = bookId || '';
    const seq = (this._seq = (this._seq || 0) + 1);
    let list = [];
    if (this.bookId) { try { list = await api.call('notesList', this.bookId); } catch { list = []; } }
    if (seq !== this._seq) return;
    this.list = list;
    this.paint();
    this.render();
  }

  // draw the highlights of the chapter on screen
  paint() {
    const v = this.app.flow;
    if (this.app.view !== v || !v.doc || !v.book) return;
    const key = (v.book.spine[v.index] || {}).key;
    const mine = this.list.filter((n) => (n.chapterKey && key ? n.chapterKey === key : n.chapter === v.index));
    const placed = v.anchorNotes(mine);
    v._noteRanges = placed;
    for (const [c] of NOTE_COLORS) v.setHighlight('br-note-' + c, placed.filter((p) => p.note.color === c).map((p) => p.range));
    v.setHighlight('br-note-mark', placed.filter((p) => p.note.note).map((p) => p.range));
    this.placed = new Set(placed.map((p) => p.note.id));
    if (!this.root.hidden) this.render();
  }

  async addFromSelection(withNote, color = 'yellow') {
    const v = this.app.flow;
    if (this.app.view !== v || !this.bookId) { toast('划线笔记目前支持 EPUB / HTML 书籍'); return; }
    const a = v.selectionAnchor();
    if (!a) { toast('请先在正文中选中要标注的文字'); return; }
    let note = '';
    if (withNote) {
      note = await this.app.prompt('写笔记（Ctrl+Enter 保存）', '', { multiline: true });
      if (note == null) return;
    }
    let rec;
    try { rec = await api.call('noteAdd', this.bookId, { ...a, color, note }); } catch (e) { toast('保存失败：' + e.message, { type: 'error' }); return; }
    this.list.push(rec);
    try { v.doc.getSelection().removeAllRanges(); } catch { /* ignore */ }
    this.paint();
    this.render();
    this.app.study.refresh();
    toast(note ? '已添加笔记' : '已高亮（点击高亮可改颜色、写笔记）');
  }

  async update(n, patch) {
    let r;
    try { r = await api.call('noteUpdate', this.bookId, n.id, patch); } catch (e) { toast('保存失败：' + e.message, { type: 'error' }); return; }
    if (r) Object.assign(n, r);
    this.paint();
    this.render();
  }

  async remove(n) {
    await api.call('noteRemove', this.bookId, n.id);
    this.list = this.list.filter((x) => x.id !== n.id);
    this.hidePopover();
    this.paint();
    this.render();
    toast('已删除高亮');
  }

  // small editor next to a highlight that was clicked in the text
  showPopover(n, rect) {
    const pop = document.getElementById('popover');
    const ta = el('textarea', { rows: 3, placeholder: '写点笔记…（Ctrl+Enter 保存）' });
    ta.value = n.note || '';
    const save = async () => { await this.update(n, { note: ta.value }); this.hidePopover(); toast('已保存笔记'); };
    ta.addEventListener('keydown', (e) => {
      e.stopPropagation();
      if (e.key === 'Enter' && e.ctrlKey) save();
      if (e.key === 'Escape') this.hidePopover();
    });
    pop.replaceChildren(
      el('div', { class: 'pop-title' }, '笔记'),
      el('div', { class: 'note-colors' }, NOTE_COLORS.map(([c, l]) => el('button', {
        class: 'nc ' + c + (n.color === c ? ' on' : ''), title: l,
        onclick: async () => { await this.update(n, { color: c }); this.showPopover(n, rect); },
      }))),
      ta,
      el('div', { class: 'pop-actions' },
        el('button', { class: 'small-btn', onclick: () => this.remove(n) }, '删除高亮'),
        el('button', { class: 'small-btn', onclick: () => { this.hidePopover(); this.app.ai.quickAction('explain', { text: n.quote, kind: 'selection' }); } }, '问 AI'),
        el('span', { class: 'grow' }),
        el('button', { class: 'small-btn primary', onclick: save }, '保存')));
    pop.hidden = false;
    pop.classList.add('note-pop');
    const w = pop.offsetWidth;
    const h = pop.offsetHeight;
    let top = rect.bottom + 8;
    if (top + h > window.innerHeight - 8) top = Math.max(8, rect.top - h - 8);
    pop.style.top = top + 'px';
    pop.style.left = Math.max(8, Math.min(window.innerWidth - w - 8, rect.left)) + 'px';
    this.app.popoverOpen = true;
    this.popFor = n.id;
    setTimeout(() => ta.focus(), 20);
  }

  hidePopover() {
    const pop = document.getElementById('popover');
    if (this.popFor && !pop.hidden) {
      pop.hidden = true;
      pop.classList.remove('note-pop');
      this.app.popoverOpen = false;
    }
    this.popFor = null;
  }

  async jump(n) {
    const v = this.app.flow;
    if (this.app.view !== v) return;
    const key = (v.book.spine[v.index] || {}).key;
    const same = n.chapterKey && key ? n.chapterKey === key : n.chapter === v.index;
    if (!same) {
      let idx = v.book.spine.findIndex((s) => s.key === n.chapterKey);
      if (idx < 0) idx = n.chapter;
      await v.show(idx, {});
    }
    const hit = (v._noteRanges || []).find((p) => p.note.id === n.id);
    if (hit) v.flashRange(hit.range);
    else if (n.pos) { this.app.jumpTo(n.pos); toast('当前显示方式中没有找到这段文字，已跳到大致位置'); }
  }

  async _onClick(e) {
    const btn = e.target.closest('[data-act]');
    const item = e.target.closest('.note-item');
    if (btn && btn.dataset.act === 'copy') { this.copyMd(); return; }
    if (btn && btn.dataset.act === 'export') { this.exportMd(); return; }
    if (!item) return;
    const n = this.list.find((x) => x.id === item.dataset.id);
    if (!n) return;
    if (btn && btn.dataset.act === 'edit') {
      const t = await this.app.prompt('编辑笔记（Ctrl+Enter 保存）', n.note || '', { multiline: true });
      if (t != null) this.update(n, { note: t });
      return;
    }
    if (btn && btn.dataset.act === 'del') { this.remove(n); return; }
    if (btn && btn.dataset.color) { this.update(n, { color: btn.dataset.color }); return; }
    this.jump(n);
  }

  render() {
    if (!this.root) return;
    if (!this.bookId) {
      this.root.replaceChildren(el('div', { class: 'empty-tip' }, '打开一本书后，在正文中选中文字，右键选择“高亮标注”或“高亮并写笔记”。'));
      return;
    }
    const tools = el('div', { class: 'tab-tools notes-tools' },
      el('span', { class: 'muted' }, this.list.length ? `${this.list.length} 条` : ''),
      el('span', { class: 'grow' }),
      el('button', { class: 'small-btn', disabled: !this.list.length, dataset: { act: 'copy' }, title: '复制为 Markdown，可粘贴到笔记软件' }, '复制'),
      el('button', { class: 'small-btn', disabled: !this.list.length, dataset: { act: 'export' } }, '导出 Markdown'));
    if (!this.list.length) {
      this.root.replaceChildren(tools, el('div', { class: 'empty-tip' }, '还没有笔记。在正文中选中文字后右键 → “高亮标注 / 高亮并写笔记”；点击正文里的高亮可以改颜色、写笔记或删除。'));
      return;
    }
    const v = this.app.flow;
    const curKey = this.app.view === v && v.book ? (v.book.spine[v.index] || {}).key : null;
    const items = [...this.list].sort((a, b) => a.chapter - b.chapter || a.created - b.created);
    const out = [tools];
    let ch = null;
    for (const n of items) {
      if (n.chapter !== ch) {
        ch = n.chapter;
        out.push(el('div', { class: 'notes-ch' }, n.chapterTitle || `第 ${n.chapter + 1} 部分`));
      }
      const here = curKey && n.chapterKey === curKey;
      out.push(el('div', { class: 'note-item ' + n.color, dataset: { id: n.id }, title: '点击跳到原文' },
        el('div', { class: 'ni-quote' }, n.quote.replace(/\s+/g, ' ').trim()),
        n.note ? el('div', { class: 'ni-note' }, n.note) : null,
        el('div', { class: 'ni-meta' },
          el('span', {}, fmt(n.created)),
          here && !this.placed.has(n.id) ? el('span', { class: 'warn' }, '（当前显示方式中未找到）') : null,
          el('span', { class: 'grow' }),
          ...NOTE_COLORS.map(([c, l]) => el('button', { class: 'nc mini ' + c + (n.color === c ? ' on' : ''), title: l, dataset: { color: c } })),
          el('button', { class: 'icon-btn', title: '编辑笔记', dataset: { act: 'edit' } }, '✎'),
          el('button', { class: 'icon-btn', title: '删除', dataset: { act: 'del' } }, '🗑'))));
    }
    this.root.replaceChildren(...out);
  }

  async copyMd() {
    const text = await api.call('notesMarkdown', this.bookId, this.app.book ? this.app.book.title : '读书笔记');
    this.app.copyOut(text);
    toast('已复制 Markdown');
  }

  async exportMd() {
    const title = this.app.book ? this.app.book.title : '读书笔记';
    const name = `${title}-笔记.md`.replace(/[\\/:*?"<>|]/g, '_');
    if (api.isElectron) {
      const p = await api.call('pickSave', name, [{ name: 'Markdown', extensions: ['md'] }]);
      if (!p) return;
      await api.call('notesExport', p, this.bookId, title);
      toast('已导出到 ' + p);
    } else {
      const text = await api.call('notesMarkdown', this.bookId, title);
      const a = document.createElement('a');
      a.href = URL.createObjectURL(new Blob([text], { type: 'text/markdown;charset=utf-8' }));
      a.download = name;
      a.click();
    }
  }
}
