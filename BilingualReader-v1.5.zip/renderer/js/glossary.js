// "术语" tab: finance terms of the built-in dictionary that occur in the current chapter (or PDF page),
// with their Chinese meaning; click to find them in the text, add them to the vocabulary book.
import { el, toast } from './util.js';
import * as api from './api.js';

export class GlossaryPanel {
  constructor(app) {
    this.app = app;
    this.root = document.getElementById('tab-glossary');
    this.items = [];
    this.key = '';
    this.label = '';
    this.onlyNew = false;
    this.root.addEventListener('click', (e) => this._onClick(e));
  }

  _key() {
    const a = this.app;
    if (!a.info || !a.view) return '';
    if (a.view === a.flow) return a.info.bookId + ':c' + a.flow.index;
    return a.info.bookId + ':p' + (a.pdf.viewer ? a.pdf.viewer.currentPageNumber : 0);
  }

  // recomputed when the chapter changes, but only while the tab is visible
  async refresh(force) {
    if (this.root.hidden && !force) return;
    const key = this._key();
    if (!key) { this.items = []; this.key = ''; this.render(); return; }
    if (!force && key === this.key) {
      try { this.syncVocab(await api.call('vocabList')); } catch { /* ignore */ }
      return;
    }
    this.key = key;
    this.root.replaceChildren(el('div', { class: 'empty-tip' }, '正在整理本章术语…'));
    let r = null;
    try { r = await this.app.aiChapterText(); } catch { r = null; }
    this.label = r ? r.label.replace(/（.*$/, '') : '';
    try { this.items = r && r.text ? await api.call('glossary', r.text) : []; } catch (e) { this.items = []; toast('术语整理失败：' + e.message, { type: 'error' }); }
    if (this._key() === key) this.render();
  }

  // keep the ✓ marks in step with the vocabulary book (words added / removed elsewhere)
  syncVocab(list) {
    if (!this.items.length) return;
    const set = new Set((list || []).map((x) => String(x.word || '').toLowerCase()));
    let changed = false;
    for (const x of this.items) {
      const v = set.has(x.w.toLowerCase());
      if (v !== !!x.inVocab) { x.inVocab = v; changed = true; }
    }
    if (changed && !this.root.hidden) this.render();
  }

  render() {
    if (!this.app.info) {
      this.root.replaceChildren(el('div', { class: 'empty-tip' }, '打开一本书后，这里会列出本章出现的金融术语和中文含义。'));
      return;
    }
    const pending = this.items.filter((x) => !x.inVocab);
    const list = this.onlyNew ? pending : this.items;
    const only = el('input', { type: 'checkbox' });
    only.checked = this.onlyNew;
    only.addEventListener('change', () => { this.onlyNew = only.checked; this.render(); });
    const tools = el('div', { class: 'tab-tools gl-tools' },
      el('div', { class: 'gl-sum' }, `${this.label || '本章'}：${this.items.length} 个金融术语`,
        this.app.view === this.app.pdf ? el('button', { class: 'small-btn', dataset: { act: 'refresh' }, title: '按当前页重新整理' }, '刷新') : null),
      el('div', { class: 'gl-row' },
        el('label', { class: 'gl-only' }, only, ' 只看未加入生词本'),
        el('span', { class: 'grow' }),
        el('button', { class: 'small-btn', disabled: !pending.length, dataset: { act: 'addall' } }, `全部加入（${pending.length}）`)));
    if (!this.items.length) {
      this.root.replaceChildren(tools, el('div', { class: 'empty-tip' }, '本章没有找到内置金融词典里的术语。'));
      return;
    }
    this.root.replaceChildren(tools, ...list.map((x, i) => el('div', { class: 'gl-item' + (x.inVocab ? ' in' : ''), dataset: { i: String(this.items.indexOf(x)) } },
      el('div', { class: 'gl-head' },
        el('a', { href: '#', class: 'gl-w', dataset: { act: 'show' }, title: '在正文中找到并查词' }, x.w),
        x.ph ? el('span', { class: 'gl-ph' }, x.ph) : null,
        el('span', { class: 'gl-count', title: '出现次数' }, '×' + x.count),
        el('span', { class: 'grow' }),
        el('button', { class: 'icon-btn', title: '朗读', dataset: { act: 'say' } }, '🔊'),
        x.inVocab ? el('span', { class: 'gl-in', title: '已在生词本' }, '✓')
          : el('button', { class: 'icon-btn', title: '加入生词本（连同第一次出现的句子）', dataset: { act: 'add' } }, '＋')),
      el('div', { class: 'gl-fin' }, x.fin),
      void i)));
  }

  async add(x, quiet) {
    try {
      await api.call('vocabAdd', {
        word: x.w, phonetic: x.ph, def: x.fin, sentence: x.sentence || '',
        bookId: this.app.info ? this.app.info.bookId : '', bookTitle: this.app.book ? this.app.book.title : '',
        chapter: this.label || '', pos: this.app.view && this.app.view.getPosition ? this.app.view.getPosition() : null,
      });
      x.inVocab = true;
      if (!quiet) toast('已加入生词本：' + x.w);
    } catch (e) {
      toast('加入失败：' + e.message, { type: 'error' });
    }
  }

  async _onClick(e) {
    const btn = e.target.closest('[data-act]');
    if (!btn) return;
    e.preventDefault();
    const act = btn.dataset.act;
    if (act === 'refresh') { this.refresh(true); return; }
    if (act === 'addall') {
      const pending = this.items.filter((x) => !x.inVocab);
      if (pending.length > 15 && !(await this.app.confirm(`把本章 ${pending.length} 个术语全部加入生词本？`))) return;
      for (const x of pending) await this.add(x, true);
      toast(`已加入 ${pending.length} 个术语`);
      this.render();
      this.app.refreshVocab();
      return;
    }
    const item = btn.closest('.gl-item');
    const x = item && this.items[+item.dataset.i];
    if (!x) return;
    if (act === 'say') this.app.speak(x.w);
    else if (act === 'add') { await this.add(x); this.render(); this.app.refreshVocab(); }
    else if (act === 'show') {
      if (this.app.view === this.app.flow) {
        const r = this.app.flow.revealForms(x.w, x.forms);
        this.app.lookup(x.w, r ? this.app.flow.contextFor(r) : { sentence: x.sentence });
      } else this.app.lookup(x.w, { sentence: x.sentence });
    }
  }
}
