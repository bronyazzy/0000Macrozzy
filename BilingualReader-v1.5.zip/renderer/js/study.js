// Learning hub: today's summary and streak (vocabulary tab + start screen), the statistics dialog,
// reading-time tracking and the spaced-repetition review session (flashcards).
import { el, toast, escapeHtml } from './util.js';
import * as api from './api.js';
import { formsRegex } from './dictpanel.js';
import { STATE_LABEL } from './vocabstate.js';
import { hasHan } from './textlang.js';

export const REVIEW_MODES = [['mixed', '混合（新词认读，复习词拼写）'], ['recall', '认词（看英文，回忆意思）'], ['spell', '拼写（看中文和例句，写出英文）']];
const MODE_SHORT = { mixed: '混合', recall: '认词', spell: '拼写' };

// answer typed in a spelling card: lower case, curly quotes and spaces normalised
const normAns = (s) => String(s || '').toLowerCase().replace(/[’‘]/g, "'").replace(/\s+/g, ' ').trim().replace(/[.,;:!?"]+$/, '');
const squash = (s) => normAns(s).replace(/[\s-]+/g, '');

export { STATE_LABEL };

function fmtMin(sec) {
  const m = Math.round((sec || 0) / 60);
  if (m < 60) return `${m} 分钟`;
  return `${Math.floor(m / 60)} 小时${m % 60 ? ' ' + (m % 60) + ' 分' : ''}`;
}

export class StudyHub {
  constructor(app) {
    this.app = app;
    this.box = document.getElementById('vocab-study');
    this.startBox = document.getElementById('start-study');
    this.stats = null;
    this.pending = 0;
    this.lastAct = 0;
    this.review = new ReviewSession(app, this);
    for (const ev of ['mousemove', 'keydown', 'wheel', 'mousedown']) {
      window.addEventListener(ev, () => this.activity(), { passive: true, capture: true });
    }
    this._t1 = setInterval(() => this.tick(), 15000);
    this._t2 = setInterval(() => this.flush(), 60000);
  }

  activity() { this.lastAct = Date.now(); }

  // 15 s of reading time when a book is open, the window has focus and the reader was active recently
  tick(force) {
    if (!this.app.view || !this.app.info || this.review.open) return;
    if (!force && (document.hidden || !document.hasFocus() || Date.now() - this.lastAct > 120000)) return;
    this.pending += 15;
  }

  async flush() {
    if (this.pending <= 0) return;
    const s = this.pending;
    this.pending = 0;
    try { await api.call('statsRead', s); } catch { this.pending += s; return; }
    this.refresh();
  }

  async init() { await this.refresh(); }

  async refresh() {
    try { this.stats = await api.call('studyStats'); } catch { return; }
    this.render();
  }

  todo() {
    const s = this.stats;
    if (!s) return 0;
    const limit = +this.app.settings.srsNewPerDay || 20;
    return s.totals.due + Math.min(s.totals.new, Math.max(0, limit - (s.today.newLearned || 0)));
  }

  _card(where) {
    const s = this.stats;
    const t = s.today || {};
    const todo = this.todo();
    return el('div', { class: 'study-card ' + where },
      el('div', { class: 'sc-top' },
        el('span', { class: 'sc-streak', title: '连续学习天数：当天阅读满 1 分钟或复习过生词就算一天' }, `🔥 连续 ${s.streak} 天`),
        el('span', { class: 'grow' }),
        el('a', { href: '#', onclick: (e) => { e.preventDefault(); this.openStats(); } }, '学习统计')),
      el('div', { class: 'sc-today' }, `今天：阅读 ${fmtMin(t.read)} · 查词 ${t.lookups || 0} · 新词 ${t.added || 0} · 复习 ${t.reviewed || 0}`),
      el('div', { class: 'sc-actions' },
        el('button', { class: todo ? 'primary review-btn' : 'review-btn', disabled: !s.totals.words, title: '快捷键 Ctrl+R', onclick: () => this.startReview() },
          !s.totals.words ? '生词本还是空的' : todo ? `开始复习（${todo}）` : '今天的复习已完成 ✓'),
        el('span', { class: 'sc-words' }, s.totals.words ? `生词 ${s.totals.words} · 已掌握 ${s.totals.mastered}` : '')));
  }

  render() {
    if (!this.stats) return;
    if (this.box) this.box.replaceChildren(this._card('in-vocab'));
    if (this.startBox) this.startBox.replaceChildren(this._card('on-start'));
    const badge = document.getElementById('vocab-count');
    const todo = this.todo();
    if (badge) {
      badge.textContent = todo ? String(todo) : this.stats.totals.words ? String(this.stats.totals.words) : '';
      badge.classList.toggle('due', !!todo);
      badge.title = todo ? `今天待复习 ${todo} 个` : '';
    }
  }

  startReview() { this.review.start(); }

  async openStats() {
    await this.refresh();
    const s = this.stats;
    if (!s) return;
    const modal = document.getElementById('modal');
    const close = () => { modal.hidden = true; modal.replaceChildren(); this.app.modalOpen = false; this.app.refocusReader(); };
    const mins = s.days.map((d) => Math.round((d.read || 0) / 60));
    const maxM = Math.max(10, ...mins);
    const maxR = Math.max(10, ...s.days.map((d) => d.reviewed || 0));
    const chart = (vals, max, cls, tip) => el('div', { class: 'chart' }, s.days.map((d, i) => el('div', { class: 'bar-wrap', title: tip(d, vals[i]) },
      el('div', { class: 'bar ' + cls + (vals[i] ? '' : ' zero'), style: { height: Math.round((vals[i] / max) * 100) + '%' } }),
      el('span', { class: 'bar-day' }, i % 5 === 4 || i === 29 ? d.day.slice(5).replace('-', '/') : ''))));
    const tile = (v, l) => el('div', { class: 'tile' }, el('b', {}, String(v)), el('span', {}, l));
    const tot = s.totals;
    modal.replaceChildren(el('div', { class: 'modal-box stats-box' },
      el('div', { class: 'modal-head' }, el('span', {}, '学习统计'), el('button', { class: 'icon-btn', onclick: close }, '✕')),
      el('div', { class: 'modal-pad' },
        el('div', { class: 'tiles' },
          tile(s.streak + ' 天', '连续学习'), tile(s.activeDays + ' 天', '累计学习'), tile(fmtMin(s.readAll), '累计阅读'),
          tile(tot.words, '生词'), tile(tot.mastered, '已掌握'), tile(tot.due + ' / ' + tot.dueTomorrow, '待复习 / 明天')),
        el('div', { class: 'chart-title' }, '近 30 天阅读时长（分钟）'),
        chart(mins, maxM, 'read', (d, v) => `${d.day}：阅读 ${v} 分钟 · 查词 ${d.lookups || 0} · 新词 ${d.added || 0}`),
        el('div', { class: 'chart-title' }, '近 30 天复习（个）'),
        chart(s.days.map((d) => d.reviewed || 0), maxR, 'rev', (d, v) => `${d.day}：复习 ${v} 个，记得 ${d.correct || 0} 个${d.ai ? ' · AI 提问 ' + d.ai + ' 次' : ''}${d.notes ? ' · 笔记 ' + d.notes + ' 条' : ''}`),
        el('div', { class: 'muted small' }, '阅读时长只统计打开书、窗口在前台且两分钟内有操作的时间。')),
      el('div', { class: 'modal-foot' },
        el('button', { onclick: close }, '关闭'),
        el('button', { class: 'primary', disabled: !tot.words, onclick: () => { close(); this.startReview(); } }, '开始复习'))));
    modal.hidden = false;
    modal.onclick = (e) => { if (e.target === modal) close(); };
    this.app.modalOpen = true;
  }
}

// ---------------------------------------------------------------- review session

export class ReviewSession {
  constructor(app, hub) {
    this.app = app;
    this.hub = hub;
    this.root = document.getElementById('review');
    this.open = false;
    this.onKey = (e) => this._key(e);
  }

  async start() {
    let q;
    try { q = await api.call('vocabQueue', +this.app.settings.srsNewPerDay || 20); } catch (e) { toast('无法开始复习：' + e.message, { type: 'error' }); return; }
    if (!q.items.length) {
      toast(q.newWaiting ? `今天的新词已学完（每天 ${this.app.settings.srsNewPerDay || 20} 个，可在设置 → 学习中调整）` : '今天没有需要复习的单词');
      return;
    }
    if (this.app.tts && this.app.tts.active) this.app.tts.stop();
    this.queue = q.items;
    this.total = q.items.length;
    this.done = 0;
    this.right = 0;
    this.spelled = 0;
    this.spelledOk = 0;
    this.again = new Set();
    this.card = null;
    this.open = true;
    this.app.modalOpen = true;
    this.root.hidden = false;
    document.addEventListener('keydown', this.onKey, true);
    for (const f of document.querySelectorAll('iframe')) try { f.contentDocument.addEventListener('keydown', this.onKey, true); } catch { /* ignore */ }
    this._next();
  }

  close() {
    if (!this.open) return;
    this.open = false;
    this.root.hidden = true;
    this.root.replaceChildren();
    this.app.modalOpen = false;
    document.removeEventListener('keydown', this.onKey, true);
    for (const f of document.querySelectorAll('iframe')) try { f.contentDocument.removeEventListener('keydown', this.onKey, true); } catch { /* ignore */ }
    try { window.speechSynthesis && window.speechSynthesis.cancel(); } catch { /* ignore */ }
    this.hub.refresh();
    this.app.refreshVocab();
    this.app.refocusReader();
  }

  _key(e) {
    if (!this.open) return;
    const k = e.key;
    if (k === 'Escape') { e.preventDefault(); e.stopPropagation(); this.close(); return; }
    if (e.target && e.target.closest && e.target.closest('.rv-mode')) return; // the review-mode menu
    if (!this.card) { if (k === 'Enter' || k === ' ') { e.preventDefault(); e.stopPropagation(); this.close(); } return; }
    const c = this.card;
    if (c.loading) { e.preventDefault(); e.stopPropagation(); return; }
    if (c.spell && !c.shown) {
      // typing the answer: only Enter (check) is taken here, letters go to the input box
      if (k === 'Enter') { e.preventDefault(); e.stopPropagation(); this._check(); }
      else if (e.target !== this.inputEl && k.length === 1 && !e.ctrlKey && !e.altKey) this.inputEl.focus();
      return;
    }
    if (!c.shown && (k === ' ' || k === 'Enter')) { e.preventDefault(); e.stopPropagation(); this._reveal(); return; }
    if (c.shown && k === 'Enter' && c.suggest != null) { e.preventDefault(); e.stopPropagation(); this._grade(c.suggest); return; }
    if (c.shown && /^[1-4]$/.test(k)) { e.preventDefault(); e.stopPropagation(); this._grade(+k - 1); return; }
    if (k.toLowerCase() === 'r' && !e.ctrlKey) { e.preventDefault(); e.stopPropagation(); this.app.speak(c.item.word); }
  }

  get mode() { return MODE_SHORT[this.app.settings.reviewMode] ? this.app.settings.reviewMode : 'mixed'; }

  // spelling for this word? (an English word or phrase, and in "mixed" mode one that was seen before)
  _wantSpell(x) {
    const m = this.mode;
    if (m === 'recall' || !/[A-Za-z]/.test(x.word) || hasHan(x.word) || x.word.length > 48) return false;
    return m === 'spell' || x.state !== 'new';
  }

  _frame(...body) {
    const pct = this.total ? Math.round((this.done / this.total) * 100) : 0;
    const mode = el('select', { class: 'rv-mode', title: '复习方式（从下一个词开始生效）' }, REVIEW_MODES.map(([v]) => el('option', { value: v }, MODE_SHORT[v])));
    mode.value = this.mode;
    mode.addEventListener('change', () => { this.app.settings.reviewMode = mode.value; this.app.saveSettingsSoon(); toast('复习方式：' + REVIEW_MODES.find((m) => m[0] === mode.value)[1] + '（下一个词起）', { ms: 2200 }); });
    this.root.replaceChildren(el('div', { class: 'rv-box' },
      el('div', { class: 'rv-head' },
        el('span', { class: 'rv-title' }, '生词复习'),
        el('span', { class: 'rv-prog' }, `${Math.min(this.done + (this.card ? 1 : 0), this.total)} / ${this.total}`),
        el('div', { class: 'rv-bar' }, el('i', { style: { width: pct + '%' } })),
        mode,
        el('button', { class: 'icon-btn', title: '结束复习（Esc）', onclick: () => this.close() }, '✕')),
      ...body));
  }

  async _next() {
    const item = this.queue.shift();
    if (!item) { this._finish(); return; }
    if (this._wantSpell(item) && await this._spellCard(item)) return;
    this.card = { item, shown: false };
    const x = item;
    const re = x.sentence ? formsRegex(x.word, [x.word], 'gi') : null;
    const sent = x.sentence ? escapeHtml(x.sentence).replace(re || /$^/, (m) => `<mark>${m}</mark>`) : '';
    this.sentEl = sent ? el('div', { class: 'rv-sent', html: sent }) : null;
    this.backEl = el('div', { class: 'rv-back', hidden: true });
    this.btnEl = el('div', { class: 'rv-btns' }, el('button', { class: 'primary rv-show', onclick: () => this._reveal() }, '显示答案（空格）'));
    this._frame(
      el('div', { class: 'rv-card' },
        el('div', { class: 'rv-state ' + (x.state || 'new') }, STATE_LABEL[x.state] || '新词'),
        el('div', { class: 'rv-word' }, x.word,
          el('button', { class: 'icon-btn rv-say', title: '朗读（R）', onclick: () => this.app.speak(x.word) }, '🔊')),
        x.phonetic ? el('div', { class: 'rv-ph' }, x.phonetic) : null,
        this.sentEl,
        x.bookTitle || x.chapter ? el('div', { class: 'rv-src' }, [x.bookTitle ? '《' + x.bookTitle + '》' : '', x.chapter].filter(Boolean).join(' · ')) : null,
        this.backEl),
      this.btnEl);
    if (this.app.settings.reviewSpeak !== false) this.app.speak(x.word);
  }

  // ---------- spelling card: Chinese meaning + example sentence with the word left out
  async _spellCard(x) {
    const pending = { item: x, shown: false, loading: true };
    this.card = pending;
    let def = x.def;
    if (!def) {
      try {
        const r = await api.call('lookup', x.word, { noStats: true });
        def = shortDefOf(r);
        if (def) { x.def = def; api.call('vocabUpdate', x.id, { def }).catch(() => {}); }
      } catch { /* ignore */ }
    }
    if (!this.open || this.card !== pending) return true;
    const forms = [...new Set([x.word, ...(x.forms || [])])];
    const re = formsRegex(x.word, forms, 'gi');
    const inSent = x.sentence && re ? (x.sentence.match(re) || []) : [];
    if (!def && !inSent.length) return false; // nothing to recall the word from: plain card
    const c = { item: x, shown: false, spell: true, tries: 0, hints: 0, forms, inSent };
    this.card = c;
    const blank = (m) => `<span class="rv-blank" title="填这里">${'&ensp;'.repeat(Math.max(3, Math.min(14, m.length)))}</span>`;
    const sent = x.sentence ? escapeHtml(x.sentence).replace(formsRegex(escapeHtml(x.word), forms.map(escapeHtml), 'gi') || /$^/, blank) : '';
    this.inputEl = el('input', { class: 'rv-input', type: 'text', placeholder: '写出英文，Enter 检查', autocomplete: 'off', spellcheck: 'false', autocapitalize: 'off' });
    this.inputEl.addEventListener('input', () => { this.msgEl.textContent = ''; this.msgEl.className = 'rv-msg'; });
    this.hintEl = el('div', { class: 'rv-hint' });
    this.msgEl = el('div', { class: 'rv-msg' });
    this.backEl = el('div', { class: 'rv-back', hidden: true });
    this.btnEl = el('div', { class: 'rv-btns' },
      el('button', { onclick: () => this._hint() }, '提示首字母'),
      el('button', { onclick: () => { c.hints++; this.app.speak(x.word); this.inputEl.focus(); } }, '听发音'),
      el('button', { onclick: () => this._spellReveal('skip') }, '不会，看答案'),
      el('button', { class: 'primary', onclick: () => this._check() }, '检查（Enter）'));
    this._frame(
      el('div', { class: 'rv-card spell' },
        el('div', { class: 'rv-state ' + (x.state || 'new') }, (STATE_LABEL[x.state] || '新词') + ' · 拼写'),
        def ? el('div', { class: 'rv-cue' }, def) : null,
        sent ? el('div', { class: 'rv-sent', html: sent }) : null,
        x.sentenceZh ? el('div', { class: 'rv-zh' }, x.sentenceZh) : null,
        el('div', { class: 'rv-answer' }, this.inputEl),
        this.hintEl,
        this.msgEl,
        this.backEl),
      this.btnEl);
    setTimeout(() => this.inputEl.focus(), 0);
    return true;
  }

  // first letters of the expected answer, one more each time
  _hint() {
    const c = this.card;
    if (!c || !c.spell || c.shown) return;
    const target = c.inSent[0] || c.item.word;
    c.hints++;
    const n = Math.min(target.length - 1, c.hints);
    this.hintEl.textContent = '提示：' + target.slice(0, Math.max(1, n)) + '…（' + target.length + ' 个字母）';
    this.inputEl.focus();
  }

  _check() {
    const c = this.card;
    if (!c || !c.spell || c.shown) return;
    const ans = normAns(this.inputEl.value);
    if (!ans) { this._spellReveal('skip'); return; }
    const ok = c.forms.some((f) => normAns(f) === ans) || c.inSent.some((f) => normAns(f) === ans) || squash(c.item.word) === squash(ans);
    if (ok) { this._spellReveal(c.hints ? 'hint' : 'ok', ans); return; }
    c.tries++;
    if (c.tries < 2) {
      this.msgEl.textContent = '不对，再试一次（可以用“提示首字母”或“听发音”）';
      this.msgEl.className = 'rv-msg bad';
      this.inputEl.classList.remove('shake');
      void this.inputEl.offsetWidth;
      this.inputEl.classList.add('shake');
      this.inputEl.select();
      return;
    }
    this._spellReveal('wrong', ans);
  }

  // shows the answer of a spelling card; result: ok | hint | wrong | skip
  async _spellReveal(result, typed) {
    const c = this.card;
    if (!c || c.shown) return;
    c.shown = true;
    c.result = result;
    c.suggest = result === 'ok' ? 2 : result === 'hint' ? 1 : 0;
    const x = c.item;
    this.inputEl.disabled = true;
    this.inputEl.classList.add(result === 'ok' || result === 'hint' ? 'right' : 'wrong');
    const exp = c.inSent[0] && normAns(c.inSent[0]) !== normAns(x.word) ? `${x.word}（句中是 ${c.inSent[0]}）` : x.word;
    this.msgEl.className = 'rv-msg ' + (result === 'ok' || result === 'hint' ? 'good' : 'bad');
    this.msgEl.textContent = result === 'ok' ? '✓ 正确' : result === 'hint' ? '✓ 正确（用了提示）' : result === 'wrong' ? `✗ 你写的是 “${typed}”` : '答案';
    this.hintEl.textContent = '';
    const re = x.sentence ? formsRegex(escapeHtml(x.word), c.forms.map(escapeHtml), 'gi') : null;
    const sent = x.sentence ? escapeHtml(x.sentence).replace(re || /$^/, (m) => `<mark>${m}</mark>`) : '';
    const sentEl = this.root.querySelector('.rv-card .rv-sent');
    if (sentEl && sent) sentEl.innerHTML = sent;
    this.backEl.replaceChildren(...[
      el('div', { class: 'rv-word sm' }, exp,
        el('button', { class: 'icon-btn rv-say', title: '朗读（R）', onclick: () => this.app.speak(x.word) }, '🔊')),
      x.phonetic ? el('div', { class: 'rv-ph' }, x.phonetic) : null,
      x.note ? el('div', { class: 'rv-note' }, '笔记：' + x.note) : null,
      el('div', { class: 'rv-links' },
        el('a', { href: '#', onclick: (e) => { e.preventDefault(); this.app.lookup(x.word, x.sentence ? { sentence: x.sentence, sentenceZh: x.sentenceZh } : null); toast('已在词典栏查询，结束复习后可查看'); } }, '在词典中查看'),
        x.pos && this.app.info && this.app.info.bookId === x.bookId ? el('a', { href: '#', onclick: (e) => { e.preventDefault(); const p = x.pos; this.close(); this.app.jumpTo(p); } }, '跳到原文') : null),
    ].filter(Boolean));
    this.backEl.hidden = false;
    this._gradeButtons(x, c.suggest);
    if (this.app.settings.reviewSpeak !== false) this.app.speak(x.word);
  }

  _gradeButtons(x, suggest) {
    const p = x.preview || ['10 分钟', '1 天', '1 天', '4 天'];
    const names = ['忘了', '模糊', '记得', '简单'];
    this.btnEl.replaceChildren(...names.map((n, i) => el('button', { class: 'rv-grade g' + i + (i === suggest ? ' suggest' : ''), title: i === suggest ? '建议（Enter）' : '', onclick: () => this._grade(i) },
      el('b', {}, n), el('small', {}, `${i + 1} · ${p[i]}`))));
    if (suggest != null) this.btnEl.append(el('div', { class: 'rv-suggest' }, `按 Enter 选“${names[suggest]}”，也可以按 1–4 自己选`));
  }

  async _reveal() {
    const c = this.card;
    if (!c || c.shown) return;
    c.shown = true;
    const x = c.item;
    let def = x.def;
    if (!def) {
      try {
        const r = await api.call('lookup', x.word, { noStats: true });
        def = shortDefOf(r);
        if (def) api.call('vocabUpdate', x.id, { def }).catch(() => {});
      } catch { /* ignore */ }
    }
    if (this.card !== c) return;
    this.backEl.replaceChildren(...[
      el('div', { class: 'rv-def' }, def || '（没有保存释义，可在词典中查看）'),
      x.sentenceZh ? el('div', { class: 'rv-zh' }, x.sentenceZh) : null,
      x.note ? el('div', { class: 'rv-note' }, '笔记：' + x.note) : null,
      el('div', { class: 'rv-links' },
        el('a', { href: '#', onclick: (e) => { e.preventDefault(); this.app.lookup(x.word, x.sentence ? { sentence: x.sentence, sentenceZh: x.sentenceZh } : null); toast('已在词典栏查询，结束复习后可查看'); } }, '在词典中查看'),
        x.pos && this.app.info && this.app.info.bookId === x.bookId ? el('a', { href: '#', onclick: (e) => { e.preventDefault(); const p = x.pos; this.close(); this.app.jumpTo(p); } }, '跳到原文') : null),
    ].filter(Boolean));
    this.backEl.hidden = false;
    this._gradeButtons(x, null);
  }

  async _grade(g) {
    const c = this.card;
    if (!c || !c.shown || c.busy) return;
    c.busy = true;
    let r;
    try { r = await api.call('vocabGrade', c.item.id, g); } catch (e) { toast('保存失败：' + e.message, { type: 'error' }); c.busy = false; return; }
    if (g === 0) {
      // show it again later in this session
      this.again.add(c.item.id);
      this.queue.splice(Math.min(3, this.queue.length), 0, { ...c.item, srs: r.srs, state: r.state, preview: r.preview });
      this.total++;
    } else if (!this.again.has(c.item.id) && g >= 2) {
      this.right++;
    }
    if (c.spell) { this.spelled++; if (c.result === 'ok') this.spelledOk++; }
    this.done++;
    this.card = null;
    this._next();
  }

  _finish() {
    this.card = null;
    const uniq = this.done - this.again.size;
    const rate = uniq > 0 ? Math.round((this.right / Math.max(1, uniq)) * 100) : 0;
    this._frame(el('div', { class: 'rv-card rv-done' },
      el('div', { class: 'rv-word' }, '🎉 今天的复习完成了'),
      el('div', { class: 'rv-sum' }, `一共复习 ${this.done} 次，第一次就记得 ${this.right} 个（${rate}%）。`),
      this.spelled ? el('div', { class: 'rv-sum' }, `拼写 ${this.spelled} 次，不看提示写对 ${this.spelledOk} 次。`) : null,
      el('div', { class: 'rv-sum muted' }, '记得的词会隔得越来越久再出现；忘了的词已经安排在近期重复。')),
      el('div', { class: 'rv-btns' }, el('button', { class: 'primary', onclick: () => this.close() }, '完成（Enter）')));
    this.hub.refresh();
  }
}

// a one-line definition from a lookup result (built-in finance meaning first)
export function shortDefOf(r) {
  for (const s of (r && r.sections) || []) {
    if (s.type === 'builtin') return [...(s.fin || []), ...(s.gen || [])].slice(0, 2).join('；');
    if (s.type === 'csv' && s.items && s.items[0]) return String(s.items[0].def || s.items[0].zh || s.items[0].meaning || '').slice(0, 120);
    if (s.type === 'mdx' && s.html) {
      const d = document.createElement('div');
      d.innerHTML = s.html;
      return d.textContent.replace(/\s+/g, ' ').trim().slice(0, 120);
    }
  }
  return '';
}
