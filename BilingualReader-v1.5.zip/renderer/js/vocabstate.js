// Learning state of a vocabulary-book entry (spaced repetition fields written by the backend).
export const STATE_LABEL = { new: '新词', learning: '学习中', mastered: '已掌握' };

export function vocabState(x) {
  const s = x && x.srs;
  if (!s || !s.last) return 'new';
  return s.ivl >= 21 ? 'mastered' : 'learning';
}

export function isDue(x) {
  const s = x && x.srs;
  return !!(s && s.last && s.due <= Date.now());
}

const dayStart = (t) => { const d = new Date(t); d.setHours(0, 0, 0, 0); return d.getTime(); };

export function dueLabel(x) {
  const s = x && x.srs;
  if (!s || !s.last) return '';
  if (s.due <= Date.now()) return '待复习';
  const d = Math.round((dayStart(s.due) - dayStart(Date.now())) / 86400000);
  if (d <= 0) return '今天稍后复习';
  if (d === 1) return '明天复习';
  return `${d} 天后复习`;
}

// the vocabulary-book entry of a word, if any (case-insensitive)
export function vocabEntry(items, word) {
  const w = String(word || '').trim().toLowerCase();
  return w ? (items || []).find((x) => String(x.word || '').toLowerCase() === w) || null : null;
}
