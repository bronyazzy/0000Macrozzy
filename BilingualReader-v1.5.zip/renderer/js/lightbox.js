// Full-window image viewer for book figures and PDF pages.
//  - opens fitted to the window (small figures are enlarged), wheel / pinch zoom around the pointer,
//    drag to move, double-click to zoom in / back, rotate, previous / next image (← →)
//  - bilingual caption, copy the image, save the image
//  - items can be produced lazily (PDF pages rendered at high resolution) and can ask to open
//    zoomed in on a region (the figure under the mouse) or a point.
import { clamp, el, toast } from './util.js';
import * as api from './api.js';

const MAX_FIT_UP = 3; // "适合窗口" enlarges small images at most this much
const MIN_SCALE = 0.05;
const MAX_SCALE = 12;

export class Lightbox {
  constructor(app) {
    this.app = app;
    this.root = document.getElementById('lightbox');
    this.stage = this.root.querySelector('.lb-stage');
    this.img = this.root.querySelector('.lb-stage img');
    this.msg = this.root.querySelector('.lb-msg');
    this.zoomLabel = this.root.querySelector('.lb-zoom');
    this.title = this.root.querySelector('.lb-title');
    this.capEn = this.root.querySelector('.lb-cap-en');
    this.capZh = this.root.querySelector('.lb-cap-zh');
    this.capBox = this.root.querySelector('.lb-captions');
    this.counter = this.root.querySelector('.lb-count');
    this.hint = this.root.querySelector('.lb-hint');
    this.items = [];
    this.index = 0;
    this.cur = null;
    this.scale = 1;
    this.tx = 0;
    this.ty = 0;
    this.rot = 0;
    this.fit = true;
    this.isOpen = false;
    this.token = 0;
    this.root.addEventListener('click', (e) => {
      const b = e.target.closest('[data-lb]');
      if (b) {
        e.stopPropagation();
        this.action(b.dataset.lb);
        return;
      }
      // a click on the dark area (not on the picture, the toolbar or selected caption text) closes the viewer
      if (this.moved) return;
      if (e.target === this.stage || e.target === this.root || (this.capBox.contains(e.target) && !String(getSelection()))) this.close();
    });
    this.stage.addEventListener('wheel', (e) => {
      e.preventDefault();
      if (this.img.hidden) return;
      const dy = e.deltaMode === 1 ? e.deltaY * 33 : e.deltaMode === 2 ? e.deltaY * 400 : e.deltaY;
      // pinch on a touchpad arrives as ctrl + wheel with small deltas
      const f = clamp(Math.exp(-dy * (e.ctrlKey ? 0.01 : 0.0018)), 0.6, 1.6);
      this.zoomBy(f, { x: e.clientX, y: e.clientY });
    }, { passive: false });
    this.stage.addEventListener('dblclick', (e) => {
      if (this.img.hidden || e.target !== this.img) return;
      const fs = this.fitScale();
      if (this.fit || Math.abs(this.scale - fs) / fs < 0.04) this.setScale(Math.max(1, fs * 2.5), { x: e.clientX, y: e.clientY });
      else this.setFit();
    });
    // drag to move (pointer events: mouse, pen and touch)
    let drag = null;
    this.stage.addEventListener('pointerdown', (e) => {
      if (e.button !== 0 || this.img.hidden) return;
      this.moved = false;
      drag = { x: e.clientX, y: e.clientY, tx: this.tx, ty: this.ty, id: e.pointerId };
      if (e.target === this.img) e.preventDefault();
    });
    this.stage.addEventListener('pointermove', (e) => {
      if (!drag || e.pointerId !== drag.id) return;
      const dx = e.clientX - drag.x;
      const dy = e.clientY - drag.y;
      if (!this.moved && Math.hypot(dx, dy) < 3) return;
      if (!this.moved) {
        // a real drag: keep receiving the moves even outside the window
        this.img.classList.add('dragging');
        try { this.stage.setPointerCapture(e.pointerId); } catch { /* ignore */ }
      }
      this.moved = true;
      this.tx = drag.tx + dx;
      this.ty = drag.ty + dy;
      this.fit = false;
      this.apply();
    });
    const end = (e) => {
      if (!drag) return;
      try { if (e && this.stage.hasPointerCapture(e.pointerId)) this.stage.releasePointerCapture(e.pointerId); } catch { /* ignore */ }
      drag = null;
      this.img.classList.remove('dragging');
      setTimeout(() => { this.moved = false; }, 0);
    };
    this.stage.addEventListener('pointerup', end);
    this.stage.addEventListener('pointercancel', end);
    window.addEventListener('resize', () => { if (this.isOpen && this.fit) this.setFit(); else if (this.isOpen) this.apply(); });
    this.img.addEventListener('load', () => this._loaded());
    this.img.addEventListener('error', () => this._failed());
  }

  // ------------------------------------------------------------------ opening

  // one image (legacy call): src + { alt, caption: { en, zh }, fallback, focus }
  open(src, opts = {}) {
    this.openItems([{ src, ...opts }], 0);
  }

  // items: [{ src | load(): Promise<{ src, focus?, revoke? }>, caption?: { en, zh }, alt?, title?, focus?, name? }]
  openItems(items, index = 0) {
    this.items = (items || []).filter(Boolean);
    if (!this.items.length) return;
    this.isOpen = true;
    this.root.hidden = false;
    this.root.classList.add('open');
    this.root.focus();
    this._showHint();
    this.show(clamp(index, 0, this.items.length - 1));
  }

  async show(i) {
    if (!this.items.length) return;
    this.index = (i + this.items.length) % this.items.length;
    const item = this.items[this.index];
    const token = ++this.token;
    this._release();
    this.rot = 0;
    this.cur = { item, src: '', focus: item.focus || null, revoke: null };
    this.counter.textContent = this.items.length > 1 ? `${this.index + 1} / ${this.items.length}` : '';
    this.root.classList.toggle('multi', this.items.length > 1);
    this._caption(item);
    this.msg.hidden = false;
    this.msg.textContent = item.load ? '正在生成高清图…' : '正在加载图片…';
    this.img.hidden = true;
    this.zoomLabel.textContent = '';
    this.img.removeAttribute('src');
    let src = item.src;
    if (item.load) {
      try {
        const r = await item.load();
        if (token !== this.token || !this.isOpen) { if (r && r.revoke) URL.revokeObjectURL(r.src); return; }
        src = r.src;
        if (r.focus) this.cur.focus = r.focus;
        if (r.revoke) this.cur.revoke = r.src;
        if (r.caption) {
          this.cur.caption = r.caption;
          this._caption({ ...item, caption: r.caption });
        }
      } catch (e) {
        if (token !== this.token) return;
        this._failed(e.message);
        return;
      }
    }
    this.cur.src = src;
    this.img.src = src;
  }

  _caption(item) {
    const cap = item.caption || {};
    const en = String(cap.en || '').trim();
    const zh = String(cap.zh || '').trim();
    const fallback = item.title || item.alt || decodeURIComponent(String(item.src || '').split('/').pop().split('?')[0] || '').slice(0, 80);
    this.title.textContent = en || zh ? '' : fallback;
    this.title.title = this.title.textContent;
    this.capEn.textContent = en;
    this.capZh.textContent = zh && zh !== en ? zh : '';
    this.capBox.hidden = !en && !zh;
  }

  _loaded() {
    if (!this.isOpen) return;
    this.msg.hidden = true;
    this.img.hidden = false;
    const f = this.cur && this.cur.focus;
    if (f) this._focus(f);
    else this.setFit();
  }

  _failed(why) {
    const it = this.cur && this.cur.item;
    if (!why && it && it.fallback && this.img.src !== it.fallback) {
      const f = it.fallback;
      it.fallback = null;
      this.img.src = f;
      return;
    }
    this.img.hidden = true;
    this.msg.hidden = false;
    this.msg.textContent = '⚠ ' + (why || '图片无法打开（文件可能已损坏或缺失）') + '。按 Esc 返回继续阅读。';
    this.zoomLabel.textContent = '';
  }

  _release() {
    if (this.cur && this.cur.revoke) {
      try { URL.revokeObjectURL(this.cur.revoke); } catch { /* ignore */ }
    }
  }

  close() {
    if (!this.isOpen) return;
    this.isOpen = false;
    this.token++;
    this._release();
    this.cur = null;
    this.items = [];
    this.root.classList.remove('open');
    this.root.hidden = true;
    this.img.removeAttribute('src');
    this.app.refocusReader();
  }

  _showHint() {
    clearTimeout(this._hintT);
    this.hint.classList.add('show');
    this._hintT = setTimeout(() => this.hint.classList.remove('show'), 3200);
  }

  // ------------------------------------------------------------------ geometry

  _nat() {
    const w = this.img.naturalWidth || 1000;
    const h = this.img.naturalHeight || 750;
    return this.rot % 180 ? { w: h, h: w, w0: w, h0: h } : { w, h, w0: w, h0: h };
  }

  fitScale() {
    const W = Math.max(50, this.stage.clientWidth - 48);
    const H = Math.max(50, this.stage.clientHeight - 48);
    const { w, h } = this._nat();
    return Math.min(MAX_FIT_UP, W / w, H / h);
  }

  setFit() {
    this.fit = true;
    this.scale = this.fitScale();
    this.tx = 0;
    this.ty = 0;
    this.apply();
  }

  // open zoomed in: { x, y } (0..1 of the image) with { scale } relative to the natural size,
  // or a rectangle { x, y, w, h } (0..1) that should fill the window
  _focus(f) {
    const { w0, h0 } = this._nat();
    const W = Math.max(50, this.stage.clientWidth - 48);
    const H = Math.max(50, this.stage.clientHeight - 48);
    let s;
    let cx = f.x;
    let cy = f.y;
    if (f.w && f.h) {
      s = Math.min(W / (f.w * w0), H / (f.h * h0));
      cx = f.x + f.w / 2;
      cy = f.y + f.h / 2;
    } else {
      s = f.scale || this.fitScale() * 2.5;
    }
    this.scale = clamp(s, Math.min(MIN_SCALE, this.fitScale()), MAX_SCALE);
    this.fit = false;
    // move that point of the image to the middle of the window
    const dx = (cx - 0.5) * w0 * this.scale;
    const dy = (cy - 0.5) * h0 * this.scale;
    const r = (this.rot * Math.PI) / 180;
    this.tx = -(dx * Math.cos(r) - dy * Math.sin(r));
    this.ty = -(dx * Math.sin(r) + dy * Math.cos(r));
    this.apply();
  }

  setScale(s, at, resetPan) {
    const old = this.scale;
    this.scale = clamp(s, Math.min(MIN_SCALE, this.fitScale()), MAX_SCALE);
    this.fit = false;
    if (resetPan) { this.tx = 0; this.ty = 0; }
    if (at && !resetPan) {
      const r = this.stage.getBoundingClientRect();
      const cx = at.x - (r.left + r.width / 2);
      const cy = at.y - (r.top + r.height / 2);
      const k = this.scale / old;
      this.tx = cx - (cx - this.tx) * k;
      this.ty = cy - (cy - this.ty) * k;
    }
    this.apply();
  }

  zoomBy(f, at) {
    if (!at) {
      const r = this.stage.getBoundingClientRect();
      at = { x: r.left + r.width / 2, y: r.top + r.height / 2 };
    }
    this.setScale(this.scale * f, at);
  }

  rotate(deg = 90) {
    this.rot = (this.rot + deg + 360) % 360;
    if (this.fit) this.setFit();
    else this.apply();
  }

  apply() {
    const { w, h, w0, h0 } = this._nat();
    // keep part of the image on screen
    const SW = this.stage.clientWidth;
    const SH = this.stage.clientHeight;
    const mx = Math.max(0, (SW + w * this.scale) / 2 - Math.min(80, (w * this.scale) / 2));
    const my = Math.max(0, (SH + h * this.scale) / 2 - Math.min(80, (h * this.scale) / 2));
    this.tx = clamp(this.tx, -mx, mx);
    this.ty = clamp(this.ty, -my, my);
    this.img.style.width = w0 * this.scale + 'px';
    this.img.style.height = h0 * this.scale + 'px';
    this.img.style.transform = `translate(calc(-50% + ${this.tx}px), calc(-50% + ${this.ty}px)) rotate(${this.rot}deg)`;
    const dims = this.img.naturalWidth ? `${this.img.naturalWidth} × ${this.img.naturalHeight}` : '';
    this.zoomLabel.textContent = `${Math.round(this.scale * 100)}%`;
    this.zoomLabel.title = dims ? `图片尺寸 ${dims} 像素` : '';
  }

  // ------------------------------------------------------------------ actions

  action(a) {
    if (a === 'close') this.close();
    else if (a === 'fit') this.setFit();
    else if (a === 'orig') this.setScale(1, null, true);
    else if (a === 'in') this.zoomBy(1.25);
    else if (a === 'out') this.zoomBy(0.8);
    else if (a === 'rot') this.rotate(90);
    else if (a === 'prev') this.step(-1);
    else if (a === 'next') this.step(1);
    else if (a === 'copy') this.copyImage();
    else if (a === 'ai') this.explain();
    else if (a === 'save') this.saveImage();
  }

  step(d) {
    if (this.items.length > 1) this.show(this.index + d);
  }

  // the image as shown (rotation applied) at its own resolution
  async _canvasBlob() {
    const w0 = this.img.naturalWidth || 1000;
    const h0 = this.img.naturalHeight || 750;
    const k = Math.min(1, 8000 / Math.max(w0, h0));
    const w = Math.round(w0 * k);
    const h = Math.round(h0 * k);
    const c = document.createElement('canvas');
    const rot = this.rot % 180;
    c.width = rot ? h : w;
    c.height = rot ? w : h;
    const g = c.getContext('2d');
    g.fillStyle = '#fff';
    g.fillRect(0, 0, c.width, c.height);
    g.translate(c.width / 2, c.height / 2);
    g.rotate((this.rot * Math.PI) / 180);
    g.drawImage(this.img, -w / 2, -h / 2, w, h);
    return new Promise((res, rej) => c.toBlob((b) => (b ? res(b) : rej(new Error('无法生成图片'))), 'image/png'));
  }

  // the part of the picture on screen (natural pixels), or null when (almost) all of it is visible
  _visibleRect() {
    const ir = this.img.getBoundingClientRect();
    const sr = this.stage.getBoundingClientRect();
    const x0 = Math.max(ir.left, sr.left);
    const y0 = Math.max(ir.top, sr.top);
    const x1 = Math.min(ir.right, sr.right);
    const y1 = Math.min(ir.bottom, sr.bottom);
    if (x1 <= x0 || y1 <= y0 || !ir.width || !ir.height) return null;
    const nw = this.img.naturalWidth || 1000;
    const nh = this.img.naturalHeight || 750;
    const r = { x: ((x0 - ir.left) / ir.width) * nw, y: ((y0 - ir.top) / ir.height) * nh, w: ((x1 - x0) / ir.width) * nw, h: ((y1 - y0) / ir.height) * nh };
    return r.w * r.h < nw * nh * 0.95 ? r : null;
  }

  // JPEG of what is shown (the visible part when zoomed in), long side ≤ max
  regionDataUrl(max = 1600) {
    const nw = this.img.naturalWidth || 1000;
    const nh = this.img.naturalHeight || 750;
    let r = { x: 0, y: 0, w: nw, h: nh };
    if (!this.rot && !this.fit) r = this._visibleRect() || r;
    const k = Math.min(2, max / Math.max(r.w, r.h));
    const W = Math.max(1, Math.round(r.w * k));
    const H = Math.max(1, Math.round(r.h * k));
    const rot = this.rot % 180;
    const c = document.createElement('canvas');
    c.width = rot ? H : W;
    c.height = rot ? W : H;
    const g = c.getContext('2d');
    g.fillStyle = '#fff';
    g.fillRect(0, 0, c.width, c.height);
    g.translate(c.width / 2, c.height / 2);
    g.rotate((this.rot * Math.PI) / 180);
    g.drawImage(this.img, r.x, r.y, r.w, r.h, -W / 2, -H / 2, W, H);
    return c.toDataURL('image/jpeg', 0.9);
  }

  // ask the AI about the picture (or the zoomed-in part of it)
  explain() {
    if (this.img.hidden || !this.img.src) return;
    let dataUrl;
    try { dataUrl = this.regionDataUrl(); } catch (e) { toast('无法读取这张图片：' + e.message, { type: 'error' }); return; }
    const it = (this.cur && this.cur.item) || {};
    const caption = (this.cur && this.cur.caption) || it.caption || null;
    const title = (caption && (caption.en || caption.zh)) || it.title || it.alt || '';
    this.close();
    this.app.ai.askImage({ dataUrl, caption, title });
  }

  async copyImage() {
    if (this.img.hidden || !this.img.src) return;
    try {
      const blob = await this._canvasBlob();
      if (api.isElectron) await api.call('clipboardImage', await blobToDataUrl(blob));
      else await navigator.clipboard.write([new ClipboardItem({ 'image/png': blob })]);
      toast('已复制图片，可以粘贴到笔记或文档中');
    } catch (e) {
      toast('复制图片失败：' + e.message, { type: 'error' });
    }
  }

  async saveImage() {
    if (this.img.hidden || !this.img.src) return;
    try {
      let blob = null;
      const src = this.cur && this.cur.src;
      // the original file when possible (keeps its format and quality)
      if (!this.rot && src && !/^blob:|^data:/i.test(src)) {
        try { const r = await fetch(src); if (r.ok) blob = await r.blob(); } catch { blob = null; }
      }
      if (!blob || !/^image\//.test(blob.type)) blob = await this._canvasBlob();
      const ext = { 'image/jpeg': 'jpg', 'image/png': 'png', 'image/gif': 'gif', 'image/webp': 'webp', 'image/svg+xml': 'svg', 'image/bmp': 'bmp' }[blob.type] || 'png';
      const it = (this.cur && this.cur.item) || {};
      const base = String(it.name || (it.caption && it.caption.en) || it.title || it.alt || '图片').replace(/[\\/:*?"<>|\r\n]+/g, ' ').trim().slice(0, 60) || '图片';
      const name = base + '.' + ext;
      if (api.isElectron) {
        const file = await api.call('pickSave', name, [{ name: '图片', extensions: [ext] }]);
        if (!file) return;
        await api.call('saveImage', file, await blobToDataUrl(blob));
        toast('已保存：' + file);
      } else {
        const a = el('a', { href: URL.createObjectURL(blob), download: name });
        document.body.append(a);
        a.click();
        a.remove();
        setTimeout(() => URL.revokeObjectURL(a.href), 4000);
        toast('已保存：' + name);
      }
    } catch (e) {
      toast('保存图片失败：' + e.message, { type: 'error' });
    }
  }

  onKey(e) {
    if (!this.isOpen) return false;
    const k = e.key;
    const ctrl = e.ctrlKey || e.metaKey;
    if (k === 'Escape') this.close();
    else if (ctrl && (k === 'c' || k === 'C')) this.copyImage();
    else if (ctrl && (k === 's' || k === 'S')) this.saveImage();
    else if (ctrl) return true; // swallow other shortcuts while the viewer is open
    else if (k === 'a' || k === 'A') this.explain();
    else if (k === '+' || k === '=') this.zoomBy(1.25);
    else if (k === '-' || k === '_') this.zoomBy(0.8);
    else if (k === '0') this.setFit();
    else if (k === '1') this.setScale(1, null, true);
    else if (k === 'r' || k === 'R') this.rotate(e.shiftKey ? -90 : 90);
    else if (k === 'ArrowLeft' || k === 'PageUp') this.step(-1);
    else if (k === 'ArrowRight' || k === 'PageDown' || k === ' ') this.step(1);
    else if (k === 'ArrowUp' || k === 'ArrowDown') { this.ty += k === 'ArrowUp' ? 80 : -80; this.fit = false; this.apply(); }
    else return true;
    e.preventDefault();
    return true;
  }
}

function blobToDataUrl(blob) {
  return new Promise((res, rej) => {
    const r = new FileReader();
    r.onload = () => res(r.result);
    r.onerror = () => rej(r.error || new Error('读取图片失败'));
    r.readAsDataURL(blob);
  });
}
