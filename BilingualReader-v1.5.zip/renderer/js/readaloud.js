// Continuous read-aloud of the English text (边听边读): sentence by sentence from the reading position,
// the sentence (and the word, when the voice reports word boundaries) highlighted and kept in view.
// Works on books (EPUB / HTML, any display mode that shows English) and on PDF pages (text layer).
import { toast, clamp, sleep } from './util.js';
import { sentences } from './textlang.js';
import { icon } from './icons.js';

const SKIP = new Set(['script', 'style', 'noscript', 'template', 'math', 'svg', 'pre', 'rt', 'rp', 'img', 'video', 'audio', 'iframe', 'object', 'button', 'select', 'textarea', 'input']);
const BLOCKISH = /^(?:p|div|li|dd|dt|td|th|tr|h[1-6]|blockquote|figcaption|caption|section|article|aside|header|footer|table|ul|ol|dl|figure)$/;
// Chinese / Japanese / Korean characters, CJK punctuation and full-width forms
const CJK_RUN = /[⺀-⿿　-〿぀-ヿ㐀-䶿一-鿿가-힯豈-﫿︰-﹏＀-￯]+/g;

// footnote markers ("¹", "[3]") are not read
function isNoteRef(e) {
  if (e.localName === 'sup' && e.querySelector('a')) return true;
  if (e.localName === 'a') {
    const t = (e.getAttribute('epub:type') || '') + ' ' + (e.getAttribute('role') || '');
    if (/noteref/.test(t)) return true;
    if (e.parentElement && e.parentElement.localName === 'sup') return true;
  }
  return false;
}

// Plain text of an element with the text nodes it came from: { text, parts: [{ node, start }] }.
// Blocks, table cells and <br> are separated by a space; skipEl(el) leaves out an element.
export function indexText(root, skipEl) {
  const parts = [];
  let text = '';
  const sep = () => { if (text && !/\s$/.test(text)) text += ' '; };
  const walk = (n) => {
    for (let c = n.firstChild; c; c = c.nextSibling) {
      if (c.nodeType === 3) {
        if (!c.data) continue;
        parts.push({ node: c, start: text.length });
        text += c.data;
      } else if (c.nodeType === 1) {
        const tag = c.localName;
        if (tag === 'br') { sep(); continue; }
        if (SKIP.has(tag) || c.hidden || c.getAttribute('aria-hidden') === 'true' || (skipEl && skipEl(c))) continue;
        const block = BLOCKISH.test(tag);
        if (block) sep();
        walk(c);
        if (block) sep();
      }
    }
  };
  walk(root);
  return { text, parts };
}

// DOM position of character offset `off` of an indexed text (offsets between parts snap to a neighbour)
function domPos(idx, off, isEnd) {
  const ps = idx.parts;
  if (!ps.length) return null;
  let lo = 0;
  let hi = ps.length - 1;
  while (lo < hi) {
    const mid = (lo + hi + 1) >> 1;
    if (ps[mid].start <= off) lo = mid; else hi = mid - 1;
  }
  let p = ps[lo];
  let o = off - p.start;
  if (o > p.node.data.length) {
    // in the gap after this part
    if (isEnd || lo === ps.length - 1) o = p.node.data.length;
    else { p = ps[lo + 1]; o = 0; }
  }
  if (o < 0) o = 0;
  return { node: p.node, offset: Math.min(o, p.node.data.length) };
}

function makeRange(doc, idx, a, b) {
  const s = domPos(idx, a, false);
  const e = domPos(idx, b, true);
  if (!s || !e) return null;
  const r = doc.createRange();
  try {
    r.setStart(s.node, s.offset);
    r.setEnd(e.node, e.offset);
  } catch { return null; }
  return r;
}

// character offset in an indexed text of a DOM point (node + offset), or -1
function offsetOf(idx, node, offset) {
  if (!node) return -1;
  if (node.nodeType === 3) {
    const p = idx.parts.find((x) => x.node === node);
    return p ? p.start + Math.min(offset || 0, node.data.length) : -1;
  }
  const p = idx.parts.find((x) => node.contains(x.node));
  return p ? p.start : -1;
}

// English sentences of a text ({ start, end }); Chinese runs are left out
export function englishSentences(text) {
  const out = [];
  const runs = [];
  let last = 0;
  CJK_RUN.lastIndex = 0;
  let m;
  while ((m = CJK_RUN.exec(text))) {
    if (m.index > last) runs.push([last, m.index]);
    last = m.index + m[0].length;
  }
  if (last < text.length) runs.push([last, text.length]);
  for (const [a, b] of runs) {
    for (const s of sentences(text.slice(a, b), 'en')) {
      if (!/[A-Za-z]{2}/.test(s.text)) continue;
      out.push({ start: a + s.start, end: a + s.end });
    }
  }
  return out;
}

// What is said for a sentence: whitespace collapsed, soft hyphens dropped and (PDF) words hyphenated
// at a line end joined again. map[i] = offset in `text` of character i of `say`.
export function spoken(text, dehyphen) {
  let say = '';
  const map = [];
  for (let i = 0; i < text.length; i++) {
    const ch = text[i];
    if (ch === '­' || ch === '​') continue;
    if (/\s/.test(ch)) {
      if (say && say[say.length - 1] !== ' ') { say += ' '; map.push(i); }
      continue;
    }
    if (dehyphen && ch === '-' && /[a-z]/i.test(text[i - 1] || '')) {
      let j = i + 1;
      while (j < text.length && /\s/.test(text[j])) j++;
      if (j > i + 1 && /[a-z]/.test(text[j] || '') && !/^(?:and|or|nor|to)\b/.test(text.slice(j, j + 4))) { i = j - 1; continue; }
    }
    say += ch;
    map.push(i);
  }
  while (say.endsWith(' ')) { say = say.slice(0, -1); map.pop(); }
  return { say, map };
}

function sentenceList(idx, extra, dehyphen) {
  const out = [];
  for (const s of englishSentences(idx.text)) {
    const text = idx.text.slice(s.start, s.end);
    const { say, map } = spoken(text, dehyphen);
    if (!/[A-Za-z]{2}/.test(say)) continue;
    out.push({ ...extra, idx, start: s.start, end: s.end, text, say, map });
  }
  return out;
}

const firstRect = (r) => { const rs = r && r.getClientRects(); return rs && rs.length ? rs[0] : r ? r.getBoundingClientRect() : null; };

// ------------------------------------------------------------------------------------------ books
class FlowSource {
  constructor(view) {
    this.view = view;
    this.moving = false;
    this._sync();
  }

  _sync() { this.doc = this.view.doc; this.index = this.view.index; this.mode = this.view.effMode; }

  alive() { return !!this.doc && this.view.doc === this.doc && this.view.effMode === this.mode; }

  emptyMessage() {
    return this.view.effMode === 'zh' ? '现在是“中”模式，看不到英文原文。请切换到 双栏、上下 或 英 后再朗读。' : '这一章没有可以朗读的英文。';
  }

  _skip(e) { return e.classList.contains('br-ui') || e.classList.contains('br-img-broken') || e.classList.contains('br-chapter-nav') || isNoteRef(e); }

  build() {
    const doc = this.doc;
    if (!doc || !doc.body || this.view.effMode === 'zh') return [];
    // English blocks on screen (tables of figures and numbers are not read)
    const blocks = [...doc.querySelectorAll('[data-lang="en"]')]
      .filter((e) => !e.querySelector('[data-lang="en"]') && !e.closest('.br-ui, .br-chapter-nav, table') && e.getClientRects().length);
    const out = [];
    for (const b of blocks) {
      const idx = indexText(b, (e) => this._skip(e));
      for (const s of sentenceList(idx, { block: b }, false)) out.push(s);
    }
    out.forEach((s, k) => { s.k = k; });
    return out;
  }

  range(s, a = s.start, b = s.end) { return makeRange(this.doc, s.idx, a, b); }

  // index of the sentence at a DOM point (a Chinese cell maps to the English of its row), or -1
  indexAt(list, node, offset) {
    if (!node) return -1;
    const elx = node.nodeType === 1 ? node : node.parentElement;
    if (!elx) return -1;
    const blk = elx.closest('[data-lang]');
    if (blk && blk.dataset.lang === 'en') {
      const mine = list.filter((s) => s.block === blk || blk.contains(s.block) || s.block.contains(blk));
      if (mine.length) {
        const off = offsetOf(mine[0].idx, node, offset);
        const hit = off < 0 ? null : [...mine].reverse().find((s) => s.start <= off);
        return (hit || mine[0]).k;
      }
    }
    const row = elx.closest('.br-row');
    if (row) {
      const s = list.find((x) => row.contains(x.block));
      if (s) return s.k;
    }
    // the first sentence after the point
    const s = list.find((x) => x.block === elx || elx.contains(x.block) || (elx.compareDocumentPosition(x.block) & Node.DOCUMENT_POSITION_FOLLOWING));
    return s ? s.k : -1;
  }

  firstVisible(list) {
    const h = this.view.win.innerHeight;
    let lastBlock = null;
    for (const s of list) {
      if (s.block !== lastBlock) {
        lastBlock = s.block;
        const br = s.block.getBoundingClientRect();
        if (br.bottom < 8) continue;
      } else if (s.block.getBoundingClientRect().bottom < 8) continue;
      const r = firstRect(this.range(s));
      if (r && r.bottom > 8 && r.top < h) return s.k;
    }
    return 0;
  }

  async begin(from) {
    const list = this.build();
    let i = -1;
    if (from && from.node) i = this.indexAt(list, from.node, from.offset);
    if (i < 0) i = this.firstVisible(list);
    return { list, i: Math.max(0, i) };
  }

  show(s) {
    const r = this.range(s);
    if (!r) return;
    this.view.setHighlight('br-tts', [r]);
    this.view.setHighlight('br-tts-word', null);
    const rect = firstRect(r);
    const h = this.view.win.innerHeight;
    if (rect && (rect.top < 48 || rect.bottom > h - 90)) {
      this.view.userMoved = true;
      this.doc.scrollingElement.scrollBy({ top: rect.top - h * 0.3 });
    }
  }

  word(s, a, b) {
    if (!this.alive()) return;
    this.view.setHighlight('br-tts-word', a < 0 ? null : [this.range(s, a, b)].filter(Boolean));
  }

  clear() {
    if (this.view.doc !== this.doc || !this.doc) return;
    this.view.setHighlight('br-tts', null);
    this.view.setHighlight('br-tts-word', null);
  }

  // the chapter was shown again (display mode changed): the same sentence in the new page
  async reattach(old) {
    if (this.view.index !== this.index || !this.view.doc) return null;
    this._sync();
    const list = this.build();
    if (!list.length) return null;
    let best = -1;
    for (const s of list) if (old && s.text === old.text && (best < 0 || Math.abs(s.k - old.k) < Math.abs(best - old.k))) best = s.k;
    return { list, i: best >= 0 ? best : this.firstVisible(list) };
  }

  // next chapter with something to read
  async advance() {
    const v = this.view;
    for (let n = 0; n < 8; n++) {
      if (!v.book || v.index >= v.book.spine.length - 1) return null;
      this.moving = true;
      try { await v.show(v.index + 1, {}); } finally { this.moving = false; }
      this._sync();
      const list = this.build();
      if (list.length) return { list };
    }
    return null;
  }

  label(i, n) { return `${Math.min(i + 1, n)} / ${n} 句`; }
}

// ------------------------------------------------------------------------------------------ PDF
class PdfSource {
  constructor(view) {
    this.view = view;
    this.page = 0;
    this.layer = null;
    this.moving = false;
  }

  emptyMessage() { return '这一页没有可以朗读的英文（扫描版 PDF 没有文字层，无法朗读）。'; }

  alive() {
    const s = this.cur;
    return !!(this.layer && this.layer.isConnected && (!s || (s.idx.parts.length && s.idx.parts[0].node.isConnected)));
  }

  // text layer of page n (scrolls the page into view when it is not drawn yet); null when it has no text
  async layerFor(n, scroll) {
    const v = this.view;
    const pv = v.viewer && v.viewer.getPageView(n - 1);
    if (!pv) return null;
    const get = () => {
      const d = pv.div && pv.div.querySelector('.textLayer');
      return d && d.querySelector('span') ? d : null;
    };
    let d = get();
    if (d) return d;
    if (scroll) v.viewer.scrollPageIntoView({ pageNumber: n });
    const t0 = Date.now();
    while (!d && Date.now() - t0 < 6000) {
      await sleep(100);
      d = get();
      if (!d && pv.renderingState === 3 && Date.now() - t0 > 900) break; // drawn, but no text
    }
    return d;
  }

  build(n, layer) {
    this.page = n;
    this.layer = layer;
    if (!layer) return [];
    const L = layer.getBoundingClientRect();
    // running heads and page numbers in the top / bottom margin are not read
    const skip = (e) => {
      if (e.localName !== 'span' || e.firstElementChild || !L.height) return false;
      const r = e.getBoundingClientRect();
      if (!r.height) return false;
      const y = (r.top + r.height / 2 - L.top) / L.height;
      return y < 0.055 || y > 0.945;
    };
    const idx = indexText(layer, skip);
    const out = sentenceList(idx, { page: n }, true);
    out.forEach((s, k) => { s.k = k; });
    return out;
  }

  range(s, a = s.start, b = s.end) { return makeRange(document, s.idx, a, b); }

  async begin(from) {
    const v = this.view;
    const pageEl = from && from.node && (from.node.nodeType === 1 ? from.node : from.node.parentElement);
    const pg = pageEl && pageEl.closest && pageEl.closest('.page[data-page-number]');
    let n = (pg && +pg.dataset.pageNumber) || (from && from.page) || v.viewer.currentPageNumber || 1;
    let list = this.build(n, await this.layerFor(n, true));
    let i = -1;
    if (from && from.node) {
      const off = list.length ? offsetOf(list[0].idx, from.node, from.offset) : -1;
      if (off >= 0) { const s = [...list].reverse().find((x) => x.start <= off); i = s ? s.k : 0; }
    } else if (from && from.clientY != null) {
      i = list.findIndex((s) => { const r = firstRect(this.range(s)); return r && r.bottom >= from.clientY; });
    } else if (list.length) {
      const c = v.container.getBoundingClientRect();
      i = list.findIndex((s) => { const r = firstRect(this.range(s)); return r && r.bottom > c.top + 4; });
    }
    // nothing on this page (blank or picture page): the next pages
    for (let k = 0; !list.length && k < 4 && n < v.pages; k++) {
      n++;
      list = this.build(n, await this.layerFor(n, true));
      i = 0;
    }
    return { list, i: Math.max(0, i) };
  }

  show(s) {
    this.cur = s;
    const r = this.range(s);
    if (!r || !window.CSS || !CSS.highlights) return;
    CSS.highlights.set('br-tts', new Highlight(r));
    CSS.highlights.delete('br-tts-word');
    const rect = firstRect(r);
    const c = this.view.container.getBoundingClientRect();
    if (rect && (rect.top < c.top + 40 || rect.bottom > c.bottom - 90)) this.view.container.scrollBy({ top: rect.top - c.top - c.height * 0.3 });
  }

  word(s, a, b) {
    if (!window.CSS || !CSS.highlights) return;
    const r = a < 0 || !this.alive() ? null : this.range(s, a, b);
    if (r) CSS.highlights.set('br-tts-word', new Highlight(r));
    else CSS.highlights.delete('br-tts-word');
  }

  clear() {
    this.cur = null;
    if (!window.CSS || !CSS.highlights) return;
    CSS.highlights.delete('br-tts');
    CSS.highlights.delete('br-tts-word');
  }

  // the text layer was drawn again (zoom): the same sentence on the new layer
  async reattach(old) {
    if (!this.view.pdf) return null;
    const list = this.build(this.page, await this.layerFor(this.page, true));
    if (!list.length) return null;
    let best = -1;
    for (const s of list) if (old && s.text === old.text && (best < 0 || Math.abs(s.k - old.k) < Math.abs(best - old.k))) best = s.k;
    return { list, i: best >= 0 ? best : 0 };
  }

  async advance() {
    const v = this.view;
    let n = this.page;
    for (let k = 0; k < 6; k++) {
      if (!v.pdf || n >= v.pages) return null;
      n++;
      this.moving = true;
      let layer;
      try { layer = await this.layerFor(n, true); } finally { this.moving = false; }
      const list = this.build(n, layer);
      if (list.length) return { list };
    }
    return null;
  }

  label(i, n) { return `第 ${this.page} 页 · ${Math.min(i + 1, n)} / ${n} 句`; }
}

// ------------------------------------------------------------------------------------------ player
export class ReadAloud {
  constructor(app) {
    this.app = app;
    this.bar = document.getElementById('tts-bar');
    this.stateEl = this.bar.querySelector('.tts-state');
    this.rateEl = this.bar.querySelector('.tts-rate');
    this.active = false;
    this.paused = false;
    this.waiting = false;
    this.src = null;
    this.list = [];
    this.i = 0;
    this.tok = 0;
    this.bar.addEventListener('click', (e) => {
      const b = e.target.closest('[data-tts]');
      if (!b) return;
      const a = b.dataset.tts;
      if (a === 'toggle') this.paused ? this.resume() : this.pause();
      else if (a === 'prev') this.step(-1);
      else if (a === 'next') this.step(1);
      else if (a === 'slower') this.setRate(this.rate - 0.1);
      else if (a === 'faster') this.setRate(this.rate + 0.1);
      else if (a === 'shadow') this.setShadow(!this.shadow);
      else if (a === 'stop') this.stop();
    });
    this.bar.addEventListener('mousedown', (e) => { if (e.target.closest('button')) e.preventDefault(); }); // keep the reading focus
  }

  get synth() { return window.speechSynthesis || null; }
  get rate() { return clamp(+this.app.settings.ttsRate || 0.9, 0.5, 2); }
  get shadow() { return !!this.app.settings.ttsShadow; }

  toggle() { if (this.active) this.stop(); else this.start(); }

  // from: { node, offset } (a point in the book or PDF), { page, clientY } (PDF) or nothing (top of the view)
  async start(from) {
    const app = this.app;
    if (!app.book || !app.view) { toast('请先打开一本书'); return; }
    const synth = this.synth;
    if (!synth || typeof window.SpeechSynthesisUtterance !== 'function') { toast('系统不支持语音朗读'); return; }
    this.stop(true);
    const src = app.view === app.pdf ? new PdfSource(app.pdf) : new FlowSource(app.flow);
    const tok = ++this.tok;
    let r;
    try { r = await src.begin(from || null); } catch (e) { toast('无法朗读：' + e.message, { type: 'error' }); return; }
    if (tok !== this.tok) return;
    if (!r.list.length) { toast(src.emptyMessage(), { ms: 5000 }); return; }
    this.src = src;
    this.list = r.list;
    this.i = clamp(r.i, 0, r.list.length - 1);
    this.active = true;
    this.paused = false;
    this.bar.hidden = false;
    document.body.classList.add('tts-on');
    this.app.updateTtsButton();
    await this._voices();
    if (tok !== this.tok) return;
    this._speak();
  }

  // the voice list is filled asynchronously the first time
  async _voices() {
    const synth = this.synth;
    try {
      if (synth.getVoices().length) return;
      await new Promise((res) => {
        const t = setTimeout(res, 1200);
        synth.addEventListener('voiceschanged', () => { clearTimeout(t); res(); }, { once: true });
      });
    } catch { /* ignore */ }
  }

  stop(quiet) {
    ++this.tok;
    clearTimeout(this._wait);
    const was = this.active;
    this.active = false;
    this.paused = false;
    this.waiting = false;
    if (was) { try { this.synth && this.synth.cancel(); } catch { /* ignore */ } }
    if (this.src) { try { this.src.clear(); } catch { /* ignore */ } }
    this.src = null;
    this.list = [];
    this.cur = null;
    this.bar.hidden = true;
    document.body.classList.remove('tts-on');
    if (was) this.app.updateTtsButton();
    void quiet;
  }

  pause() {
    if (!this.active || this.paused) return;
    this.paused = true;
    this.waiting = false;
    ++this.tok;
    clearTimeout(this._wait);
    try { this.synth.cancel(); } catch { /* ignore */ }
    if (this.src && this.cur) this.src.word(this.cur, -1);
    this._renderBar();
  }

  resume() {
    if (!this.active) { this.start(); return; }
    if (!this.paused) return;
    this.paused = false;
    this._speak();
  }

  step(d) {
    if (!this.active) return;
    // during the shadowing pause the next sentence is already lined up
    const base = this.waiting && d > 0 ? this.i - 1 : this.i;
    this.waiting = false;
    this.i = clamp(base + d, 0, this.list.length); // past the end = next chapter / page
    if (this.paused) {
      if (this.i < this.list.length && this.src.alive()) { this.cur = this.list[this.i]; this.src.show(this.cur); }
      this._renderBar();
    } else this._speak();
  }

  setRate(v) {
    this.app.settings.ttsRate = Math.round(clamp(v, 0.5, 2) * 100) / 100;
    this.app.saveSettingsSoon();
    this._renderBar();
    if (this.active && !this.paused && !this.waiting) this._speak(); // say the sentence again at the new speed
  }

  setShadow(on) {
    this.app.settings.ttsShadow = !!on;
    this.app.saveSettingsSoon();
    this._renderBar();
    toast(on ? '跟读：每句读完停一会儿，跟着说一遍' : '已关闭跟读停顿', { ms: 1800 });
  }

  // the page changed under the reader (chapter shown again, another chapter opened by the user)
  onViewChanged() {
    if (!this.active || !this.src || this.src.moving) return;
    if (this.src.alive()) return;
    if (this.src instanceof FlowSource && this.app.flow.index !== this.src.index) {
      this.stop();
      this.app.flashStatus('已停止朗读');
      return;
    }
    if (!this.paused) this._speak();
  }

  _speak(delay = 40) {
    const tok = ++this.tok;
    this.waiting = false;
    clearTimeout(this._wait);
    try { this.synth.cancel(); } catch { /* ignore */ }
    // Chromium sometimes drops an utterance queued right after cancel()
    this._wait = setTimeout(() => { this._next(tok).catch((e) => { if (tok === this.tok) { this.stop(); toast('朗读出错：' + e.message, { type: 'error' }); } }); }, delay);
  }

  async _next(tok) {
    if (tok !== this.tok || !this.active || this.paused) return;
    const src = this.src;
    if (!src.alive()) {
      const r = await src.reattach(this.cur || this.list[this.i]);
      if (tok !== this.tok) return;
      if (!r) { this.stop(); this.app.flashStatus('已停止朗读'); return; }
      this.list = r.list;
      this.i = r.i;
    }
    while (this.i >= this.list.length) {
      this.stateEl.textContent = src instanceof PdfSource ? '翻页…' : '下一章…';
      const r = await src.advance();
      if (tok !== this.tok || !this.active) return;
      if (!r) { this.stop(); toast(src instanceof PdfSource ? '已读到最后一页' : '已读到全书末尾', { ms: 2500 }); return; }
      this.list = r.list;
      this.i = 0;
    }
    const s = this.list[this.i];
    this.cur = s;
    src.show(s);
    this._renderBar();
    const synth = this.synth;
    const u = new SpeechSynthesisUtterance(s.say);
    const v = this.app.pickVoice();
    if (v) { u.voice = v; u.lang = v.lang; } else u.lang = 'en-US';
    u.rate = this.rate;
    u.onboundary = (e) => {
      if (tok !== this.tok || (e.name && e.name !== 'word')) return;
      const ci = e.charIndex | 0;
      if (ci < 0 || ci >= s.map.length) return;
      let len = e.charLength | 0;
      if (!len) { const m = /^[\w'’.-]+/.exec(s.say.slice(ci)); len = m ? m[0].length : 1; }
      const a = s.start + s.map[ci];
      const b = s.start + s.map[Math.min(ci + len, s.map.length) - 1] + 1;
      src.word(s, a, b);
    };
    u.onend = () => {
      if (tok !== this.tok) return;
      src.word(s, -1);
      this.i++;
      if (this.shadow) {
        // shadowing: leave time to repeat the sentence aloud
        const t = ++this.tok;
        this.waiting = true;
        this._renderBar();
        const ms = clamp((s.say.length * 70) / this.rate, 1200, 9000);
        this._wait = setTimeout(() => { if (t === this.tok && this.active && !this.paused) this._speak(0); }, ms);
      } else this._speak(0);
    };
    u.onerror = (e) => {
      if (tok !== this.tok) return;
      const why = (e && e.error) || '';
      if (/interrupted|canceled/.test(why)) return;
      this.stop();
      toast('朗读出错' + (why ? '（' + why + '）' : '') + '。可在 设置 → 学习 → 朗读 换一个英文语音再试。', { type: 'error', ms: 6000 });
    };
    this.utt = u; // keep a reference: Chromium may otherwise drop the end event
    synth.speak(u);
  }

  _renderBar() {
    const b = this.bar;
    const tg = b.querySelector('[data-tts="toggle"]');
    tg.innerHTML = icon(this.paused ? 'play' : 'pause', 18);
    tg.title = this.paused ? '继续（从这一句开始）' : '暂停';
    b.classList.toggle('paused', this.paused);
    b.querySelector('[data-tts="shadow"]').classList.toggle('on', this.shadow);
    this.rateEl.textContent = this.rate.toFixed(2).replace(/0$/, '') + '×';
    const where = this.src ? this.src.label(this.i, this.list.length) : '';
    this.stateEl.textContent = this.paused ? '已暂停 · ' + where : this.waiting ? '跟读… · ' + where : where;
  }
}
